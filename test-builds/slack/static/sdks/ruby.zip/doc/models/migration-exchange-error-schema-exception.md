
# Migration Exchange Error Schema Exception

Schema for error response from migration.exchange method

*This model accepts additional fields of type Object.*

## Structure

`MigrationExchangeErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`MigrationExchangeErrorEnum`](../../doc/models/migration-exchange-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue MigrationExchangeErrorSchemaException => e
  puts "Caught MigrationExchangeErrorSchemaException: #{e.message}"
end
```



# Chat Me Message Error Schema Exception

Schema for error response from chat.meMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatMeMessageErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatMeMessageErrorEnum`](../../doc/models/chat-me-message-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ChatMeMessageErrorSchemaException => e
  puts "Caught ChatMeMessageErrorSchemaException: #{e.message}"
end
```



# Conversations Open Error Schema Exception

Schema for error response from conversations.open method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsOpenErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsOpenErrorEnum`](../../doc/models/conversations-open-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsOpenErrorSchemaException => e
  puts "Caught ConversationsOpenErrorSchemaException: #{e.message}"
end
```


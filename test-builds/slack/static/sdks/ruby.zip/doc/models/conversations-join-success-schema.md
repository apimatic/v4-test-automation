
# Conversations Join Success Schema

Schema for successful response from conversations.join method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsJoinSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `Object` | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `response_metadata` | [`ResponseMetadata3`](../../doc/models/response-metadata-3.md) | Optional | - |
| `warning` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
conversations_join_success_schema = ConversationsJoinSuccessSchema.new(
  channel: JSON.parse('{"key1":"val1","key2":"val2"}'),
  ok: 'True',
  response_metadata: ResponseMetadata3.new(
    warnings: [
      'warnings8',
      'warnings9',
      'warnings0'
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  warning: 'warning2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


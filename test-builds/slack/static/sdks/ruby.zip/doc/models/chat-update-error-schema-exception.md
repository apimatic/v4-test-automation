
# Chat Update Error Schema Exception

Schema for error response chat.update method

*This model accepts additional fields of type Object.*

## Structure

`ChatUpdateErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatUpdateErrorEnum`](../../doc/models/chat-update-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ChatUpdateErrorSchemaException => e
  puts "Caught ChatUpdateErrorSchemaException: #{e.message}"
end
```


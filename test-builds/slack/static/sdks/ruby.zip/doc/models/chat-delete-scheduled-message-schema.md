
# Chat Delete Scheduled Message Schema

Schema for successful response from chat.deleteScheduledMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatDeleteScheduledMessageSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
chat_delete_scheduled_message_schema = ChatDeleteScheduledMessageSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


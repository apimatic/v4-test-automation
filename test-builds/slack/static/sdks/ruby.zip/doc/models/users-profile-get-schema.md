
# Users Profile Get Schema

Schema for successful response from users.profile.get method

*This model accepts additional fields of type Object.*

## Structure

`UsersProfileGetSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `profile` | [`UserProfileObject`](../../doc/models/user-profile-object.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
users_profile_get_schema = UsersProfileGetSchema.new(
  ok: 'True',
  profile: UserProfileObject.new(
    avatar_hash: 'avatar_hash0',
    display_name: 'display_name0',
    display_name_normalized: 'display_name_normalized0',
    fields: [
      { 'key1' => 'val1', 'key2' => 'val2' }
    ],
    phone: 'phone0',
    real_name: 'real_name6',
    real_name_normalized: 'real_name_normalized6',
    skype: 'skype0',
    status_emoji: 'status_emoji4',
    status_text: 'status_text8',
    title: 'title6',
    always_active: false,
    api_app_id: 'api_app_id0',
    bot_id: 'bot_id6',
    email: 'email6',
    first_name: 'first_name0',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


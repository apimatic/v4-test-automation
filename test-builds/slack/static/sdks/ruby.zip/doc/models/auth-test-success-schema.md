
# Auth Test Success Schema

Schema for successful response auth.test method

*This model accepts additional fields of type Object.*

## Structure

`AuthTestSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bot_id` | `String` | Optional | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` |
| `is_enterprise_install` | `TrueClass \| FalseClass` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `team` | `String` | Required | - |
| `team_id` | `String` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `url` | `String` | Required | - |
| `user` | `String` | Required | - |
| `user_id` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
auth_test_success_schema = AuthTestSuccessSchema.new(
  ok: 'True',
  team: 'team4',
  team_id: 'team_id0',
  url: 'url0',
  user: 'user6',
  user_id: 'user_id4',
  bot_id: 'bot_id0',
  is_enterprise_install: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


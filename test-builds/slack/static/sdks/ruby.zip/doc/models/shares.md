
# Shares

*This model accepts additional fields of type Object.*

## Structure

`Shares`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `private` | `Object` | Optional | - |
| `public` | `Object` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
shares = Shares.new(
  private: JSON.parse('{"key1":"val1","key2":"val2"}'),
  public: JSON.parse('{"key1":"val1","key2":"val2"}'),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


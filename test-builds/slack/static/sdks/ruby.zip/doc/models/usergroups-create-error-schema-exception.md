
# Usergroups Create Error Schema Exception

Schema for error response from usergroups.create method

*This model accepts additional fields of type Object.*

## Structure

`UsergroupsCreateErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsCreateErrorEnum`](../../doc/models/usergroups-create-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsergroupsCreateErrorSchemaException => e
  puts "Caught UsergroupsCreateErrorSchemaException: #{e.message}"
end
```


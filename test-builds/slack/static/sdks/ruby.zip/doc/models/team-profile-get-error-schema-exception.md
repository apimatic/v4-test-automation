
# Team Profile Get Error Schema Exception

Schema for error response from team.profile.get method

*This model accepts additional fields of type Object.*

## Structure

`TeamProfileGetErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`TeamProfileGetErrorEnum`](../../doc/models/team-profile-get-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue TeamProfileGetErrorSchemaException => e
  puts "Caught TeamProfileGetErrorSchemaException: #{e.message}"
end
```


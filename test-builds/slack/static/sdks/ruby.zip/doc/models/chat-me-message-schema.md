
# Chat Me Message Schema

Schema for successful response from chat.meMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatMeMessageSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `String` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `ts` | `String` | Optional | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
chat_me_message_schema = ChatMeMessageSchema.new(
  ok: 'True',
  channel: 'channel8',
  ts: 'ts8',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


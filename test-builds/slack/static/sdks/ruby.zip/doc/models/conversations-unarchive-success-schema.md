
# Conversations Unarchive Success Schema

Schema for successful response from conversations.unarchive method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsUnarchiveSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
conversations_unarchive_success_schema = ConversationsUnarchiveSuccessSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


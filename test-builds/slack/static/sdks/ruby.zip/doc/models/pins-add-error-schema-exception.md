
# Pins Add Error Schema Exception

Schema for error response from pins.add method

*This model accepts additional fields of type Object.*

## Structure

`PinsAddErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`PinsAddErrorEnum`](../../doc/models/pins-add-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue PinsAddErrorSchemaException => e
  puts "Caught PinsAddErrorSchemaException: #{e.message}"
end
```


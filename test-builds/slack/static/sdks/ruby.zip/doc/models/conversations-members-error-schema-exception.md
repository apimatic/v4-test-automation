
# Conversations Members Error Schema Exception

Schema for error response conversations.members method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsMembersErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsMembersErrorEnum`](../../doc/models/conversations-members-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsMembersErrorSchemaException => e
  puts "Caught ConversationsMembersErrorSchemaException: #{e.message}"
end
```


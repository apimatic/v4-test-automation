
# Profile 1

*This model accepts additional fields of type Object.*

## Structure

`Profile1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `avatar_hash` | `String` | Required | **Constraints**: *Pattern*: `^[0-9a-f]{12}$` |
| `image_1024` | `String` | Required | - |
| `image_192` | `String` | Required | - |
| `image_24` | `String` | Required | - |
| `image_32` | `String` | Required | - |
| `image_48` | `String` | Required | - |
| `image_512` | `String` | Required | - |
| `image_72` | `String` | Required | - |
| `image_original` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
profile1 = Profile1.new(
  avatar_hash: 'avatar_hash2',
  image_1024: 'image_10248',
  image_192: 'image_1928',
  image_24: 'image_246',
  image_32: 'image_328',
  image_48: 'image_480',
  image_512: 'image_5122',
  image_72: 'image_726',
  image_original: 'image_original8',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


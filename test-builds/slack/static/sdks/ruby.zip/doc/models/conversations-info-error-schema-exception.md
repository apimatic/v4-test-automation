
# Conversations Info Error Schema Exception

Schema for error response from conversations.info method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsInfoErrorEnum`](../../doc/models/conversations-info-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsInfoErrorSchemaException => e
  puts "Caught ConversationsInfoErrorSchemaException: #{e.message}"
end
```



# Users Lookup by Email Error Schema Exception

Schema for error response from users.lookupByEmail method

*This model accepts additional fields of type Object.*

## Structure

`UsersLookupByEmailErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersLookupByEmailErrorEnum`](../../doc/models/users-lookup-by-email-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsersLookupByEmailErrorSchemaException => e
  puts "Caught UsersLookupByEmailErrorSchemaException: #{e.message}"
end
```


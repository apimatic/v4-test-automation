
# Conversations Rename Error Enum

## Enumeration

`ConversationsRenameErrorEnum`

## Fields

| Name |
|  --- |
| `USER_IS_RESTRICTED` |
| `METHOD_NOT_SUPPORTED_FOR_CHANNEL_TYPE` |
| `MISSING_SCOPE` |
| `CHANNEL_NOT_FOUND` |
| `NOT_IN_CHANNEL` |
| `NOT_AUTHORIZED` |
| `INVALID_NAME` |
| `NAME_TAKEN` |
| `INVALID_NAME_REQUIRED` |
| `INVALID_NAME_PUNCTUATION` |
| `INVALID_NAME_MAXLENGTH` |
| `INVALID_NAME_SPECIALS` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```ruby
conversations_rename_error_enum = ConversationsRenameErrorEnum::INVALID_NAME
```


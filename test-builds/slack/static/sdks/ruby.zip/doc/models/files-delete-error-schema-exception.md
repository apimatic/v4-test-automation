
# Files Delete Error Schema Exception

Schema for error response files.delete method

*This model accepts additional fields of type Object.*

## Structure

`FilesDeleteErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesDeleteErrorEnum`](../../doc/models/files-delete-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue FilesDeleteErrorSchemaException => e
  puts "Caught FilesDeleteErrorSchemaException: #{e.message}"
end
```


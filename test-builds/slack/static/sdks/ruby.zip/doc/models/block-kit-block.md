
# Block Kit Block

*This model accepts additional fields of type Object.*

## Structure

`BlockKitBlock`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
block_kit_block = BlockKitBlock.new(
  type: 'type8',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Conversations Replies Success Schema

Schema for successful response from conversations.replies method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsRepliesSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `has_more` | `TrueClass \| FalseClass` | Optional | - |
| `messages` | `Array[Object]` | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
conversations_replies_success_schema = ConversationsRepliesSuccessSchema.new(
  messages: [
    JSON.parse('{"key1":"val1","key2":"val2"}'),
    JSON.parse('{"key1":"val1","key2":"val2"}'),
    JSON.parse('{"key1":"val1","key2":"val2"}')
  ],
  ok: 'True',
  has_more: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


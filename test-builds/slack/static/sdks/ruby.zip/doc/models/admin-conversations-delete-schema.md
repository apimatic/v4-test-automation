
# Admin Conversations Delete Schema

Schema for successful response of admin.conversations.delete

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsDeleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
admin_conversations_delete_schema = AdminConversationsDeleteSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Attachment

*This model accepts additional fields of type Object.*

## Structure

`Attachment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fallback` | `String` | Optional | - |
| `id` | `Integer` | Required | - |
| `image_bytes` | `Integer` | Optional | - |
| `image_height` | `Integer` | Optional | - |
| `image_url` | `String` | Optional | - |
| `image_width` | `Integer` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
attachment = Attachment.new(
  id: 248,
  fallback: 'fallback6',
  image_bytes: 78,
  image_height: 110,
  image_url: 'image_url4',
  image_width: 236,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Api Test Success Schema

Schema for successful response api.test method

*This model accepts additional fields of type Object.*

## Structure

`ApiTestSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
api_test_success_schema = ApiTestSuccessSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => { 'key1' => 'val1', 'key2' => 'val2' }
  }
)
```



# Users Conversations Error Schema Exception

Schema for error response from users.conversations method

*This model accepts additional fields of type Object.*

## Structure

`UsersConversationsErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersConversationsErrorEnum`](../../doc/models/users-conversations-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsersConversationsErrorSchemaException => e
  puts "Caught UsersConversationsErrorSchemaException: #{e.message}"
end
```


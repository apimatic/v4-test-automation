
# Reminders Complete Error Schema Exception

Schema for error response from reminders.complete method

*This model accepts additional fields of type Object.*

## Structure

`RemindersCompleteErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RemindersCompleteErrorEnum`](../../doc/models/reminders-complete-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue RemindersCompleteErrorSchemaException => e
  puts "Caught RemindersCompleteErrorSchemaException: #{e.message}"
end
```


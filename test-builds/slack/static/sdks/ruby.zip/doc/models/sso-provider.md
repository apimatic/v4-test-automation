
# Sso Provider

*This model accepts additional fields of type Object.*

## Structure

`SsoProvider`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | `String` | Optional | - |
| `name` | `String` | Optional | - |
| `type` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
sso_provider = SsoProvider.new(
  label: 'label6',
  name: 'name6',
  type: 'type4',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Reactions List Error Schema Exception

Schema for error response from reactions.list method

*This model accepts additional fields of type Object.*

## Structure

`ReactionsListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ReactionsListErrorEnum`](../../doc/models/reactions-list-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ReactionsListErrorSchemaException => e
  puts "Caught ReactionsListErrorSchemaException: #{e.message}"
end
```



# Apps Permissions Request Schema

Schema for successful response from apps.permissions.request method

*This model accepts additional fields of type Object.*

## Structure

`AppsPermissionsRequestSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
apps_permissions_request_schema = AppsPermissionsRequestSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


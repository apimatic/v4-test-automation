
# Chat Delete Error Schema Exception

Schema for error response from chat.delete method

*This model accepts additional fields of type Object.*

## Structure

`ChatDeleteErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatDeleteErrorEnum`](../../doc/models/chat-delete-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ChatDeleteErrorSchemaException => e
  puts "Caught ChatDeleteErrorSchemaException: #{e.message}"
end
```


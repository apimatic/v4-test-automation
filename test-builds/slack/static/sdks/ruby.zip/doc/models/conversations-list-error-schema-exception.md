
# Conversations List Error Schema Exception

Schema for error response from conversations.list method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsListErrorEnum`](../../doc/models/conversations-list-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsListErrorSchemaException => e
  puts "Caught ConversationsListErrorSchemaException: #{e.message}"
end
```



# Admin Conversations Set Conversation Prefs Schema

Schema for successful response of admin.conversations.setConversationPrefs

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsSetConversationPrefsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
admin_conversations_set_conversation_prefs_schema = AdminConversationsSetConversationPrefsSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


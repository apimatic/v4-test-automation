
# Users Profile Set Error Schema Exception

Schema for error response from users.profile.set method

*This model accepts additional fields of type Object.*

## Structure

`UsersProfileSetErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersProfileSetErrorEnum`](../../doc/models/users-profile-set-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsersProfileSetErrorSchemaException => e
  puts "Caught UsersProfileSetErrorSchemaException: #{e.message}"
end
```


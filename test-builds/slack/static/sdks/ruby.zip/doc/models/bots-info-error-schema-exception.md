
# Bots Info Error Schema Exception

Schema for error response from bots.info method

*This model accepts additional fields of type Object.*

## Structure

`BotsInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`BotsInfoErrorEnum`](../../doc/models/bots-info-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue BotsInfoErrorSchemaException => e
  puts "Caught BotsInfoErrorSchemaException: #{e.message}"
end
```


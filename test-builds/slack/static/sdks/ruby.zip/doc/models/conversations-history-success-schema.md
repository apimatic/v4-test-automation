
# Conversations History Success Schema

Schema for successful response from conversations.history method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsHistorySuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel_actions_count` | `Integer` | Required | - |
| `channel_actions_ts` | `Object` | Required | - |
| `has_more` | `TrueClass \| FalseClass` | Required | - |
| `messages` | [`Array[MessageObject]`](../../doc/models/message-object.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `pin_count` | `Integer` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
conversations_history_success_schema = ConversationsHistorySuccessSchema.new(
  channel_actions_count: 96,
  channel_actions_ts: JSON.parse('{"key1":"val1","key2":"val2"}'),
  has_more: false,
  messages: [
    MessageObject.new(
      text: 'text8',
      ts: 'ts0',
      type: 'type8',
      attachments: [
        Attachment.new(
          id: 36,
          fallback: 'fallback4',
          image_bytes: 34,
          image_height: 154,
          image_url: 'image_url6',
          image_width: 24,
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        Attachment.new(
          id: 36,
          fallback: 'fallback4',
          image_bytes: 34,
          image_height: 154,
          image_url: 'image_url6',
          image_width: 24,
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      blocks: [
        BlockKitBlock.new(
          type: 'type4',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        BlockKitBlock.new(
          type: 'type4',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      bot_id: JSON.parse('{"key1":"val1","key2":"val2"}'),
      bot_profile: BotProfileObject.new(
        app_id: 'app_id8',
        deleted: false,
        icons: Icons.new(
          image_36: 'image_362',
          image_48: 'image_488',
          image_72: 'image_722',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        id: 'id8',
        name: 'name8',
        team_id: 'team_id8',
        updated: 44,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      client_msg_id: 'client_msg_id4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  ok: 'True',
  pin_count: 162,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


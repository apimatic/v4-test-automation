
# Errors Is Returned when an Error Associates an User

*This model accepts additional fields of type Object.*

## Structure

`ErrorsIsReturnedWhenAnErrorAssociatesAnUser`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`ConversationsInviteErrorEnum`](../../doc/models/conversations-invite-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `user` | `String` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
errors_is_returned_when_an_error_associates_an_user = ErrorsIsReturnedWhenAnErrorAssociatesAnUser.new(
  error: ConversationsInviteErrorEnum::USER_IS_BOT,
  ok: 'False',
  user: 'user8',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


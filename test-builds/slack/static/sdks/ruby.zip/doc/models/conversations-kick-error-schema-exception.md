
# Conversations Kick Error Schema Exception

Schema for error response conversations.kick method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsKickErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsKickErrorEnum`](../../doc/models/conversations-kick-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsKickErrorSchemaException => e
  puts "Caught ConversationsKickErrorSchemaException: #{e.message}"
end
```



# Chat Post Ephemeral Error Enum

## Enumeration

`ChatPostEphemeralErrorEnum`

## Fields

| Name |
|  --- |
| `CHANNEL_NOT_FOUND` |
| `IS_ARCHIVED` |
| `MSG_TOO_LONG` |
| `NO_TEXT` |
| `RESTRICTED_ACTION` |
| `TOO_MANY_ATTACHMENTS` |
| `USER_NOT_IN_CHANNEL` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```ruby
chat_post_ephemeral_error_enum = ChatPostEphemeralErrorEnum::TOKEN_REVOKED
```



# Chat Update Error Enum

## Enumeration

`ChatUpdateErrorEnum`

## Fields

| Name |
|  --- |
| `MESSAGE_NOT_FOUND` |
| `CANT_UPDATE_MESSAGE` |
| `CHANNEL_NOT_FOUND` |
| `EDIT_WINDOW_CLOSED` |
| `MSG_TOO_LONG` |
| `TOO_MANY_ATTACHMENTS` |
| `RATE_LIMITED` |
| `NO_TEXT` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `REQUEST_TIMEOUT` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |
| `IS_INACTIVE` |

## Example

```ruby
chat_update_error_enum = ChatUpdateErrorEnum::MISSING_POST_TYPE
```



# Reactions Remove Error Schema Exception

Schema for error response from reactions.remove method

*This model accepts additional fields of type Object.*

## Structure

`ReactionsRemoveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ReactionsRemoveErrorEnum`](../../doc/models/reactions-remove-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ReactionsRemoveErrorSchemaException => e
  puts "Caught ReactionsRemoveErrorSchemaException: #{e.message}"
end
```


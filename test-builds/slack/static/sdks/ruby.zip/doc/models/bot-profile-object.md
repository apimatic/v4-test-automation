
# Bot Profile Object

*This model accepts additional fields of type Object.*

## Structure

`BotProfileObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` |
| `deleted` | `TrueClass \| FalseClass` | Required | - |
| `icons` | [`Icons`](../../doc/models/icons.md) | Required | - |
| `id` | `String` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` |
| `name` | `String` | Required | - |
| `team_id` | `String` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `updated` | `Integer` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
bot_profile_object = BotProfileObject.new(
  app_id: 'app_id2',
  deleted: false,
  icons: Icons.new(
    image_36: 'image_362',
    image_48: 'image_488',
    image_72: 'image_722',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  id: 'id4',
  name: 'name4',
  team_id: 'team_id8',
  updated: 42,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


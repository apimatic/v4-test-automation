
# Reactions Get Error Enum

## Enumeration

`ReactionsGetErrorEnum`

## Fields

| Name |
|  --- |
| `BAD_TIMESTAMP` |
| `FILE_NOT_FOUND` |
| `FILE_COMMENT_NOT_FOUND` |
| `MESSAGE_NOT_FOUND` |
| `NO_ITEM_SPECIFIED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```ruby
reactions_get_error_enum = ReactionsGetErrorEnum::INVALID_CHARSET
```



# Team Info Schema

Schema for successful response from team.info method

*This model accepts additional fields of type Object.*

## Structure

`TeamInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `team` | [`TeamObject`](../../doc/models/team-object.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
team_info_schema = TeamInfoSchema.new(
  ok: 'True',
  team: TeamObject.new(
    domain: 'domain6',
    email_domain: 'email_domain0',
    icon: ObjsIcon.new(
      image_102: 'image_1020',
      image_132: 'image_1326',
      image_230: 'image_2308',
      image_34: 'image_340',
      image_44: 'image_440',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    id: 'id0',
    name: 'name0',
    archived: false,
    avatar_base_url: 'avatar_base_url0',
    created: 212,
    date_create: 62,
    deleted: false,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


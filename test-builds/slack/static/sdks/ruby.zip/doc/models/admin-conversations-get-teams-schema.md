
# Admin Conversations Get Teams Schema

Schema for successful response of admin.conversations.getTeams

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsGetTeamsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `response_metadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - |
| `team_ids` | `Array[String]` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
admin_conversations_get_teams_schema = AdminConversationsGetTeamsSchema.new(
  ok: 'True',
  team_ids: [
    'team_ids5',
    'team_ids6',
    'team_ids7'
  ],
  response_metadata: ResponseMetadata.new(
    next_cursor: 'next_cursor2',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


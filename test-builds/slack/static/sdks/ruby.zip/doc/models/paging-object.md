
# Paging Object

*This model accepts additional fields of type Object.*

## Structure

`PagingObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `Integer` | Optional | - |
| `page` | `Integer` | Required | - |
| `pages` | `Integer` | Optional | - |
| `per_page` | `Integer` | Optional | - |
| `spill` | `Integer` | Optional | - |
| `total` | `Integer` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
paging_object = PagingObject.new(
  page: 0,
  total: 236,
  count: 30,
  pages: 124,
  per_page: 168,
  spill: 220,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


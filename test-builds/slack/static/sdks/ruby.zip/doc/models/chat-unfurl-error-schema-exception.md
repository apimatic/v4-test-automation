
# Chat Unfurl Error Schema Exception

Schema for error response from chat.unfurl method

*This model accepts additional fields of type Object.*

## Structure

`ChatUnfurlErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatUnfurlErrorEnum`](../../doc/models/chat-unfurl-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ChatUnfurlErrorSchemaException => e
  puts "Caught ChatUnfurlErrorSchemaException: #{e.message}"
end
```


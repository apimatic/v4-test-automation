
# Reaction Object

*This model accepts additional fields of type Object.*

## Structure

`ReactionObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `Integer` | Required | - |
| `name` | `String` | Required | - |
| `users` | `Array[String]` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
reaction_object = ReactionObject.new(
  count: 146,
  name: 'name4',
  users: [
    'users9',
    'users0',
    'users1'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


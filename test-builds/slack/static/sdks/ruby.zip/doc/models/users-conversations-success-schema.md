
# Users Conversations Success Schema

Schema for successful response from users.conversations method. Returned conversation objects do not include `num_members` or `is_member`

*This model accepts additional fields of type Object.*

## Structure

`UsersConversationsSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channels` | `Array[Object]` | Required | **Constraints**: *Unique Items Required* |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `response_metadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
users_conversations_success_schema = UsersConversationsSuccessSchema.new(
  channels: [
    JSON.parse('{"key1":"val1","key2":"val2"}')
  ],
  ok: 'True',
  response_metadata: ResponseMetadata.new(
    next_cursor: 'next_cursor2',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


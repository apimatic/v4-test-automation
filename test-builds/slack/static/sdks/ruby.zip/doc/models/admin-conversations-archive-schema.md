
# Admin Conversations Archive Schema

Schema for successful response of admin.conversations.archive

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsArchiveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
admin_conversations_archive_schema = AdminConversationsArchiveSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


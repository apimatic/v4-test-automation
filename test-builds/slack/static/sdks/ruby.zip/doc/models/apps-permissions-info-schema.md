
# Apps Permissions Info Schema

Schema for successful response from apps.permissions.info method

*This model accepts additional fields of type Object.*

## Structure

`AppsPermissionsInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `info` | [`Info`](../../doc/models/info.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
apps_permissions_info_schema = AppsPermissionsInfoSchema.new(
  info: Info.new(
    app_home: AppHome.new(
      resources: ResourcesInInfoFromAppsPermissionsInfo.new(
        ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        excluded_ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        wildcard: false,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      scopes: [
        'scopes4',
        'scopes3',
        'scopes2'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    channel: Channel.new(
      resources: ResourcesInInfoFromAppsPermissionsInfo.new(
        ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        excluded_ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        wildcard: false,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      scopes: [
        'scopes2',
        'scopes1'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    group: Group.new(
      resources: ResourcesInInfoFromAppsPermissionsInfo.new(
        ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        excluded_ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        wildcard: false,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      scopes: [
        'scopes4'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    im: Im.new(
      resources: ResourcesInInfoFromAppsPermissionsInfo.new(
        ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        excluded_ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        wildcard: false,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      scopes: [
        'scopes0',
        'scopes9',
        'scopes8'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    mpim: Mpim.new(
      resources: ResourcesInInfoFromAppsPermissionsInfo.new(
        ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        excluded_ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        wildcard: false,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      scopes: [
        'scopes6'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    team: Team.new(
      resources: ResourcesInInfoFromAppsPermissionsInfo.new(
        ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        excluded_ids: [
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}'),
          JSON.parse('{"key1":"val1","key2":"val2"}')
        ],
        wildcard: false,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      scopes: [
        'scopes6',
        'scopes5',
        'scopes4'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


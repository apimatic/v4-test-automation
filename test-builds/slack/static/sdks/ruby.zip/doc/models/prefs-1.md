
# Prefs 1

*This model accepts additional fields of type Object.*

## Structure

`Prefs1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `can_thread` | [`CanThread`](../../doc/models/can-thread.md) | Optional | - |
| `who_can_post` | [`WhoCanPost`](../../doc/models/who-can-post.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
prefs1 = Prefs1.new(
  can_thread: CanThread.new(
    type: [
      'type1',
      'type0'
    ],
    user: [
      'user6',
      'user7'
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  who_can_post: WhoCanPost.new(
    type: [
      'type5',
      'type4'
    ],
    user: [
      'user0',
      'user1'
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


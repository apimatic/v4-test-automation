
# Prefs

*This model accepts additional fields of type Object.*

## Structure

`Prefs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channels` | `Array[String]` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` |
| `groups` | `Array[String]` | Required | **Constraints**: *Pattern*: `^[G][A-Z0-9]{8,}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
prefs = Prefs.new(
  channels: [
    'channels5',
    'channels4'
  ],
  groups: [
    'groups4',
    'groups5',
    'groups6'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


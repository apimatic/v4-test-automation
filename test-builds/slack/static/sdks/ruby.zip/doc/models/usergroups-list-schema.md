
# Usergroups List Schema

Schema for successful response from usergroups.list method

*This model accepts additional fields of type Object.*

## Structure

`UsergroupsListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `usergroups` | [`Array[SubteamUsergroupObject]`](../../doc/models/subteam-usergroup-object.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
usergroups_list_schema = UsergroupsListSchema.new(
  ok: 'True',
  usergroups: [
    SubteamUsergroupObject.new(
      auto_provision: false,
      auto_type: JSON.parse('{"key1":"val1","key2":"val2"}'),
      created_by: 'created_by8',
      date_create: 66,
      date_delete: 114,
      date_update: 100,
      deleted_by: JSON.parse('{"key1":"val1","key2":"val2"}'),
      description: 'description6',
      enterprise_subteam_id: 'enterprise_subteam_id2',
      handle: 'handle0',
      id: 'id4',
      is_external: false,
      is_subteam: false,
      is_usergroup: false,
      name: 'name4',
      prefs: Prefs.new(
        channels: [
          'channels5',
          'channels4'
        ],
        groups: [
          'groups4',
          'groups5',
          'groups6'
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      team_id: 'team_id2',
      updated_by: 'updated_by8',
      channel_count: 222,
      user_count: 28,
      users: [
        'users9'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


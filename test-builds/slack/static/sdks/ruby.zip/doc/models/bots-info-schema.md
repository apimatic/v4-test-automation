
# Bots Info Schema

Schema for successful response from bots.info method

*This model accepts additional fields of type Object.*

## Structure

`BotsInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bot` | [`Bot`](../../doc/models/bot.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
bots_info_schema = BotsInfoSchema.new(
  bot: Bot.new(
    app_id: 'app_id0',
    deleted: false,
    icons: Icons.new(
      image_36: 'image_362',
      image_48: 'image_488',
      image_72: 'image_722',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    id: 'id6',
    name: 'name6',
    updated: 214,
    user_id: 'user_id4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Reminders Delete Error Schema Exception

Schema for error response from reminders.delete method

*This model accepts additional fields of type Object.*

## Structure

`RemindersDeleteErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RemindersDeleteErrorEnum`](../../doc/models/reminders-delete-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue RemindersDeleteErrorSchemaException => e
  puts "Caught RemindersDeleteErrorSchemaException: #{e.message}"
end
```


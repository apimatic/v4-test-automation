
# Files Comments Delete Error Schema Exception

Schema for error response files.comments.delete method

*This model accepts additional fields of type Object.*

## Structure

`FilesCommentsDeleteErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesCommentsDeleteErrorEnum`](../../doc/models/files-comments-delete-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue FilesCommentsDeleteErrorSchemaException => e
  puts "Caught FilesCommentsDeleteErrorSchemaException: #{e.message}"
end
```


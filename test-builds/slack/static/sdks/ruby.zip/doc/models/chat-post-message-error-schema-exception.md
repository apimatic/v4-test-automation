
# Chat Post Message Error Schema Exception

Schema for error response chat.postMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatPostMessageErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatPostMessageErrorEnum`](../../doc/models/chat-post-message-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ChatPostMessageErrorSchemaException => e
  puts "Caught ChatPostMessageErrorSchemaException: #{e.message}"
end
```


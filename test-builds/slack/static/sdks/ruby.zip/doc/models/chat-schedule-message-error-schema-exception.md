
# Chat Schedule Message Error Schema Exception

Schema for error response chat.scheduleMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatScheduleMessageErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatScheduleMessageErrorEnum`](../../doc/models/chat-schedule-message-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ChatScheduleMessageErrorSchemaException => e
  puts "Caught ChatScheduleMessageErrorSchemaException: #{e.message}"
end
```


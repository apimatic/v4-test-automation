
# Users Info Success Schema

Schema for successful response from users.info method

*This model accepts additional fields of type Object.*

## Structure

`UsersInfoSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `user` | `Object` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
users_info_success_schema = UsersInfoSuccessSchema.new(
  ok: 'True',
  user: JSON.parse('{"key1":"val1","key2":"val2"}'),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


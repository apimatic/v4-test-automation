
# Auth Test Error Schema Exception

Schema for error response auth.test method

*This model accepts additional fields of type Object.*

## Structure

`AuthTestErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AuthTestErrorEnum`](../../doc/models/auth-test-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue AuthTestErrorSchemaException => e
  puts "Caught AuthTestErrorSchemaException: #{e.message}"
end
```


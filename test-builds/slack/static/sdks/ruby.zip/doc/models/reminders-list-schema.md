
# Reminders List Schema

Schema for successful response from reminders.list method

*This model accepts additional fields of type Object.*

## Structure

`RemindersListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `reminders` | [`Array[ObjsReminder]`](../../doc/models/objs-reminder.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
reminders_list_schema = RemindersListSchema.new(
  ok: 'True',
  reminders: [
    ObjsReminder.new(
      creator: 'creator0',
      id: 'id2',
      recurring: false,
      text: 'text2',
      user: 'user2',
      complete_ts: 28,
      time: 186,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


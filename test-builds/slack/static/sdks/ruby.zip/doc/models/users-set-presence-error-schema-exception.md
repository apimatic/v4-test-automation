
# Users Set Presence Error Schema Exception

Schema for error response from users.setPresence method

*This model accepts additional fields of type Object.*

## Structure

`UsersSetPresenceErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersSetPresenceErrorEnum`](../../doc/models/users-set-presence-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsersSetPresenceErrorSchemaException => e
  puts "Caught UsersSetPresenceErrorSchemaException: #{e.message}"
end
```


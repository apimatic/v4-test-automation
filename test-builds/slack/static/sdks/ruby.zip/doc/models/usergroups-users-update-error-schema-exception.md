
# Usergroups Users Update Error Schema Exception

Schema for error response from usergroups.users.update method

*This model accepts additional fields of type Object.*

## Structure

`UsergroupsUsersUpdateErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsUpdateErrorEnum`](../../doc/models/usergroups-update-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsergroupsUsersUpdateErrorSchemaException => e
  puts "Caught UsergroupsUsersUpdateErrorSchemaException: #{e.message}"
end
```



# Chat Update Success Schema

Schema for successful response of chat.update method

*This model accepts additional fields of type Object.*

## Structure

`ChatUpdateSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `String` | Required | - |
| `message` | [`MessageObject1`](../../doc/models/message-object-1.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `text` | `String` | Required | - |
| `ts` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
chat_update_success_schema = ChatUpdateSuccessSchema.new(
  channel: 'channel2',
  message: MessageObject1.new(
    text: 'text0',
    attachments: [
      { 'key1' => 'val1', 'key2' => 'val2' },
      { 'key1' => 'val1', 'key2' => 'val2' }
    ],
    blocks: { 'key1' => 'val1', 'key2' => 'val2' },
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  ok: 'True',
  text: 'text8',
  ts: 'ts4',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


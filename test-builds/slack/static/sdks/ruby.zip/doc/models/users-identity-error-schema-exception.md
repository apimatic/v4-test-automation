
# Users Identity Error Schema Exception

Schema for error response from users.identity method

*This model accepts additional fields of type Object.*

## Structure

`UsersIdentityErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsInfoErrorEnum`](../../doc/models/apps-permissions-info-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsersIdentityErrorSchemaException => e
  puts "Caught UsersIdentityErrorSchemaException: #{e.message}"
end
```


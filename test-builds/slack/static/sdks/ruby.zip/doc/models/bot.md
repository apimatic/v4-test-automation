
# Bot

*This model accepts additional fields of type Object.*

## Structure

`Bot`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` |
| `deleted` | `TrueClass \| FalseClass` | Required | - |
| `icons` | [`Icons`](../../doc/models/icons.md) | Required | - |
| `id` | `String` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` |
| `name` | `String` | Required | - |
| `updated` | `Integer` | Required | - |
| `user_id` | `String` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
bot = Bot.new(
  app_id: 'app_id0',
  deleted: false,
  icons: Icons.new(
    image_36: 'image_362',
    image_48: 'image_488',
    image_72: 'image_722',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  id: 'id6',
  name: 'name6',
  updated: 214,
  user_id: 'user_id4',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


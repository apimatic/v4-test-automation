
# Stars Remove Error Schema Exception

Schema for error response from stars.remove method

*This model accepts additional fields of type Object.*

## Structure

`StarsRemoveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`StarsRemoveErrorEnum`](../../doc/models/stars-remove-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue StarsRemoveErrorSchemaException => e
  puts "Caught StarsRemoveErrorSchemaException: #{e.message}"
end
```


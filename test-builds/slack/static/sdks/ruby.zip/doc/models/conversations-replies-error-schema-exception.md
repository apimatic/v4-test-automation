
# Conversations Replies Error Schema Exception

Schema for error response from conversations.replies method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsRepliesErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsRepliesErrorEnum`](../../doc/models/conversations-replies-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsRepliesErrorSchemaException => e
  puts "Caught ConversationsRepliesErrorSchemaException: #{e.message}"
end
```



# Message

*This model accepts additional fields of type Object.*

## Structure

`Message`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bot_id` | `String` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` |
| `bot_profile` | [`BotProfileObject`](../../doc/models/bot-profile-object.md) | Optional | - |
| `team` | `String` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `text` | `String` | Required | - |
| `type` | `String` | Required | - |
| `user` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `username` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
message = Message.new(
  bot_id: 'bot_id6',
  team: 'team0',
  text: 'text0',
  type: 'type0',
  user: 'user0',
  bot_profile: BotProfileObject.new(
    app_id: 'app_id8',
    deleted: false,
    icons: Icons.new(
      image_36: 'image_362',
      image_48: 'image_488',
      image_72: 'image_722',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    id: 'id8',
    name: 'name8',
    team_id: 'team_id8',
    updated: 44,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  username: 'username0',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


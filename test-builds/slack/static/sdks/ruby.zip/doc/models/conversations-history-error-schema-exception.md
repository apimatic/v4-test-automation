
# Conversations History Error Schema Exception

Schema for error response from conversations.history method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsHistoryErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsHistoryErrorEnum`](../../doc/models/conversations-history-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsHistoryErrorSchemaException => e
  puts "Caught ConversationsHistoryErrorSchemaException: #{e.message}"
end
```


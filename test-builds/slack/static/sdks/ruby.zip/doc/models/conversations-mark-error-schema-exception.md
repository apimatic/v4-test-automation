
# Conversations Mark Error Schema Exception

Schema for error response from conversations.mark method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsMarkErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsMarkErrorEnum`](../../doc/models/conversations-mark-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsMarkErrorSchemaException => e
  puts "Caught ConversationsMarkErrorSchemaException: #{e.message}"
end
```


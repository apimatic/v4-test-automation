
# Icons 1

*This model accepts additional fields of type Object.*

## Structure

`Icons1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `emoji` | `String` | Optional | - |
| `image_64` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
icons1 = Icons1.new(
  emoji: 'emoji4',
  image_64: 'image_646',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Conversations Mark Success Schema

Schema for successful response conversations.mark method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsMarkSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
conversations_mark_success_schema = ConversationsMarkSuccessSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


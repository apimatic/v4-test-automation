
# Users Delete Photo Schema

Schema for successful response from users.deletePhoto method

*This model accepts additional fields of type Object.*

## Structure

`UsersDeletePhotoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
users_delete_photo_schema = UsersDeletePhotoSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


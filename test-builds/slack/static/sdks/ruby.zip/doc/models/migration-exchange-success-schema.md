
# Migration Exchange Success Schema

Schema for successful response from migration.exchange method

*This model accepts additional fields of type Object.*

## Structure

`MigrationExchangeSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enterprise_id` | `String` | Required | - |
| `invalid_user_ids` | `Array[String]` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `team_id` | `String` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `user_id_map` | `Object` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
migration_exchange_success_schema = MigrationExchangeSuccessSchema.new(
  enterprise_id: 'enterprise_id6',
  ok: 'True',
  team_id: 'team_id0',
  invalid_user_ids: [
    'invalid_user_ids4'
  ],
  user_id_map: { 'key1' => 'val1', 'key2' => 'val2' },
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


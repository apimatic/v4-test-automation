
# Apps Uninstall Error Schema Exception

Schema for error response from apps.uninstall method

*This model accepts additional fields of type Object.*

## Structure

`AppsUninstallErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsUninstallErrorEnum`](../../doc/models/apps-uninstall-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue AppsUninstallErrorSchemaException => e
  puts "Caught AppsUninstallErrorSchemaException: #{e.message}"
end
```


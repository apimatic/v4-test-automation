
# Profile

*This model accepts additional fields of type Object.*

## Structure

`Profile`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fields` | [`Array[ObjsTeamProfileField]`](../../doc/models/objs-team-profile-field.md) | Required | **Constraints**: *Unique Items Required* |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
profile = Profile.new(
  fields: [
    ObjsTeamProfileField.new(
      hint: 'hint8',
      id: 'id8',
      label: 'label8',
      ordering: 158.68,
      type: Type::OPTIONS_LIST,
      field_name: 'field_name2',
      is_hidden: false,
      options: JSON.parse('{"key1":"val1","key2":"val2"}'),
      possible_values: [
        'possible_values9',
        'possible_values0'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


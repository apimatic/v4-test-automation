
# External Org Migrations

*This model accepts additional fields of type Object.*

## Structure

`ExternalOrgMigrations`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `current` | [`Array[Current]`](../../doc/models/current.md) | Required | - |
| `date_updated` | `Integer` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
external_org_migrations = ExternalOrgMigrations.new(
  current: [
    Current.new(
      date_started: 84,
      team_id: 'team_id0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  date_updated: 206,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


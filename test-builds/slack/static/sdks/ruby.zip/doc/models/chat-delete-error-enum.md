
# Chat Delete Error Enum

## Enumeration

`ChatDeleteErrorEnum`

## Fields

| Name |
|  --- |
| `MESSAGE_NOT_FOUND` |
| `CHANNEL_NOT_FOUND` |
| `CANT_DELETE_MESSAGE` |
| `COMPLIANCE_EXPORTS_PREVENT_DELETION` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```ruby
chat_delete_error_enum = ChatDeleteErrorEnum::NO_PERMISSION
```


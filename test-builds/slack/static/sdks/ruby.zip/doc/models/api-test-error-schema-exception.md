
# Api Test Error Schema Exception

Schema for error response api.test method

*This model accepts additional fields of type Object.*

## Structure

`ApiTestErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `String` | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ApiTestErrorSchemaException => e
  puts "Caught ApiTestErrorSchemaException: #{e.message}"
end
```


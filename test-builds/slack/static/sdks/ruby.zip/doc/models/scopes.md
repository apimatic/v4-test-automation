
# Scopes

*This model accepts additional fields of type Object.*

## Structure

`Scopes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_home` | `Array[String]` | Optional | - |
| `channel` | `Array[String]` | Optional | - |
| `group` | `Array[String]` | Optional | - |
| `im` | `Array[String]` | Optional | - |
| `mpim` | `Array[String]` | Optional | - |
| `team` | `Array[String]` | Optional | - |
| `user` | `Array[String]` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
scopes = Scopes.new(
  app_home: [
    'app_home0',
    'app_home1',
    'app_home2'
  ],
  channel: [
    'channel2',
    'channel1'
  ],
  group: [
    'group1'
  ],
  im: [
    'im1',
    'im2',
    'im3'
  ],
  mpim: [
    'mpim2'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Reminders List Error Schema Exception

Schema for error response from reminders.list method

*This model accepts additional fields of type Object.*

## Structure

`RemindersListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsInfoErrorEnum`](../../doc/models/apps-permissions-info-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue RemindersListErrorSchemaException => e
  puts "Caught RemindersListErrorSchemaException: #{e.message}"
end
```


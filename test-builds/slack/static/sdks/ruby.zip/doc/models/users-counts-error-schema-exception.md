
# Users Counts Error Schema Exception

Schema for error response users.getPresence method

*This model accepts additional fields of type Object.*

## Structure

`UsersCountsErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `String` | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsersCountsErrorSchemaException => e
  puts "Caught UsersCountsErrorSchemaException: #{e.message}"
end
```



# Conversations Rename Error Schema Exception

Schema for error response from conversations.rename method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsRenameErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsRenameErrorEnum`](../../doc/models/conversations-rename-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsRenameErrorSchemaException => e
  puts "Caught ConversationsRenameErrorSchemaException: #{e.message}"
end
```


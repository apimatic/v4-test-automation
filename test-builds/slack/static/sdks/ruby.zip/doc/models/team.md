
# Team

*This model accepts additional fields of type Object.*

## Structure

`Team`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resources` | [`ResourcesInInfoFromAppsPermissionsInfo`](../../doc/models/resources-in-info-from-apps-permissions-info.md) | Required | - |
| `scopes` | `Array[String]` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
team = Team.new(
  resources: ResourcesInInfoFromAppsPermissionsInfo.new(
    ids: [
      JSON.parse('{"key1":"val1","key2":"val2"}'),
      JSON.parse('{"key1":"val1","key2":"val2"}'),
      JSON.parse('{"key1":"val1","key2":"val2"}')
    ],
    excluded_ids: [
      JSON.parse('{"key1":"val1","key2":"val2"}'),
      JSON.parse('{"key1":"val1","key2":"val2"}'),
      JSON.parse('{"key1":"val1","key2":"val2"}')
    ],
    wildcard: false,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  scopes: [
    'scopes6',
    'scopes5',
    'scopes4'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Users List Error Enum

## Enumeration

`UsersListErrorEnum`

## Fields

| Name |
|  --- |
| `LIMIT_REQUIRED` |
| `INVALID_CURSOR` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```ruby
users_list_error_enum = UsersListErrorEnum::TEAM_ADDED_TO_ORG
```


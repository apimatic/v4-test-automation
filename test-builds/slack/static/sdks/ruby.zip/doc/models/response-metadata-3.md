
# Response Metadata 3

*This model accepts additional fields of type Object.*

## Structure

`ResponseMetadata3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `warnings` | `Array[String]` | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
response_metadata3 = ResponseMetadata3.new(
  warnings: [
    'warnings4'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Files Comments Delete Error Enum

## Enumeration

`FilesCommentsDeleteErrorEnum`

## Fields

| Name |
|  --- |
| `CANT_DELETE` |
| `COMMENT_NOT_FOUND` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```ruby
files_comments_delete_error_enum = FilesCommentsDeleteErrorEnum::INVALID_JSON
```



# Plan

## Enumeration

`Plan`

## Fields

| Name |
|  --- |
| `STD` |
| `PLUS` |
| `COMPLIANCE` |
| `ENTERPRISE` |

## Example

```ruby
plan = Plan::COMPLIANCE
```


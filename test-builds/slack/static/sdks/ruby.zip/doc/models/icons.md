
# Icons

*This model accepts additional fields of type Object.*

## Structure

`Icons`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image_36` | `String` | Required | - |
| `image_48` | `String` | Required | - |
| `image_72` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
icons = Icons.new(
  image_36: 'image_362',
  image_48: 'image_488',
  image_72: 'image_722',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


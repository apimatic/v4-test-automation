
# Conversations List Error Enum

## Enumeration

`ConversationsListErrorEnum`

## Fields

| Name |
|  --- |
| `MISSING_SCOPE` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```ruby
conversations_list_error_enum = ConversationsListErrorEnum::INVALID_CHARSET
```



# Can Thread

*This model accepts additional fields of type Object.*

## Structure

`CanThread`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `Array[String]` | Optional | - |
| `user` | `Array[String]` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
can_thread = CanThread.new(
  type: [
    'type1',
    'type0'
  ],
  user: [
    'user6',
    'user7'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


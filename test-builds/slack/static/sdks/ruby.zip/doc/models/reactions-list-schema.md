
# Reactions List Schema

Schema for successful response from reactions.list method

*This model accepts additional fields of type Object.*

## Structure

`ReactionsListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `items` | `Array[Object]` | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Optional | - |
| `response_metadata` | `Object` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
reactions_list_schema = ReactionsListSchema.new(
  items: [
    JSON.parse('{"key1":"val1","key2":"val2"}'),
    JSON.parse('{"key1":"val1","key2":"val2"}')
  ],
  ok: 'True',
  paging: PagingObject.new(
    page: 26,
    total: 6,
    count: 56,
    pages: 150,
    per_page: 194,
    spill: 246,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  response_metadata: JSON.parse('{"key1":"val1","key2":"val2"}'),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


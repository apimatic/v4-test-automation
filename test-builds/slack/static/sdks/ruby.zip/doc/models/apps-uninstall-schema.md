
# Apps Uninstall Schema

Schema for successful response from apps.uninstall method

*This model accepts additional fields of type Object.*

## Structure

`AppsUninstallSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
apps_uninstall_schema = AppsUninstallSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Admin Conversations Disconnect Shared Error Schema Exception

Schema for error response from admin.conversations.disconnectShared

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsDisconnectSharedErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsDisconnectSharedErrorEnum`](../../doc/models/admin-conversations-disconnect-shared-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue AdminConversationsDisconnectSharedErrorSchemaException => e
  puts "Caught AdminConversationsDisconnectSharedErrorSchemaException: #{e.message}"
end
```


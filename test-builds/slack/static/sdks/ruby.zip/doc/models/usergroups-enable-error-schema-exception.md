
# Usergroups Enable Error Schema Exception

Schema for error response from usergroups.enable method

*This model accepts additional fields of type Object.*

## Structure

`UsergroupsEnableErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsEnableErrorEnum`](../../doc/models/usergroups-enable-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsergroupsEnableErrorSchemaException => e
  puts "Caught UsergroupsEnableErrorSchemaException: #{e.message}"
end
```


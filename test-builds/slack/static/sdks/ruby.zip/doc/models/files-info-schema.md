
# Files Info Schema

Schema for successful response from files.info method

*This model accepts additional fields of type Object.*

## Structure

`FilesInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `comments` | `Array[Object]` | Required | - |
| `content_html` | `String` | Optional | - |
| `editor` | `String` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `file` | [`FileObject`](../../doc/models/file-object.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Optional | - |
| `response_metadata` | `Object` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
files_info_schema = FilesInfoSchema.new(
  comments: [
    JSON.parse('{"key1":"val1","key2":"val2"}')
  ],
  file: FileObject.new(
    channels: [
      'channels5',
      'channels4'
    ],
    comments_count: 56,
    created: 220,
    date_delete: 118,
    display_as_bot: false,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  ok: 'True',
  content_html: 'content_html6',
  editor: 'editor2',
  paging: PagingObject.new(
    page: 26,
    total: 6,
    count: 56,
    pages: 150,
    per_page: 194,
    spill: 246,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  response_metadata: JSON.parse('{"key1":"val1","key2":"val2"}'),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Current

*This model accepts additional fields of type Object.*

## Structure

`Current`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date_started` | `Integer` | Required | - |
| `team_id` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
current = Current.new(
  date_started: 84,
  team_id: 'team_id0',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


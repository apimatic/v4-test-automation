
# Apps Permissions Request Error Schema Exception

Schema for error response from apps.permissions.request method

*This model accepts additional fields of type Object.*

## Structure

`AppsPermissionsRequestErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsRequestErrorEnum`](../../doc/models/apps-permissions-request-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue AppsPermissionsRequestErrorSchemaException => e
  puts "Caught AppsPermissionsRequestErrorSchemaException: #{e.message}"
end
```


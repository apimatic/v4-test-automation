
# Users List Error Schema Exception

Schema for error response from users.list method

*This model accepts additional fields of type Object.*

## Structure

`UsersListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersListErrorEnum`](../../doc/models/users-list-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsersListErrorSchemaException => e
  puts "Caught UsersListErrorSchemaException: #{e.message}"
end
```


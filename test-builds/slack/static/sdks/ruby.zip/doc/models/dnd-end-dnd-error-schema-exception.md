
# Dnd End Dnd Error Schema Exception

Schema for error response from dnd.endDnd method

*This model accepts additional fields of type Object.*

## Structure

`DndEndDndErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndEndDndErrorEnum`](../../doc/models/dnd-end-dnd-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue DndEndDndErrorSchemaException => e
  puts "Caught DndEndDndErrorSchemaException: #{e.message}"
end
```


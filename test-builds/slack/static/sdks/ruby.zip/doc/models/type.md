
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `TEXT` |
| `DATE` |
| `LINK` |
| `MAILTO` |
| `OPTIONS_LIST` |
| `USER` |

## Example

```ruby
type = Type::LINK
```


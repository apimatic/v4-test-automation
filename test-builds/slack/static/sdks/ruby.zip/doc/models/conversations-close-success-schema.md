
# Conversations Close Success Schema

Schema for successful response conversations.close method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsCloseSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `already_closed` | `TrueClass \| FalseClass` | Optional | - |
| `no_op` | `TrueClass \| FalseClass` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
conversations_close_success_schema = ConversationsCloseSuccessSchema.new(
  ok: 'True',
  already_closed: false,
  no_op: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Users Profile Get Error Schema Exception

Schema for error response from users.profile.get method

*This model accepts additional fields of type Object.*

## Structure

`UsersProfileGetErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersProfileGetErrorEnum`](../../doc/models/users-profile-get-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsersProfileGetErrorSchemaException => e
  puts "Caught UsersProfileGetErrorSchemaException: #{e.message}"
end
```


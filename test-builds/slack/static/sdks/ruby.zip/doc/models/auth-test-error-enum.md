
# Auth Test Error Enum

## Enumeration

`AuthTestErrorEnum`

## Fields

| Name |
|  --- |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `TOKEN_REVOKED` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```ruby
auth_test_error_enum = AuthTestErrorEnum::INVALID_CHARSET
```


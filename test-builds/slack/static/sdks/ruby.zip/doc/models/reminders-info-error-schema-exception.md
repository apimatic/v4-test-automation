
# Reminders Info Error Schema Exception

Schema for error response from reminders.info method

*This model accepts additional fields of type Object.*

## Structure

`RemindersInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RemindersDeleteErrorEnum`](../../doc/models/reminders-delete-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue RemindersInfoErrorSchemaException => e
  puts "Caught RemindersInfoErrorSchemaException: #{e.message}"
end
```


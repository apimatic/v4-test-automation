
# Dnd End Dnd Schema

Schema for successful response from dnd.endDnd method

*This model accepts additional fields of type Object.*

## Structure

`DndEndDndSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
dnd_end_dnd_schema = DndEndDndSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


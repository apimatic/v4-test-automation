
# Rtm Connect Error Schema Exception

Schema for error response from rtm.connect method

*This model accepts additional fields of type Object.*

## Structure

`RtmConnectErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RtmConnectErrorEnum`](../../doc/models/rtm-connect-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue RtmConnectErrorSchemaException => e
  puts "Caught RtmConnectErrorSchemaException: #{e.message}"
end
```


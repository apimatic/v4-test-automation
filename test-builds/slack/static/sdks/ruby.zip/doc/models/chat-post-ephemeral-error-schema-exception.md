
# Chat Post Ephemeral Error Schema Exception

Schema for error response from chat.postEphemeral method

*This model accepts additional fields of type Object.*

## Structure

`ChatPostEphemeralErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatPostEphemeralErrorEnum`](../../doc/models/chat-post-ephemeral-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ChatPostEphemeralErrorSchemaException => e
  puts "Caught ChatPostEphemeralErrorSchemaException: #{e.message}"
end
```


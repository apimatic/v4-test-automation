
# Objs Primary Owner

*This model accepts additional fields of type Object.*

## Structure

`ObjsPrimaryOwner`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `String` | Required | - |
| `id` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
objs_primary_owner = ObjsPrimaryOwner.new(
  email: 'email0',
  id: 'id6',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Reactions Get Error Schema Exception

Schema for error response from reactions.get method

*This model accepts additional fields of type Object.*

## Structure

`ReactionsGetErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ReactionsGetErrorEnum`](../../doc/models/reactions-get-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ReactionsGetErrorSchemaException => e
  puts "Caught ReactionsGetErrorSchemaException: #{e.message}"
end
```


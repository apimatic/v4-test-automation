
# Admin Conversations Unarchive Schema

Schema for successful response of admin.conversations.unarchive

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsUnarchiveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
admin_conversations_unarchive_schema = AdminConversationsUnarchiveSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


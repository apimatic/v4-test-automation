
# Conversations Create Success Schema

Schema for successful response conversations.create method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsCreateSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `Object` | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
conversations_create_success_schema = ConversationsCreateSuccessSchema.new(
  channel: JSON.parse('{"key1":"val1","key2":"val2"}'),
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Conversations Unarchive Error Schema Exception

Schema for error response from conversations.unarchive method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsUnarchiveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsUnarchiveErrorEnum`](../../doc/models/conversations-unarchive-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsUnarchiveErrorSchemaException => e
  puts "Caught ConversationsUnarchiveErrorSchemaException: #{e.message}"
end
```


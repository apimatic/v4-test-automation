
# Who Can Post

*This model accepts additional fields of type Object.*

## Structure

`WhoCanPost`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `Array[String]` | Optional | - |
| `user` | `Array[String]` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
who_can_post = WhoCanPost.new(
  type: [
    'type5',
    'type4'
  ],
  user: [
    'user0',
    'user1'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


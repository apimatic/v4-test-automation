
# Chat Unfurl Success Schema

Schema for successful response from chat.unfurl method

*This model accepts additional fields of type Object.*

## Structure

`ChatUnfurlSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
chat_unfurl_success_schema = ChatUnfurlSuccessSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


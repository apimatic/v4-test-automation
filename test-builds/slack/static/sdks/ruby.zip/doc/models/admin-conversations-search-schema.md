
# Admin Conversations Search Schema

Schema for successful response of admin.conversations.search

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsSearchSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channels` | [`Array[ChannelObject]`](../../doc/models/channel-object.md) | Required | - |
| `next_cursor` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
admin_conversations_search_schema = AdminConversationsSearchSchema.new(
  channels: [
    ChannelObject.new(
      created: 90,
      creator: 'creator8',
      id: 'id0',
      is_channel: false,
      is_mpim: false,
      is_org_shared: false,
      is_private: false,
      is_shared: false,
      members: [
        'members8'
      ],
      name: 'name0',
      name_normalized: 'name_normalized8',
      purpose: Purpose.new(
        creator: 'creator4',
        last_set: 30,
        value: 'value8',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      topic: Topic.new(
        creator: 'creator6',
        last_set: 242,
        value: 'value0',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      accepted_user: 'accepted_user8',
      is_archived: false,
      is_frozen: false,
      is_general: false,
      is_member: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  next_cursor: 'next_cursor6',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


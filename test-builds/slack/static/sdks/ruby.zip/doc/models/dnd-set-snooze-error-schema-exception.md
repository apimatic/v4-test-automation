
# Dnd Set Snooze Error Schema Exception

Schema for error response from dnd.setSnooze method

*This model accepts additional fields of type Object.*

## Structure

`DndSetSnoozeErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndSetSnoozeErrorEnum`](../../doc/models/dnd-set-snooze-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue DndSetSnoozeErrorSchemaException => e
  puts "Caught DndSetSnoozeErrorSchemaException: #{e.message}"
end
```


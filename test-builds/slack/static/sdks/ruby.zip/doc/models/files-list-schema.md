
# Files List Schema

Schema for successful response from files.list method

*This model accepts additional fields of type Object.*

## Structure

`FilesListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `files` | [`Array[FileObject]`](../../doc/models/file-object.md) | Required | **Constraints**: *Minimum Items*: `0`, *Unique Items Required* |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
files_list_schema = FilesListSchema.new(
  files: [
    FileObject.new(
      channels: [
        'channels9'
      ],
      comments_count: 150,
      created: 58,
      date_delete: 212,
      display_as_bot: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  ok: 'True',
  paging: PagingObject.new(
    page: 26,
    total: 6,
    count: 56,
    pages: 150,
    per_page: 194,
    spill: 246,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


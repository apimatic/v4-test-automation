
# Reminders Add Error Schema Exception

Schema for error response from reminders.add method

*This model accepts additional fields of type Object.*

## Structure

`RemindersAddErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RemindersAddErrorEnum`](../../doc/models/reminders-add-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue RemindersAddErrorSchemaException => e
  puts "Caught RemindersAddErrorSchemaException: #{e.message}"
end
```


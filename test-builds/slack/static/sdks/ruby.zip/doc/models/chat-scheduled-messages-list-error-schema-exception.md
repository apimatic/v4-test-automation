
# Chat Scheduled Messages List Error Schema Exception

Schema for error response from chat.scheduledMessages.list method

*This model accepts additional fields of type Object.*

## Structure

`ChatScheduledMessagesListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatScheduledMessagesListErrorEnum`](../../doc/models/chat-scheduled-messages-list-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ChatScheduledMessagesListErrorSchemaException => e
  puts "Caught ChatScheduledMessagesListErrorSchemaException: #{e.message}"
end
```



# Files Comments Delete Schema

Schema for successful response files.comments.delete method

*This model accepts additional fields of type Object.*

## Structure

`FilesCommentsDeleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
files_comments_delete_schema = FilesCommentsDeleteSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


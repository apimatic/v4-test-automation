
# Dialog Open Error Schema Exception

Schema for error response from dialog.open method

*This model accepts additional fields of type Object.*

## Structure

`DialogOpenErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DialogOpenErrorEnum`](../../doc/models/dialog-open-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue DialogOpenErrorSchemaException => e
  puts "Caught DialogOpenErrorSchemaException: #{e.message}"
end
```


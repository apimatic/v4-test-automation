
# Usergroups Disable Error Schema Exception

Schema for error response from usergroups.disable method

*This model accepts additional fields of type Object.*

## Structure

`UsergroupsDisableErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsCreateErrorEnum`](../../doc/models/usergroups-create-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsergroupsDisableErrorSchemaException => e
  puts "Caught UsergroupsDisableErrorSchemaException: #{e.message}"
end
```


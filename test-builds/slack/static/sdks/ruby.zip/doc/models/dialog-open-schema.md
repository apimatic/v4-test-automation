
# Dialog Open Schema

Schema for successful response from dialog.open method

*This model accepts additional fields of type Object.*

## Structure

`DialogOpenSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
dialog_open_schema = DialogOpenSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


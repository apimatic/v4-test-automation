
# Pins Remove Error Enum

## Enumeration

`PinsRemoveErrorEnum`

## Fields

| Name |
|  --- |
| `BAD_TIMESTAMP` |
| `FILE_NOT_FOUND` |
| `FILE_COMMENT_NOT_FOUND` |
| `MESSAGE_NOT_FOUND` |
| `NO_ITEM_SPECIFIED` |
| `NOT_PINNED` |
| `PERMISSION_DENIED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYP` |
| `MISSING_POST_TYP` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOU` |
| `UPGRADE_REQUIRED` |

## Example

```ruby
pins_remove_error_enum = PinsRemoveErrorEnum::NO_PERMISSION
```


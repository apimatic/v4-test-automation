
# Users Set Presence Schema

Schema for successful response from users.setPresence method

*This model accepts additional fields of type Object.*

## Structure

`UsersSetPresenceSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
users_set_presence_schema = UsersSetPresenceSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Conversations Leave Error Schema Exception

Schema for error response from conversations.leave method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsLeaveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsLeaveErrorEnum`](../../doc/models/conversations-leave-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsLeaveErrorSchemaException => e
  puts "Caught ConversationsLeaveErrorSchemaException: #{e.message}"
end
```


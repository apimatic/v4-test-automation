
# Apps Permissions Resources List Error Schema Exception

Schema for error response from apps.permissions.resources.list method

*This model accepts additional fields of type Object.*

## Structure

`AppsPermissionsResourcesListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsResourcesListErrorEnum`](../../doc/models/apps-permissions-resources-list-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue AppsPermissionsResourcesListErrorSchemaException => e
  puts "Caught AppsPermissionsResourcesListErrorSchemaException: #{e.message}"
end
```


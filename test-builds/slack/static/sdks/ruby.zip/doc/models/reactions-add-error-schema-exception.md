
# Reactions Add Error Schema Exception

Schema for error response from reactions.add method

*This model accepts additional fields of type Object.*

## Structure

`ReactionsAddErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ReactionsAddErrorEnum`](../../doc/models/reactions-add-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ReactionsAddErrorSchemaException => e
  puts "Caught ReactionsAddErrorSchemaException: #{e.message}"
end
```


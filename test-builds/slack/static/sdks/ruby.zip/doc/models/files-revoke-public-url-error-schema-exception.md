
# Files Revoke Public Url Error Schema Exception

Schema for error response from files.revokePublicURL method

*This model accepts additional fields of type Object.*

## Structure

`FilesRevokePublicUrlErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesRevokePublicUrlErrorEnum`](../../doc/models/files-revoke-public-url-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue FilesRevokePublicUrlErrorSchemaException => e
  puts "Caught FilesRevokePublicUrlErrorSchemaException: #{e.message}"
end
```


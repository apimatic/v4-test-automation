
# Reminders Add Error Enum

## Enumeration

`RemindersAddErrorEnum`

## Fields

| Name |
|  --- |
| `CANNOT_PARSE` |
| `USER_NOT_FOUND` |
| `CANNOT_ADD_BOT` |
| `CANNOT_ADD_SLACKBOT` |
| `CANNOT_ADD_OTHERS` |
| `CANNOT_ADD_OTHERS_RECURRING` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `USER_IS_BOT` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```ruby
reminders_add_error_enum = RemindersAddErrorEnum::INVALID_ARRAY_ARG
```


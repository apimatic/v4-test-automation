
# Chat Post Message Success Schema

Schema for successful response of chat.postMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatPostMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `String` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `message` | [`MessageObject`](../../doc/models/message-object.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `ts` | `String` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
chat_post_message_success_schema = ChatPostMessageSuccessSchema.new(
  channel: 'channel0',
  message: MessageObject.new(
    text: 'text0',
    ts: 'ts2',
    type: 'type0',
    attachments: [
      Attachment.new(
        id: 36,
        fallback: 'fallback4',
        image_bytes: 34,
        image_height: 154,
        image_url: 'image_url6',
        image_width: 24,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      Attachment.new(
        id: 36,
        fallback: 'fallback4',
        image_bytes: 34,
        image_height: 154,
        image_url: 'image_url6',
        image_width: 24,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    blocks: [
      BlockKitBlock.new(
        type: 'type4',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      BlockKitBlock.new(
        type: 'type4',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    bot_id: JSON.parse('{"key1":"val1","key2":"val2"}'),
    bot_profile: BotProfileObject.new(
      app_id: 'app_id8',
      deleted: false,
      icons: Icons.new(
        image_36: 'image_362',
        image_48: 'image_488',
        image_72: 'image_722',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      id: 'id8',
      name: 'name8',
      team_id: 'team_id8',
      updated: 44,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    client_msg_id: 'client_msg_id4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  ok: 'True',
  ts: 'ts6',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


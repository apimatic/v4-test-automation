
# Conversations Close Error Schema Exception

Schema for error response from conversations.close method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsCloseErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsCloseErrorEnum`](../../doc/models/conversations-close-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsCloseErrorSchemaException => e
  puts "Caught ConversationsCloseErrorSchemaException: #{e.message}"
end
```


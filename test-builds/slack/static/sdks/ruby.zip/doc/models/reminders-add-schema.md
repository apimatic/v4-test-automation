
# Reminders Add Schema

Schema for successful response from reminders.add method

*This model accepts additional fields of type Object.*

## Structure

`RemindersAddSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `reminder` | [`ObjsReminder`](../../doc/models/objs-reminder.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
reminders_add_schema = RemindersAddSchema.new(
  ok: 'True',
  reminder: ObjsReminder.new(
    creator: 'creator8',
    id: 'id0',
    recurring: false,
    text: 'text0',
    user: 'user0',
    complete_ts: 136,
    time: 38,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


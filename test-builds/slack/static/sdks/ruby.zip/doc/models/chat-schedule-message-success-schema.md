
# Chat Schedule Message Success Schema

Schema for successful response of chat.scheduleMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatScheduleMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `String` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `message` | [`Message`](../../doc/models/message.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `post_at` | `Integer` | Required | - |
| `scheduled_message_id` | `String` | Required | **Constraints**: *Pattern*: `^[Q][A-Z0-9]{8,}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
chat_schedule_message_success_schema = ChatScheduleMessageSuccessSchema.new(
  channel: 'channel8',
  message: Message.new(
    bot_id: 'bot_id6',
    team: 'team0',
    text: 'text0',
    type: 'type0',
    user: 'user0',
    bot_profile: BotProfileObject.new(
      app_id: 'app_id8',
      deleted: false,
      icons: Icons.new(
        image_36: 'image_362',
        image_48: 'image_488',
        image_72: 'image_722',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      id: 'id8',
      name: 'name8',
      team_id: 'team_id8',
      updated: 44,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    username: 'username0',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  ok: 'True',
  post_at: 30,
  scheduled_message_id: 'scheduled_message_id2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


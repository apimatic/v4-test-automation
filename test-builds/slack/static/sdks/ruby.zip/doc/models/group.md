
# Group

*This model accepts additional fields of type Object.*

## Structure

`Group`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resources` | [`ResourcesInInfoFromAppsPermissionsInfo`](../../doc/models/resources-in-info-from-apps-permissions-info.md) | Optional | - |
| `scopes` | `Array[String]` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
group = Group.new(
  resources: ResourcesInInfoFromAppsPermissionsInfo.new(
    ids: [
      JSON.parse('{"key1":"val1","key2":"val2"}'),
      JSON.parse('{"key1":"val1","key2":"val2"}'),
      JSON.parse('{"key1":"val1","key2":"val2"}')
    ],
    excluded_ids: [
      JSON.parse('{"key1":"val1","key2":"val2"}'),
      JSON.parse('{"key1":"val1","key2":"val2"}'),
      JSON.parse('{"key1":"val1","key2":"val2"}')
    ],
    wildcard: false,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  scopes: [
    'scopes4'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Default Success Template

This method either only returns a brief _OK_ response or a verbose schema is not available for this method.

*This model accepts additional fields of type Object.*

## Structure

`DefaultSuccessTemplate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
default_success_template = DefaultSuccessTemplate.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


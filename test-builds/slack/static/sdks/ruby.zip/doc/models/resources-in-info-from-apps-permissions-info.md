
# Resources in Info from Apps Permissions Info

*This model accepts additional fields of type Object.*

## Structure

`ResourcesInInfoFromAppsPermissionsInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `excluded_ids` | `Array[Object]` | Optional | - |
| `ids` | `Array[Object]` | Required | - |
| `wildcard` | `TrueClass \| FalseClass` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
resources_in_info_from_apps_permissions_info = ResourcesInInfoFromAppsPermissionsInfo.new(
  ids: [
    JSON.parse('{"key1":"val1","key2":"val2"}'),
    JSON.parse('{"key1":"val1","key2":"val2"}')
  ],
  excluded_ids: [
    JSON.parse('{"key1":"val1","key2":"val2"}'),
    JSON.parse('{"key1":"val1","key2":"val2"}')
  ],
  wildcard: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


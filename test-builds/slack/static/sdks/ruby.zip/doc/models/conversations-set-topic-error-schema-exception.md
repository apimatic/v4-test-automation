
# Conversations Set Topic Error Schema Exception

Schema for error response from conversations.setTopic method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsSetTopicErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsSetPurposeErrorEnum`](../../doc/models/conversations-set-purpose-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsSetTopicErrorSchemaException => e
  puts "Caught ConversationsSetTopicErrorSchemaException: #{e.message}"
end
```


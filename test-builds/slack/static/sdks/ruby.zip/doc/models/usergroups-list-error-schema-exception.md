
# Usergroups List Error Schema Exception

Schema for error response from usergroups.list method

*This model accepts additional fields of type Object.*

## Structure

`UsergroupsListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsEnableErrorEnum`](../../doc/models/usergroups-enable-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsergroupsListErrorSchemaException => e
  puts "Caught UsergroupsListErrorSchemaException: #{e.message}"
end
```


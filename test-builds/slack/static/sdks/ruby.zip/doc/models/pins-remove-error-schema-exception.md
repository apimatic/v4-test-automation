
# Pins Remove Error Schema Exception

Schema for error response from pins.remove method

*This model accepts additional fields of type Object.*

## Structure

`PinsRemoveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`PinsRemoveErrorEnum`](../../doc/models/pins-remove-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue PinsRemoveErrorSchemaException => e
  puts "Caught PinsRemoveErrorSchemaException: #{e.message}"
end
```



# Objs Team Profile Field

*This model accepts additional fields of type Object.*

## Structure

`ObjsTeamProfileField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field_name` | `String` | Optional | - |
| `hint` | `String` | Required | - |
| `id` | `String` | Required | **Constraints**: *Pattern*: `^X[a-zA-Z0-9]{9,}$` |
| `is_hidden` | `TrueClass \| FalseClass` | Optional | - |
| `label` | `String` | Required | - |
| `options` | `Object` | Optional | - |
| `ordering` | `Float` | Required | - |
| `possible_values` | `Array[String]` | Optional | - |
| `type` | [`Type`](../../doc/models/type.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
objs_team_profile_field = ObjsTeamProfileField.new(
  hint: 'hint0',
  id: 'id0',
  label: 'label0',
  ordering: 211.1,
  type: Type::OPTIONS_LIST,
  field_name: 'field_name4',
  is_hidden: false,
  options: JSON.parse('{"key1":"val1","key2":"val2"}'),
  possible_values: [
    'possible_values1',
    'possible_values2'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


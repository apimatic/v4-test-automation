
# Conversations Archive Error Schema Exception

Schema for error response from conversations.archive method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsArchiveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsArchiveErrorEnum`](../../doc/models/conversations-archive-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsArchiveErrorSchemaException => e
  puts "Caught ConversationsArchiveErrorSchemaException: #{e.message}"
end
```



# Files Upload Error Schema Exception

Schema for error response files.upload method

*This model accepts additional fields of type Object.*

## Structure

`FilesUploadErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesUploadErrorEnum`](../../doc/models/files-upload-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue FilesUploadErrorSchemaException => e
  puts "Caught FilesUploadErrorSchemaException: #{e.message}"
end
```



# Chat Delete Scheduled Message Error Schema Exception

Schema for error response from chat.deleteScheduledMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatDeleteScheduledMessageErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatDeleteScheduledMessageErrorEnum`](../../doc/models/chat-delete-scheduled-message-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ChatDeleteScheduledMessageErrorSchemaException => e
  puts "Caught ChatDeleteScheduledMessageErrorSchemaException: #{e.message}"
end
```


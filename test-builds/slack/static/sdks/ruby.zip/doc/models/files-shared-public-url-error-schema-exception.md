
# Files Shared Public Url Error Schema Exception

Schema for error response from files.sharedPublicURL method

*This model accepts additional fields of type Object.*

## Structure

`FilesSharedPublicUrlErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesSharedPublicUrlErrorEnum`](../../doc/models/files-shared-public-url-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue FilesSharedPublicUrlErrorSchemaException => e
  puts "Caught FilesSharedPublicUrlErrorSchemaException: #{e.message}"
end
```


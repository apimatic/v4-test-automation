
# File Comment Object

*This model accepts additional fields of type Object.*

## Structure

`FileCommentObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `comment` | `String` | Required | - |
| `created` | `Integer` | Required | - |
| `id` | `String` | Required | **Constraints**: *Pattern*: `^Fc[A-Z0-9]{8,}$` |
| `is_intro` | `TrueClass \| FalseClass` | Required | - |
| `is_starred` | `TrueClass \| FalseClass` | Optional | - |
| `num_stars` | `Integer` | Optional | - |
| `pinned_info` | `Object` | Optional | - |
| `pinned_to` | `Array[String]` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `reactions` | [`Array[ReactionObject]`](../../doc/models/reaction-object.md) | Optional | - |
| `timestamp` | `Integer` | Required | - |
| `user` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
file_comment_object = FileCommentObject.new(
  comment: 'comment8',
  created: 190,
  id: 'id4',
  is_intro: false,
  timestamp: 168,
  user: 'user4',
  is_starred: false,
  num_stars: 158,
  pinned_info: { 'key1' => 'val1', 'key2' => 'val2' },
  pinned_to: [
    'pinned_to8',
    'pinned_to9',
    'pinned_to0'
  ],
  reactions: [
    ReactionObject.new(
      count: 208,
      name: 'name8',
      users: [
        'users5',
        'users6',
        'users7'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Conversations Archive Success Schema

Schema for successful response conversations.archive method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsArchiveSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
conversations_archive_success_schema = ConversationsArchiveSuccessSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


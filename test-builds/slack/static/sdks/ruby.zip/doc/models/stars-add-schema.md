
# Stars Add Schema

Schema for successful response from stars.add method

*This model accepts additional fields of type Object.*

## Structure

`StarsAddSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
stars_add_schema = StarsAddSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


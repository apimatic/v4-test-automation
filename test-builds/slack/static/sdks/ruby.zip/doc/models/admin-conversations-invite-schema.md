
# Admin Conversations Invite Schema

Schema for successful response of admin.conversations.invite

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsInviteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
admin_conversations_invite_schema = AdminConversationsInviteSchema.new(
  ok: 'True',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


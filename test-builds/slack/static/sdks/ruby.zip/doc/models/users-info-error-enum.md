
# Users Info Error Enum

## Enumeration

`UsersInfoErrorEnum`

## Fields

| Name |
|  --- |
| `USER_NOT_FOUND` |
| `USER_NOT_VISIBLE` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```ruby
users_info_error_enum = UsersInfoErrorEnum::INVALID_JSON
```



# Auth Revoke Schema

Schema for successful response from auth.revoke method

*This model accepts additional fields of type Object.*

## Structure

`AuthRevokeSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `revoked` | `TrueClass \| FalseClass` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
auth_revoke_schema = AuthRevokeSchema.new(
  ok: 'True',
  revoked: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


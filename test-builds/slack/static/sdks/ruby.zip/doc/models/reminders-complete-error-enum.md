
# Reminders Complete Error Enum

## Enumeration

`RemindersCompleteErrorEnum`

## Fields

| Name |
|  --- |
| `NOT_FOUND` |
| `CANNOT_COMPLETE_RECURRING` |
| `CANNOT_COMPLETE_OTHERS` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `USER_IS_BOT` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```ruby
reminders_complete_error_enum = RemindersCompleteErrorEnum::NOT_FOUND
```


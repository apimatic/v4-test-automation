
# Stars Add Error Schema Exception

Schema for error response from stars.add method

*This model accepts additional fields of type Object.*

## Structure

`StarsAddErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`StarsAddErrorEnum`](../../doc/models/stars-add-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue StarsAddErrorSchemaException => e
  puts "Caught StarsAddErrorSchemaException: #{e.message}"
end
```


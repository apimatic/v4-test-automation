
# Log

*This model accepts additional fields of type Object.*

## Structure

`Log`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `admin_app_id` | `String` | Optional | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` |
| `app_id` | `String` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` |
| `app_type` | `String` | Required | - |
| `change_type` | `String` | Required | - |
| `channel` | `String` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `date` | `String` | Required | - |
| `scope` | `String` | Required | - |
| `service_id` | `String` | Optional | - |
| `service_type` | `String` | Optional | - |
| `user_id` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `user_name` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
log = Log.new(
  app_id: 'app_id8',
  app_type: 'app_type2',
  change_type: 'change_type8',
  date: 'date6',
  scope: 'scope4',
  user_id: 'user_id6',
  user_name: 'user_name4',
  admin_app_id: 'admin_app_id6',
  channel: 'channel6',
  service_id: 'service_id2',
  service_type: 'service_type4',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Auth Revoke Error Schema Exception

Schema for error response from auth.revoke method

*This model accepts additional fields of type Object.*

## Structure

`AuthRevokeErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AuthRevokeErrorEnum`](../../doc/models/auth-revoke-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue AuthRevokeErrorSchemaException => e
  puts "Caught AuthRevokeErrorSchemaException: #{e.message}"
end
```



# Users Set Active Error Schema Exception

Schema for error response from users.setActive method

*This model accepts additional fields of type Object.*

## Structure

`UsersSetActiveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersSetActiveErrorEnum`](../../doc/models/users-set-active-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue UsersSetActiveErrorSchemaException => e
  puts "Caught UsersSetActiveErrorSchemaException: #{e.message}"
end
```


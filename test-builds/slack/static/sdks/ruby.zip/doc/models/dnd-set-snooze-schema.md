
# Dnd Set Snooze Schema

Schema for successful response from dnd.setSnooze method

*This model accepts additional fields of type Object.*

## Structure

`DndSetSnoozeSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `snooze_enabled` | `TrueClass \| FalseClass` | Required | - |
| `snooze_endtime` | `Integer` | Required | - |
| `snooze_remaining` | `Integer` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
dnd_set_snooze_schema = DndSetSnoozeSchema.new(
  ok: 'True',
  snooze_enabled: false,
  snooze_endtime: 194,
  snooze_remaining: 194,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```



# Pins List Error Schema Exception

Schema for error response from pins.list method

*This model accepts additional fields of type Object.*

## Structure

`PinsListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`PinsListErrorEnum`](../../doc/models/pins-list-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue PinsListErrorSchemaException => e
  puts "Caught PinsListErrorSchemaException: #{e.message}"
end
```


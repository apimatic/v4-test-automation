
# Admin Conversations Get Teams Error Enum

## Enumeration

`AdminConversationsGetTeamsErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `CHANNEL_NOT_FOUND` |
| `CHANNEL_TYPE_NOT_SUPPORTED` |
| `UNSUPPORTED_TEAM_TYPE` |
| `RESTRICTED_ACTION` |
| `COULD_NOT_GET_TEAMS` |
| `INVALID_CURSOR` |
| `INVALID_LIMIT` |

## Example

```ruby
admin_conversations_get_teams_error_enum = AdminConversationsGetTeamsErrorEnum::FEATURE_NOT_ENABLED
```


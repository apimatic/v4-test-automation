
# Dnd Info Error Schema Exception

Schema for error response from dnd.info method

*This model accepts additional fields of type Object.*

## Structure

`DndInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndInfoErrorEnum`](../../doc/models/dnd-info-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue DndInfoErrorSchemaException => e
  puts "Caught DndInfoErrorSchemaException: #{e.message}"
end
```


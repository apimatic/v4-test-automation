
# Team Access Logs Error Schema Exception

Schema for error response from team.accessLogs method

*This model accepts additional fields of type Object.*

## Structure

`TeamAccessLogsErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`TeamAccessLogsErrorEnum`](../../doc/models/team-access-logs-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue TeamAccessLogsErrorSchemaException => e
  puts "Caught TeamAccessLogsErrorSchemaException: #{e.message}"
end
```


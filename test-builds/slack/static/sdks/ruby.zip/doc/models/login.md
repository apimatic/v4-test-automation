
# Login

*This model accepts additional fields of type Object.*

## Structure

`Login`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `Integer` | Required | - |
| `country` | `String` | Required | - |
| `date_first` | `Integer` | Required | - |
| `date_last` | `Integer` | Required | - |
| `ip` | `String` | Required | - |
| `isp` | `String` | Required | - |
| `region` | `String` | Required | - |
| `user_agent` | `String` | Required | - |
| `user_id` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `username` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
login = Login.new(
  count: 110,
  country: 'country4',
  date_first: 206,
  date_last: 222,
  ip: 'ip4',
  isp: 'isp0',
  region: 'region6',
  user_agent: 'user_agent2',
  user_id: 'user_id8',
  username: 'username0',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


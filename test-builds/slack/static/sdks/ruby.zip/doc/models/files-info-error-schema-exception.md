
# Files Info Error Schema Exception

Schema for error response from files.info method

*This model accepts additional fields of type Object.*

## Structure

`FilesInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesInfoErrorEnum`](../../doc/models/files-info-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue FilesInfoErrorSchemaException => e
  puts "Caught FilesInfoErrorSchemaException: #{e.message}"
end
```


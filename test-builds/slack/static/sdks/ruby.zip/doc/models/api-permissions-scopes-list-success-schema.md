
# Api Permissions Scopes List Success Schema

Schema for successful response api.permissions.scopes.list method

*This model accepts additional fields of type Object.*

## Structure

`ApiPermissionsScopesListSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `String` | Required, Constant | **Value**: `'True'` |
| `scopes` | [`Scopes`](../../doc/models/scopes.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
api_permissions_scopes_list_success_schema = ApiPermissionsScopesListSuccessSchema.new(
  ok: 'True',
  scopes: Scopes.new(
    app_home: [
      'app_home0',
      'app_home1',
      'app_home2'
    ],
    channel: [
      'channel2',
      'channel1'
    ],
    group: [
      'group1'
    ],
    im: [
      'im1',
      'im2',
      'im3'
    ],
    mpim: [
      'mpim2'
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


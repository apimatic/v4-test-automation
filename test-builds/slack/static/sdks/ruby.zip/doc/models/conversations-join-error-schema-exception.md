
# Conversations Join Error Schema Exception

Schema for error response from conversations.join method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsJoinErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsJoinErrorEnum`](../../doc/models/conversations-join-error-enum.md) | Required | - |
| `needed` | `String` | Optional | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `provided` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ConversationsJoinErrorSchemaException => e
  puts "Caught ConversationsJoinErrorSchemaException: #{e.message}"
end
```



# Files List Error Schema Exception

Schema for error response from files.list method

*This model accepts additional fields of type Object.*

## Structure

`FilesListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesListErrorEnum`](../../doc/models/files-list-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue FilesListErrorSchemaException => e
  puts "Caught FilesListErrorSchemaException: #{e.message}"
end
```


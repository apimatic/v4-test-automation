
# Response Metadata

*This model accepts additional fields of type Object.*

## Structure

`ResponseMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_cursor` | `String` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
response_metadata = ResponseMetadata.new(
  next_cursor: 'next_cursor2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```


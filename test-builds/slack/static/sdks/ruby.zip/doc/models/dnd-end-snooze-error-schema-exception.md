
# Dnd End Snooze Error Schema Exception

Schema for error response from dnd.endSnooze method

*This model accepts additional fields of type Object.*

## Structure

`DndEndSnoozeErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndEndSnoozeErrorEnum`](../../doc/models/dnd-end-snooze-error-enum.md) | Required | - |
| `ok` | `String` | Required, Constant | **Value**: `'False'` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue DndEndSnoozeErrorSchemaException => e
  puts "Caught DndEndSnoozeErrorSchemaException: #{e.message}"
end
```


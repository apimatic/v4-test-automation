Gem::Specification.new do |s|
  s.name = 'slack-apimatic-sdk'
  s.version = '1.0.0'
  s.summary = 'slack_web_api'
  s.description = ''
  s.authors = ['Slack developer relations']
  s.email = ['support@apimatic.io']
  s.homepage = 'https://api.slack.com/support'
  s.licenses = ['MIT']
  s.add_dependency('apimatic_core_interfaces', '~> 0.2.3')
  s.add_dependency('apimatic_core', '~> 0.3.20')
  s.add_dependency('apimatic_faraday_client_adapter', '~> 0.1.6')
  s.required_ruby_version = ['>= 2.6']
  s.files = Dir['{bin,lib,man,test,spec}/**/*', 'README*', 'LICENSE*']
  s.require_paths = ['lib']
end

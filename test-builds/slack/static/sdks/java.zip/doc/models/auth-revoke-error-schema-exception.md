
# Auth Revoke Error Schema Exception

Schema for error response from auth.revoke method

*This model accepts additional fields of type Object.*

## Structure

`AuthRevokeErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`AuthRevokeErrorEnum`](../../doc/models/auth-revoke-error-enum.md) | Required | - | AuthRevokeErrorEnum getError() | setError(AuthRevokeErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (AuthRevokeErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


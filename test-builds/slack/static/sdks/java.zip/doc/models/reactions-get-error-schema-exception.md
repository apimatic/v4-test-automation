
# Reactions Get Error Schema Exception

Schema for error response from reactions.get method

*This model accepts additional fields of type Object.*

## Structure

`ReactionsGetErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`ReactionsGetErrorEnum`](../../doc/models/reactions-get-error-enum.md) | Required | - | ReactionsGetErrorEnum getError() | setError(ReactionsGetErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (ReactionsGetErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


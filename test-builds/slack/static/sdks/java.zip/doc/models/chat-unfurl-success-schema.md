
# Chat Unfurl Success Schema

Schema for successful response from chat.unfurl method

*This model accepts additional fields of type Object.*

## Structure

`ChatUnfurlSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ChatUnfurlSuccessSchema;
import java.io.IOException;

ChatUnfurlSuccessSchema chatUnfurlSuccessSchema = new ChatUnfurlSuccessSchema.Builder(
    "True"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Files List Error Schema Exception

Schema for error response from files.list method

*This model accepts additional fields of type Object.*

## Structure

`FilesListErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`FilesListErrorEnum`](../../doc/models/files-list-error-enum.md) | Required | - | FilesListErrorEnum getError() | setError(FilesListErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (FilesListErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


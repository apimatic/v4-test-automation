
# Channel Object

*This model accepts additional fields of type Object.*

## Structure

`ChannelObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AcceptedUser` | `String` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getAcceptedUser() | setAcceptedUser(String acceptedUser) |
| `Created` | `int` | Required | - | int getCreated() | setCreated(int created) |
| `Creator` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getCreator() | setCreator(String creator) |
| `Id` | `String` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` | String getId() | setId(String id) |
| `IsArchived` | `Boolean` | Optional | - | Boolean getIsArchived() | setIsArchived(Boolean isArchived) |
| `IsChannel` | `boolean` | Required | - | boolean getIsChannel() | setIsChannel(boolean isChannel) |
| `IsFrozen` | `Boolean` | Optional | - | Boolean getIsFrozen() | setIsFrozen(Boolean isFrozen) |
| `IsGeneral` | `Boolean` | Optional | - | Boolean getIsGeneral() | setIsGeneral(Boolean isGeneral) |
| `IsMember` | `Boolean` | Optional | - | Boolean getIsMember() | setIsMember(Boolean isMember) |
| `IsMoved` | `Integer` | Optional | - | Integer getIsMoved() | setIsMoved(Integer isMoved) |
| `IsMpim` | `boolean` | Required | - | boolean getIsMpim() | setIsMpim(boolean isMpim) |
| `IsNonThreadable` | `Boolean` | Optional | - | Boolean getIsNonThreadable() | setIsNonThreadable(Boolean isNonThreadable) |
| `IsOrgShared` | `boolean` | Required | - | boolean getIsOrgShared() | setIsOrgShared(boolean isOrgShared) |
| `IsPendingExtShared` | `Boolean` | Optional | - | Boolean getIsPendingExtShared() | setIsPendingExtShared(Boolean isPendingExtShared) |
| `IsPrivate` | `boolean` | Required | - | boolean getIsPrivate() | setIsPrivate(boolean isPrivate) |
| `IsReadOnly` | `Boolean` | Optional | - | Boolean getIsReadOnly() | setIsReadOnly(Boolean isReadOnly) |
| `IsShared` | `boolean` | Required | - | boolean getIsShared() | setIsShared(boolean isShared) |
| `IsThreadOnly` | `Boolean` | Optional | - | Boolean getIsThreadOnly() | setIsThreadOnly(Boolean isThreadOnly) |
| `LastRead` | `String` | Optional | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | String getLastRead() | setLastRead(String lastRead) |
| `Latest` | `Object` | Optional | - | Object getLatest() | setLatest(Object latest) |
| `Members` | `List<String>` | Required | **Constraints**: *Minimum Items*: `0`, *Unique Items Required*, *Pattern*: `^[UW][A-Z0-9]{2,}$` | List<String> getMembers() | setMembers(List<String> members) |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `NameNormalized` | `String` | Required | - | String getNameNormalized() | setNameNormalized(String nameNormalized) |
| `NumMembers` | `Integer` | Optional | - | Integer getNumMembers() | setNumMembers(Integer numMembers) |
| `PendingShared` | `List<String>` | Optional | **Constraints**: *Minimum Items*: `0`, *Unique Items Required*, *Pattern*: `^[T][A-Z0-9]{2,}$` | List<String> getPendingShared() | setPendingShared(List<String> pendingShared) |
| `PreviousNames` | `List<String>` | Optional | **Constraints**: *Minimum Items*: `0`, *Unique Items Required* | List<String> getPreviousNames() | setPreviousNames(List<String> previousNames) |
| `Priority` | `Double` | Optional | - | Double getPriority() | setPriority(Double priority) |
| `Purpose` | [`Purpose`](../../doc/models/purpose.md) | Required | - | Purpose getPurpose() | setPurpose(Purpose purpose) |
| `Topic` | [`Topic`](../../doc/models/topic.md) | Required | - | Topic getTopic() | setTopic(Topic topic) |
| `Unlinked` | `Integer` | Optional | - | Integer getUnlinked() | setUnlinked(Integer unlinked) |
| `UnreadCount` | `Integer` | Optional | - | Integer getUnreadCount() | setUnreadCount(Integer unreadCount) |
| `UnreadCountDisplay` | `Integer` | Optional | - | Integer getUnreadCountDisplay() | setUnreadCountDisplay(Integer unreadCountDisplay) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ChannelObject;
import com.slack.models.Purpose;
import com.slack.models.Topic;
import java.io.IOException;
import java.util.Arrays;

ChannelObject channelObject = new ChannelObject.Builder(
    36,
    "creator4",
    "id6",
    false,
    false,
    false,
    false,
    false,
    Arrays.asList(
        "members4",
        "members5"
    ),
    "name6",
    "name_normalized4",
    new Purpose.Builder(
        "creator4",
        30,
        "value8"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    new Topic.Builder(
        "creator6",
        242,
        "value0"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.acceptedUser("accepted_user4")
.isArchived(false)
.isFrozen(false)
.isGeneral(false)
.isMember(false)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


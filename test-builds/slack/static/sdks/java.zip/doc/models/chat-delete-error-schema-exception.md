
# Chat Delete Error Schema Exception

Schema for error response from chat.delete method

*This model accepts additional fields of type Object.*

## Structure

`ChatDeleteErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`ChatDeleteErrorEnum`](../../doc/models/chat-delete-error-enum.md) | Required | - | ChatDeleteErrorEnum getError() | setError(ChatDeleteErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (ChatDeleteErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


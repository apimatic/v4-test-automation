
# Dnd End Dnd Error Schema Exception

Schema for error response from dnd.endDnd method

*This model accepts additional fields of type Object.*

## Structure

`DndEndDndErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`DndEndDndErrorEnum`](../../doc/models/dnd-end-dnd-error-enum.md) | Required | - | DndEndDndErrorEnum getError() | setError(DndEndDndErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (DndEndDndErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```



# Usergroups List Schema

Schema for successful response from usergroups.list method

*This model accepts additional fields of type Object.*

## Structure

`UsergroupsListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Usergroups` | [`List<SubteamUsergroupObject>`](../../doc/models/subteam-usergroup-object.md) | Required | - | List<SubteamUsergroupObject> getUsergroups() | setUsergroups(List<SubteamUsergroupObject> usergroups) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Prefs;
import com.slack.models.SubteamUsergroupObject;
import com.slack.models.UsergroupsListSchema;
import java.io.IOException;
import java.util.Arrays;

UsergroupsListSchema usergroupsListSchema = new UsergroupsListSchema.Builder(
    "True",
    Arrays.asList(
        new SubteamUsergroupObject.Builder(
            false,
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            "created_by8",
            66,
            114,
            100,
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            "description6",
            "enterprise_subteam_id2",
            "handle0",
            "id4",
            false,
            false,
            false,
            "name4",
            new Prefs.Builder(
                Arrays.asList(
                    "channels5",
                    "channels4"
                ),
                Arrays.asList(
                    "groups4",
                    "groups5",
                    "groups6"
                )
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            "team_id2",
            "updated_by8"
        )
        .channelCount(222)
        .userCount(28)
        .users(Arrays.asList(
                "users9"
            ))
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Conversations Join Error Schema Exception

Schema for error response from conversations.join method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsJoinErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`ConversationsJoinErrorEnum`](../../doc/models/conversations-join-error-enum.md) | Required | - | ConversationsJoinErrorEnum getError() | setError(ConversationsJoinErrorEnum error) |
| `Needed` | `String` | Optional | - | String getNeeded() | setNeeded(String needed) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `Provided` | `String` | Optional | - | String getProvided() | setProvided(String provided) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (ConversationsJoinErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


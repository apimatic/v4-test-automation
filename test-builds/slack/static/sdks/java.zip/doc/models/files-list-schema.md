
# Files List Schema

Schema for successful response from files.list method

*This model accepts additional fields of type Object.*

## Structure

`FilesListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Files` | [`List<FileObject>`](../../doc/models/file-object.md) | Required | **Constraints**: *Minimum Items*: `0`, *Unique Items Required* | List<FileObject> getFiles() | setFiles(List<FileObject> files) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - | PagingObject getPaging() | setPaging(PagingObject paging) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.FileObject;
import com.slack.models.FilesListSchema;
import com.slack.models.PagingObject;
import java.io.IOException;
import java.util.Arrays;

FilesListSchema filesListSchema = new FilesListSchema.Builder(
    Arrays.asList(
        new FileObject.Builder()
            .channels(Arrays.asList(
                "channels9"
            ))
            .commentsCount(150)
            .created(58)
            .dateDelete(212)
            .displayAsBot(false)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    ),
    "True",
    new PagingObject.Builder(
        26,
        6
    )
    .count(56)
    .pages(150)
    .perPage(194)
    .spill(246)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


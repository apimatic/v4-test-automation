
# Reminders Add Schema

Schema for successful response from reminders.add method

*This model accepts additional fields of type Object.*

## Structure

`RemindersAddSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Reminder` | [`ObjsReminder`](../../doc/models/objs-reminder.md) | Required | - | ObjsReminder getReminder() | setReminder(ObjsReminder reminder) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ObjsReminder;
import com.slack.models.RemindersAddSchema;
import java.io.IOException;

RemindersAddSchema remindersAddSchema = new RemindersAddSchema.Builder(
    "True",
    new ObjsReminder.Builder(
        "creator8",
        "id0",
        false,
        "text0",
        "user0"
    )
    .completeTs(136)
    .time(38)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


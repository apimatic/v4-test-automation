
# Can Thread

*This model accepts additional fields of type Object.*

## Structure

`CanThread`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | `List<String>` | Optional | - | List<String> getType() | setType(List<String> type) |
| `User` | `List<String>` | Optional | - | List<String> getUser() | setUser(List<String> user) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.CanThread;
import java.io.IOException;
import java.util.Arrays;

CanThread canThread = new CanThread.Builder()
    .type(Arrays.asList(
        "type3"
    ))
    .user(Arrays.asList(
        "user8",
        "user9",
        "user0"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```



# Users Profile Get Error Schema Exception

Schema for error response from users.profile.get method

*This model accepts additional fields of type Object.*

## Structure

`UsersProfileGetErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`UsersProfileGetErrorEnum`](../../doc/models/users-profile-get-error-enum.md) | Required | - | UsersProfileGetErrorEnum getError() | setError(UsersProfileGetErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (UsersProfileGetErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```



# Attachment

*This model accepts additional fields of type Object.*

## Structure

`Attachment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Fallback` | `String` | Optional | - | String getFallback() | setFallback(String fallback) |
| `Id` | `int` | Required | - | int getId() | setId(int id) |
| `ImageBytes` | `Integer` | Optional | - | Integer getImageBytes() | setImageBytes(Integer imageBytes) |
| `ImageHeight` | `Integer` | Optional | - | Integer getImageHeight() | setImageHeight(Integer imageHeight) |
| `ImageUrl` | `String` | Optional | - | String getImageUrl() | setImageUrl(String imageUrl) |
| `ImageWidth` | `Integer` | Optional | - | Integer getImageWidth() | setImageWidth(Integer imageWidth) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Attachment;
import java.io.IOException;

Attachment attachment = new Attachment.Builder(
    248
)
.fallback("fallback6")
.imageBytes(78)
.imageHeight(110)
.imageUrl("image_url4")
.imageWidth(236)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


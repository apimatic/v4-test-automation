
# Info

*This model accepts additional fields of type Object.*

## Structure

`Info`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AppHome` | [`AppHome`](../../doc/models/app-home.md) | Required | - | AppHome getAppHome() | setAppHome(AppHome appHome) |
| `Channel` | [`Channel`](../../doc/models/channel.md) | Required | - | Channel getChannel() | setChannel(Channel channel) |
| `Group` | [`Group`](../../doc/models/group.md) | Required | - | Group getGroup() | setGroup(Group group) |
| `Im` | [`Im`](../../doc/models/im.md) | Required | - | Im getIm() | setIm(Im im) |
| `Mpim` | [`Mpim`](../../doc/models/mpim.md) | Required | - | Mpim getMpim() | setMpim(Mpim mpim) |
| `Team` | [`Team`](../../doc/models/team.md) | Required | - | Team getTeam() | setTeam(Team team) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.AppHome;
import com.slack.models.Channel;
import com.slack.models.Group;
import com.slack.models.Im;
import com.slack.models.Info;
import com.slack.models.Mpim;
import com.slack.models.ResourcesInInfoFromAppsPermissionsInfo;
import com.slack.models.Team;
import java.io.IOException;
import java.util.Arrays;

Info info = new Info.Builder(
    new AppHome.Builder()
        .resources(new ResourcesInInfoFromAppsPermissionsInfo.Builder(
            Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            )
        )
        .excludedIds(Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            ))
        .wildcard(false)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
        .scopes(Arrays.asList(
            "scopes4",
            "scopes3",
            "scopes2"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
    new Channel.Builder()
        .resources(new ResourcesInInfoFromAppsPermissionsInfo.Builder(
            Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            )
        )
        .excludedIds(Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            ))
        .wildcard(false)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
        .scopes(Arrays.asList(
            "scopes2",
            "scopes1"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
    new Group.Builder()
        .resources(new ResourcesInInfoFromAppsPermissionsInfo.Builder(
            Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            )
        )
        .excludedIds(Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            ))
        .wildcard(false)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
        .scopes(Arrays.asList(
            "scopes4"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
    new Im.Builder()
        .resources(new ResourcesInInfoFromAppsPermissionsInfo.Builder(
            Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            )
        )
        .excludedIds(Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            ))
        .wildcard(false)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
        .scopes(Arrays.asList(
            "scopes0",
            "scopes9",
            "scopes8"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
    new Mpim.Builder()
        .resources(new ResourcesInInfoFromAppsPermissionsInfo.Builder(
            Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            )
        )
        .excludedIds(Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            ))
        .wildcard(false)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
        .scopes(Arrays.asList(
            "scopes6"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
    new Team.Builder(
        new ResourcesInInfoFromAppsPermissionsInfo.Builder(
            Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            )
        )
        .excludedIds(Arrays.asList(
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
            ))
        .wildcard(false)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
        Arrays.asList(
            "scopes6",
            "scopes5",
            "scopes4"
        )
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Users Conversations Error Schema Exception

Schema for error response from users.conversations method

*This model accepts additional fields of type Object.*

## Structure

`UsersConversationsErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`UsersConversationsErrorEnum`](../../doc/models/users-conversations-error-enum.md) | Required | - | UsersConversationsErrorEnum getError() | setError(UsersConversationsErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (UsersConversationsErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


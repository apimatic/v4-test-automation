
# Icons 1

*This model accepts additional fields of type Object.*

## Structure

`Icons1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Emoji` | `String` | Optional | - | String getEmoji() | setEmoji(String emoji) |
| `Image64` | `String` | Optional | - | String getImage64() | setImage64(String image64) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Icons1;
import java.io.IOException;

Icons1 icons1 = new Icons1.Builder()
    .emoji("emoji4")
    .image64("image_646")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```


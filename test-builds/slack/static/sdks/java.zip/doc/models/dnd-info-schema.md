
# Dnd Info Schema

Schema for successful response from dnd.info method

*This model accepts additional fields of type Object.*

## Structure

`DndInfoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DndEnabled` | `boolean` | Required | - | boolean getDndEnabled() | setDndEnabled(boolean dndEnabled) |
| `NextDndEndTs` | `int` | Required | - | int getNextDndEndTs() | setNextDndEndTs(int nextDndEndTs) |
| `NextDndStartTs` | `int` | Required | - | int getNextDndStartTs() | setNextDndStartTs(int nextDndStartTs) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `SnoozeEnabled` | `Boolean` | Optional | - | Boolean getSnoozeEnabled() | setSnoozeEnabled(Boolean snoozeEnabled) |
| `SnoozeEndtime` | `Integer` | Optional | - | Integer getSnoozeEndtime() | setSnoozeEndtime(Integer snoozeEndtime) |
| `SnoozeRemaining` | `Integer` | Optional | - | Integer getSnoozeRemaining() | setSnoozeRemaining(Integer snoozeRemaining) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.DndInfoSchema;
import java.io.IOException;

DndInfoSchema dndInfoSchema = new DndInfoSchema.Builder(
    false,
    132,
    204,
    "True"
)
.snoozeEnabled(false)
.snoozeEndtime(102)
.snoozeRemaining(102)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


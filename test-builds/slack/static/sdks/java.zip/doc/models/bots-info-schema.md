
# Bots Info Schema

Schema for successful response from bots.info method

*This model accepts additional fields of type Object.*

## Structure

`BotsInfoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Bot` | [`Bot`](../../doc/models/bot.md) | Required | - | Bot getBot() | setBot(Bot bot) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Bot;
import com.slack.models.BotsInfoSchema;
import com.slack.models.Icons;
import java.io.IOException;

BotsInfoSchema botsInfoSchema = new BotsInfoSchema.Builder(
    new Bot.Builder(
        "app_id0",
        false,
        new Icons.Builder(
            "image_362",
            "image_488",
            "image_722"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
        "id6",
        "name6",
        214
    )
    .userId("user_id4")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    "True"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


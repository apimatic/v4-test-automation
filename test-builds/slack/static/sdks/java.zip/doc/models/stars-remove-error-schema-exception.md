
# Stars Remove Error Schema Exception

Schema for error response from stars.remove method

*This model accepts additional fields of type Object.*

## Structure

`StarsRemoveErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`StarsRemoveErrorEnum`](../../doc/models/stars-remove-error-enum.md) | Required | - | StarsRemoveErrorEnum getError() | setError(StarsRemoveErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (StarsRemoveErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


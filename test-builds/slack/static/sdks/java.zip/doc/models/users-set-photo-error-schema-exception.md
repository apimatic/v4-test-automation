
# Users Set Photo Error Schema Exception

Schema for error response from users.setPhoto method

*This model accepts additional fields of type Object.*

## Structure

`UsersSetPhotoErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `DebugStep` | `String` | Optional | possibly DEV/QA only | String getDebugStep() | setDebugStep(String debugStep) |
| `Dims` | `String` | Optional | possibly DEV/QA only | String getDims() | setDims(String dims) |
| `Error` | [`UsersSetPhotoErrorEnum`](../../doc/models/users-set-photo-error-enum.md) | Required | - | UsersSetPhotoErrorEnum getError() | setError(UsersSetPhotoErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `TimeIdent` | `Integer` | Optional | possibly DEV/QA only | Integer getTimeIdent() | setTimeIdent(Integer timeIdent) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (UsersSetPhotoErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```



# Message Object 1

*This model accepts additional fields of type Object.*

## Structure

`MessageObject1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Attachments` | `List<Object>` | Optional | - | List<Object> getAttachments() | setAttachments(List<Object> attachments) |
| `Blocks` | `Object` | Optional | - | Object getBlocks() | setBlocks(Object blocks) |
| `Text` | `String` | Required | - | String getText() | setText(String text) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.MessageObject1;
import java.io.IOException;
import java.util.Arrays;

MessageObject1 messageObject1 = new MessageObject1.Builder(
    "text0"
)
.attachments(Arrays.asList(
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
    ))
.blocks(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


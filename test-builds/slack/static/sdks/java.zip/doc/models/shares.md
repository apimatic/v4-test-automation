
# Shares

*This model accepts additional fields of type Object.*

## Structure

`Shares`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Private` | `Object` | Optional | - | Object getPrivate() | setPrivate(Object mPrivate) |
| `Public` | `Object` | Optional | - | Object getPublic() | setPublic(Object mPublic) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Shares;
import java.io.IOException;

Shares shares = new Shares.Builder()
    .mPrivate(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .mPublic(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```



# External Org Migrations

*This model accepts additional fields of type Object.*

## Structure

`ExternalOrgMigrations`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Current` | [`List<Current>`](../../doc/models/current.md) | Required | - | List<Current> getCurrent() | setCurrent(List<Current> current) |
| `DateUpdated` | `int` | Required | - | int getDateUpdated() | setDateUpdated(int dateUpdated) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Current;
import com.slack.models.ExternalOrgMigrations;
import java.io.IOException;
import java.util.Arrays;

ExternalOrgMigrations externalOrgMigrations = new ExternalOrgMigrations.Builder(
    Arrays.asList(
        new Current.Builder(
            84,
            "team_id0"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ),
    16
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


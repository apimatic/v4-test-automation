
# Users Profile Set Schema

Schema for successful response from users.profile.set method

*This model accepts additional fields of type Object.*

## Structure

`UsersProfileSetSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EmailPending` | `String` | Optional | - | String getEmailPending() | setEmailPending(String emailPending) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Profile` | [`UserProfileObject`](../../doc/models/user-profile-object.md) | Required | - | UserProfileObject getProfile() | setProfile(UserProfileObject profile) |
| `Username` | `String` | Required | - | String getUsername() | setUsername(String username) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.UserProfileObject;
import com.slack.models.UsersProfileSetSchema;
import java.io.IOException;
import java.util.Arrays;

UsersProfileSetSchema usersProfileSetSchema = new UsersProfileSetSchema.Builder(
    "True",
    new UserProfileObject.Builder(
        "avatar_hash0",
        "display_name0",
        "display_name_normalized0",
        Arrays.asList(
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
        ),
        "phone0",
        "real_name6",
        "real_name_normalized6",
        "skype0",
        "status_emoji4",
        "status_text8",
        "title6"
    )
    .alwaysActive(false)
    .apiAppId("api_app_id0")
    .botId("bot_id6")
    .email("email6")
    .firstName("first_name0")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    "username8"
)
.emailPending("email_pending0")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


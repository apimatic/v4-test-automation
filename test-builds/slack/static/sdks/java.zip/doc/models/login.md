
# Login

*This model accepts additional fields of type Object.*

## Structure

`Login`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Count` | `int` | Required | - | int getCount() | setCount(int count) |
| `Country` | `String` | Required | - | String getCountry() | setCountry(String country) |
| `DateFirst` | `int` | Required | - | int getDateFirst() | setDateFirst(int dateFirst) |
| `DateLast` | `int` | Required | - | int getDateLast() | setDateLast(int dateLast) |
| `Ip` | `String` | Required | - | String getIp() | setIp(String ip) |
| `Isp` | `String` | Required | - | String getIsp() | setIsp(String isp) |
| `Region` | `String` | Required | - | String getRegion() | setRegion(String region) |
| `UserAgent` | `String` | Required | - | String getUserAgent() | setUserAgent(String userAgent) |
| `UserId` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getUserId() | setUserId(String userId) |
| `Username` | `String` | Required | - | String getUsername() | setUsername(String username) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Login;
import java.io.IOException;

Login login = new Login.Builder(
    110,
    "country4",
    206,
    222,
    "ip4",
    "isp0",
    "region6",
    "user_agent2",
    "user_id8",
    "username0"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


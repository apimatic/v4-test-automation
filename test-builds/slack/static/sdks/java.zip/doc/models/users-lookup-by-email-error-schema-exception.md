
# Users Lookup by Email Error Schema Exception

Schema for error response from users.lookupByEmail method

*This model accepts additional fields of type Object.*

## Structure

`UsersLookupByEmailErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`UsersLookupByEmailErrorEnum`](../../doc/models/users-lookup-by-email-error-enum.md) | Required | - | UsersLookupByEmailErrorEnum getError() | setError(UsersLookupByEmailErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (UsersLookupByEmailErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


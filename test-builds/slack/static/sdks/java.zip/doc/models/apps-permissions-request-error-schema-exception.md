
# Apps Permissions Request Error Schema Exception

Schema for error response from apps.permissions.request method

*This model accepts additional fields of type Object.*

## Structure

`AppsPermissionsRequestErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`AppsPermissionsRequestErrorEnum`](../../doc/models/apps-permissions-request-error-enum.md) | Required | - | AppsPermissionsRequestErrorEnum getError() | setError(AppsPermissionsRequestErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (AppsPermissionsRequestErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


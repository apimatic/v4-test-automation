
# Objs Team Profile Field

*This model accepts additional fields of type Object.*

## Structure

`ObjsTeamProfileField`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FieldName` | `String` | Optional | - | String getFieldName() | setFieldName(String fieldName) |
| `Hint` | `String` | Required | - | String getHint() | setHint(String hint) |
| `Id` | `String` | Required | **Constraints**: *Pattern*: `^X[a-zA-Z0-9]{9,}$` | String getId() | setId(String id) |
| `IsHidden` | `Boolean` | Optional | - | Boolean getIsHidden() | setIsHidden(Boolean isHidden) |
| `Label` | `String` | Required | - | String getLabel() | setLabel(String label) |
| `Options` | `Object` | Optional | - | Object getOptions() | setOptions(Object options) |
| `Ordering` | `double` | Required | - | double getOrdering() | setOrdering(double ordering) |
| `PossibleValues` | `List<String>` | Optional | - | List<String> getPossibleValues() | setPossibleValues(List<String> possibleValues) |
| `Type` | [`Type`](../../doc/models/type.md) | Required | - | Type getType() | setType(Type type) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ObjsTeamProfileField;
import com.slack.models.Type;
import java.io.IOException;
import java.util.Arrays;

ObjsTeamProfileField objsTeamProfileField = new ObjsTeamProfileField.Builder(
    "hint6",
    "id6",
    "label6",
    127.94D,
    Type.OPTIONS_LIST
)
.fieldName("field_name0")
.isHidden(false)
.options(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.possibleValues(Arrays.asList(
        "possible_values7",
        "possible_values8"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Conversations Leave Error Enum

## Enumeration

`ConversationsLeaveErrorEnum`

## Fields

| Name |
|  --- |
| `METHOD_NOT_SUPPORTED_FOR_CHANNEL_TYPE` |
| `LAST_MEMBER` |
| `MISSING_SCOPE` |
| `CHANNEL_NOT_FOUND` |
| `IS_ARCHIVED` |
| `CANT_LEAVE_GENERAL` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `USER_IS_BOT` |
| `USER_IS_RESTRICTED` |
| `USER_IS_ULTRA_RESTRICTED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `TEAM_ADDED_TO_ORG` |
| `MISSING_CHARSET` |
| `SUPERFLUOUS_CHARSET` |

## Example

```java
import com.slack.models.ConversationsLeaveErrorEnum;

ConversationsLeaveErrorEnum conversationsLeaveErrorEnum = ConversationsLeaveErrorEnum.INVALID_ARRAY_ARG;
```


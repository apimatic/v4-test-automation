
# Migration Exchange Success Schema

Schema for successful response from migration.exchange method

*This model accepts additional fields of type Object.*

## Structure

`MigrationExchangeSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EnterpriseId` | `String` | Required | - | String getEnterpriseId() | setEnterpriseId(String enterpriseId) |
| `InvalidUserIds` | `List<String>` | Optional | - | List<String> getInvalidUserIds() | setInvalidUserIds(List<String> invalidUserIds) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `TeamId` | `String` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | String getTeamId() | setTeamId(String teamId) |
| `UserIdMap` | `Object` | Optional | - | Object getUserIdMap() | setUserIdMap(Object userIdMap) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.MigrationExchangeSuccessSchema;
import java.io.IOException;
import java.util.Arrays;

MigrationExchangeSuccessSchema migrationExchangeSuccessSchema = new MigrationExchangeSuccessSchema.Builder(
    "enterprise_id2",
    "True",
    "team_id4"
)
.invalidUserIds(Arrays.asList(
        "invalid_user_ids0"
    ))
.userIdMap(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


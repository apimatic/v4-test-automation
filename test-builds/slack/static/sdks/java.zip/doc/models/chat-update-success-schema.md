
# Chat Update Success Schema

Schema for successful response of chat.update method

*This model accepts additional fields of type Object.*

## Structure

`ChatUpdateSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Channel` | `String` | Required | - | String getChannel() | setChannel(String channel) |
| `Message` | [`MessageObject1`](../../doc/models/message-object-1.md) | Required | - | MessageObject1 getMessage() | setMessage(MessageObject1 message) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Text` | `String` | Required | - | String getText() | setText(String text) |
| `Ts` | `String` | Required | - | String getTs() | setTs(String ts) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ChatUpdateSuccessSchema;
import com.slack.models.MessageObject1;
import java.io.IOException;
import java.util.Arrays;

ChatUpdateSuccessSchema chatUpdateSuccessSchema = new ChatUpdateSuccessSchema.Builder(
    "channel2",
    new MessageObject1.Builder(
        "text0"
    )
    .attachments(Arrays.asList(
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
        ))
    .blocks(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    "True",
    "text2",
    "ts4"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


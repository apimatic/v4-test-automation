
# Admin Conversations Get Conversation Prefs Schema

Schema for successful response of admin.conversations.getConversationPrefs

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsGetConversationPrefsSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Prefs` | [`Prefs1`](../../doc/models/prefs-1.md) | Optional | - | Prefs1 getPrefs() | setPrefs(Prefs1 prefs) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.AdminConversationsGetConversationPrefsSchema;
import com.slack.models.CanThread;
import com.slack.models.Prefs1;
import com.slack.models.WhoCanPost;
import java.io.IOException;
import java.util.Arrays;

AdminConversationsGetConversationPrefsSchema adminConversationsGetConversationPrefsSchema = new AdminConversationsGetConversationPrefsSchema.Builder(
    "True"
)
.prefs(new Prefs1.Builder()
        .canThread(new CanThread.Builder()
            .type(Arrays.asList(
                "type1",
                "type0"
            ))
            .user(Arrays.asList(
                "user6",
                "user7"
            ))
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build())
        .whoCanPost(new WhoCanPost.Builder()
            .type(Arrays.asList(
                "type5",
                "type4"
            ))
            .user(Arrays.asList(
                "user0",
                "user1"
            ))
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build())
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# File Comment Object

*This model accepts additional fields of type Object.*

## Structure

`FileCommentObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Comment` | `String` | Required | - | String getComment() | setComment(String comment) |
| `Created` | `int` | Required | - | int getCreated() | setCreated(int created) |
| `Id` | `String` | Required | **Constraints**: *Pattern*: `^Fc[A-Z0-9]{8,}$` | String getId() | setId(String id) |
| `IsIntro` | `boolean` | Required | - | boolean getIsIntro() | setIsIntro(boolean isIntro) |
| `IsStarred` | `Boolean` | Optional | - | Boolean getIsStarred() | setIsStarred(Boolean isStarred) |
| `NumStars` | `Integer` | Optional | - | Integer getNumStars() | setNumStars(Integer numStars) |
| `PinnedInfo` | `Object` | Optional | - | Object getPinnedInfo() | setPinnedInfo(Object pinnedInfo) |
| `PinnedTo` | `List<String>` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | List<String> getPinnedTo() | setPinnedTo(List<String> pinnedTo) |
| `Reactions` | [`List<ReactionObject>`](../../doc/models/reaction-object.md) | Optional | - | List<ReactionObject> getReactions() | setReactions(List<ReactionObject> reactions) |
| `Timestamp` | `int` | Required | - | int getTimestamp() | setTimestamp(int timestamp) |
| `User` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getUser() | setUser(String user) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.FileCommentObject;
import com.slack.models.ReactionObject;
import java.io.IOException;
import java.util.Arrays;

FileCommentObject fileCommentObject = new FileCommentObject.Builder(
    "comment4",
    72,
    "id2",
    false,
    50,
    "user2"
)
.isStarred(false)
.numStars(40)
.pinnedInfo(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.pinnedTo(Arrays.asList(
        "pinned_to0",
        "pinned_to1",
        "pinned_to2"
    ))
.reactions(Arrays.asList(
        new ReactionObject.Builder(
            208,
            "name8",
            Arrays.asList(
                "users5",
                "users6",
                "users7"
            )
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


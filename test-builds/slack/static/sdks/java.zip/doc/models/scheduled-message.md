
# Scheduled Message

*This model accepts additional fields of type Object.*

## Structure

`ScheduledMessage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChannelId` | `String` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` | String getChannelId() | setChannelId(String channelId) |
| `DateCreated` | `int` | Required | - | int getDateCreated() | setDateCreated(int dateCreated) |
| `Id` | `String` | Required | **Constraints**: *Pattern*: `^[Q][A-Z0-9]{8,}$` | String getId() | setId(String id) |
| `PostAt` | `int` | Required | - | int getPostAt() | setPostAt(int postAt) |
| `Text` | `String` | Optional | - | String getText() | setText(String text) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ScheduledMessage;
import java.io.IOException;

ScheduledMessage scheduledMessage = new ScheduledMessage.Builder(
    "channel_id6",
    168,
    "id0",
    244
)
.text("text0")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Files Shared Public Url Error Schema Exception

Schema for error response from files.sharedPublicURL method

*This model accepts additional fields of type Object.*

## Structure

`FilesSharedPublicUrlErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`FilesSharedPublicUrlErrorEnum`](../../doc/models/files-shared-public-url-error-enum.md) | Required | - | FilesSharedPublicUrlErrorEnum getError() | setError(FilesSharedPublicUrlErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (FilesSharedPublicUrlErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


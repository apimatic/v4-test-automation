
# Dnd End Snooze Schema

Schema for successful response from dnd.endSnooze method

*This model accepts additional fields of type Object.*

## Structure

`DndEndSnoozeSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DndEnabled` | `boolean` | Required | - | boolean getDndEnabled() | setDndEnabled(boolean dndEnabled) |
| `NextDndEndTs` | `int` | Required | - | int getNextDndEndTs() | setNextDndEndTs(int nextDndEndTs) |
| `NextDndStartTs` | `int` | Required | - | int getNextDndStartTs() | setNextDndStartTs(int nextDndStartTs) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `SnoozeEnabled` | `boolean` | Required | - | boolean getSnoozeEnabled() | setSnoozeEnabled(boolean snoozeEnabled) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.DndEndSnoozeSchema;
import java.io.IOException;

DndEndSnoozeSchema dndEndSnoozeSchema = new DndEndSnoozeSchema.Builder(
    false,
    152,
    184,
    "True",
    false
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


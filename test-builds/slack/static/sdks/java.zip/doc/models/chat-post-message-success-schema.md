
# Chat Post Message Success Schema

Schema for successful response of chat.postMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatPostMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Channel` | `String` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | String getChannel() | setChannel(String channel) |
| `Message` | [`MessageObject`](../../doc/models/message-object.md) | Required | - | MessageObject getMessage() | setMessage(MessageObject message) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Ts` | `String` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | String getTs() | setTs(String ts) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Attachment;
import com.slack.models.BlockKitBlock;
import com.slack.models.BotProfileObject;
import com.slack.models.ChatPostMessageSuccessSchema;
import com.slack.models.Icons;
import com.slack.models.MessageObject;
import java.io.IOException;
import java.util.Arrays;

ChatPostMessageSuccessSchema chatPostMessageSuccessSchema = new ChatPostMessageSuccessSchema.Builder(
    "channel6",
    new MessageObject.Builder(
        "text0",
        "ts2",
        "type0"
    )
    .attachments(Arrays.asList(
            new Attachment.Builder(
                36
            )
            .fallback("fallback4")
            .imageBytes(34)
            .imageHeight(154)
            .imageUrl("image_url6")
            .imageWidth(24)
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            new Attachment.Builder(
                36
            )
            .fallback("fallback4")
            .imageBytes(34)
            .imageHeight(154)
            .imageUrl("image_url6")
            .imageWidth(24)
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
        ))
    .blocks(Arrays.asList(
            new BlockKitBlock.Builder(
                "type4"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            new BlockKitBlock.Builder(
                "type4"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
        ))
    .botId(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .botProfile(new BotProfileObject.Builder(
            "app_id8",
            false,
            new Icons.Builder(
                "image_362",
                "image_488",
                "image_722"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            "id8",
            "name8",
            "team_id8",
            44
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .clientMsgId("client_msg_id4")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    "True",
    "ts0"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Reactions List Schema

Schema for successful response from reactions.list method

*This model accepts additional fields of type Object.*

## Structure

`ReactionsListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Items` | `List<Object>` | Required | - | List<Object> getItems() | setItems(List<Object> items) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Paging` | [`PagingObject`](../../doc/models/paging-object.md) | Optional | - | PagingObject getPaging() | setPaging(PagingObject paging) |
| `ResponseMetadata` | `Object` | Optional | - | Object getResponseMetadata() | setResponseMetadata(Object responseMetadata) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.PagingObject;
import com.slack.models.ReactionsListSchema;
import java.io.IOException;
import java.util.Arrays;

ReactionsListSchema reactionsListSchema = new ReactionsListSchema.Builder(
    Arrays.asList(
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
    ),
    "True"
)
.paging(new PagingObject.Builder(
        26,
        6
    )
    .count(56)
    .pages(150)
    .perPage(194)
    .spill(246)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
.responseMetadata(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


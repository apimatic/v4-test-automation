
# Conversations History Success Schema

Schema for successful response from conversations.history method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsHistorySuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ChannelActionsCount` | `int` | Required | - | int getChannelActionsCount() | setChannelActionsCount(int channelActionsCount) |
| `ChannelActionsTs` | `Object` | Required | - | Object getChannelActionsTs() | setChannelActionsTs(Object channelActionsTs) |
| `HasMore` | `boolean` | Required | - | boolean getHasMore() | setHasMore(boolean hasMore) |
| `Messages` | [`List<MessageObject>`](../../doc/models/message-object.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<MessageObject> getMessages() | setMessages(List<MessageObject> messages) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `PinCount` | `int` | Required | - | int getPinCount() | setPinCount(int pinCount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Attachment;
import com.slack.models.BlockKitBlock;
import com.slack.models.BotProfileObject;
import com.slack.models.ConversationsHistorySuccessSchema;
import com.slack.models.Icons;
import com.slack.models.MessageObject;
import java.io.IOException;
import java.util.Arrays;

ConversationsHistorySuccessSchema conversationsHistorySuccessSchema = new ConversationsHistorySuccessSchema.Builder(
    18,
    ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    false,
    Arrays.asList(
        new MessageObject.Builder(
            "text8",
            "ts0",
            "type8"
        )
        .attachments(Arrays.asList(
                new Attachment.Builder(
                    36
                )
                .fallback("fallback4")
                .imageBytes(34)
                .imageHeight(154)
                .imageUrl("image_url6")
                .imageWidth(24)
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build(),
                new Attachment.Builder(
                    36
                )
                .fallback("fallback4")
                .imageBytes(34)
                .imageHeight(154)
                .imageUrl("image_url6")
                .imageWidth(24)
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
            ))
        .blocks(Arrays.asList(
                new BlockKitBlock.Builder(
                    "type4"
                )
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build(),
                new BlockKitBlock.Builder(
                    "type4"
                )
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
            ))
        .botId(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .botProfile(new BotProfileObject.Builder(
                "app_id8",
                false,
                new Icons.Builder(
                    "image_362",
                    "image_488",
                    "image_722"
                )
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build(),
                "id8",
                "name8",
                "team_id8",
                44
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build())
        .clientMsgId("client_msg_id4")
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ),
    "True",
    84
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


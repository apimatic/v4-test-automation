
# Users Profile Set Error Schema Exception

Schema for error response from users.profile.set method

*This model accepts additional fields of type Object.*

## Structure

`UsersProfileSetErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`UsersProfileSetErrorEnum`](../../doc/models/users-profile-set-error-enum.md) | Required | - | UsersProfileSetErrorEnum getError() | setError(UsersProfileSetErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (UsersProfileSetErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


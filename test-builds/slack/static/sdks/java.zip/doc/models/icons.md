
# Icons

*This model accepts additional fields of type Object.*

## Structure

`Icons`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Image36` | `String` | Required | - | String getImage36() | setImage36(String image36) |
| `Image48` | `String` | Required | - | String getImage48() | setImage48(String image48) |
| `Image72` | `String` | Required | - | String getImage72() | setImage72(String image72) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Icons;
import java.io.IOException;

Icons icons = new Icons.Builder(
    "image_362",
    "image_488",
    "image_722"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


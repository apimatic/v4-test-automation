
# Auth Test Success Schema

Schema for successful response auth.test method

*This model accepts additional fields of type Object.*

## Structure

`AuthTestSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BotId` | `String` | Optional | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` | String getBotId() | setBotId(String botId) |
| `IsEnterpriseInstall` | `Boolean` | Optional | - | Boolean getIsEnterpriseInstall() | setIsEnterpriseInstall(Boolean isEnterpriseInstall) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Team` | `String` | Required | - | String getTeam() | setTeam(String team) |
| `TeamId` | `String` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | String getTeamId() | setTeamId(String teamId) |
| `Url` | `String` | Required | - | String getUrl() | setUrl(String url) |
| `User` | `String` | Required | - | String getUser() | setUser(String user) |
| `UserId` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getUserId() | setUserId(String userId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.AuthTestSuccessSchema;
import java.io.IOException;

AuthTestSuccessSchema authTestSuccessSchema = new AuthTestSuccessSchema.Builder(
    "True",
    "team6",
    "team_id8",
    "url8",
    "user4",
    "user_id2"
)
.botId("bot_id2")
.isEnterpriseInstall(false)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


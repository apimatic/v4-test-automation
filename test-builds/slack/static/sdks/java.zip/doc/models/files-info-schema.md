
# Files Info Schema

Schema for successful response from files.info method

*This model accepts additional fields of type Object.*

## Structure

`FilesInfoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Comments` | `List<Object>` | Required | - | List<Object> getComments() | setComments(List<Object> comments) |
| `ContentHtml` | `String` | Optional | - | String getContentHtml() | setContentHtml(String contentHtml) |
| `Editor` | `String` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getEditor() | setEditor(String editor) |
| `File` | [`FileObject`](../../doc/models/file-object.md) | Required | - | FileObject getFile() | setFile(FileObject file) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Paging` | [`PagingObject`](../../doc/models/paging-object.md) | Optional | - | PagingObject getPaging() | setPaging(PagingObject paging) |
| `ResponseMetadata` | `Object` | Optional | - | Object getResponseMetadata() | setResponseMetadata(Object responseMetadata) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.FileObject;
import com.slack.models.FilesInfoSchema;
import com.slack.models.PagingObject;
import java.io.IOException;
import java.util.Arrays;

FilesInfoSchema filesInfoSchema = new FilesInfoSchema.Builder(
    Arrays.asList(
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
    ),
    new FileObject.Builder()
        .channels(Arrays.asList(
            "channels5",
            "channels4"
        ))
        .commentsCount(56)
        .created(220)
        .dateDelete(118)
        .displayAsBot(false)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
    "True"
)
.contentHtml("content_html0")
.editor("editor4")
.paging(new PagingObject.Builder(
        26,
        6
    )
    .count(56)
    .pages(150)
    .perPage(194)
    .spill(246)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
.responseMetadata(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


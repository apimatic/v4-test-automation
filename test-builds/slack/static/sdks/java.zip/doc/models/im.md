
# Im

*This model accepts additional fields of type Object.*

## Structure

`Im`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Resources` | [`ResourcesInInfoFromAppsPermissionsInfo`](../../doc/models/resources-in-info-from-apps-permissions-info.md) | Optional | - | ResourcesInInfoFromAppsPermissionsInfo getResources() | setResources(ResourcesInInfoFromAppsPermissionsInfo resources) |
| `Scopes` | `List<String>` | Optional | - | List<String> getScopes() | setScopes(List<String> scopes) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Im;
import com.slack.models.ResourcesInInfoFromAppsPermissionsInfo;
import java.io.IOException;
import java.util.Arrays;

Im im = new Im.Builder()
    .resources(new ResourcesInInfoFromAppsPermissionsInfo.Builder(
        Arrays.asList(
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
        )
    )
    .excludedIds(Arrays.asList(
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
        ))
    .wildcard(false)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
    .scopes(Arrays.asList(
        "scopes0",
        "scopes9",
        "scopes8"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```


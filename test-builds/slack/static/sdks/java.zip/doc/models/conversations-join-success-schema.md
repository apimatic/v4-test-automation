
# Conversations Join Success Schema

Schema for successful response from conversations.join method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsJoinSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Channel` | `Object` | Required | - | Object getChannel() | setChannel(Object channel) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `ResponseMetadata` | [`ResponseMetadata3`](../../doc/models/response-metadata-3.md) | Optional | - | ResponseMetadata3 getResponseMetadata() | setResponseMetadata(ResponseMetadata3 responseMetadata) |
| `Warning` | `String` | Optional | - | String getWarning() | setWarning(String warning) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ConversationsJoinSuccessSchema;
import com.slack.models.ResponseMetadata3;
import java.io.IOException;
import java.util.Arrays;

ConversationsJoinSuccessSchema conversationsJoinSuccessSchema = new ConversationsJoinSuccessSchema.Builder(
    ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    "True"
)
.responseMetadata(new ResponseMetadata3.Builder()
        .warnings(Arrays.asList(
            "warnings8",
            "warnings9",
            "warnings0"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.warning("warning4")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


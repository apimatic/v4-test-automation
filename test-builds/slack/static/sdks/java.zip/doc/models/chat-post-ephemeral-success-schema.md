
# Chat Post Ephemeral Success Schema

Schema for successful response from chat.postEphemeral method

*This model accepts additional fields of type Object.*

## Structure

`ChatPostEphemeralSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MessageTs` | `String` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | String getMessageTs() | setMessageTs(String messageTs) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ChatPostEphemeralSuccessSchema;
import java.io.IOException;

ChatPostEphemeralSuccessSchema chatPostEphemeralSuccessSchema = new ChatPostEphemeralSuccessSchema.Builder(
    "message_ts2",
    "True"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


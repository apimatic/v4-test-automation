
# Chat Schedule Message Error Schema Exception

Schema for error response chat.scheduleMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatScheduleMessageErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`ChatScheduleMessageErrorEnum`](../../doc/models/chat-schedule-message-error-enum.md) | Required | - | ChatScheduleMessageErrorEnum getError() | setError(ChatScheduleMessageErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (ChatScheduleMessageErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


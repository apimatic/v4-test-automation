
# Conversations History Error Schema Exception

Schema for error response from conversations.history method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsHistoryErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`ConversationsHistoryErrorEnum`](../../doc/models/conversations-history-error-enum.md) | Required | - | ConversationsHistoryErrorEnum getError() | setError(ConversationsHistoryErrorEnum error) |
| `Needed` | `String` | Optional | - | String getNeeded() | setNeeded(String needed) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `Provided` | `String` | Optional | - | String getProvided() | setProvided(String provided) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (ConversationsHistoryErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


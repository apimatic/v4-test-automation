
# Response Metadata

*This model accepts additional fields of type Object.*

## Structure

`ResponseMetadata`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NextCursor` | `String` | Required | - | String getNextCursor() | setNextCursor(String nextCursor) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ResponseMetadata;
import java.io.IOException;

ResponseMetadata responseMetadata = new ResponseMetadata.Builder(
    "next_cursor8"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


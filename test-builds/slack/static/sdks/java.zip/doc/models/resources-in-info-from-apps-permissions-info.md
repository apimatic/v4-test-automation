
# Resources in Info from Apps Permissions Info

*This model accepts additional fields of type Object.*

## Structure

`ResourcesInInfoFromAppsPermissionsInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ExcludedIds` | `List<Object>` | Optional | - | List<Object> getExcludedIds() | setExcludedIds(List<Object> excludedIds) |
| `Ids` | `List<Object>` | Required | - | List<Object> getIds() | setIds(List<Object> ids) |
| `Wildcard` | `Boolean` | Optional | - | Boolean getWildcard() | setWildcard(Boolean wildcard) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ResourcesInInfoFromAppsPermissionsInfo;
import java.io.IOException;
import java.util.Arrays;

ResourcesInInfoFromAppsPermissionsInfo resourcesInInfoFromAppsPermissionsInfo = new ResourcesInInfoFromAppsPermissionsInfo.Builder(
    Arrays.asList(
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
    )
)
.excludedIds(Arrays.asList(
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
    ))
.wildcard(false)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


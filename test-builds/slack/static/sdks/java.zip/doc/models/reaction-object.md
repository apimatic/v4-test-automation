
# Reaction Object

*This model accepts additional fields of type Object.*

## Structure

`ReactionObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Count` | `int` | Required | - | int getCount() | setCount(int count) |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `Users` | `List<String>` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | List<String> getUsers() | setUsers(List<String> users) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ReactionObject;
import java.io.IOException;
import java.util.Arrays;

ReactionObject reactionObject = new ReactionObject.Builder(
    228,
    "name8",
    Arrays.asList(
        "users5",
        "users4"
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Reactions Add Error Enum

## Enumeration

`ReactionsAddErrorEnum`

## Fields

| Name |
|  --- |
| `BAD_TIMESTAMP` |
| `MESSAGE_NOT_FOUND` |
| `NO_ITEM_SPECIFIED` |
| `INVALID_NAME` |
| `ALREADY_REACTED` |
| `TOO_MANY_EMOJI` |
| `TOO_MANY_REACTIONS` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```java
import com.slack.models.ReactionsAddErrorEnum;

ReactionsAddErrorEnum reactionsAddErrorEnum = ReactionsAddErrorEnum.MISSING_POST_TYPE;
```


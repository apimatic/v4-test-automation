
# Topic

*This model accepts additional fields of type Object.*

## Structure

`Topic`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Creator` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{8,}$\|^$` | String getCreator() | setCreator(String creator) |
| `LastSet` | `int` | Required | - | int getLastSet() | setLastSet(int lastSet) |
| `Value` | `String` | Required | - | String getValue() | setValue(String value) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Topic;
import java.io.IOException;

Topic topic = new Topic.Builder(
    "creator6",
    242,
    "value0"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Migration Exchange Error Schema Exception

Schema for error response from migration.exchange method

*This model accepts additional fields of type Object.*

## Structure

`MigrationExchangeErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`MigrationExchangeErrorEnum`](../../doc/models/migration-exchange-error-enum.md) | Required | - | MigrationExchangeErrorEnum getError() | setError(MigrationExchangeErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (MigrationExchangeErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```



# Admin Conversations Unarchive Error Enum

## Enumeration

`AdminConversationsUnarchiveErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `CHANNEL_NOT_FOUND` |
| `CHANNEL_NOT_ARCHIVED` |
| `CHANNEL_TYPE_NOT_SUPPORTED` |
| `RESTRICTED_ACTION` |
| `COULD_NOT_UNARCHIVE_CHANNEL` |
| `DEFAULT_ORG_WIDE_CHANNEL` |
| `MISSING_SCOPE` |

## Example

```java
import com.slack.models.AdminConversationsUnarchiveErrorEnum;

AdminConversationsUnarchiveErrorEnum adminConversationsUnarchiveErrorEnum = AdminConversationsUnarchiveErrorEnum.RESTRICTED_ACTION;
```



# Chat Schedule Message Success Schema

Schema for successful response of chat.scheduleMessage method

*This model accepts additional fields of type Object.*

## Structure

`ChatScheduleMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Channel` | `String` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | String getChannel() | setChannel(String channel) |
| `Message` | [`Message`](../../doc/models/message.md) | Required | - | Message getMessage() | setMessage(Message message) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `PostAt` | `int` | Required | - | int getPostAt() | setPostAt(int postAt) |
| `ScheduledMessageId` | `String` | Required | **Constraints**: *Pattern*: `^[Q][A-Z0-9]{8,}$` | String getScheduledMessageId() | setScheduledMessageId(String scheduledMessageId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.BotProfileObject;
import com.slack.models.ChatScheduleMessageSuccessSchema;
import com.slack.models.Icons;
import com.slack.models.Message;
import java.io.IOException;

ChatScheduleMessageSuccessSchema chatScheduleMessageSuccessSchema = new ChatScheduleMessageSuccessSchema.Builder(
    "channel0",
    new Message.Builder(
        "bot_id6",
        "team0",
        "text0",
        "type0",
        "user0"
    )
    .botProfile(new BotProfileObject.Builder(
            "app_id8",
            false,
            new Icons.Builder(
                "image_362",
                "image_488",
                "image_722"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            "id8",
            "name8",
            "team_id8",
            44
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .username("username0")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    "True",
    76,
    "scheduled_message_id6"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Admin Conversations Get Teams Schema

Schema for successful response of admin.conversations.getTeams

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsGetTeamsSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `ResponseMetadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - | ResponseMetadata getResponseMetadata() | setResponseMetadata(ResponseMetadata responseMetadata) |
| `TeamIds` | `List<String>` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | List<String> getTeamIds() | setTeamIds(List<String> teamIds) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.AdminConversationsGetTeamsSchema;
import com.slack.models.ResponseMetadata;
import java.io.IOException;
import java.util.Arrays;

AdminConversationsGetTeamsSchema adminConversationsGetTeamsSchema = new AdminConversationsGetTeamsSchema.Builder(
    "True",
    Arrays.asList(
        "team_ids1",
        "team_ids2",
        "team_ids3"
    )
)
.responseMetadata(new ResponseMetadata.Builder(
        "next_cursor2"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


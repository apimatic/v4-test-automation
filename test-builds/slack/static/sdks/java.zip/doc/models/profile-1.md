
# Profile 1

*This model accepts additional fields of type Object.*

## Structure

`Profile1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AvatarHash` | `String` | Required | **Constraints**: *Pattern*: `^[0-9a-f]{12}$` | String getAvatarHash() | setAvatarHash(String avatarHash) |
| `Image1024` | `String` | Required | - | String getImage1024() | setImage1024(String image1024) |
| `Image192` | `String` | Required | - | String getImage192() | setImage192(String image192) |
| `Image24` | `String` | Required | - | String getImage24() | setImage24(String image24) |
| `Image32` | `String` | Required | - | String getImage32() | setImage32(String image32) |
| `Image48` | `String` | Required | - | String getImage48() | setImage48(String image48) |
| `Image512` | `String` | Required | - | String getImage512() | setImage512(String image512) |
| `Image72` | `String` | Required | - | String getImage72() | setImage72(String image72) |
| `ImageOriginal` | `String` | Required | - | String getImageOriginal() | setImageOriginal(String imageOriginal) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Profile1;
import java.io.IOException;

Profile1 profile1 = new Profile1.Builder(
    "avatar_hash2",
    "image_10248",
    "image_1928",
    "image_246",
    "image_328",
    "image_480",
    "image_5122",
    "image_726",
    "image_original8"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Admin Conversations Unarchive Error Schema 3 Exception

Schema for error response from admin.conversations.unarchive

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsUnarchiveErrorSchema3Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | [`AdminConversationsUnarchiveErrorEnum`](../../doc/models/admin-conversations-unarchive-error-enum.md) | Required | - | AdminConversationsUnarchiveErrorEnum getError() | setError(AdminConversationsUnarchiveErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (AdminConversationsUnarchiveErrorSchema3Exception e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


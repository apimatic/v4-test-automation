
# Conversations Invite Error Schema 1 Exception

Schema for error response from conversations.invite method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsInviteErrorSchema1Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`ConversationsInviteErrorEnum`](../../doc/models/conversations-invite-error-enum.md) | Optional | - | ConversationsInviteErrorEnum getError() | setError(ConversationsInviteErrorEnum error) |
| `Errors` | [`List<ErrorsIsReturnedWhenAnErrorAssociatesAnUser>`](../../doc/models/errors-is-returned-when-an-error-associates-an-user.md) | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<ErrorsIsReturnedWhenAnErrorAssociatesAnUser> getErrors() | setErrors(List<ErrorsIsReturnedWhenAnErrorAssociatesAnUser> errors) |
| `Needed` | `String` | Optional | - | String getNeeded() | setNeeded(String needed) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `Provided` | `String` | Optional | - | String getProvided() | setProvided(String provided) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (ConversationsInviteErrorSchema1Exception e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


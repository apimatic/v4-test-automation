
# Objs User Profile Short

*This model accepts additional fields of type Object.*

## Structure

`ObjsUserProfileShort`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AvatarHash` | `String` | Required | - | String getAvatarHash() | setAvatarHash(String avatarHash) |
| `DisplayName` | `String` | Required | - | String getDisplayName() | setDisplayName(String displayName) |
| `DisplayNameNormalized` | `String` | Optional | - | String getDisplayNameNormalized() | setDisplayNameNormalized(String displayNameNormalized) |
| `FirstName` | `String` | Required | - | String getFirstName() | setFirstName(String firstName) |
| `Image72` | `String` | Required | - | String getImage72() | setImage72(String image72) |
| `IsRestricted` | `boolean` | Required | - | boolean getIsRestricted() | setIsRestricted(boolean isRestricted) |
| `IsUltraRestricted` | `boolean` | Required | - | boolean getIsUltraRestricted() | setIsUltraRestricted(boolean isUltraRestricted) |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `RealName` | `String` | Required | - | String getRealName() | setRealName(String realName) |
| `RealNameNormalized` | `String` | Optional | - | String getRealNameNormalized() | setRealNameNormalized(String realNameNormalized) |
| `Team` | `String` | Required | **Constraints**: *Pattern*: `^[TE][A-Z0-9]{8,}$` | String getTeam() | setTeam(String team) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ObjsUserProfileShort;
import java.io.IOException;

ObjsUserProfileShort objsUserProfileShort = new ObjsUserProfileShort.Builder(
    "avatar_hash2",
    "display_name2",
    "first_name2",
    "image_726",
    false,
    false,
    "name2",
    "real_name8",
    "team8"
)
.displayNameNormalized("display_name_normalized2")
.realNameNormalized("real_name_normalized4")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


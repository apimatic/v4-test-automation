
# Conversations List Error Enum

## Enumeration

`ConversationsListErrorEnum`

## Fields

| Name |
|  --- |
| `MISSING_SCOPE` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```java
import com.slack.models.ConversationsListErrorEnum;

ConversationsListErrorEnum conversationsListErrorEnum = ConversationsListErrorEnum.INVALID_POST_TYPE;
```



# Team Access Logs Error Schema Exception

Schema for error response from team.accessLogs method

*This model accepts additional fields of type Object.*

## Structure

`TeamAccessLogsErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`TeamAccessLogsErrorEnum`](../../doc/models/team-access-logs-error-enum.md) | Required | - | TeamAccessLogsErrorEnum getError() | setError(TeamAccessLogsErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (TeamAccessLogsErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```



# Users Set Photo Schema

Schema for successful response from users.setPhoto method

*This model accepts additional fields of type Object.*

## Structure

`UsersSetPhotoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Profile` | [`Profile1`](../../doc/models/profile-1.md) | Required | - | Profile1 getProfile() | setProfile(Profile1 profile) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Profile1;
import com.slack.models.UsersSetPhotoSchema;
import java.io.IOException;

UsersSetPhotoSchema usersSetPhotoSchema = new UsersSetPhotoSchema.Builder(
    "True",
    new Profile1.Builder(
        "avatar_hash0",
        "image_10246",
        "image_1926",
        "image_248",
        "image_326",
        "image_488",
        "image_5124",
        "image_724",
        "image_original6"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


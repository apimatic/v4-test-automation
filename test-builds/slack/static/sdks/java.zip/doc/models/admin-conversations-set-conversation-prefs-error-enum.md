
# Admin Conversations Set Conversation Prefs Error Enum

## Enumeration

`AdminConversationsSetConversationPrefsErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `NOT_AN_ADMIN` |
| `CHANNEL_NOT_FOUND` |
| `CHANNEL_TYPE_NOT_SUPPORTED` |
| `RESTRICTED_ACTION` |
| `MISSING_SCOPE` |
| `COULD_NOT_SET_CHANNEL_PREF` |
| `DEFAULT_ORG_WIDE_CHANNEL` |

## Example

```java
import com.slack.models.AdminConversationsSetConversationPrefsErrorEnum;

AdminConversationsSetConversationPrefsErrorEnum adminConversationsSetConversationPrefsErrorEnum = AdminConversationsSetConversationPrefsErrorEnum.FEATURE_NOT_ENABLED;
```


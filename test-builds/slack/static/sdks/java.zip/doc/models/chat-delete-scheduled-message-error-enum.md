
# Chat Delete Scheduled Message Error Enum

## Enumeration

`ChatDeleteScheduledMessageErrorEnum`

## Fields

| Name |
|  --- |
| `INVALID_SCHEDULED_MESSAGE_ID` |
| `CHANNEL_NOT_FOUND` |
| `BAD_TOKEN` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `EKM_ACCESS_DENIED` |
| `MISSING_SCOPE` |
| `INVALID_ARGUMENTS` |
| `INVALID_ARG_NAME` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```java
import com.slack.models.ChatDeleteScheduledMessageErrorEnum;

ChatDeleteScheduledMessageErrorEnum chatDeleteScheduledMessageErrorEnum = ChatDeleteScheduledMessageErrorEnum.INVALID_JSON;
```


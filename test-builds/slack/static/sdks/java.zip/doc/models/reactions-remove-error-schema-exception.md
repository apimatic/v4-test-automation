
# Reactions Remove Error Schema Exception

Schema for error response from reactions.remove method

*This model accepts additional fields of type Object.*

## Structure

`ReactionsRemoveErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`ReactionsRemoveErrorEnum`](../../doc/models/reactions-remove-error-enum.md) | Required | - | ReactionsRemoveErrorEnum getError() | setError(ReactionsRemoveErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (ReactionsRemoveErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```



# Conversations Unarchive Error Enum

## Enumeration

`ConversationsUnarchiveErrorEnum`

## Fields

| Name |
|  --- |
| `METHOD_NOT_SUPPORTED_FOR_CHANNEL_TYPE` |
| `MISSING_SCOPE` |
| `CHANNEL_NOT_FOUND` |
| `NOT_ARCHIVED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `USER_IS_BOT` |
| `USER_IS_RESTRICTED` |
| `USER_IS_ULTRA_RESTRICTED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `TEAM_ADDED_TO_ORG` |
| `MISSING_CHARSET` |
| `SUPERFLUOUS_CHARSET` |

## Example

```java
import com.slack.models.ConversationsUnarchiveErrorEnum;

ConversationsUnarchiveErrorEnum conversationsUnarchiveErrorEnum = ConversationsUnarchiveErrorEnum.UPGRADE_REQUIRED;
```


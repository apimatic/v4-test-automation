
# Who Can Post

*This model accepts additional fields of type Object.*

## Structure

`WhoCanPost`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | `List<String>` | Optional | - | List<String> getType() | setType(List<String> type) |
| `User` | `List<String>` | Optional | - | List<String> getUser() | setUser(List<String> user) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.WhoCanPost;
import java.io.IOException;
import java.util.Arrays;

WhoCanPost whoCanPost = new WhoCanPost.Builder()
    .type(Arrays.asList(
        "type7"
    ))
    .user(Arrays.asList(
        "user2",
        "user3",
        "user4"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```


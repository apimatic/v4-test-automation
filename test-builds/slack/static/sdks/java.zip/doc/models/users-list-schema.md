
# Users List Schema

Schema for successful response from users.list method

*This model accepts additional fields of type Object.*

## Structure

`UsersListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CacheTs` | `int` | Required | - | int getCacheTs() | setCacheTs(int cacheTs) |
| `Members` | `List<Object>` | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<Object> getMembers() | setMembers(List<Object> members) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `ResponseMetadata` | `Object` | Optional | - | Object getResponseMetadata() | setResponseMetadata(Object responseMetadata) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.UsersListSchema;
import java.io.IOException;
import java.util.Arrays;

UsersListSchema usersListSchema = new UsersListSchema.Builder(
    60,
    Arrays.asList(
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
    ),
    "True"
)
.responseMetadata(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


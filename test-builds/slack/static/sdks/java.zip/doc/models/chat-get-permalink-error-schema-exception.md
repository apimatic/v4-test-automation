
# Chat Get Permalink Error Schema Exception

Schema for error response from chat.getPermalink method

*This model accepts additional fields of type Object.*

## Structure

`ChatGetPermalinkErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`ChatGetPermalinkErrorEnum`](../../doc/models/chat-get-permalink-error-enum.md) | Required | - | ChatGetPermalinkErrorEnum getError() | setError(ChatGetPermalinkErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (ChatGetPermalinkErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


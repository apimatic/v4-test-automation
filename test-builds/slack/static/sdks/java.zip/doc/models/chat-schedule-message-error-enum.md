
# Chat Schedule Message Error Enum

## Enumeration

`ChatScheduleMessageErrorEnum`

## Fields

| Name |
|  --- |
| `INVALID_TIME` |
| `TIME_IN_PAST` |
| `TIME_TOO_FAR` |
| `CHANNEL_NOT_FOUND` |
| `NOT_IN_CHANNEL` |
| `IS_ARCHIVED` |
| `MSG_TOO_LONG` |
| `NO_TEXT` |
| `RESTRICTED_ACTION` |
| `RESTRICTED_ACTION_READ_ONLY_CHANNEL` |
| `RESTRICTED_ACTION_THREAD_ONLY_CHANNEL` |
| `RESTRICTED_ACTION_NON_THREADABLE_CHANNEL` |
| `TOO_MANY_ATTACHMENTS` |
| `RATE_LIMITED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `EKM_ACCESS_DENIED` |
| `MISSING_SCOPE` |
| `INVALID_ARGUMENTS` |
| `INVALID_ARG_NAME` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```java
import com.slack.models.ChatScheduleMessageErrorEnum;

ChatScheduleMessageErrorEnum chatScheduleMessageErrorEnum = ChatScheduleMessageErrorEnum.INVALID_CHARSET;
```


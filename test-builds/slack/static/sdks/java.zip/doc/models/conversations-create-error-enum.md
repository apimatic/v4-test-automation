
# Conversations Create Error Enum

## Enumeration

`ConversationsCreateErrorEnum`

## Fields

| Name |
|  --- |
| `METHOD_NOT_SUPPORTED_FOR_CHANNEL_TYPE` |
| `MISSING_SCOPE` |
| `NAME_TAKEN` |
| `RESTRICTED_ACTION` |
| `NO_CHANNEL` |
| `INVALID_NAME_REQUIRED` |
| `INVALID_NAME_PUNCTUATION` |
| `INVALID_NAME_MAXLENGTH` |
| `INVALID_NAME_SPECIALS` |
| `INVALID_NAME` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `USER_IS_BOT` |
| `USER_IS_RESTRICTED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```java
import com.slack.models.ConversationsCreateErrorEnum;

ConversationsCreateErrorEnum conversationsCreateErrorEnum = ConversationsCreateErrorEnum.INVALID_NAME_PUNCTUATION;
```


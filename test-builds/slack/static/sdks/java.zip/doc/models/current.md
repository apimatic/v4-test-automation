
# Current

*This model accepts additional fields of type Object.*

## Structure

`Current`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DateStarted` | `int` | Required | - | int getDateStarted() | setDateStarted(int dateStarted) |
| `TeamId` | `String` | Required | - | String getTeamId() | setTeamId(String teamId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Current;
import java.io.IOException;

Current current = new Current.Builder(
    84,
    "team_id0"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Sso Provider

*This model accepts additional fields of type Object.*

## Structure

`SsoProvider`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Label` | `String` | Optional | - | String getLabel() | setLabel(String label) |
| `Name` | `String` | Optional | - | String getName() | setName(String name) |
| `Type` | `String` | Optional | - | String getType() | setType(String type) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.SsoProvider;
import java.io.IOException;

SsoProvider ssoProvider = new SsoProvider.Builder()
    .label("label8")
    .name("name8")
    .type("type2")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```



# Team Info Schema

Schema for successful response from team.info method

*This model accepts additional fields of type Object.*

## Structure

`TeamInfoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Team` | [`TeamObject`](../../doc/models/team-object.md) | Required | - | TeamObject getTeam() | setTeam(TeamObject team) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ObjsIcon;
import com.slack.models.TeamInfoSchema;
import com.slack.models.TeamObject;
import java.io.IOException;

TeamInfoSchema teamInfoSchema = new TeamInfoSchema.Builder(
    "True",
    new TeamObject.Builder(
        "domain6",
        "email_domain0",
        new ObjsIcon.Builder()
            .image102("image_1020")
            .image132("image_1326")
            .image230("image_2308")
            .image34("image_340")
            .image44("image_440")
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
        "id0",
        "name0"
    )
    .archived(false)
    .avatarBaseUrl("avatar_base_url0")
    .created(212)
    .dateCreate(62)
    .deleted(false)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


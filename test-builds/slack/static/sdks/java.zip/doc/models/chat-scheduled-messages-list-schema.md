
# Chat Scheduled Messages List Schema

Schema for successful response from chat.scheduledMessages.list method

*This model accepts additional fields of type Object.*

## Structure

`ChatScheduledMessagesListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `ResponseMetadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Required | - | ResponseMetadata getResponseMetadata() | setResponseMetadata(ResponseMetadata responseMetadata) |
| `ScheduledMessages` | [`List<ScheduledMessage>`](../../doc/models/scheduled-message.md) | Required | - | List<ScheduledMessage> getScheduledMessages() | setScheduledMessages(List<ScheduledMessage> scheduledMessages) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ChatScheduledMessagesListSchema;
import com.slack.models.ResponseMetadata;
import com.slack.models.ScheduledMessage;
import java.io.IOException;
import java.util.Arrays;

ChatScheduledMessagesListSchema chatScheduledMessagesListSchema = new ChatScheduledMessagesListSchema.Builder(
    "True",
    new ResponseMetadata.Builder(
        "next_cursor2"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    Arrays.asList(
        new ScheduledMessage.Builder(
            "channel_id8",
            100,
            "id2",
            0
        )
        .text("text2")
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


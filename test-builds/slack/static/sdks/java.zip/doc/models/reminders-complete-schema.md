
# Reminders Complete Schema

Schema for successful response from reminders.complete method

*This model accepts additional fields of type Object.*

## Structure

`RemindersCompleteSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.RemindersCompleteSchema;
import java.io.IOException;

RemindersCompleteSchema remindersCompleteSchema = new RemindersCompleteSchema.Builder(
    "True"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


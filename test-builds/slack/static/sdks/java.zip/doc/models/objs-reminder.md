
# Objs Reminder

*This model accepts additional fields of type Object.*

## Structure

`ObjsReminder`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CompleteTs` | `Integer` | Optional | - | Integer getCompleteTs() | setCompleteTs(Integer completeTs) |
| `Creator` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getCreator() | setCreator(String creator) |
| `Id` | `String` | Required | **Constraints**: *Pattern*: `^Rm[A-Z0-9]{8,}$` | String getId() | setId(String id) |
| `Recurring` | `boolean` | Required | - | boolean getRecurring() | setRecurring(boolean recurring) |
| `Text` | `String` | Required | - | String getText() | setText(String text) |
| `Time` | `Integer` | Optional | - | Integer getTime() | setTime(Integer time) |
| `User` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getUser() | setUser(String user) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ObjsReminder;
import java.io.IOException;

ObjsReminder objsReminder = new ObjsReminder.Builder(
    "creator8",
    "id0",
    false,
    "text0",
    "user0"
)
.completeTs(160)
.time(194)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


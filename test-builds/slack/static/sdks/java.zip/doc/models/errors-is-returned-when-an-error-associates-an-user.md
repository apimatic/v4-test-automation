
# Errors Is Returned when an Error Associates an User

*This model accepts additional fields of type Object.*

## Structure

`ErrorsIsReturnedWhenAnErrorAssociatesAnUser`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | [`ConversationsInviteErrorEnum`](../../doc/models/conversations-invite-error-enum.md) | Required | - | ConversationsInviteErrorEnum getError() | setError(ConversationsInviteErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `User` | `String` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getUser() | setUser(String user) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ConversationsInviteErrorEnum;
import com.slack.models.ErrorsIsReturnedWhenAnErrorAssociatesAnUser;
import java.io.IOException;

ErrorsIsReturnedWhenAnErrorAssociatesAnUser errorsIsReturnedWhenAnErrorAssociatesAnUser = new ErrorsIsReturnedWhenAnErrorAssociatesAnUser.Builder(
    ConversationsInviteErrorEnum.USER_NOT_FOUND,
    "False"
)
.user("user2")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


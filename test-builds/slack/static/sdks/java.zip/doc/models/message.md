
# Message

*This model accepts additional fields of type Object.*

## Structure

`Message`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BotId` | `String` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` | String getBotId() | setBotId(String botId) |
| `BotProfile` | [`BotProfileObject`](../../doc/models/bot-profile-object.md) | Optional | - | BotProfileObject getBotProfile() | setBotProfile(BotProfileObject botProfile) |
| `Team` | `String` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | String getTeam() | setTeam(String team) |
| `Text` | `String` | Required | - | String getText() | setText(String text) |
| `Type` | `String` | Required | - | String getType() | setType(String type) |
| `User` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getUser() | setUser(String user) |
| `Username` | `String` | Optional | - | String getUsername() | setUsername(String username) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.BotProfileObject;
import com.slack.models.Icons;
import com.slack.models.Message;
import java.io.IOException;

Message message = new Message.Builder(
    "bot_id6",
    "team0",
    "text0",
    "type0",
    "user0"
)
.botProfile(new BotProfileObject.Builder(
        "app_id8",
        false,
        new Icons.Builder(
            "image_362",
            "image_488",
            "image_722"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
        "id8",
        "name8",
        "team_id8",
        44
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
.username("username0")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


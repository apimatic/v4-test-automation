
# Prefs 1

*This model accepts additional fields of type Object.*

## Structure

`Prefs1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CanThread` | [`CanThread`](../../doc/models/can-thread.md) | Optional | - | CanThread getCanThread() | setCanThread(CanThread canThread) |
| `WhoCanPost` | [`WhoCanPost`](../../doc/models/who-can-post.md) | Optional | - | WhoCanPost getWhoCanPost() | setWhoCanPost(WhoCanPost whoCanPost) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.CanThread;
import com.slack.models.Prefs1;
import com.slack.models.WhoCanPost;
import java.io.IOException;
import java.util.Arrays;

Prefs1 prefs1 = new Prefs1.Builder()
    .canThread(new CanThread.Builder()
        .type(Arrays.asList(
            "type1",
            "type0"
        ))
        .user(Arrays.asList(
            "user6",
            "user7"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .whoCanPost(new WhoCanPost.Builder()
        .type(Arrays.asList(
            "type5",
            "type4"
        ))
        .user(Arrays.asList(
            "user0",
            "user1"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```


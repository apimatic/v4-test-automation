
# Conversations Members Success Schema

Schema for successful response conversations.members method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsMembersSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Members` | `List<String>` | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required*, *Pattern*: `^[UW][A-Z0-9]{2,}$` | List<String> getMembers() | setMembers(List<String> members) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `ResponseMetadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Required | - | ResponseMetadata getResponseMetadata() | setResponseMetadata(ResponseMetadata responseMetadata) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ConversationsMembersSuccessSchema;
import com.slack.models.ResponseMetadata;
import java.io.IOException;
import java.util.Arrays;

ConversationsMembersSuccessSchema conversationsMembersSuccessSchema = new ConversationsMembersSuccessSchema.Builder(
    Arrays.asList(
        "members0",
        "members1"
    ),
    "True",
    new ResponseMetadata.Builder(
        "next_cursor2"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


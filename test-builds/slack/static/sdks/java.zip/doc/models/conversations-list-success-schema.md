
# Conversations List Success Schema

Schema for successful response from conversations.list method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsListSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Channels` | `List<Object>` | Required | **Constraints**: *Unique Items Required* | List<Object> getChannels() | setChannels(List<Object> channels) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `ResponseMetadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - | ResponseMetadata getResponseMetadata() | setResponseMetadata(ResponseMetadata responseMetadata) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ConversationsListSuccessSchema;
import com.slack.models.ResponseMetadata;
import java.io.IOException;
import java.util.Arrays;

ConversationsListSuccessSchema conversationsListSuccessSchema = new ConversationsListSuccessSchema.Builder(
    Arrays.asList(
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
    ),
    "True"
)
.responseMetadata(new ResponseMetadata.Builder(
        "next_cursor2"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


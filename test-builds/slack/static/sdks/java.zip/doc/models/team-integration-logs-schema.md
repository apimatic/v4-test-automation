
# Team Integration Logs Schema

Schema for successful response from team.integrationLogs method

*This model accepts additional fields of type Object.*

## Structure

`TeamIntegrationLogsSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Logs` | [`List<Log>`](../../doc/models/log.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<Log> getLogs() | setLogs(List<Log> logs) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - | PagingObject getPaging() | setPaging(PagingObject paging) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Log;
import com.slack.models.PagingObject;
import com.slack.models.TeamIntegrationLogsSchema;
import java.io.IOException;
import java.util.Arrays;

TeamIntegrationLogsSchema teamIntegrationLogsSchema = new TeamIntegrationLogsSchema.Builder(
    Arrays.asList(
        new Log.Builder(
            "app_id8",
            "app_type2",
            "change_type8",
            "date4",
            "scope6",
            "user_id6",
            "user_name4"
        )
        .adminAppId("admin_app_id6")
        .channel("channel6")
        .serviceId("service_id8")
        .serviceType("service_type4")
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ),
    "True",
    new PagingObject.Builder(
        26,
        6
    )
    .count(56)
    .pages(150)
    .perPage(194)
    .spill(246)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Admin Conversations Search Schema

Schema for successful response of admin.conversations.search

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsSearchSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Channels` | [`List<ChannelObject>`](../../doc/models/channel-object.md) | Required | - | List<ChannelObject> getChannels() | setChannels(List<ChannelObject> channels) |
| `NextCursor` | `String` | Required | - | String getNextCursor() | setNextCursor(String nextCursor) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.AdminConversationsSearchSchema;
import com.slack.models.ChannelObject;
import com.slack.models.Purpose;
import com.slack.models.Topic;
import java.io.IOException;
import java.util.Arrays;

AdminConversationsSearchSchema adminConversationsSearchSchema = new AdminConversationsSearchSchema.Builder(
    Arrays.asList(
        new ChannelObject.Builder(
            90,
            "creator8",
            "id0",
            false,
            false,
            false,
            false,
            false,
            Arrays.asList(
                "members8"
            ),
            "name0",
            "name_normalized8",
            new Purpose.Builder(
                "creator4",
                30,
                "value8"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            new Topic.Builder(
                "creator6",
                242,
                "value0"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
        )
        .acceptedUser("accepted_user8")
        .isArchived(false)
        .isFrozen(false)
        .isGeneral(false)
        .isMember(false)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ),
    "next_cursor4"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Admin Conversations Rename Schema 1

Schema for successful response of admin.conversations.rename

*This model accepts additional fields of type Object.*

## Structure

`AdminConversationsRenameSchema1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.AdminConversationsRenameSchema1;
import java.io.IOException;

AdminConversationsRenameSchema1 adminConversationsRenameSchema1 = new AdminConversationsRenameSchema1.Builder(
    "True"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


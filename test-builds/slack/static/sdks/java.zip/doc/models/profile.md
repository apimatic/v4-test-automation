
# Profile

*This model accepts additional fields of type Object.*

## Structure

`Profile`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Fields` | [`List<ObjsTeamProfileField>`](../../doc/models/objs-team-profile-field.md) | Required | **Constraints**: *Unique Items Required* | List<ObjsTeamProfileField> getFields() | setFields(List<ObjsTeamProfileField> fields) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ObjsTeamProfileField;
import com.slack.models.Profile;
import com.slack.models.Type;
import java.io.IOException;
import java.util.Arrays;

Profile profile = new Profile.Builder(
    Arrays.asList(
        new ObjsTeamProfileField.Builder(
            "hint8",
            "id8",
            "label8",
            158.68D,
            Type.OPTIONS_LIST
        )
        .fieldName("field_name2")
        .isHidden(false)
        .options(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .possibleValues(Arrays.asList(
                "possible_values9",
                "possible_values0"
            ))
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


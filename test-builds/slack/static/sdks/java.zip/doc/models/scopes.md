
# Scopes

*This model accepts additional fields of type Object.*

## Structure

`Scopes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AppHome` | `List<String>` | Optional | - | List<String> getAppHome() | setAppHome(List<String> appHome) |
| `Channel` | `List<String>` | Optional | - | List<String> getChannel() | setChannel(List<String> channel) |
| `Group` | `List<String>` | Optional | - | List<String> getGroup() | setGroup(List<String> group) |
| `Im` | `List<String>` | Optional | - | List<String> getIm() | setIm(List<String> im) |
| `Mpim` | `List<String>` | Optional | - | List<String> getMpim() | setMpim(List<String> mpim) |
| `Team` | `List<String>` | Optional | - | List<String> getTeam() | setTeam(List<String> team) |
| `User` | `List<String>` | Optional | - | List<String> getUser() | setUser(List<String> user) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Scopes;
import java.io.IOException;
import java.util.Arrays;

Scopes scopes = new Scopes.Builder()
    .appHome(Arrays.asList(
        "app_home0",
        "app_home1",
        "app_home2"
    ))
    .channel(Arrays.asList(
        "channel2",
        "channel1"
    ))
    .group(Arrays.asList(
        "group1"
    ))
    .im(Arrays.asList(
        "im1",
        "im2",
        "im3"
    ))
    .mpim(Arrays.asList(
        "mpim2"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```


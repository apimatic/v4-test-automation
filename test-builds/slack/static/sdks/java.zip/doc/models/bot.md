
# Bot

*This model accepts additional fields of type Object.*

## Structure

`Bot`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AppId` | `String` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` | String getAppId() | setAppId(String appId) |
| `Deleted` | `boolean` | Required | - | boolean getDeleted() | setDeleted(boolean deleted) |
| `Icons` | [`Icons`](../../doc/models/icons.md) | Required | - | Icons getIcons() | setIcons(Icons icons) |
| `Id` | `String` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` | String getId() | setId(String id) |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `Updated` | `int` | Required | - | int getUpdated() | setUpdated(int updated) |
| `UserId` | `String` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getUserId() | setUserId(String userId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Bot;
import com.slack.models.Icons;
import java.io.IOException;

Bot bot = new Bot.Builder(
    "app_id0",
    false,
    new Icons.Builder(
        "image_362",
        "image_488",
        "image_722"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    "id6",
    "name6",
    214
)
.userId("user_id4")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


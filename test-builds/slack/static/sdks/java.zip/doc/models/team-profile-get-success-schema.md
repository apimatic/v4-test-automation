
# Team Profile Get Success Schema

Schema for successful response from team.profile.get method

*This model accepts additional fields of type Object.*

## Structure

`TeamProfileGetSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Profile` | [`Profile`](../../doc/models/profile.md) | Required | - | Profile getProfile() | setProfile(Profile profile) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ObjsTeamProfileField;
import com.slack.models.Profile;
import com.slack.models.TeamProfileGetSuccessSchema;
import com.slack.models.Type;
import java.io.IOException;
import java.util.Arrays;

TeamProfileGetSuccessSchema teamProfileGetSuccessSchema = new TeamProfileGetSuccessSchema.Builder(
    "True",
    new Profile.Builder(
        Arrays.asList(
            new ObjsTeamProfileField.Builder(
                "hint8",
                "id8",
                "label8",
                158.68D,
                Type.OPTIONS_LIST
            )
            .fieldName("field_name2")
            .isHidden(false)
            .options(ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .possibleValues(Arrays.asList(
                    "possible_values9",
                    "possible_values0"
                ))
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
        )
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


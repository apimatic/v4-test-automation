
# Usergroups Create Schema

Schema for successful response from usergroups.create method

*This model accepts additional fields of type Object.*

## Structure

`UsergroupsCreateSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Usergroup` | [`SubteamUsergroupObject`](../../doc/models/subteam-usergroup-object.md) | Required | - | SubteamUsergroupObject getUsergroup() | setUsergroup(SubteamUsergroupObject usergroup) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Prefs;
import com.slack.models.SubteamUsergroupObject;
import com.slack.models.UsergroupsCreateSchema;
import java.io.IOException;
import java.util.Arrays;

UsergroupsCreateSchema usergroupsCreateSchema = new UsergroupsCreateSchema.Builder(
    "True",
    new SubteamUsergroupObject.Builder(
        false,
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        "created_by0",
        164,
        212,
        198,
        ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        "description2",
        "enterprise_subteam_id0",
        "handle8",
        "id2",
        false,
        false,
        false,
        "name2",
        new Prefs.Builder(
            Arrays.asList(
                "channels5",
                "channels4"
            ),
            Arrays.asList(
                "groups4",
                "groups5",
                "groups6"
            )
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
        "team_id6",
        "updated_by6"
    )
    .channelCount(64)
    .userCount(70)
    .users(Arrays.asList(
            "users3",
            "users4",
            "users5"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Admin Conversations Convert to Private Error Enum

## Enumeration

`AdminConversationsConvertToPrivateErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `RESTRICTED_ACTION` |
| `NAME_TAKEN` |
| `CHANNEL_NOT_FOUND` |
| `CHANNEL_TYPE_NOT_SUPPORTED` |
| `DEFAULT_ORG_WIDE_CHANNEL` |
| `METHOD_NOT_SUPPORTED_FOR_CHANNEL_TYPE` |
| `COULD_NOT_CONVERT_CHANNEL` |
| `EXTERNAL_CHANNEL_MIGRATING` |

## Example

```java
import com.slack.models.AdminConversationsConvertToPrivateErrorEnum;

AdminConversationsConvertToPrivateErrorEnum adminConversationsConvertToPrivateErrorEnum = AdminConversationsConvertToPrivateErrorEnum.EXTERNAL_CHANNEL_MIGRATING;
```


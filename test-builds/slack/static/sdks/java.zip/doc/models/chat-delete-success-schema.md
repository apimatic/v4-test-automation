
# Chat Delete Success Schema

Schema for successful response of chat.delete method

*This model accepts additional fields of type Object.*

## Structure

`ChatDeleteSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Channel` | `String` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | String getChannel() | setChannel(String channel) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Ts` | `String` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | String getTs() | setTs(String ts) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ChatDeleteSuccessSchema;
import java.io.IOException;

ChatDeleteSuccessSchema chatDeleteSuccessSchema = new ChatDeleteSuccessSchema.Builder(
    "channel6",
    "True",
    "ts0"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


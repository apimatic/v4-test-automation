
# Usergroups Create Error Schema Exception

Schema for error response from usergroups.create method

*This model accepts additional fields of type Object.*

## Structure

`UsergroupsCreateErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`UsergroupsCreateErrorEnum`](../../doc/models/usergroups-create-error-enum.md) | Required | - | UsergroupsCreateErrorEnum getError() | setError(UsergroupsCreateErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (UsergroupsCreateErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


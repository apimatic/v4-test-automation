
# Rtm Connect Schema

Schema for successful response from rtm.connect method

*This model accepts additional fields of type Object.*

## Structure

`RtmConnectSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Self` | [`Self`](../../doc/models/self.md) | Required | - | Self getSelf() | setSelf(Self self) |
| `Team` | [`Team1`](../../doc/models/team-1.md) | Required | - | Team1 getTeam() | setTeam(Team1 team) |
| `Url` | `String` | Required | - | String getUrl() | setUrl(String url) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.RtmConnectSchema;
import com.slack.models.Self;
import com.slack.models.Team1;
import java.io.IOException;

RtmConnectSchema rtmConnectSchema = new RtmConnectSchema.Builder(
    "True",
    new Self.Builder(
        "id8",
        "name8"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    new Team1.Builder(
        "domain6",
        "id0",
        "name0"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    "url2"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Conversations Set Topic Success Schema

Schema for successful response from conversations.setTopic method

*This model accepts additional fields of type Object.*

## Structure

`ConversationsSetTopicSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Channel` | `Object` | Required | - | Object getChannel() | setChannel(Object channel) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ConversationsSetTopicSuccessSchema;
import java.io.IOException;

ConversationsSetTopicSuccessSchema conversationsSetTopicSuccessSchema = new ConversationsSetTopicSuccessSchema.Builder(
    ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    "True"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


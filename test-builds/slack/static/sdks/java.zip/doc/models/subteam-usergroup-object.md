
# Subteam Usergroup Object

*This model accepts additional fields of type Object.*

## Structure

`SubteamUsergroupObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AutoProvision` | `boolean` | Required | - | boolean getAutoProvision() | setAutoProvision(boolean autoProvision) |
| `AutoType` | `Object` | Required | - | Object getAutoType() | setAutoType(Object autoType) |
| `ChannelCount` | `Integer` | Optional | - | Integer getChannelCount() | setChannelCount(Integer channelCount) |
| `CreatedBy` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getCreatedBy() | setCreatedBy(String createdBy) |
| `DateCreate` | `int` | Required | - | int getDateCreate() | setDateCreate(int dateCreate) |
| `DateDelete` | `int` | Required | - | int getDateDelete() | setDateDelete(int dateDelete) |
| `DateUpdate` | `int` | Required | - | int getDateUpdate() | setDateUpdate(int dateUpdate) |
| `DeletedBy` | `Object` | Required | - | Object getDeletedBy() | setDeletedBy(Object deletedBy) |
| `Description` | `String` | Required | - | String getDescription() | setDescription(String description) |
| `EnterpriseSubteamId` | `String` | Required | - | String getEnterpriseSubteamId() | setEnterpriseSubteamId(String enterpriseSubteamId) |
| `Handle` | `String` | Required | - | String getHandle() | setHandle(String handle) |
| `Id` | `String` | Required | **Constraints**: *Pattern*: `^S[A-Z0-9]{2,}$` | String getId() | setId(String id) |
| `IsExternal` | `boolean` | Required | - | boolean getIsExternal() | setIsExternal(boolean isExternal) |
| `IsSubteam` | `boolean` | Required | - | boolean getIsSubteam() | setIsSubteam(boolean isSubteam) |
| `IsUsergroup` | `boolean` | Required | - | boolean getIsUsergroup() | setIsUsergroup(boolean isUsergroup) |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `Prefs` | [`Prefs`](../../doc/models/prefs.md) | Required | - | Prefs getPrefs() | setPrefs(Prefs prefs) |
| `TeamId` | `String` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | String getTeamId() | setTeamId(String teamId) |
| `UpdatedBy` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getUpdatedBy() | setUpdatedBy(String updatedBy) |
| `UserCount` | `Integer` | Optional | - | Integer getUserCount() | setUserCount(Integer userCount) |
| `Users` | `List<String>` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | List<String> getUsers() | setUsers(List<String> users) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Prefs;
import com.slack.models.SubteamUsergroupObject;
import java.io.IOException;
import java.util.Arrays;

SubteamUsergroupObject subteamUsergroupObject = new SubteamUsergroupObject.Builder(
    false,
    ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    "created_by8",
    254,
    46,
    32,
    ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    "description0",
    "enterprise_subteam_id8",
    "handle6",
    "id0",
    false,
    false,
    false,
    "name0",
    new Prefs.Builder(
        Arrays.asList(
            "channels5",
            "channels4"
        ),
        Arrays.asList(
            "groups4",
            "groups5",
            "groups6"
        )
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    "team_id4",
    "updated_by4"
)
.channelCount(154)
.userCount(160)
.users(Arrays.asList(
        "users1",
        "users2",
        "users3"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


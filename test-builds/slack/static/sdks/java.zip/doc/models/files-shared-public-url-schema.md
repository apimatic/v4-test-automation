
# Files Shared Public Url Schema

Schema for successful response from files.sharedPublicURL method

*This model accepts additional fields of type Object.*

## Structure

`FilesSharedPublicUrlSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `File` | [`FileObject`](../../doc/models/file-object.md) | Required | - | FileObject getFile() | setFile(FileObject file) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.FileObject;
import com.slack.models.FilesSharedPublicUrlSchema;
import java.io.IOException;
import java.util.Arrays;

FilesSharedPublicUrlSchema filesSharedPublicUrlSchema = new FilesSharedPublicUrlSchema.Builder(
    new FileObject.Builder()
        .channels(Arrays.asList(
            "channels5",
            "channels4"
        ))
        .commentsCount(56)
        .created(220)
        .dateDelete(118)
        .displayAsBot(false)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
    "True"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


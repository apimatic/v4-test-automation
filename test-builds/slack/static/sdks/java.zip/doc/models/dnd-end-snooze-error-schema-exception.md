
# Dnd End Snooze Error Schema Exception

Schema for error response from dnd.endSnooze method

*This model accepts additional fields of type Object.*

## Structure

`DndEndSnoozeErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`DndEndSnoozeErrorEnum`](../../doc/models/dnd-end-snooze-error-enum.md) | Required | - | DndEndSnoozeErrorEnum getError() | setError(DndEndSnoozeErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (DndEndSnoozeErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


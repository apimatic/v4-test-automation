
# Reminders Info Error Schema Exception

Schema for error response from reminders.info method

*This model accepts additional fields of type Object.*

## Structure

`RemindersInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`RemindersDeleteErrorEnum`](../../doc/models/reminders-delete-error-enum.md) | Required | - | RemindersDeleteErrorEnum getError() | setError(RemindersDeleteErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (RemindersInfoErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


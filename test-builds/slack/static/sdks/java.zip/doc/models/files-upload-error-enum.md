
# Files Upload Error Enum

## Enumeration

`FilesUploadErrorEnum`

## Fields

| Name |
|  --- |
| `POSTING_TO_GENERAL_CHANNEL_DENIED` |
| `INVALID_CHANNEL` |
| `FILE_UPLOADS_DISABLED` |
| `FILE_UPLOADS_EXCEPT_IMAGES_DISABLED` |
| `STORAGE_LIMIT_REACHED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```java
import com.slack.models.FilesUploadErrorEnum;

FilesUploadErrorEnum filesUploadErrorEnum = FilesUploadErrorEnum.NO_PERMISSION;
```


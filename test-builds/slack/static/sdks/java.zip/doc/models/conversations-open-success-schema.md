
# Conversations Open Success Schema

Schema for successful response from conversations.open method when opening channels, ims, mpims

*This model accepts additional fields of type Object.*

## Structure

`ConversationsOpenSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AlreadyOpen` | `Boolean` | Optional | - | Boolean getAlreadyOpen() | setAlreadyOpen(Boolean alreadyOpen) |
| `Channel` | `Object` | Required | - | Object getChannel() | setChannel(Object channel) |
| `NoOp` | `Boolean` | Optional | - | Boolean getNoOp() | setNoOp(Boolean noOp) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ConversationsOpenSuccessSchema;
import java.io.IOException;

ConversationsOpenSuccessSchema conversationsOpenSuccessSchema = new ConversationsOpenSuccessSchema.Builder(
    ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    "True"
)
.alreadyOpen(false)
.noOp(false)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


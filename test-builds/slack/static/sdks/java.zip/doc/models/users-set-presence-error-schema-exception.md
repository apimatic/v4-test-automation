
# Users Set Presence Error Schema Exception

Schema for error response from users.setPresence method

*This model accepts additional fields of type Object.*

## Structure

`UsersSetPresenceErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`UsersSetPresenceErrorEnum`](../../doc/models/users-set-presence-error-enum.md) | Required | - | UsersSetPresenceErrorEnum getError() | setError(UsersSetPresenceErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (UsersSetPresenceErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


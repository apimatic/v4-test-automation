
# Reminders List Schema

Schema for successful response from reminders.list method

*This model accepts additional fields of type Object.*

## Structure

`RemindersListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Reminders` | [`List<ObjsReminder>`](../../doc/models/objs-reminder.md) | Required | - | List<ObjsReminder> getReminders() | setReminders(List<ObjsReminder> reminders) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ObjsReminder;
import com.slack.models.RemindersListSchema;
import java.io.IOException;
import java.util.Arrays;

RemindersListSchema remindersListSchema = new RemindersListSchema.Builder(
    "True",
    Arrays.asList(
        new ObjsReminder.Builder(
            "creator0",
            "id2",
            false,
            "text2",
            "user2"
        )
        .completeTs(28)
        .time(186)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


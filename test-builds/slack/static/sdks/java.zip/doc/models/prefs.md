
# Prefs

*This model accepts additional fields of type Object.*

## Structure

`Prefs`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Channels` | `List<String>` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` | List<String> getChannels() | setChannels(List<String> channels) |
| `Groups` | `List<String>` | Required | **Constraints**: *Pattern*: `^[G][A-Z0-9]{8,}$` | List<String> getGroups() | setGroups(List<String> groups) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Prefs;
import java.io.IOException;
import java.util.Arrays;

Prefs prefs = new Prefs.Builder(
    Arrays.asList(
        "channels5",
        "channels4"
    ),
    Arrays.asList(
        "groups4",
        "groups5",
        "groups6"
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```



# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `TEXT` |
| `DATE` |
| `LINK` |
| `MAILTO` |
| `OPTIONS_LIST` |
| `USER` |

## Example

```java
import com.slack.models.Type;

Type type = Type.LINK;
```


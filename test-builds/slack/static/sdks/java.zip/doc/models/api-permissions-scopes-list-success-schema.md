
# Api Permissions Scopes List Success Schema

Schema for successful response api.permissions.scopes.list method

*This model accepts additional fields of type Object.*

## Structure

`ApiPermissionsScopesListSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Scopes` | [`Scopes`](../../doc/models/scopes.md) | Required | - | Scopes getScopes() | setScopes(Scopes scopes) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ApiPermissionsScopesListSuccessSchema;
import com.slack.models.Scopes;
import java.io.IOException;
import java.util.Arrays;

ApiPermissionsScopesListSuccessSchema apiPermissionsScopesListSuccessSchema = new ApiPermissionsScopesListSuccessSchema.Builder(
    "True",
    new Scopes.Builder()
        .appHome(Arrays.asList(
            "app_home0",
            "app_home1",
            "app_home2"
        ))
        .channel(Arrays.asList(
            "channel2",
            "channel1"
        ))
        .group(Arrays.asList(
            "group1"
        ))
        .im(Arrays.asList(
            "im1",
            "im2",
            "im3"
        ))
        .mpim(Arrays.asList(
            "mpim2"
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


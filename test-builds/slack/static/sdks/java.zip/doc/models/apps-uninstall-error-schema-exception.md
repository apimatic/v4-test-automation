
# Apps Uninstall Error Schema Exception

Schema for error response from apps.uninstall method

*This model accepts additional fields of type Object.*

## Structure

`AppsUninstallErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`AppsUninstallErrorEnum`](../../doc/models/apps-uninstall-error-enum.md) | Required | - | AppsUninstallErrorEnum getError() | setError(AppsUninstallErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (AppsUninstallErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


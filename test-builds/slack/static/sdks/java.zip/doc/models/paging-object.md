
# Paging Object

*This model accepts additional fields of type Object.*

## Structure

`PagingObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Count` | `Integer` | Optional | - | Integer getCount() | setCount(Integer count) |
| `Page` | `int` | Required | - | int getPage() | setPage(int page) |
| `Pages` | `Integer` | Optional | - | Integer getPages() | setPages(Integer pages) |
| `PerPage` | `Integer` | Optional | - | Integer getPerPage() | setPerPage(Integer perPage) |
| `Spill` | `Integer` | Optional | - | Integer getSpill() | setSpill(Integer spill) |
| `Total` | `int` | Required | - | int getTotal() | setTotal(int total) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.PagingObject;
import java.io.IOException;

PagingObject pagingObject = new PagingObject.Builder(
    62,
    42
)
.count(92)
.pages(186)
.perPage(230)
.spill(230)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


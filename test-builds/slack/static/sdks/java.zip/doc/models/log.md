
# Log

*This model accepts additional fields of type Object.*

## Structure

`Log`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AdminAppId` | `String` | Optional | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` | String getAdminAppId() | setAdminAppId(String adminAppId) |
| `AppId` | `String` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` | String getAppId() | setAppId(String appId) |
| `AppType` | `String` | Required | - | String getAppType() | setAppType(String appType) |
| `ChangeType` | `String` | Required | - | String getChangeType() | setChangeType(String changeType) |
| `Channel` | `String` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | String getChannel() | setChannel(String channel) |
| `Date` | `String` | Required | - | String getDate() | setDate(String date) |
| `Scope` | `String` | Required | - | String getScope() | setScope(String scope) |
| `ServiceId` | `String` | Optional | - | String getServiceId() | setServiceId(String serviceId) |
| `ServiceType` | `String` | Optional | - | String getServiceType() | setServiceType(String serviceType) |
| `UserId` | `String` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | String getUserId() | setUserId(String userId) |
| `UserName` | `String` | Required | - | String getUserName() | setUserName(String userName) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Log;
import java.io.IOException;

Log log = new Log.Builder(
    "app_id8",
    "app_type2",
    "change_type8",
    "date6",
    "scope4",
    "user_id6",
    "user_name4"
)
.adminAppId("admin_app_id6")
.channel("channel6")
.serviceId("service_id2")
.serviceType("service_type4")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


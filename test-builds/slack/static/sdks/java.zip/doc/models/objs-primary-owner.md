
# Objs Primary Owner

*This model accepts additional fields of type Object.*

## Structure

`ObjsPrimaryOwner`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Email` | `String` | Required | - | String getEmail() | setEmail(String email) |
| `Id` | `String` | Required | - | String getId() | setId(String id) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ObjsPrimaryOwner;
import java.io.IOException;

ObjsPrimaryOwner objsPrimaryOwner = new ObjsPrimaryOwner.Builder(
    "email4",
    "id2"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


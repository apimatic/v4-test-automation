
# Plan

## Enumeration

`Plan`

## Fields

| Name |
|  --- |
| `STD` |
| `PLUS` |
| `COMPLIANCE` |
| `ENTERPRISE` |

## Example

```java
import com.slack.models.Plan;

Plan plan = Plan.COMPLIANCE;
```


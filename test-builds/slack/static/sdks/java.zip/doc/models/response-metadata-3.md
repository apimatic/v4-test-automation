
# Response Metadata 3

*This model accepts additional fields of type Object.*

## Structure

`ResponseMetadata3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Warnings` | `List<String>` | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<String> getWarnings() | setWarnings(List<String> warnings) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.ResponseMetadata3;
import java.io.IOException;
import java.util.Arrays;

ResponseMetadata3 responseMetadata3 = new ResponseMetadata3.Builder()
    .warnings(Arrays.asList(
        "warnings0"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```



# Reactions Add Error Schema Exception

Schema for error response from reactions.add method

*This model accepts additional fields of type Object.*

## Structure

`ReactionsAddErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Callstack` | `String` | Optional | Note: PHP callstack is only visible in dev/qa | String getCallstack() | setCallstack(String callstack) |
| `Error` | [`ReactionsAddErrorEnum`](../../doc/models/reactions-add-error-enum.md) | Required | - | ReactionsAddErrorEnum getError() | setError(ReactionsAddErrorEnum error) |
| `Ok` | `String` | Required, Constant | **Value**: `"False"` | String getOk() | setOk(String ok) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
try {
    // make the API call
} catch (ReactionsAddErrorSchemaException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```


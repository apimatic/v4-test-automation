
# Team Access Logs Schema

Schema for successful response from team.accessLogs method

*This model accepts additional fields of type Object.*

## Structure

`TeamAccessLogsSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Logins` | [`List<Login>`](../../doc/models/login.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | List<Login> getLogins() | setLogins(List<Login> logins) |
| `Ok` | `String` | Required, Constant | **Value**: `"True"` | String getOk() | setOk(String ok) |
| `Paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - | PagingObject getPaging() | setPaging(PagingObject paging) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.slack.ApiHelper;
import com.slack.models.Login;
import com.slack.models.PagingObject;
import com.slack.models.TeamAccessLogsSchema;
import java.io.IOException;
import java.util.Arrays;

TeamAccessLogsSchema teamAccessLogsSchema = new TeamAccessLogsSchema.Builder(
    Arrays.asList(
        new Login.Builder(
            244,
            "country8",
            108,
            124,
            "ip8",
            "isp4",
            "region0",
            "user_agent6",
            "user_id2",
            "username6"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ),
    "True",
    new PagingObject.Builder(
        26,
        6
    )
    .count(56)
    .pages(150)
    .perPage(194)
    .spill(246)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```


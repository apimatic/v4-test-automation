# Rtm

```java
RtmApi rtmApi = client.getRtmApi();
```

## Class Name

`RtmApi`


# Rtm Connect

Starts a Real Time Messaging session.

API method documentation: [https://api.slack.com/methods/rtm.connect](https://api.slack.com/methods/rtm.connect)

```java
CompletableFuture<ApiResponse<RtmConnectSchema>> rtmConnectAsync(
    final String token,
    final Boolean batchPresenceAware,
    final Boolean presenceSub)
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `String` | Query, Required | Authentication token. Requires scope: `rtm:stream` |
| `batchPresenceAware` | `Boolean` | Query, Optional | Batch presence deliveries via subscription. Enabling changes the shape of `presence_change` events. |
| `presenceSub` | `Boolean` | Query, Optional | Only deliver presence events when requested by subscription |

## Requires scope

### slackAuth

`rtm:stream`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`RtmConnectSchema`](../../doc/models/rtm-connect-schema.md).

## Example Usage

```java
String token = "token6";

rtmApi.rtmConnectAsync(token, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof RtmConnectErrorSchemaException) {
        RtmConnectErrorSchemaException rtmConnectErrorSchemaException = (RtmConnectErrorSchemaException) cause;
        rtmConnectErrorSchemaException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`RtmConnectErrorSchemaException`](../../doc/models/rtm-connect-error-schema-exception.md) |


# Apps Permissions Resources

```java
AppsPermissionsResourcesApi appsPermissionsResourcesApi = client.getAppsPermissionsResourcesApi();
```

## Class Name

`AppsPermissionsResourcesApi`


# Apps Permissions Resources List

Returns list of resource grants this app has on a team.

API method documentation: [https://api.slack.com/methods/apps.permissions.resources.list](https://api.slack.com/methods/apps.permissions.resources.list)

```java
CompletableFuture<ApiResponse<AppsPermissionsResourcesListSuccessSchema>> appsPermissionsResourcesListAsync(
    final String token,
    final String cursor,
    final Integer limit)
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `String` | Query, Required | Authentication token. Requires scope: `none` |
| `cursor` | `String` | Query, Optional | Paginate through collections of data by setting the `cursor` parameter to a `next_cursor` attribute returned by a previous request's `response_metadata`. Default value fetches the first "page" of the collection. |
| `limit` | `Integer` | Query, Optional | The maximum number of items to return. |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Typical successful paginated response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`AppsPermissionsResourcesListSuccessSchema`](../../doc/models/apps-permissions-resources-list-success-schema.md).

## Example Usage

```java
String token = "token6";

appsPermissionsResourcesApi.appsPermissionsResourcesListAsync(token, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof AppsPermissionsResourcesListErrorSchemaException) {
        AppsPermissionsResourcesListErrorSchemaException appsPermissionsResourcesListErrorSchemaException = (AppsPermissionsResourcesListErrorSchemaException) cause;
        appsPermissionsResourcesListErrorSchemaException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AppsPermissionsResourcesListErrorSchemaException`](../../doc/models/apps-permissions-resources-list-error-schema-exception.md) |


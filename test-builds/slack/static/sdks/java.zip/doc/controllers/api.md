# Api

```java
Api api = client.getApi();
```

## Class Name

`Api`


# Api Test

Checks API calling code.

API method documentation: [https://api.slack.com/methods/api.test](https://api.slack.com/methods/api.test)

```java
CompletableFuture<ApiResponse<ApiTestSuccessSchema>> apiTestAsync(
    final String error,
    final String foo)
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `String` | Query, Optional | Error response to return |
| `foo` | `String` | Query, Optional | example property to return |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Standard success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`ApiTestSuccessSchema`](../../doc/models/api-test-success-schema.md).

## Example Usage

```java
api.apiTestAsync(null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ApiTestErrorSchemaException) {
        ApiTestErrorSchemaException apiTestErrorSchemaException = (ApiTestErrorSchemaException) cause;
        apiTestErrorSchemaException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Artificial error response | [`ApiTestErrorSchemaException`](../../doc/models/api-test-error-schema-exception.md) |


# Admin Apps Requests

```java
AdminAppsRequestsApi adminAppsRequestsApi = client.getAdminAppsRequestsApi();
```

## Class Name

`AdminAppsRequestsApi`


# Admin Apps Requests List

List app requests for a team/workspace.

API method documentation: [https://api.slack.com/methods/admin.apps.requests.list](https://api.slack.com/methods/admin.apps.requests.list)

```java
CompletableFuture<ApiResponse<DefaultSuccessTemplate>> adminAppsRequestsListAsync(
    final String token,
    final Integer limit,
    final String cursor,
    final String teamId)
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `String` | Query, Required | Authentication token. Requires scope: `admin.apps:read` |
| `limit` | `Integer` | Query, Optional | The maximum number of items to return. Must be between 1 - 1000 both inclusive. |
| `cursor` | `String` | Query, Optional | Set `cursor` to `next_cursor` returned by the previous call to list items in the next page |
| `teamId` | `String` | Query, Optional | - |

## Requires scope

### slackAuth

`admin.apps:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```java
String token = "token6";

adminAppsRequestsApi.adminAppsRequestsListAsync(token, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof DefaultErrorTemplateException) {
        DefaultErrorTemplateException defaultErrorTemplateException = (DefaultErrorTemplateException) cause;
        defaultErrorTemplateException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


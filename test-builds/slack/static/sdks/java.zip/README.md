
# Getting Started with Slack Web API

## Introduction

One way to interact with the Slack platform is its HTTP RPC-based Web API, a collection of methods requiring OAuth 2.0-based user, bot, or workspace tokens blessed with related OAuth scopes.

Learn more about the Slack Web API: [https://api.slack.com/web](https://api.slack.com/web)

## Install the Package

Install the SDK by adding the following dependency in your project's pom.xml file:

```xml
<dependency>
  <groupId>io.sdks</groupId>
  <artifactId>slack-apimatic-sdk</artifactId>
  <version>1.0.0</version>
</dependency>
```

You can also view the package at:
https://central.sonatype.com/artifact/io.sdks/slack-apimatic-sdk/1.0.0

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |
| loggingConfig | [`Consumer<ApiLoggingConfiguration.Builder>`](doc/api-logging-configuration-builder.md) | Set up Logging Configuration instance. |
| authorizationCodeAuth | [`AuthorizationCodeAuth`](doc/auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```java
import com.slack.Environment;
import com.slack.SlackWebApiClient;
import com.slack.authentication.AuthorizationCodeAuthModel;
import com.slack.exceptions.ApiException;
import com.slack.http.response.ApiResponse;
import com.slack.models.OauthScope;
import com.slack.models.OauthToken;
import java.io.IOException;
import java.util.Arrays;
import org.slf4j.event.Level;

public class Program {
    public static void main(String[] args) {
        SlackWebApiClient client = new SlackWebApiClient.Builder()
            .loggingConfig(builder -> builder
                    .level(Level.DEBUG)
                    .requestConfig(logConfigBuilder -> logConfigBuilder.body(true))
                    .responseConfig(logConfigBuilder -> logConfigBuilder.headers(true)))
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .authorizationCodeAuth(new AuthorizationCodeAuthModel.Builder(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri"
                )
                .oauthScopes(Arrays.asList(
                        OauthScope.ADMIN,
                        OauthScope.ADMIN_APPSREAD
                    ))
                .build())
            .environment(Environment.PRODUCTION)
            .build();

    }
}
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| PRODUCTION | **Default** |

## Authorization

This API uses the following authentication schemes.

* [`slackAuth (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)

## List of APIs

* [Admin Apps](doc/controllers/admin-apps.md)
* [Admin Apps Approved](doc/controllers/admin-apps-approved.md)
* [Admin Apps Requests](doc/controllers/admin-apps-requests.md)
* [Admin Apps Restricted](doc/controllers/admin-apps-restricted.md)
* [Admin Conversations](doc/controllers/admin-conversations.md)
* [Admin Conversations Ekm](doc/controllers/admin-conversations-ekm.md)
* [Admin Conversations Restrict Access](doc/controllers/admin-conversations-restrict-access.md)
* [Admin Emoji](doc/controllers/admin-emoji.md)
* [Admin Invite Requests](doc/controllers/admin-invite-requests.md)
* [Admin Invite Requests Approved](doc/controllers/admin-invite-requests-approved.md)
* [Admin Invite Requests Denied](doc/controllers/admin-invite-requests-denied.md)
* [Admin Teams Admins](doc/controllers/admin-teams-admins.md)
* [Admin Teams](doc/controllers/admin-teams.md)
* [Admin Teams Owners](doc/controllers/admin-teams-owners.md)
* [Admin Teams Settings](doc/controllers/admin-teams-settings.md)
* [Admin Usergroups](doc/controllers/admin-usergroups.md)
* [Admin Users](doc/controllers/admin-users.md)
* [Admin Users Session](doc/controllers/admin-users-session.md)
* [Api](doc/controllers/api.md)
* [Apps Event Authorizations](doc/controllers/apps-event-authorizations.md)
* [Apps Permissions](doc/controllers/apps-permissions.md)
* [Apps Permissions Resources](doc/controllers/apps-permissions-resources.md)
* [Apps Permissions Scopes](doc/controllers/apps-permissions-scopes.md)
* [Apps Permissions Users](doc/controllers/apps-permissions-users.md)
* [Apps](doc/controllers/apps.md)
* [Auth](doc/controllers/auth.md)
* [Bots](doc/controllers/bots.md)
* [Calls](doc/controllers/calls.md)
* [Calls Participants](doc/controllers/calls-participants.md)
* [Chat](doc/controllers/chat.md)
* [Chat Scheduled Messages](doc/controllers/chat-scheduled-messages.md)
* [Conversations](doc/controllers/conversations.md)
* [Dialog](doc/controllers/dialog.md)
* [Dnd](doc/controllers/dnd.md)
* [Emoji](doc/controllers/emoji.md)
* [Files Comments](doc/controllers/files-comments.md)
* [Files](doc/controllers/files.md)
* [Files Remote](doc/controllers/files-remote.md)
* [Migration](doc/controllers/migration.md)
* [oauth](doc/controllers/oauth.md)
* [oauth V2](doc/controllers/oauth-v2.md)
* [Pins](doc/controllers/pins.md)
* [Reactions](doc/controllers/reactions.md)
* [Reminders](doc/controllers/reminders.md)
* [Rtm](doc/controllers/rtm.md)
* [Search](doc/controllers/search.md)
* [Stars](doc/controllers/stars.md)
* [Team](doc/controllers/team.md)
* [Team Profile](doc/controllers/team-profile.md)
* [Usergroups](doc/controllers/usergroups.md)
* [Usergroups Users](doc/controllers/usergroups-users.md)
* [Users](doc/controllers/users.md)
* [Users Profile](doc/controllers/users-profile.md)
* [Views](doc/controllers/views.md)
* [Workflows](doc/controllers/workflows.md)

## SDK Infrastructure

### Configuration

* [ApiLoggingConfiguration](doc/api-logging-configuration.md)
* [ApiLoggingConfiguration.Builder](doc/api-logging-configuration-builder.md)
* [ApiRequestLoggingConfiguration.Builder](doc/api-request-logging-configuration-builder.md)
* [ApiResponseLoggingConfiguration.Builder](doc/api-response-logging-configuration-builder.md)
* [Configuration Interface](doc/configuration-interface.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfiguration.Builder](doc/http-client-configuration-builder.md)
* [HttpProxyConfiguration](doc/http-proxy-configuration.md)
* [HttpProxyConfiguration.Builder](doc/http-proxy-configuration-builder.md)

### HTTP

* [Headers](doc/headers.md)
* [HttpCallback Interface](doc/http-callback-interface.md)
* [HttpContext](doc/http-context.md)
* [HttpBodyRequest](doc/http-body-request.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)

### Utilities

* [ApiException](doc/api-exception.md)
* [ApiResponse](doc/api-response.md)
* [ApiHelper](doc/api-helper.md)
* [FileWrapper](doc/file-wrapper.md)



# Getting Started with Slack Web API

## Introduction

One way to interact with the Slack platform is its HTTP RPC-based Web API, a collection of methods requiring OAuth 2.0-based user, bot, or workspace tokens blessed with related OAuth scopes.

Learn more about the Slack Web API: [https://api.slack.com/web](https://api.slack.com/web)

## Install the Package

Run the following command to install the package and automatically add the dependency to your composer.json file:

```bash
composer require "ai-apimatic/slack-apimatic-sdk:1.0.0"
```

Or add it to the composer.json file manually as given below:

```json
"require": {
    "ai-apimatic/slack-apimatic-sdk": "1.0.0"
}
```

You can also view the package at:
https://packagist.org/packages/ai-apimatic/slack-apimatic-sdk#1.0.0

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| timeout | `int` | Timeout for API calls in seconds.<br>*Default*: `30` |
| enableRetries | `bool` | Whether to enable retries and backoff feature.<br>*Default*: `false` |
| numberOfRetries | `int` | The number of retries to make.<br>*Default*: `0` |
| retryInterval | `float` | The retry time interval between the endpoint calls.<br>*Default*: `1` |
| backOffFactor | `float` | Exponential backoff factor to increase interval between retries.<br>*Default*: `2` |
| maximumRetryWaitTime | `int` | The maximum wait time in seconds for overall retrying requests.<br>*Default*: `0` |
| retryOnTimeout | `bool` | Whether to retry on request timeout.<br>*Default*: `true` |
| httpStatusCodesToRetry | `array` | Http status codes to retry against.<br>*Default*: `408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524` |
| httpMethodsToRetry | `array` | Http methods to retry against.<br>*Default*: `'GET', 'PUT', 'GET', 'PUT'` |
| loggingConfiguration | [`LoggingConfigurationBuilder`](doc/logging-configuration-builder.md) | Represents the logging configurations for API calls |
| proxyConfiguration | [`ProxyConfigurationBuilder`](doc/proxy-configuration-builder.md) | Represents the proxy configurations for API calls |
| authorizationCodeAuth | [`AuthorizationCodeAuth`](doc/auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```php
use SlackWebApiLib\Logging\LoggingConfigurationBuilder;
use SlackWebApiLib\Logging\RequestLoggingConfigurationBuilder;
use SlackWebApiLib\Logging\ResponseLoggingConfigurationBuilder;
use Psr\Log\LogLevel;
use SlackWebApiLib\Environment;
use SlackWebApiLib\Authentication\AuthorizationCodeAuthCredentialsBuilder;
use SlackWebApiLib\Models\OauthScope;
use SlackWebApiLib\SlackWebApiClientBuilder;

$client = SlackWebApiClientBuilder::init()
    ->authorizationCodeAuthCredentials(
        AuthorizationCodeAuthCredentialsBuilder::init(
            'OAuthClientId',
            'OAuthClientSecret',
            'OAuthRedirectUri'
        )
            ->oauthScopes(
                [
                    OauthScope::ADMIN,
                    OauthScope::ADMIN_APPSREAD
                ]
            )
    )
    ->environment(Environment::PRODUCTION)
    ->loggingConfiguration(
        LoggingConfigurationBuilder::init()
            ->level(LogLevel::INFO)
            ->requestConfiguration(RequestLoggingConfigurationBuilder::init()->body(true))
            ->responseConfiguration(ResponseLoggingConfigurationBuilder::init()->headers(true))
    )
    ->build();
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| PRODUCTION | **Default** |

## Authorization

This API uses the following authentication schemes.

* [`slackAuth (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)

## List of APIs

* [Admin Apps](doc/controllers/admin-apps.md)
* [Admin Apps Approved](doc/controllers/admin-apps-approved.md)
* [Admin Apps Requests](doc/controllers/admin-apps-requests.md)
* [Admin Apps Restricted](doc/controllers/admin-apps-restricted.md)
* [Admin Conversations](doc/controllers/admin-conversations.md)
* [Admin Conversations Ekm](doc/controllers/admin-conversations-ekm.md)
* [Admin Conversations Restrict Access](doc/controllers/admin-conversations-restrict-access.md)
* [Admin Emoji](doc/controllers/admin-emoji.md)
* [Admin Invite Requests](doc/controllers/admin-invite-requests.md)
* [Admin Invite Requests Approved](doc/controllers/admin-invite-requests-approved.md)
* [Admin Invite Requests Denied](doc/controllers/admin-invite-requests-denied.md)
* [Admin Teams Admins](doc/controllers/admin-teams-admins.md)
* [Admin Teams](doc/controllers/admin-teams.md)
* [Admin Teams Owners](doc/controllers/admin-teams-owners.md)
* [Admin Teams Settings](doc/controllers/admin-teams-settings.md)
* [Admin Usergroups](doc/controllers/admin-usergroups.md)
* [Admin Users](doc/controllers/admin-users.md)
* [Admin Users Session](doc/controllers/admin-users-session.md)
* [Api](doc/controllers/api.md)
* [Apps Event Authorizations](doc/controllers/apps-event-authorizations.md)
* [Apps Permissions](doc/controllers/apps-permissions.md)
* [Apps Permissions Resources](doc/controllers/apps-permissions-resources.md)
* [Apps Permissions Scopes](doc/controllers/apps-permissions-scopes.md)
* [Apps Permissions Users](doc/controllers/apps-permissions-users.md)
* [Apps](doc/controllers/apps.md)
* [Auth](doc/controllers/auth.md)
* [Bots](doc/controllers/bots.md)
* [Calls](doc/controllers/calls.md)
* [Calls Participants](doc/controllers/calls-participants.md)
* [Chat](doc/controllers/chat.md)
* [Chat Scheduled Messages](doc/controllers/chat-scheduled-messages.md)
* [Conversations](doc/controllers/conversations.md)
* [Dialog](doc/controllers/dialog.md)
* [Dnd](doc/controllers/dnd.md)
* [Emoji](doc/controllers/emoji.md)
* [Files Comments](doc/controllers/files-comments.md)
* [Files](doc/controllers/files.md)
* [Files Remote](doc/controllers/files-remote.md)
* [Migration](doc/controllers/migration.md)
* [oauth](doc/controllers/oauth.md)
* [oauth V2](doc/controllers/oauth-v2.md)
* [Pins](doc/controllers/pins.md)
* [Reactions](doc/controllers/reactions.md)
* [Reminders](doc/controllers/reminders.md)
* [Rtm](doc/controllers/rtm.md)
* [Search](doc/controllers/search.md)
* [Stars](doc/controllers/stars.md)
* [Team](doc/controllers/team.md)
* [Team Profile](doc/controllers/team-profile.md)
* [Usergroups](doc/controllers/usergroups.md)
* [Usergroups Users](doc/controllers/usergroups-users.md)
* [Users](doc/controllers/users.md)
* [Users Profile](doc/controllers/users-profile.md)
* [Views](doc/controllers/views.md)
* [Workflows](doc/controllers/workflows.md)

## SDK Infrastructure

### Configuration

* [ProxyConfigurationBuilder](doc/proxy-configuration-builder.md)
* [LoggingConfigurationBuilder](doc/logging-configuration-builder.md)
* [RequestLoggingConfigurationBuilder](doc/request-logging-configuration-builder.md)
* [ResponseLoggingConfigurationBuilder](doc/response-logging-configuration-builder.md)

### HTTP

* [HttpRequest](doc/http-request.md)

### Utilities

* [ApiResponse](doc/api-response.md)


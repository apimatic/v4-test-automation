
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| timeout | `int` | Timeout for API calls in seconds.<br>*Default*: `30` |
| enableRetries | `bool` | Whether to enable retries and backoff feature.<br>*Default*: `false` |
| numberOfRetries | `int` | The number of retries to make.<br>*Default*: `0` |
| retryInterval | `float` | The retry time interval between the endpoint calls.<br>*Default*: `1` |
| backOffFactor | `float` | Exponential backoff factor to increase interval between retries.<br>*Default*: `2` |
| maximumRetryWaitTime | `int` | The maximum wait time in seconds for overall retrying requests.<br>*Default*: `0` |
| retryOnTimeout | `bool` | Whether to retry on request timeout.<br>*Default*: `true` |
| httpStatusCodesToRetry | `array` | Http status codes to retry against.<br>*Default*: `408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524` |
| httpMethodsToRetry | `array` | Http methods to retry against.<br>*Default*: `'GET', 'PUT', 'GET', 'PUT'` |
| loggingConfiguration | [`LoggingConfigurationBuilder`](../doc/logging-configuration-builder.md) | Represents the logging configurations for API calls |
| proxyConfiguration | [`ProxyConfigurationBuilder`](../doc/proxy-configuration-builder.md) | Represents the proxy configurations for API calls |
| authorizationCodeAuth | [`AuthorizationCodeAuth`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```php
use SlackWebApiLib\Logging\LoggingConfigurationBuilder;
use SlackWebApiLib\Logging\RequestLoggingConfigurationBuilder;
use SlackWebApiLib\Logging\ResponseLoggingConfigurationBuilder;
use Psr\Log\LogLevel;
use SlackWebApiLib\Environment;
use SlackWebApiLib\Authentication\AuthorizationCodeAuthCredentialsBuilder;
use SlackWebApiLib\Models\OauthScope;
use SlackWebApiLib\SlackWebApiClientBuilder;

$client = SlackWebApiClientBuilder::init()
    ->authorizationCodeAuthCredentials(
        AuthorizationCodeAuthCredentialsBuilder::init(
            'OAuthClientId',
            'OAuthClientSecret',
            'OAuthRedirectUri'
        )
            ->oauthScopes(
                [
                    OauthScope::ADMIN,
                    OauthScope::ADMIN_APPSREAD
                ]
            )
    )
    ->environment(Environment::PRODUCTION)
    ->loggingConfiguration(
        LoggingConfigurationBuilder::init()
            ->level(LogLevel::INFO)
            ->requestConfiguration(RequestLoggingConfigurationBuilder::init()->body(true))
            ->responseConfiguration(ResponseLoggingConfigurationBuilder::init()->headers(true))
    )
    ->build();
```

## Slack Web API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| getAdminAppsApi() | Gets AdminAppsApi |
| getAdminAppsApprovedApi() | Gets AdminAppsApprovedApi |
| getAdminAppsRequestsApi() | Gets AdminAppsRequestsApi |
| getAdminAppsRestrictedApi() | Gets AdminAppsRestrictedApi |
| getAdminConversationsApi() | Gets AdminConversationsApi |
| getAdminConversationsEkmApi() | Gets AdminConversationsEkmApi |
| getAdminConversationsRestrictAccessApi() | Gets AdminConversationsRestrictAccessApi |
| getAdminEmojiApi() | Gets AdminEmojiApi |
| getAdminInviteRequestsApi() | Gets AdminInviteRequestsApi |
| getAdminInviteRequestsApprovedApi() | Gets AdminInviteRequestsApprovedApi |
| getAdminInviteRequestsDeniedApi() | Gets AdminInviteRequestsDeniedApi |
| getAdminTeamsAdminsApi() | Gets AdminTeamsAdminsApi |
| getAdminTeamsApi() | Gets AdminTeamsApi |
| getAdminTeamsOwnersApi() | Gets AdminTeamsOwnersApi |
| getAdminTeamsSettingsApi() | Gets AdminTeamsSettingsApi |
| getAdminUsergroupsApi() | Gets AdminUsergroupsApi |
| getAdminUsersApi() | Gets AdminUsersApi |
| getAdminUsersSessionApi() | Gets AdminUsersSessionApi |
| getApi() | Gets Api |
| getAppsEventAuthorizationsApi() | Gets AppsEventAuthorizationsApi |
| getAppsPermissionsApi() | Gets AppsPermissionsApi |
| getAppsPermissionsResourcesApi() | Gets AppsPermissionsResourcesApi |
| getAppsPermissionsScopesApi() | Gets AppsPermissionsScopesApi |
| getAppsPermissionsUsersApi() | Gets AppsPermissionsUsersApi |
| getAppsApi() | Gets AppsApi |
| getAuthApi() | Gets AuthApi |
| getBotsApi() | Gets BotsApi |
| getCallsApi() | Gets CallsApi |
| getCallsParticipantsApi() | Gets CallsParticipantsApi |
| getChatApi() | Gets ChatApi |
| getChatScheduledMessagesApi() | Gets ChatScheduledMessagesApi |
| getConversationsApi() | Gets ConversationsApi |
| getDialogApi() | Gets DialogApi |
| getDndApi() | Gets DndApi |
| getEmojiApi() | Gets EmojiApi |
| getFilesCommentsApi() | Gets FilesCommentsApi |
| getFilesApi() | Gets FilesApi |
| getFilesRemoteApi() | Gets FilesRemoteApi |
| getMigrationApi() | Gets MigrationApi |
| getOauthApi() | Gets OauthApi |
| getOauthV2Api() | Gets OauthV2Api |
| getPinsApi() | Gets PinsApi |
| getReactionsApi() | Gets ReactionsApi |
| getRemindersApi() | Gets RemindersApi |
| getRtmApi() | Gets RtmApi |
| getSearchApi() | Gets SearchApi |
| getStarsApi() | Gets StarsApi |
| getTeamApi() | Gets TeamApi |
| getTeamProfileApi() | Gets TeamProfileApi |
| getUsergroupsApi() | Gets UsergroupsApi |
| getUsergroupsUsersApi() | Gets UsergroupsUsersApi |
| getUsersApi() | Gets UsersApi |
| getUsersProfileApi() | Gets UsersProfileApi |
| getViewsApi() | Gets ViewsApi |
| getWorkflowsApi() | Gets WorkflowsApi |
| getOauthAuthorizationApi() | Gets OauthAuthorizationApi |


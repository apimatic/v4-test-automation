
# Conversations History Success Schema

Schema for successful response from conversations.history method

*This model accepts additional fields of type array.*

## Structure

`ConversationsHistorySuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channelActionsCount` | `int` | Required | - | getChannelActionsCount(): int | setChannelActionsCount(int channelActionsCount): void |
| `channelActionsTs` | `array` | Required | - | getChannelActionsTs(): array | setChannelActionsTs(array channelActionsTs): void |
| `hasMore` | `bool` | Required | - | getHasMore(): bool | setHasMore(bool hasMore): void |
| `messages` | [`MessageObject[]`](../../doc/models/message-object.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | getMessages(): array | setMessages(array messages): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `pinCount` | `int` | Required | - | getPinCount(): int | setPinCount(int pinCount): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ConversationsHistorySuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\MessageObjectBuilder;
use SlackWebApiLib\Models\Builders\AttachmentBuilder;
use SlackWebApiLib\Models\Builders\BlockKitBlockBuilder;
use SlackWebApiLib\Models\Builders\BotProfileObjectBuilder;
use SlackWebApiLib\Models\Builders\IconsBuilder;

$conversationsHistorySuccessSchema = ConversationsHistorySuccessSchemaBuilder::init(
    18,
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
    false,
    [
        MessageObjectBuilder::init(
            'text8',
            'ts0',
            'type8'
        )
            ->attachments(
                [
                    AttachmentBuilder::init(
                        36
                    )
                        ->fallback('fallback4')
                        ->imageBytes(34)
                        ->imageHeight(154)
                        ->imageUrl('image_url6')
                        ->imageWidth(24)
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build(),
                    AttachmentBuilder::init(
                        36
                    )
                        ->fallback('fallback4')
                        ->imageBytes(34)
                        ->imageHeight(154)
                        ->imageUrl('image_url6')
                        ->imageWidth(24)
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build()
                ]
            )
            ->blocks(
                [
                    BlockKitBlockBuilder::init(
                        'type4'
                    )
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build(),
                    BlockKitBlockBuilder::init(
                        'type4'
                    )
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build()
                ]
            )
            ->botId(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->botProfile(
                BotProfileObjectBuilder::init(
                    'app_id8',
                    false,
                    IconsBuilder::init(
                        'image_362',
                        'image_488',
                        'image_722'
                    )
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build(),
                    'id8',
                    'name8',
                    'team_id8',
                    44
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->clientMsgId('client_msg_id4')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ],
    84
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Purpose

*This model accepts additional fields of type array.*

## Structure

`Purpose`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `creator` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{8,}$\|^$` | getCreator(): string | setCreator(string creator): void |
| `lastSet` | `int` | Required | - | getLastSet(): int | setLastSet(int lastSet): void |
| `value` | `string` | Required | - | getValue(): string | setValue(string value): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\PurposeBuilder;
use SlackWebApiLib\ApiHelper;

$purpose = PurposeBuilder::init(
    'creator4',
    30,
    'value8'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


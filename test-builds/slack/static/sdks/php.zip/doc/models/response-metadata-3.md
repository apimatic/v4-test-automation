
# Response Metadata 3

*This model accepts additional fields of type array.*

## Structure

`ResponseMetadata3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `warnings` | `?(string[])` | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | getWarnings(): ?array | setWarnings(?array warnings): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ResponseMetadata3Builder;
use SlackWebApiLib\ApiHelper;

$responseMetadata3 = ResponseMetadata3Builder::init()
    ->warnings(
        [
            'warnings0'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


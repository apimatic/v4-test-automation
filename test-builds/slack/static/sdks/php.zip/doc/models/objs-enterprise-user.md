
# Objs Enterprise User

*This model accepts additional fields of type array.*

## Structure

`ObjsEnterpriseUser`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `enterpriseId` | `string` | Required | **Constraints**: *Pattern*: `^[E][A-Z0-9]{8,}$` | getEnterpriseId(): string | setEnterpriseId(string enterpriseId): void |
| `enterpriseName` | `string` | Required | - | getEnterpriseName(): string | setEnterpriseName(string enterpriseName): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^[WU][A-Z0-9]{8,}$` | getId(): string | setId(string id): void |
| `isAdmin` | `bool` | Required | - | getIsAdmin(): bool | setIsAdmin(bool isAdmin): void |
| `isOwner` | `bool` | Required | - | getIsOwner(): bool | setIsOwner(bool isOwner): void |
| `teams` | `string[]` | Required | **Constraints**: *Unique Items Required*, *Pattern*: `^[T][A-Z0-9]{2,}$` | getTeams(): array | setTeams(array teams): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ObjsEnterpriseUserBuilder;
use SlackWebApiLib\ApiHelper;

$objsEnterpriseUser = ObjsEnterpriseUserBuilder::init(
    'enterprise_id2',
    'enterprise_name8',
    'id2',
    false,
    false,
    [
        'teams3',
        'teams2'
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


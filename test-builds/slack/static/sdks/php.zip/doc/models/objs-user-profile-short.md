
# Objs User Profile Short

*This model accepts additional fields of type array.*

## Structure

`ObjsUserProfileShort`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `avatarHash` | `string` | Required | - | getAvatarHash(): string | setAvatarHash(string avatarHash): void |
| `displayName` | `string` | Required | - | getDisplayName(): string | setDisplayName(string displayName): void |
| `displayNameNormalized` | `?string` | Optional | - | getDisplayNameNormalized(): ?string | setDisplayNameNormalized(?string displayNameNormalized): void |
| `firstName` | `?string` | Required | - | getFirstName(): ?string | setFirstName(?string firstName): void |
| `image72` | `string` | Required | - | getImage72(): string | setImage72(string image72): void |
| `isRestricted` | `bool` | Required | - | getIsRestricted(): bool | setIsRestricted(bool isRestricted): void |
| `isUltraRestricted` | `bool` | Required | - | getIsUltraRestricted(): bool | setIsUltraRestricted(bool isUltraRestricted): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `realName` | `string` | Required | - | getRealName(): string | setRealName(string realName): void |
| `realNameNormalized` | `?string` | Optional | - | getRealNameNormalized(): ?string | setRealNameNormalized(?string realNameNormalized): void |
| `team` | `string` | Required | **Constraints**: *Pattern*: `^[TE][A-Z0-9]{8,}$` | getTeam(): string | setTeam(string team): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ObjsUserProfileShortBuilder;
use SlackWebApiLib\ApiHelper;

$objsUserProfileShort = ObjsUserProfileShortBuilder::init(
    'avatar_hash2',
    'display_name2',
    'image_726',
    false,
    false,
    'name2',
    'real_name8',
    'team8'
)
    ->displayNameNormalized('display_name_normalized2')
    ->firstName('first_name2')
    ->realNameNormalized('real_name_normalized4')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Prefs 1

*This model accepts additional fields of type array.*

## Structure

`Prefs1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `canThread` | [`?CanThread`](../../doc/models/can-thread.md) | Optional | - | getCanThread(): ?CanThread | setCanThread(?CanThread canThread): void |
| `whoCanPost` | [`?WhoCanPost`](../../doc/models/who-can-post.md) | Optional | - | getWhoCanPost(): ?WhoCanPost | setWhoCanPost(?WhoCanPost whoCanPost): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\Prefs1Builder;
use SlackWebApiLib\Models\Builders\CanThreadBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\WhoCanPostBuilder;

$prefs1 = Prefs1Builder::init()
    ->canThread(
        CanThreadBuilder::init()
            ->type(
                [
                    'type1',
                    'type0'
                ]
            )
            ->user(
                [
                    'user6',
                    'user7'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->whoCanPost(
        WhoCanPostBuilder::init()
            ->type(
                [
                    'type5',
                    'type4'
                ]
            )
            ->user(
                [
                    'user0',
                    'user1'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


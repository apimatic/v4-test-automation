
# Default Success Template

This method either only returns a brief _OK_ response or a verbose schema is not available for this method.

*This model accepts additional fields of type array.*

## Structure

`DefaultSuccessTemplate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\DefaultSuccessTemplateBuilder;
use SlackWebApiLib\ApiHelper;

$defaultSuccessTemplate = DefaultSuccessTemplateBuilder::init()
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Objs Icon

*This model accepts additional fields of type array.*

## Structure

`ObjsIcon`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `image102` | `?string` | Optional | - | getImage102(): ?string | setImage102(?string image102): void |
| `image132` | `?string` | Optional | - | getImage132(): ?string | setImage132(?string image132): void |
| `image230` | `?string` | Optional | - | getImage230(): ?string | setImage230(?string image230): void |
| `image34` | `?string` | Optional | - | getImage34(): ?string | setImage34(?string image34): void |
| `image44` | `?string` | Optional | - | getImage44(): ?string | setImage44(?string image44): void |
| `image68` | `?string` | Optional | - | getImage68(): ?string | setImage68(?string image68): void |
| `image88` | `?string` | Optional | - | getImage88(): ?string | setImage88(?string image88): void |
| `imageDefault` | `?bool` | Optional | - | getImageDefault(): ?bool | setImageDefault(?bool imageDefault): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ObjsIconBuilder;
use SlackWebApiLib\ApiHelper;

$objsIcon = ObjsIconBuilder::init()
    ->image102('image_1024')
    ->image132('image_1322')
    ->image230('image_2308')
    ->image34('image_346')
    ->image44('image_446')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


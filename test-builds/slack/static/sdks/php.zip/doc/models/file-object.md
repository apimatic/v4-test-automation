
# File Object

*This model accepts additional fields of type array.*

## Structure

`FileObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channels` | `?(string[])` | Optional | **Constraints**: *Unique Items Required*, *Pattern*: `^[C][A-Z0-9]{2,}$` | getChannels(): ?array | setChannels(?array channels): void |
| `commentsCount` | `?int` | Optional | - | getCommentsCount(): ?int | setCommentsCount(?int commentsCount): void |
| `created` | `?int` | Optional | - | getCreated(): ?int | setCreated(?int created): void |
| `dateDelete` | `?int` | Optional | - | getDateDelete(): ?int | setDateDelete(?int dateDelete): void |
| `displayAsBot` | `?bool` | Optional | - | getDisplayAsBot(): ?bool | setDisplayAsBot(?bool displayAsBot): void |
| `editable` | `?bool` | Optional | - | getEditable(): ?bool | setEditable(?bool editable): void |
| `editor` | `?string` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getEditor(): ?string | setEditor(?string editor): void |
| `externalId` | `?string` | Optional | - | getExternalId(): ?string | setExternalId(?string externalId): void |
| `externalType` | `?string` | Optional | - | getExternalType(): ?string | setExternalType(?string externalType): void |
| `externalUrl` | `?string` | Optional | - | getExternalUrl(): ?string | setExternalUrl(?string externalUrl): void |
| `filetype` | `?string` | Optional | - | getFiletype(): ?string | setFiletype(?string filetype): void |
| `groups` | `?(string[])` | Optional | **Constraints**: *Unique Items Required*, *Pattern*: `^[G][A-Z0-9]{8,}$` | getGroups(): ?array | setGroups(?array groups): void |
| `hasRichPreview` | `?bool` | Optional | - | getHasRichPreview(): ?bool | setHasRichPreview(?bool hasRichPreview): void |
| `id` | `?string` | Optional | **Constraints**: *Pattern*: `^[F][A-Z0-9]{8,}$` | getId(): ?string | setId(?string id): void |
| `imageExifRotation` | `?int` | Optional | - | getImageExifRotation(): ?int | setImageExifRotation(?int imageExifRotation): void |
| `ims` | `?(string[])` | Optional | **Constraints**: *Unique Items Required*, *Pattern*: `^[D][A-Z0-9]{8,}$` | getIms(): ?array | setIms(?array ims): void |
| `isExternal` | `?bool` | Optional | - | getIsExternal(): ?bool | setIsExternal(?bool isExternal): void |
| `isPublic` | `?bool` | Optional | - | getIsPublic(): ?bool | setIsPublic(?bool isPublic): void |
| `isStarred` | `?bool` | Optional | - | getIsStarred(): ?bool | setIsStarred(?bool isStarred): void |
| `isTombstoned` | `?bool` | Optional | - | getIsTombstoned(): ?bool | setIsTombstoned(?bool isTombstoned): void |
| `lastEditor` | `?string` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getLastEditor(): ?string | setLastEditor(?string lastEditor): void |
| `mimetype` | `?string` | Optional | - | getMimetype(): ?string | setMimetype(?string mimetype): void |
| `mode` | `?string` | Optional | - | getMode(): ?string | setMode(?string mode): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `nonOwnerEditable` | `?bool` | Optional | - | getNonOwnerEditable(): ?bool | setNonOwnerEditable(?bool nonOwnerEditable): void |
| `numStars` | `?int` | Optional | - | getNumStars(): ?int | setNumStars(?int numStars): void |
| `originalH` | `?int` | Optional | - | getOriginalH(): ?int | setOriginalH(?int originalH): void |
| `originalW` | `?int` | Optional | - | getOriginalW(): ?int | setOriginalW(?int originalW): void |
| `permalink` | `?string` | Optional | - | getPermalink(): ?string | setPermalink(?string permalink): void |
| `permalinkPublic` | `?string` | Optional | - | getPermalinkPublic(): ?string | setPermalinkPublic(?string permalinkPublic): void |
| `pinnedInfo` | `?array` | Optional | - | getPinnedInfo(): ?array | setPinnedInfo(?array pinnedInfo): void |
| `pinnedTo` | `?(string[])` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | getPinnedTo(): ?array | setPinnedTo(?array pinnedTo): void |
| `prettyType` | `?string` | Optional | - | getPrettyType(): ?string | setPrettyType(?string prettyType): void |
| `preview` | `?string` | Optional | - | getPreview(): ?string | setPreview(?string preview): void |
| `publicUrlShared` | `?bool` | Optional | - | getPublicUrlShared(): ?bool | setPublicUrlShared(?bool publicUrlShared): void |
| `reactions` | [`?(ReactionObject[])`](../../doc/models/reaction-object.md) | Optional | - | getReactions(): ?array | setReactions(?array reactions): void |
| `shares` | [`?Shares`](../../doc/models/shares.md) | Optional | - | getShares(): ?Shares | setShares(?Shares shares): void |
| `size` | `?int` | Optional | - | getSize(): ?int | setSize(?int size): void |
| `sourceTeam` | `?string` | Optional | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | getSourceTeam(): ?string | setSourceTeam(?string sourceTeam): void |
| `state` | `?string` | Optional | - | getState(): ?string | setState(?string state): void |
| `thumb1024` | `?string` | Optional | - | getThumb1024(): ?string | setThumb1024(?string thumb1024): void |
| `thumb1024H` | `?int` | Optional | - | getThumb1024H(): ?int | setThumb1024H(?int thumb1024H): void |
| `thumb1024W` | `?int` | Optional | - | getThumb1024W(): ?int | setThumb1024W(?int thumb1024W): void |
| `thumb160` | `?string` | Optional | - | getThumb160(): ?string | setThumb160(?string thumb160): void |
| `thumb360` | `?string` | Optional | - | getThumb360(): ?string | setThumb360(?string thumb360): void |
| `thumb360H` | `?int` | Optional | - | getThumb360H(): ?int | setThumb360H(?int thumb360H): void |
| `thumb360W` | `?int` | Optional | - | getThumb360W(): ?int | setThumb360W(?int thumb360W): void |
| `thumb480` | `?string` | Optional | - | getThumb480(): ?string | setThumb480(?string thumb480): void |
| `thumb480H` | `?int` | Optional | - | getThumb480H(): ?int | setThumb480H(?int thumb480H): void |
| `thumb480W` | `?int` | Optional | - | getThumb480W(): ?int | setThumb480W(?int thumb480W): void |
| `thumb64` | `?string` | Optional | - | getThumb64(): ?string | setThumb64(?string thumb64): void |
| `thumb720` | `?string` | Optional | - | getThumb720(): ?string | setThumb720(?string thumb720): void |
| `thumb720H` | `?int` | Optional | - | getThumb720H(): ?int | setThumb720H(?int thumb720H): void |
| `thumb720W` | `?int` | Optional | - | getThumb720W(): ?int | setThumb720W(?int thumb720W): void |
| `thumb80` | `?string` | Optional | - | getThumb80(): ?string | setThumb80(?string thumb80): void |
| `thumb800` | `?string` | Optional | - | getThumb800(): ?string | setThumb800(?string thumb800): void |
| `thumb800H` | `?int` | Optional | - | getThumb800H(): ?int | setThumb800H(?int thumb800H): void |
| `thumb800W` | `?int` | Optional | - | getThumb800W(): ?int | setThumb800W(?int thumb800W): void |
| `thumb960` | `?string` | Optional | - | getThumb960(): ?string | setThumb960(?string thumb960): void |
| `thumb960H` | `?int` | Optional | - | getThumb960H(): ?int | setThumb960H(?int thumb960H): void |
| `thumb960W` | `?int` | Optional | - | getThumb960W(): ?int | setThumb960W(?int thumb960W): void |
| `thumbTiny` | `?string` | Optional | - | getThumbTiny(): ?string | setThumbTiny(?string thumbTiny): void |
| `timestamp` | `?int` | Optional | - | getTimestamp(): ?int | setTimestamp(?int timestamp): void |
| `title` | `?string` | Optional | - | getTitle(): ?string | setTitle(?string title): void |
| `updated` | `?int` | Optional | - | getUpdated(): ?int | setUpdated(?int updated): void |
| `urlPrivate` | `?string` | Optional | - | getUrlPrivate(): ?string | setUrlPrivate(?string urlPrivate): void |
| `urlPrivateDownload` | `?string` | Optional | - | getUrlPrivateDownload(): ?string | setUrlPrivateDownload(?string urlPrivateDownload): void |
| `user` | `?string` | Optional | - | getUser(): ?string | setUser(?string user): void |
| `userTeam` | `?string` | Optional | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | getUserTeam(): ?string | setUserTeam(?string userTeam): void |
| `username` | `?string` | Optional | - | getUsername(): ?string | setUsername(?string username): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\FileObjectBuilder;
use SlackWebApiLib\ApiHelper;

$fileObject = FileObjectBuilder::init()
    ->channels(
        [
            'channels5',
            'channels6'
        ]
    )
    ->commentsCount(132)
    ->created(40)
    ->dateDelete(194)
    ->displayAsBot(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


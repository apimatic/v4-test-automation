
# Conversations Close Success Schema

Schema for successful response conversations.close method

*This model accepts additional fields of type array.*

## Structure

`ConversationsCloseSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `alreadyClosed` | `?bool` | Optional | - | getAlreadyClosed(): ?bool | setAlreadyClosed(?bool alreadyClosed): void |
| `noOp` | `?bool` | Optional | - | getNoOp(): ?bool | setNoOp(?bool noOp): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ConversationsCloseSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$conversationsCloseSuccessSchema = ConversationsCloseSuccessSchemaBuilder::init()
    ->alreadyClosed(false)
    ->noOp(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


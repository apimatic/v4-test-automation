
# Users Info Error Schema Exception

Schema for error response from users.info method

*This model accepts additional fields of type array.*

## Structure

`UsersInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callstack` | `?string` | Optional | - | getCallstack(): ?string | setCallstack(?string callstack): void |
| `error` | [`string(UsersInfoErrorEnum)`](../../doc/models/users-info-error-enum.md) | Required | - | getError(): string | setError(string error): void |
| `ok` | `string` | Required, Constant | **Value**: `'False'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |



# Dnd End Snooze Error Enum

## Enumeration

`DndEndSnoozeErrorEnum`

## Fields

| Name |
|  --- |
| `SNOOZE_NOT_ACTIVE` |
| `SNOOZE_END_FAILED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `USER_IS_BOT` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```php
use SlackWebApiLib\Models\DndEndSnoozeErrorEnum;

$dndEndSnoozeErrorEnum = DndEndSnoozeErrorEnum::NO_PERMISSION;
```


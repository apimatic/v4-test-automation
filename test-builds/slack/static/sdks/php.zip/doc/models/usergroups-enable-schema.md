
# Usergroups Enable Schema

Schema for successful response from usergroups.enable method

*This model accepts additional fields of type array.*

## Structure

`UsergroupsEnableSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `usergroup` | [`SubteamUsergroupObject`](../../doc/models/subteam-usergroup-object.md) | Required | - | getUsergroup(): SubteamUsergroupObject | setUsergroup(SubteamUsergroupObject usergroup): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\UsergroupsEnableSchemaBuilder;
use SlackWebApiLib\Models\Builders\SubteamUsergroupObjectBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\PrefsBuilder;

$usergroupsEnableSchema = UsergroupsEnableSchemaBuilder::init(
    SubteamUsergroupObjectBuilder::init(
        false,
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
        'created_by0',
        164,
        212,
        198,
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
        'description2',
        'enterprise_subteam_id0',
        'handle8',
        'id2',
        false,
        false,
        false,
        'name2',
        PrefsBuilder::init(
            [
                'channels5',
                'channels4'
            ],
            [
                'groups4',
                'groups5',
                'groups6'
            ]
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build(),
        'team_id6',
        'updated_by6'
    )
        ->channelCount(64)
        ->userCount(70)
        ->users(
            [
                'users3',
                'users4',
                'users5'
            ]
        )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Who Can Post

*This model accepts additional fields of type array.*

## Structure

`WhoCanPost`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?(string[])` | Optional | - | getType(): ?array | setType(?array type): void |
| `user` | `?(string[])` | Optional | - | getUser(): ?array | setUser(?array user): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\WhoCanPostBuilder;
use SlackWebApiLib\ApiHelper;

$whoCanPost = WhoCanPostBuilder::init()
    ->type(
        [
            'type7'
        ]
    )
    ->user(
        [
            'user2',
            'user3',
            'user4'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


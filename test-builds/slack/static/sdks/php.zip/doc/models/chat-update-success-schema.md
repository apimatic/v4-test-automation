
# Chat Update Success Schema

Schema for successful response of chat.update method

*This model accepts additional fields of type array.*

## Structure

`ChatUpdateSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channel` | `string` | Required | - | getChannel(): string | setChannel(string channel): void |
| `message` | [`MessageObject1`](../../doc/models/message-object-1.md) | Required | - | getMessage(): MessageObject1 | setMessage(MessageObject1 message): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `text` | `string` | Required | - | getText(): string | setText(string text): void |
| `ts` | `string` | Required | - | getTs(): string | setTs(string ts): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ChatUpdateSuccessSchemaBuilder;
use SlackWebApiLib\Models\Builders\MessageObject1Builder;
use SlackWebApiLib\ApiHelper;

$chatUpdateSuccessSchema = ChatUpdateSuccessSchemaBuilder::init(
    'channel2',
    MessageObject1Builder::init(
        'text0'
    )
        ->attachments(
            [
                ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
            ]
        )
        ->blocks(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    'text2',
    'ts4'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


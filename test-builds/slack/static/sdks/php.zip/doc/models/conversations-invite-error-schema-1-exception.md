
# Conversations Invite Error Schema 1 Exception

Schema for error response from conversations.invite method

*This model accepts additional fields of type array.*

## Structure

`ConversationsInviteErrorSchema1Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callstack` | `?string` | Optional | Note: PHP callstack is only visible in dev/qa | getCallstack(): ?string | setCallstack(?string callstack): void |
| `error` | [`?string(ConversationsInviteErrorEnum)`](../../doc/models/conversations-invite-error-enum.md) | Optional | - | getError(): ?string | setError(?string error): void |
| `errors` | [`?(ErrorsIsReturnedWhenAnErrorAssociatesAnUser[])`](../../doc/models/errors-is-returned-when-an-error-associates-an-user.md) | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | getErrors(): ?array | setErrors(?array errors): void |
| `needed` | `?string` | Optional | - | getNeeded(): ?string | setNeeded(?string needed): void |
| `ok` | `string` | Required, Constant | **Value**: `'False'` | getOk(): string | setOk(string ok): void |
| `provided` | `?string` | Optional | - | getProvided(): ?string | setProvided(?string provided): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |


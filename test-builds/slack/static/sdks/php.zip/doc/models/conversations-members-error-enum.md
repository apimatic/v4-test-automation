
# Conversations Members Error Enum

## Enumeration

`ConversationsMembersErrorEnum`

## Fields

| Name |
|  --- |
| `CHANNEL_NOT_FOUND` |
| `INVALID_LIMIT` |
| `INVALID_CURSOR` |
| `FETCH_MEMBERS_FAILED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```php
use SlackWebApiLib\Models\ConversationsMembersErrorEnum;

$conversationsMembersErrorEnum = ConversationsMembersErrorEnum::INVALID_CURSOR;
```


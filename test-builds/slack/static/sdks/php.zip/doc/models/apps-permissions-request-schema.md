
# Apps Permissions Request Schema

Schema for successful response from apps.permissions.request method

*This model accepts additional fields of type array.*

## Structure

`AppsPermissionsRequestSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AppsPermissionsRequestSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$appsPermissionsRequestSchema = AppsPermissionsRequestSchemaBuilder::init()
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


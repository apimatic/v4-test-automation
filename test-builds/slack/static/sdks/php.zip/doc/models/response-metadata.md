
# Response Metadata

*This model accepts additional fields of type array.*

## Structure

`ResponseMetadata`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `nextCursor` | `string` | Required | - | getNextCursor(): string | setNextCursor(string nextCursor): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ResponseMetadataBuilder;
use SlackWebApiLib\ApiHelper;

$responseMetadata = ResponseMetadataBuilder::init(
    'next_cursor8'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


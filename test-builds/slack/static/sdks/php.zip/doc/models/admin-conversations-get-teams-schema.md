
# Admin Conversations Get Teams Schema

Schema for successful response of admin.conversations.getTeams

*This model accepts additional fields of type array.*

## Structure

`AdminConversationsGetTeamsSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `responseMetadata` | [`?ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - | getResponseMetadata(): ?ResponseMetadata | setResponseMetadata(?ResponseMetadata responseMetadata): void |
| `teamIds` | `string[]` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | getTeamIds(): array | setTeamIds(array teamIds): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AdminConversationsGetTeamsSchemaBuilder;
use SlackWebApiLib\Models\Builders\ResponseMetadataBuilder;
use SlackWebApiLib\ApiHelper;

$adminConversationsGetTeamsSchema = AdminConversationsGetTeamsSchemaBuilder::init(
    [
        'team_ids1',
        'team_ids2',
        'team_ids3'
    ]
)
    ->responseMetadata(
        ResponseMetadataBuilder::init(
            'next_cursor2'
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Conversations Rename Success Schema

Schema for successful response from conversations.rename method

*This model accepts additional fields of type array.*

## Structure

`ConversationsRenameSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channel` | `array` | Required | - | getChannel(): array | setChannel(array channel): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ConversationsRenameSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$conversationsRenameSuccessSchema = ConversationsRenameSuccessSchemaBuilder::init(
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


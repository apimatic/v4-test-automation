
# Paging Object

*This model accepts additional fields of type array.*

## Structure

`PagingObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `count` | `?int` | Optional | - | getCount(): ?int | setCount(?int count): void |
| `page` | `int` | Required | - | getPage(): int | setPage(int page): void |
| `pages` | `?int` | Optional | - | getPages(): ?int | setPages(?int pages): void |
| `perPage` | `?int` | Optional | - | getPerPage(): ?int | setPerPage(?int perPage): void |
| `spill` | `?int` | Optional | - | getSpill(): ?int | setSpill(?int spill): void |
| `total` | `int` | Required | - | getTotal(): int | setTotal(int total): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\PagingObjectBuilder;
use SlackWebApiLib\ApiHelper;

$pagingObject = PagingObjectBuilder::init(
    62,
    42
)
    ->count(92)
    ->pages(186)
    ->perPage(230)
    ->spill(230)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Users Set Photo Error Schema Exception

Schema for error response from users.setPhoto method

*This model accepts additional fields of type array.*

## Structure

`UsersSetPhotoErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callstack` | `?string` | Optional | Note: PHP callstack is only visible in dev/qa | getCallstack(): ?string | setCallstack(?string callstack): void |
| `debugStep` | `?string` | Optional | possibly DEV/QA only | getDebugStep(): ?string | setDebugStep(?string debugStep): void |
| `dims` | `?string` | Optional | possibly DEV/QA only | getDims(): ?string | setDims(?string dims): void |
| `error` | [`string(UsersSetPhotoErrorEnum)`](../../doc/models/users-set-photo-error-enum.md) | Required | - | getError(): string | setError(string error): void |
| `ok` | `string` | Required, Constant | **Value**: `'False'` | getOk(): string | setOk(string ok): void |
| `timeIdent` | `?int` | Optional | possibly DEV/QA only | getTimeIdent(): ?int | setTimeIdent(?int timeIdent): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |


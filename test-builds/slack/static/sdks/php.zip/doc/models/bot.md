
# Bot

*This model accepts additional fields of type array.*

## Structure

`Bot`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appId` | `string` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` | getAppId(): string | setAppId(string appId): void |
| `deleted` | `bool` | Required | - | getDeleted(): bool | setDeleted(bool deleted): void |
| `icons` | [`Icons`](../../doc/models/icons.md) | Required | - | getIcons(): Icons | setIcons(Icons icons): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` | getId(): string | setId(string id): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `updated` | `int` | Required | - | getUpdated(): int | setUpdated(int updated): void |
| `userId` | `?string` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUserId(): ?string | setUserId(?string userId): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\BotBuilder;
use SlackWebApiLib\Models\Builders\IconsBuilder;
use SlackWebApiLib\ApiHelper;

$bot = BotBuilder::init(
    'app_id0',
    false,
    IconsBuilder::init(
        'image_362',
        'image_488',
        'image_722'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    'id6',
    'name6',
    214
)
    ->userId('user_id4')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


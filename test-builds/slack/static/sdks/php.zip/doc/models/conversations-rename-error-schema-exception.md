
# Conversations Rename Error Schema Exception

Schema for error response from conversations.rename method

*This model accepts additional fields of type array.*

## Structure

`ConversationsRenameErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callstack` | `?string` | Optional | Note: PHP callstack is only visible in dev/qa | getCallstack(): ?string | setCallstack(?string callstack): void |
| `error` | [`string(ConversationsRenameErrorEnum)`](../../doc/models/conversations-rename-error-enum.md) | Required | - | getError(): string | setError(string error): void |
| `needed` | `?string` | Optional | - | getNeeded(): ?string | setNeeded(?string needed): void |
| `ok` | `string` | Required, Constant | **Value**: `'False'` | getOk(): string | setOk(string ok): void |
| `provided` | `?string` | Optional | - | getProvided(): ?string | setProvided(?string provided): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |



# Bot Profile Object

*This model accepts additional fields of type array.*

## Structure

`BotProfileObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appId` | `string` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` | getAppId(): string | setAppId(string appId): void |
| `deleted` | `bool` | Required | - | getDeleted(): bool | setDeleted(bool deleted): void |
| `icons` | [`Icons`](../../doc/models/icons.md) | Required | - | getIcons(): Icons | setIcons(Icons icons): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` | getId(): string | setId(string id): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `teamId` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | getTeamId(): string | setTeamId(string teamId): void |
| `updated` | `int` | Required | - | getUpdated(): int | setUpdated(int updated): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\BotProfileObjectBuilder;
use SlackWebApiLib\Models\Builders\IconsBuilder;
use SlackWebApiLib\ApiHelper;

$botProfileObject = BotProfileObjectBuilder::init(
    'app_id4',
    false,
    IconsBuilder::init(
        'image_362',
        'image_488',
        'image_722'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    'id2',
    'name2',
    'team_id6',
    114
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Apps Permissions Resources List Success Schema

Schema for successful response apps.permissions.resources.list method

*This model accepts additional fields of type array.*

## Structure

`AppsPermissionsResourcesListSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `resources` | [`Resource2[]`](../../doc/models/resource-2.md) | Required | - | getResources(): array | setResources(array resources): void |
| `responseMetadata` | [`?ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - | getResponseMetadata(): ?ResponseMetadata | setResponseMetadata(?ResponseMetadata responseMetadata): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AppsPermissionsResourcesListSuccessSchemaBuilder;
use SlackWebApiLib\Models\Builders\Resource2Builder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\ResponseMetadataBuilder;

$appsPermissionsResourcesListSuccessSchema = AppsPermissionsResourcesListSuccessSchemaBuilder::init(
    [
        Resource2Builder::init()
            ->id('id0')
            ->type('type0')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->responseMetadata(
        ResponseMetadataBuilder::init(
            'next_cursor2'
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


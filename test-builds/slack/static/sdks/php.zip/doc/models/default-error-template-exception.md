
# Default Error Template Exception

This method either only returns a brief _not OK_ response or a verbose schema is not available for this method.

*This model accepts additional fields of type array.*

## Structure

`DefaultErrorTemplateException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'False'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |


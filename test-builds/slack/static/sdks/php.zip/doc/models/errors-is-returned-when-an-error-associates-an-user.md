
# Errors Is Returned when an Error Associates an User

*This model accepts additional fields of type array.*

## Structure

`ErrorsIsReturnedWhenAnErrorAssociatesAnUser`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `error` | [`string(ConversationsInviteErrorEnum)`](../../doc/models/conversations-invite-error-enum.md) | Required | - | getError(): string | setError(string error): void |
| `ok` | `string` | Required, Constant | **Value**: `'False'` | getOk(): string | setOk(string ok): void |
| `user` | `?string` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUser(): ?string | setUser(?string user): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ErrorsIsReturnedWhenAnErrorAssociatesAnUserBuilder;
use SlackWebApiLib\Models\ConversationsInviteErrorEnum;
use SlackWebApiLib\ApiHelper;

$errorsIsReturnedWhenAnErrorAssociatesAnUser = ErrorsIsReturnedWhenAnErrorAssociatesAnUserBuilder::init(
    ConversationsInviteErrorEnum::USER_NOT_FOUND
)
    ->user('user2')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


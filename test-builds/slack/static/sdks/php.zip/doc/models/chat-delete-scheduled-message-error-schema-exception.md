
# Chat Delete Scheduled Message Error Schema Exception

Schema for error response from chat.deleteScheduledMessage method

*This model accepts additional fields of type array.*

## Structure

`ChatDeleteScheduledMessageErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callstack` | `?string` | Optional | Note: PHP callstack is only visible in dev/qa | getCallstack(): ?string | setCallstack(?string callstack): void |
| `error` | [`string(ChatDeleteScheduledMessageErrorEnum)`](../../doc/models/chat-delete-scheduled-message-error-enum.md) | Required | - | getError(): string | setError(string error): void |
| `ok` | `string` | Required, Constant | **Value**: `'False'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |


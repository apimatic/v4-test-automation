
# Profile

*This model accepts additional fields of type array.*

## Structure

`Profile`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `fields` | [`ObjsTeamProfileField[]`](../../doc/models/objs-team-profile-field.md) | Required | **Constraints**: *Unique Items Required* | getFields(): array | setFields(array fields): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ProfileBuilder;
use SlackWebApiLib\Models\Builders\ObjsTeamProfileFieldBuilder;
use SlackWebApiLib\Models\Type;
use SlackWebApiLib\ApiHelper;

$profile = ProfileBuilder::init(
    [
        ObjsTeamProfileFieldBuilder::init(
            'hint8',
            'id8',
            'label8',
            158.68,
            Type::OPTIONS_LIST
        )
            ->fieldName('field_name2')
            ->isHidden(false)
            ->options(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->possibleValues(
                [
                    'possible_values9',
                    'possible_values0'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


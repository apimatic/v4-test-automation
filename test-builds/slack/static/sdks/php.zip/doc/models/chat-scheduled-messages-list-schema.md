
# Chat Scheduled Messages List Schema

Schema for successful response from chat.scheduledMessages.list method

*This model accepts additional fields of type array.*

## Structure

`ChatScheduledMessagesListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `responseMetadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Required | - | getResponseMetadata(): ResponseMetadata | setResponseMetadata(ResponseMetadata responseMetadata): void |
| `scheduledMessages` | [`ScheduledMessage[]`](../../doc/models/scheduled-message.md) | Required | - | getScheduledMessages(): array | setScheduledMessages(array scheduledMessages): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ChatScheduledMessagesListSchemaBuilder;
use SlackWebApiLib\Models\Builders\ResponseMetadataBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\ScheduledMessageBuilder;

$chatScheduledMessagesListSchema = ChatScheduledMessagesListSchemaBuilder::init(
    ResponseMetadataBuilder::init(
        'next_cursor2'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    [
        ScheduledMessageBuilder::init(
            'channel_id8',
            100,
            'id2',
            0
        )
            ->text('text2')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


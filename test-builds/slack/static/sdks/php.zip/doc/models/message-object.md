
# Message Object

*This model accepts additional fields of type array.*

## Structure

`MessageObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `attachments` | [`?(Attachment[])`](../../doc/models/attachment.md) | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | getAttachments(): ?array | setAttachments(?array attachments): void |
| `blocks` | [`?(BlockKitBlock[])`](../../doc/models/block-kit-block.md) | Optional | This is a very loose definition, in the future, we'll populate this with deeper schema in this definition namespace. | getBlocks(): ?array | setBlocks(?array blocks): void |
| `botId` | `?array` | Optional | - | getBotId(): ?array | setBotId(?array botId): void |
| `botProfile` | [`?BotProfileObject`](../../doc/models/bot-profile-object.md) | Optional | - | getBotProfile(): ?BotProfileObject | setBotProfile(?BotProfileObject botProfile): void |
| `clientMsgId` | `?string` | Optional | - | getClientMsgId(): ?string | setClientMsgId(?string clientMsgId): void |
| `comment` | [`?FileCommentObject`](../../doc/models/file-comment-object.md) | Optional | - | getComment(): ?FileCommentObject | setComment(?FileCommentObject comment): void |
| `displayAsBot` | `?bool` | Optional | - | getDisplayAsBot(): ?bool | setDisplayAsBot(?bool displayAsBot): void |
| `file` | [`?FileObject`](../../doc/models/file-object.md) | Optional | - | getFile(): ?FileObject | setFile(?FileObject file): void |
| `files` | [`?(FileObject[])`](../../doc/models/file-object.md) | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | getFiles(): ?array | setFiles(?array files): void |
| `icons` | [`?Icons1`](../../doc/models/icons-1.md) | Optional | - | getIcons(): ?Icons1 | setIcons(?Icons1 icons): void |
| `inviter` | `?string` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getInviter(): ?string | setInviter(?string inviter): void |
| `isDelayedMessage` | `?bool` | Optional | - | getIsDelayedMessage(): ?bool | setIsDelayedMessage(?bool isDelayedMessage): void |
| `isIntro` | `?bool` | Optional | - | getIsIntro(): ?bool | setIsIntro(?bool isIntro): void |
| `isStarred` | `?bool` | Optional | - | getIsStarred(): ?bool | setIsStarred(?bool isStarred): void |
| `lastRead` | `?string` | Optional | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | getLastRead(): ?string | setLastRead(?string lastRead): void |
| `latestReply` | `?string` | Optional | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | getLatestReply(): ?string | setLatestReply(?string latestReply): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `oldName` | `?string` | Optional | - | getOldName(): ?string | setOldName(?string oldName): void |
| `parentUserId` | `?string` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getParentUserId(): ?string | setParentUserId(?string parentUserId): void |
| `permalink` | `?string` | Optional | - | getPermalink(): ?string | setPermalink(?string permalink): void |
| `pinnedTo` | `?(string[])` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | getPinnedTo(): ?array | setPinnedTo(?array pinnedTo): void |
| `purpose` | `?string` | Optional | - | getPurpose(): ?string | setPurpose(?string purpose): void |
| `reactions` | [`?(ReactionObject[])`](../../doc/models/reaction-object.md) | Optional | - | getReactions(): ?array | setReactions(?array reactions): void |
| `replyCount` | `?int` | Optional | - | getReplyCount(): ?int | setReplyCount(?int replyCount): void |
| `replyUsers` | `?(string[])` | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required*, *Pattern*: `^[UW][A-Z0-9]{2,}$` | getReplyUsers(): ?array | setReplyUsers(?array replyUsers): void |
| `replyUsersCount` | `?int` | Optional | - | getReplyUsersCount(): ?int | setReplyUsersCount(?int replyUsersCount): void |
| `sourceTeam` | `?string` | Optional | **Constraints**: *Pattern*: `^[TE][A-Z0-9]{8,}$` | getSourceTeam(): ?string | setSourceTeam(?string sourceTeam): void |
| `subscribed` | `?bool` | Optional | - | getSubscribed(): ?bool | setSubscribed(?bool subscribed): void |
| `subtype` | `?string` | Optional | - | getSubtype(): ?string | setSubtype(?string subtype): void |
| `team` | `?string` | Optional | **Constraints**: *Pattern*: `^[TE][A-Z0-9]{8,}$` | getTeam(): ?string | setTeam(?string team): void |
| `text` | `string` | Required | - | getText(): string | setText(string text): void |
| `threadTs` | `?string` | Optional | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | getThreadTs(): ?string | setThreadTs(?string threadTs): void |
| `topic` | `?string` | Optional | - | getTopic(): ?string | setTopic(?string topic): void |
| `ts` | `string` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | getTs(): string | setTs(string ts): void |
| `type` | `string` | Required | - | getType(): string | setType(string type): void |
| `unreadCount` | `?int` | Optional | - | getUnreadCount(): ?int | setUnreadCount(?int unreadCount): void |
| `upload` | `?bool` | Optional | - | getUpload(): ?bool | setUpload(?bool upload): void |
| `user` | `?string` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUser(): ?string | setUser(?string user): void |
| `userProfile` | [`?ObjsUserProfileShort`](../../doc/models/objs-user-profile-short.md) | Optional | - | getUserProfile(): ?ObjsUserProfileShort | setUserProfile(?ObjsUserProfileShort userProfile): void |
| `userTeam` | `?string` | Optional | **Constraints**: *Pattern*: `^[TE][A-Z0-9]{8,}$` | getUserTeam(): ?string | setUserTeam(?string userTeam): void |
| `username` | `?string` | Optional | - | getUsername(): ?string | setUsername(?string username): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\MessageObjectBuilder;
use SlackWebApiLib\Models\Builders\AttachmentBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\BlockKitBlockBuilder;
use SlackWebApiLib\Models\Builders\BotProfileObjectBuilder;
use SlackWebApiLib\Models\Builders\IconsBuilder;

$messageObject = MessageObjectBuilder::init(
    'text2',
    'ts4',
    'type2'
)
    ->attachments(
        [
            AttachmentBuilder::init(
                36
            )
                ->fallback('fallback4')
                ->imageBytes(34)
                ->imageHeight(154)
                ->imageUrl('image_url6')
                ->imageWidth(24)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            AttachmentBuilder::init(
                36
            )
                ->fallback('fallback4')
                ->imageBytes(34)
                ->imageHeight(154)
                ->imageUrl('image_url6')
                ->imageWidth(24)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->blocks(
        [
            BlockKitBlockBuilder::init(
                'type4'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            BlockKitBlockBuilder::init(
                'type4'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->botId(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->botProfile(
        BotProfileObjectBuilder::init(
            'app_id8',
            false,
            IconsBuilder::init(
                'image_362',
                'image_488',
                'image_722'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            'id8',
            'name8',
            'team_id8',
            44
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->clientMsgId('client_msg_id8')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Auth Test Success Schema

Schema for successful response auth.test method

*This model accepts additional fields of type array.*

## Structure

`AuthTestSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `botId` | `?string` | Optional | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` | getBotId(): ?string | setBotId(?string botId): void |
| `isEnterpriseInstall` | `?bool` | Optional | - | getIsEnterpriseInstall(): ?bool | setIsEnterpriseInstall(?bool isEnterpriseInstall): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `team` | `string` | Required | - | getTeam(): string | setTeam(string team): void |
| `teamId` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | getTeamId(): string | setTeamId(string teamId): void |
| `url` | `string` | Required | - | getUrl(): string | setUrl(string url): void |
| `user` | `string` | Required | - | getUser(): string | setUser(string user): void |
| `userId` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUserId(): string | setUserId(string userId): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AuthTestSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$authTestSuccessSchema = AuthTestSuccessSchemaBuilder::init(
    'team6',
    'team_id8',
    'url8',
    'user4',
    'user_id2'
)
    ->botId('bot_id2')
    ->isEnterpriseInstall(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


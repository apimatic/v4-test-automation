
# Topic

*This model accepts additional fields of type array.*

## Structure

`Topic`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `creator` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{8,}$\|^$` | getCreator(): string | setCreator(string creator): void |
| `lastSet` | `int` | Required | - | getLastSet(): int | setLastSet(int lastSet): void |
| `value` | `string` | Required | - | getValue(): string | setValue(string value): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\TopicBuilder;
use SlackWebApiLib\ApiHelper;

$topic = TopicBuilder::init(
    'creator6',
    242,
    'value0'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


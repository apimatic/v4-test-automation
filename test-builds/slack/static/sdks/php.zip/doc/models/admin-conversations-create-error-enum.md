
# Admin Conversations Create Error Enum

## Enumeration

`AdminConversationsCreateErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `NAME_TAKEN` |
| `RESTRICTED_ACTION` |
| `TEAM_NOT_FOUND` |
| `INVALID_TEAM` |
| `INVALID_NAME` |
| `COULD_NOT_CREATE_CHANNEL` |
| `TEAM_ID_OR_ORG_REQUIRED` |

## Example

```php
use SlackWebApiLib\Models\AdminConversationsCreateErrorEnum;

$adminConversationsCreateErrorEnum = AdminConversationsCreateErrorEnum::FEATURE_NOT_ENABLED;
```


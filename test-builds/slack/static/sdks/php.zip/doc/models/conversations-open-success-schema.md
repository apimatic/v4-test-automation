
# Conversations Open Success Schema

Schema for successful response from conversations.open method when opening channels, ims, mpims

*This model accepts additional fields of type array.*

## Structure

`ConversationsOpenSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `alreadyOpen` | `?bool` | Optional | - | getAlreadyOpen(): ?bool | setAlreadyOpen(?bool alreadyOpen): void |
| `channel` | `array` | Required | - | getChannel(): array | setChannel(array channel): void |
| `noOp` | `?bool` | Optional | - | getNoOp(): ?bool | setNoOp(?bool noOp): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ConversationsOpenSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$conversationsOpenSuccessSchema = ConversationsOpenSuccessSchemaBuilder::init(
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
)
    ->alreadyOpen(false)
    ->noOp(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


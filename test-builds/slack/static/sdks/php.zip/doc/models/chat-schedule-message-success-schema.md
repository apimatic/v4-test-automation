
# Chat Schedule Message Success Schema

Schema for successful response of chat.scheduleMessage method

*This model accepts additional fields of type array.*

## Structure

`ChatScheduleMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channel` | `string` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | getChannel(): string | setChannel(string channel): void |
| `message` | [`Message`](../../doc/models/message.md) | Required | - | getMessage(): Message | setMessage(Message message): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `postAt` | `int` | Required | - | getPostAt(): int | setPostAt(int postAt): void |
| `scheduledMessageId` | `string` | Required | **Constraints**: *Pattern*: `^[Q][A-Z0-9]{8,}$` | getScheduledMessageId(): string | setScheduledMessageId(string scheduledMessageId): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ChatScheduleMessageSuccessSchemaBuilder;
use SlackWebApiLib\Models\Builders\MessageBuilder;
use SlackWebApiLib\Models\Builders\BotProfileObjectBuilder;
use SlackWebApiLib\Models\Builders\IconsBuilder;
use SlackWebApiLib\ApiHelper;

$chatScheduleMessageSuccessSchema = ChatScheduleMessageSuccessSchemaBuilder::init(
    'channel0',
    MessageBuilder::init(
        'bot_id6',
        'team0',
        'text0',
        'type0',
        'user0'
    )
        ->botProfile(
            BotProfileObjectBuilder::init(
                'app_id8',
                false,
                IconsBuilder::init(
                    'image_362',
                    'image_488',
                    'image_722'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build(),
                'id8',
                'name8',
                'team_id8',
                44
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
        ->username('username0')
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    76,
    'scheduled_message_id6'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


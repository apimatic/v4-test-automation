
# Message Object 1

*This model accepts additional fields of type array.*

## Structure

`MessageObject1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `attachments` | `?(array[])` | Optional | - | getAttachments(): ?array | setAttachments(?array attachments): void |
| `blocks` | `?array` | Optional | - | getBlocks(): ?array | setBlocks(?array blocks): void |
| `text` | `string` | Required | - | getText(): string | setText(string text): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\MessageObject1Builder;
use SlackWebApiLib\ApiHelper;

$messageObject1 = MessageObject1Builder::init(
    'text0'
)
    ->attachments(
        [
            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
        ]
    )
    ->blocks(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


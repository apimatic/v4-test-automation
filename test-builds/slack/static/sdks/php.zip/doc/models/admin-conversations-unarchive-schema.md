
# Admin Conversations Unarchive Schema

Schema for successful response of admin.conversations.unarchive

*This model accepts additional fields of type array.*

## Structure

`AdminConversationsUnarchiveSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AdminConversationsUnarchiveSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$adminConversationsUnarchiveSchema = AdminConversationsUnarchiveSchemaBuilder::init()
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Chat Me Message Error Enum

## Enumeration

`ChatMeMessageErrorEnum`

## Fields

| Name |
|  --- |
| `CHANNEL_NOT_FOUND` |
| `NOT_IN_CHANNEL` |
| `IS_ARCHIVED` |
| `MSG_TOO_LONG` |
| `NO_TEXT` |
| `RATE_LIMITED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```php
use SlackWebApiLib\Models\ChatMeMessageErrorEnum;

$chatMeMessageErrorEnum = ChatMeMessageErrorEnum::IS_ARCHIVED;
```


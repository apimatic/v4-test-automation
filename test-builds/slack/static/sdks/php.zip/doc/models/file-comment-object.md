
# File Comment Object

*This model accepts additional fields of type array.*

## Structure

`FileCommentObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `comment` | `string` | Required | - | getComment(): string | setComment(string comment): void |
| `created` | `int` | Required | - | getCreated(): int | setCreated(int created): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^Fc[A-Z0-9]{8,}$` | getId(): string | setId(string id): void |
| `isIntro` | `bool` | Required | - | getIsIntro(): bool | setIsIntro(bool isIntro): void |
| `isStarred` | `?bool` | Optional | - | getIsStarred(): ?bool | setIsStarred(?bool isStarred): void |
| `numStars` | `?int` | Optional | - | getNumStars(): ?int | setNumStars(?int numStars): void |
| `pinnedInfo` | `?array` | Optional | - | getPinnedInfo(): ?array | setPinnedInfo(?array pinnedInfo): void |
| `pinnedTo` | `?(string[])` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | getPinnedTo(): ?array | setPinnedTo(?array pinnedTo): void |
| `reactions` | [`?(ReactionObject[])`](../../doc/models/reaction-object.md) | Optional | - | getReactions(): ?array | setReactions(?array reactions): void |
| `timestamp` | `int` | Required | - | getTimestamp(): int | setTimestamp(int timestamp): void |
| `user` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUser(): string | setUser(string user): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\FileCommentObjectBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\ReactionObjectBuilder;

$fileCommentObject = FileCommentObjectBuilder::init(
    'comment4',
    72,
    'id2',
    false,
    50,
    'user2'
)
    ->isStarred(false)
    ->numStars(40)
    ->pinnedInfo(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->pinnedTo(
        [
            'pinned_to0',
            'pinned_to1',
            'pinned_to2'
        ]
    )
    ->reactions(
        [
            ReactionObjectBuilder::init(
                208,
                'name8',
                [
                    'users5',
                    'users6',
                    'users7'
                ]
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


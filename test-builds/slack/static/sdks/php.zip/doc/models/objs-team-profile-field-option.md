
# Objs Team Profile Field Option

*This model accepts additional fields of type array.*

## Structure

`ObjsTeamProfileFieldOption`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `isCustom` | `?bool` | Optional | - | getIsCustom(): ?bool | setIsCustom(?bool isCustom): void |
| `isMultipleEntry` | `?bool` | Optional | - | getIsMultipleEntry(): ?bool | setIsMultipleEntry(?bool isMultipleEntry): void |
| `isProtected` | `?bool` | Optional | - | getIsProtected(): ?bool | setIsProtected(?bool isProtected): void |
| `isScim` | `?bool` | Optional | - | getIsScim(): ?bool | setIsScim(?bool isScim): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ObjsTeamProfileFieldOptionBuilder;
use SlackWebApiLib\ApiHelper;

$objsTeamProfileFieldOption = ObjsTeamProfileFieldOptionBuilder::init()
    ->isCustom(false)
    ->isMultipleEntry(false)
    ->isProtected(false)
    ->isScim(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


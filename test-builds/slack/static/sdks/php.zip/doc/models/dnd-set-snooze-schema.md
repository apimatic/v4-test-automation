
# Dnd Set Snooze Schema

Schema for successful response from dnd.setSnooze method

*This model accepts additional fields of type array.*

## Structure

`DndSetSnoozeSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `snoozeEnabled` | `bool` | Required | - | getSnoozeEnabled(): bool | setSnoozeEnabled(bool snoozeEnabled): void |
| `snoozeEndtime` | `int` | Required | - | getSnoozeEndtime(): int | setSnoozeEndtime(int snoozeEndtime): void |
| `snoozeRemaining` | `int` | Required | - | getSnoozeRemaining(): int | setSnoozeRemaining(int snoozeRemaining): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\DndSetSnoozeSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$dndSetSnoozeSchema = DndSetSnoozeSchemaBuilder::init(
    false,
    60,
    60
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


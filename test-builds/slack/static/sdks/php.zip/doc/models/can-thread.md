
# Can Thread

*This model accepts additional fields of type array.*

## Structure

`CanThread`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?(string[])` | Optional | - | getType(): ?array | setType(?array type): void |
| `user` | `?(string[])` | Optional | - | getUser(): ?array | setUser(?array user): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\CanThreadBuilder;
use SlackWebApiLib\ApiHelper;

$canThread = CanThreadBuilder::init()
    ->type(
        [
            'type3'
        ]
    )
    ->user(
        [
            'user8',
            'user9',
            'user0'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


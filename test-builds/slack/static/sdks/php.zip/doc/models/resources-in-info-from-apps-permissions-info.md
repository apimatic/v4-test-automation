
# Resources in Info from Apps Permissions Info

*This model accepts additional fields of type array.*

## Structure

`ResourcesInInfoFromAppsPermissionsInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `excludedIds` | `?(array[])` | Optional | - | getExcludedIds(): ?array | setExcludedIds(?array excludedIds): void |
| `ids` | `array[]` | Required | - | getIds(): array | setIds(array ids): void |
| `wildcard` | `?bool` | Optional | - | getWildcard(): ?bool | setWildcard(?bool wildcard): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ResourcesInInfoFromAppsPermissionsInfoBuilder;
use SlackWebApiLib\ApiHelper;

$resourcesInInfoFromAppsPermissionsInfo = ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
    [
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
    ]
)
    ->excludedIds(
        [
            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
        ]
    )
    ->wildcard(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


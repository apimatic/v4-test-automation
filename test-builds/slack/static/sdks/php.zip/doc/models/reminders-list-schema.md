
# Reminders List Schema

Schema for successful response from reminders.list method

*This model accepts additional fields of type array.*

## Structure

`RemindersListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `reminders` | [`ObjsReminder[]`](../../doc/models/objs-reminder.md) | Required | - | getReminders(): array | setReminders(array reminders): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\RemindersListSchemaBuilder;
use SlackWebApiLib\Models\Builders\ObjsReminderBuilder;
use SlackWebApiLib\ApiHelper;

$remindersListSchema = RemindersListSchemaBuilder::init(
    [
        ObjsReminderBuilder::init(
            'creator0',
            'id2',
            false,
            'text2',
            'user2'
        )
            ->completeTs(28)
            ->time(186)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


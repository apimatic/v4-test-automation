
# Stars List Schema

Schema for successful response from stars.list method

*This model accepts additional fields of type array.*

## Structure

`StarsListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | `array[]` | Required | - | getItems(): array | setItems(array items): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `paging` | [`?PagingObject`](../../doc/models/paging-object.md) | Optional | - | getPaging(): ?PagingObject | setPaging(?PagingObject paging): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\StarsListSchemaBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\PagingObjectBuilder;

$starsListSchema = StarsListSchemaBuilder::init(
    [
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
    ]
)
    ->paging(
        PagingObjectBuilder::init(
            26,
            6
        )
            ->count(56)
            ->pages(150)
            ->perPage(194)
            ->spill(246)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


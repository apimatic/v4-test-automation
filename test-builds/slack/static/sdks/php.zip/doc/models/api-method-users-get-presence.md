
# Api Method Users Get Presence

Generated from users.getPresence with shasum e7251aec575d8863f9e0eb38663ae9dc26655f65

*This model accepts additional fields of type array.*

## Structure

`ApiMethodUsersGetPresence`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `autoAway` | `?bool` | Optional | - | getAutoAway(): ?bool | setAutoAway(?bool autoAway): void |
| `connectionCount` | `?int` | Optional | - | getConnectionCount(): ?int | setConnectionCount(?int connectionCount): void |
| `lastActivity` | `?int` | Optional | - | getLastActivity(): ?int | setLastActivity(?int lastActivity): void |
| `manualAway` | `?bool` | Optional | - | getManualAway(): ?bool | setManualAway(?bool manualAway): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `online` | `?bool` | Optional | - | getOnline(): ?bool | setOnline(?bool online): void |
| `presence` | `string` | Required | - | getPresence(): string | setPresence(string presence): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ApiMethodUsersGetPresenceBuilder;
use SlackWebApiLib\ApiHelper;

$apiMethodUsersGetPresence = ApiMethodUsersGetPresenceBuilder::init(
    'presence6'
)
    ->autoAway(false)
    ->connectionCount(60)
    ->lastActivity(184)
    ->manualAway(false)
    ->online(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


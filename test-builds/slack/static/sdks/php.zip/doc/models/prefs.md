
# Prefs

*This model accepts additional fields of type array.*

## Structure

`Prefs`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channels` | `string[]` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` | getChannels(): array | setChannels(array channels): void |
| `groups` | `string[]` | Required | **Constraints**: *Pattern*: `^[G][A-Z0-9]{8,}$` | getGroups(): array | setGroups(array groups): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\PrefsBuilder;
use SlackWebApiLib\ApiHelper;

$prefs = PrefsBuilder::init(
    [
        'channels5',
        'channels4'
    ],
    [
        'groups4',
        'groups5',
        'groups6'
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


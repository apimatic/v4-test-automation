
# Admin Conversations Search Schema

Schema for successful response of admin.conversations.search

*This model accepts additional fields of type array.*

## Structure

`AdminConversationsSearchSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channels` | [`ChannelObject[]`](../../doc/models/channel-object.md) | Required | - | getChannels(): array | setChannels(array channels): void |
| `nextCursor` | `string` | Required | - | getNextCursor(): string | setNextCursor(string nextCursor): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AdminConversationsSearchSchemaBuilder;
use SlackWebApiLib\Models\Builders\ChannelObjectBuilder;
use SlackWebApiLib\Models\Builders\PurposeBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\TopicBuilder;

$adminConversationsSearchSchema = AdminConversationsSearchSchemaBuilder::init(
    [
        ChannelObjectBuilder::init(
            90,
            'creator8',
            'id0',
            false,
            false,
            false,
            false,
            false,
            [
                'members8'
            ],
            'name0',
            'name_normalized8',
            PurposeBuilder::init(
                'creator4',
                30,
                'value8'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            TopicBuilder::init(
                'creator6',
                242,
                'value0'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
            ->acceptedUser('accepted_user8')
            ->isArchived(false)
            ->isFrozen(false)
            ->isGeneral(false)
            ->isMember(false)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ],
    'next_cursor4'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


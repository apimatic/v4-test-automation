
# Dnd Info Schema

Schema for successful response from dnd.info method

*This model accepts additional fields of type array.*

## Structure

`DndInfoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dndEnabled` | `bool` | Required | - | getDndEnabled(): bool | setDndEnabled(bool dndEnabled): void |
| `nextDndEndTs` | `int` | Required | - | getNextDndEndTs(): int | setNextDndEndTs(int nextDndEndTs): void |
| `nextDndStartTs` | `int` | Required | - | getNextDndStartTs(): int | setNextDndStartTs(int nextDndStartTs): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `snoozeEnabled` | `?bool` | Optional | - | getSnoozeEnabled(): ?bool | setSnoozeEnabled(?bool snoozeEnabled): void |
| `snoozeEndtime` | `?int` | Optional | - | getSnoozeEndtime(): ?int | setSnoozeEndtime(?int snoozeEndtime): void |
| `snoozeRemaining` | `?int` | Optional | - | getSnoozeRemaining(): ?int | setSnoozeRemaining(?int snoozeRemaining): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\DndInfoSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$dndInfoSchema = DndInfoSchemaBuilder::init(
    false,
    132,
    204
)
    ->snoozeEnabled(false)
    ->snoozeEndtime(102)
    ->snoozeRemaining(102)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


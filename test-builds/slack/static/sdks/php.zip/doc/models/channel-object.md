
# Channel Object

*This model accepts additional fields of type array.*

## Structure

`ChannelObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `acceptedUser` | `?string` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getAcceptedUser(): ?string | setAcceptedUser(?string acceptedUser): void |
| `created` | `int` | Required | - | getCreated(): int | setCreated(int created): void |
| `creator` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getCreator(): string | setCreator(string creator): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` | getId(): string | setId(string id): void |
| `isArchived` | `?bool` | Optional | - | getIsArchived(): ?bool | setIsArchived(?bool isArchived): void |
| `isChannel` | `bool` | Required | - | getIsChannel(): bool | setIsChannel(bool isChannel): void |
| `isFrozen` | `?bool` | Optional | - | getIsFrozen(): ?bool | setIsFrozen(?bool isFrozen): void |
| `isGeneral` | `?bool` | Optional | - | getIsGeneral(): ?bool | setIsGeneral(?bool isGeneral): void |
| `isMember` | `?bool` | Optional | - | getIsMember(): ?bool | setIsMember(?bool isMember): void |
| `isMoved` | `?int` | Optional | - | getIsMoved(): ?int | setIsMoved(?int isMoved): void |
| `isMpim` | `bool` | Required | - | getIsMpim(): bool | setIsMpim(bool isMpim): void |
| `isNonThreadable` | `?bool` | Optional | - | getIsNonThreadable(): ?bool | setIsNonThreadable(?bool isNonThreadable): void |
| `isOrgShared` | `bool` | Required | - | getIsOrgShared(): bool | setIsOrgShared(bool isOrgShared): void |
| `isPendingExtShared` | `?bool` | Optional | - | getIsPendingExtShared(): ?bool | setIsPendingExtShared(?bool isPendingExtShared): void |
| `isPrivate` | `bool` | Required | - | getIsPrivate(): bool | setIsPrivate(bool isPrivate): void |
| `isReadOnly` | `?bool` | Optional | - | getIsReadOnly(): ?bool | setIsReadOnly(?bool isReadOnly): void |
| `isShared` | `bool` | Required | - | getIsShared(): bool | setIsShared(bool isShared): void |
| `isThreadOnly` | `?bool` | Optional | - | getIsThreadOnly(): ?bool | setIsThreadOnly(?bool isThreadOnly): void |
| `lastRead` | `?string` | Optional | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | getLastRead(): ?string | setLastRead(?string lastRead): void |
| `latest` | `?array` | Optional | - | getLatest(): ?array | setLatest(?array latest): void |
| `members` | `string[]` | Required | **Constraints**: *Minimum Items*: `0`, *Unique Items Required*, *Pattern*: `^[UW][A-Z0-9]{2,}$` | getMembers(): array | setMembers(array members): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `nameNormalized` | `string` | Required | - | getNameNormalized(): string | setNameNormalized(string nameNormalized): void |
| `numMembers` | `?int` | Optional | - | getNumMembers(): ?int | setNumMembers(?int numMembers): void |
| `pendingShared` | `?(string[])` | Optional | **Constraints**: *Minimum Items*: `0`, *Unique Items Required*, *Pattern*: `^[T][A-Z0-9]{2,}$` | getPendingShared(): ?array | setPendingShared(?array pendingShared): void |
| `previousNames` | `?(string[])` | Optional | **Constraints**: *Minimum Items*: `0`, *Unique Items Required* | getPreviousNames(): ?array | setPreviousNames(?array previousNames): void |
| `priority` | `?float` | Optional | - | getPriority(): ?float | setPriority(?float priority): void |
| `purpose` | [`Purpose`](../../doc/models/purpose.md) | Required | - | getPurpose(): Purpose | setPurpose(Purpose purpose): void |
| `topic` | [`Topic`](../../doc/models/topic.md) | Required | - | getTopic(): Topic | setTopic(Topic topic): void |
| `unlinked` | `?int` | Optional | - | getUnlinked(): ?int | setUnlinked(?int unlinked): void |
| `unreadCount` | `?int` | Optional | - | getUnreadCount(): ?int | setUnreadCount(?int unreadCount): void |
| `unreadCountDisplay` | `?int` | Optional | - | getUnreadCountDisplay(): ?int | setUnreadCountDisplay(?int unreadCountDisplay): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ChannelObjectBuilder;
use SlackWebApiLib\Models\Builders\PurposeBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\TopicBuilder;

$channelObject = ChannelObjectBuilder::init(
    36,
    'creator4',
    'id6',
    false,
    false,
    false,
    false,
    false,
    [
        'members4',
        'members5'
    ],
    'name6',
    'name_normalized4',
    PurposeBuilder::init(
        'creator4',
        30,
        'value8'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    TopicBuilder::init(
        'creator6',
        242,
        'value0'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->acceptedUser('accepted_user4')
    ->isArchived(false)
    ->isFrozen(false)
    ->isGeneral(false)
    ->isMember(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


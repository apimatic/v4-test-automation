
# Plan

## Enumeration

`Plan`

## Fields

| Name |
|  --- |
| `STD` |
| `PLUS` |
| `COMPLIANCE` |
| `ENTERPRISE` |

## Example

```php
use SlackWebApiLib\Models\Plan;

$plan = Plan::COMPLIANCE;
```


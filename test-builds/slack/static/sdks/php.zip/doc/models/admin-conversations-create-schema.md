
# Admin Conversations Create Schema

Schema for successful response of admin.conversations.create

*This model accepts additional fields of type array.*

## Structure

`AdminConversationsCreateSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channelId` | `?string` | Optional | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` | getChannelId(): ?string | setChannelId(?string channelId): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AdminConversationsCreateSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$adminConversationsCreateSchema = AdminConversationsCreateSchemaBuilder::init()
    ->channelId('channel_id2')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


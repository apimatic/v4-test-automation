
# App Home

*This model accepts additional fields of type array.*

## Structure

`AppHome`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `resources` | [`?ResourcesInInfoFromAppsPermissionsInfo`](../../doc/models/resources-in-info-from-apps-permissions-info.md) | Optional | - | getResources(): ?ResourcesInInfoFromAppsPermissionsInfo | setResources(?ResourcesInInfoFromAppsPermissionsInfo resources): void |
| `scopes` | `?(string[])` | Optional | - | getScopes(): ?array | setScopes(?array scopes): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AppHomeBuilder;
use SlackWebApiLib\Models\Builders\ResourcesInInfoFromAppsPermissionsInfoBuilder;
use SlackWebApiLib\ApiHelper;

$appHome = AppHomeBuilder::init()
    ->resources(
        ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
            [
                ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
            ]
        )
            ->excludedIds(
                [
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
            ->wildcard(false)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->scopes(
        [
            'scopes4',
            'scopes3'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


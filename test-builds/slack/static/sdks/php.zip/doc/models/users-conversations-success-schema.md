
# Users Conversations Success Schema

Schema for successful response from users.conversations method. Returned conversation objects do not include `num_members` or `is_member`

*This model accepts additional fields of type array.*

## Structure

`UsersConversationsSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channels` | `array[]` | Required | **Constraints**: *Unique Items Required* | getChannels(): array | setChannels(array channels): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `responseMetadata` | [`?ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - | getResponseMetadata(): ?ResponseMetadata | setResponseMetadata(?ResponseMetadata responseMetadata): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\UsersConversationsSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\ResponseMetadataBuilder;

$usersConversationsSuccessSchema = UsersConversationsSuccessSchemaBuilder::init(
    [
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
    ]
)
    ->responseMetadata(
        ResponseMetadataBuilder::init(
            'next_cursor2'
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


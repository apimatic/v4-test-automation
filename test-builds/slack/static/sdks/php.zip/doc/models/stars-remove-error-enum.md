
# Stars Remove Error Enum

## Enumeration

`StarsRemoveErrorEnum`

## Fields

| Name |
|  --- |
| `BAD_TIMESTAMP` |
| `MESSAGE_NOT_FOUND` |
| `FILE_NOT_FOUND` |
| `FILE_COMMENT_NOT_FOUND` |
| `CHANNEL_NOT_FOUND` |
| `NO_ITEM_SPECIFIED` |
| `NOT_STARRED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```php
use SlackWebApiLib\Models\StarsRemoveErrorEnum;

$starsRemoveErrorEnum = StarsRemoveErrorEnum::ORG_LOGIN_REQUIRED;
```


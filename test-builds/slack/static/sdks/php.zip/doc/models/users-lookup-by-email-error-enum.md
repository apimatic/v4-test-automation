
# Users Lookup by Email Error Enum

## Enumeration

`UsersLookupByEmailErrorEnum`

## Fields

| Name |
|  --- |
| `USERS_NOT_FOUND` |
| `ENTERPRISE_IS_RESTRICTED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```php
use SlackWebApiLib\Models\UsersLookupByEmailErrorEnum;

$usersLookupByEmailErrorEnum = UsersLookupByEmailErrorEnum::TEAM_ADDED_TO_ORG;
```


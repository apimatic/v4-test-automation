
# Scopes

*This model accepts additional fields of type array.*

## Structure

`Scopes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appHome` | `?(string[])` | Optional | - | getAppHome(): ?array | setAppHome(?array appHome): void |
| `channel` | `?(string[])` | Optional | - | getChannel(): ?array | setChannel(?array channel): void |
| `group` | `?(string[])` | Optional | - | getGroup(): ?array | setGroup(?array group): void |
| `im` | `?(string[])` | Optional | - | getIm(): ?array | setIm(?array im): void |
| `mpim` | `?(string[])` | Optional | - | getMpim(): ?array | setMpim(?array mpim): void |
| `team` | `?(string[])` | Optional | - | getTeam(): ?array | setTeam(?array team): void |
| `user` | `?(string[])` | Optional | - | getUser(): ?array | setUser(?array user): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ScopesBuilder;
use SlackWebApiLib\ApiHelper;

$scopes = ScopesBuilder::init()
    ->appHome(
        [
            'app_home0',
            'app_home1',
            'app_home2'
        ]
    )
    ->channel(
        [
            'channel2',
            'channel1'
        ]
    )
    ->group(
        [
            'group1'
        ]
    )
    ->im(
        [
            'im1',
            'im2',
            'im3'
        ]
    )
    ->mpim(
        [
            'mpim2'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


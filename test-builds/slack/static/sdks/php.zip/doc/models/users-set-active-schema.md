
# Users Set Active Schema

Schema for successful response from users.setActive method

*This model accepts additional fields of type array.*

## Structure

`UsersSetActiveSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\UsersSetActiveSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$usersSetActiveSchema = UsersSetActiveSchemaBuilder::init()
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


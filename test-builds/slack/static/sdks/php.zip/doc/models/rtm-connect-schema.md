
# Rtm Connect Schema

Schema for successful response from rtm.connect method

*This model accepts additional fields of type array.*

## Structure

`RtmConnectSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `self` | [`MSelf`](../../doc/models/m-self.md) | Required | - | getSelf(): MSelf | setSelf(MSelf self): void |
| `team` | [`Team1`](../../doc/models/team-1.md) | Required | - | getTeam(): Team1 | setTeam(Team1 team): void |
| `url` | `string` | Required | - | getUrl(): string | setUrl(string url): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\RtmConnectSchemaBuilder;
use SlackWebApiLib\Models\Builders\MSelfBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\Team1Builder;

$rtmConnectSchema = RtmConnectSchemaBuilder::init(
    MSelfBuilder::init(
        'id8',
        'name8'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    Team1Builder::init(
        'domain6',
        'id0',
        'name0'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    'url2'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# User Profile Object

*This model accepts additional fields of type array.*

## Structure

`UserProfileObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `alwaysActive` | `?bool` | Optional | - | getAlwaysActive(): ?bool | setAlwaysActive(?bool alwaysActive): void |
| `apiAppId` | `?string` | Optional | **Constraints**: *Pattern*: `^(A[A-Z0-9]{1,})?$` | getApiAppId(): ?string | setApiAppId(?string apiAppId): void |
| `avatarHash` | `string` | Required | - | getAvatarHash(): string | setAvatarHash(string avatarHash): void |
| `botId` | `?string` | Optional | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` | getBotId(): ?string | setBotId(?string botId): void |
| `displayName` | `string` | Required | - | getDisplayName(): string | setDisplayName(string displayName): void |
| `displayNameNormalized` | `string` | Required | - | getDisplayNameNormalized(): string | setDisplayNameNormalized(string displayNameNormalized): void |
| `email` | `?string` | Optional | - | getEmail(): ?string | setEmail(?string email): void |
| `fields` | `?(array[])` | Required | - | getFields(): ?array | setFields(?array fields): void |
| `firstName` | `?string` | Optional | - | getFirstName(): ?string | setFirstName(?string firstName): void |
| `guestExpirationTs` | `?int` | Optional | - | getGuestExpirationTs(): ?int | setGuestExpirationTs(?int guestExpirationTs): void |
| `guestInvitedBy` | `?string` | Optional | - | getGuestInvitedBy(): ?string | setGuestInvitedBy(?string guestInvitedBy): void |
| `image1024` | `?string` | Optional | - | getImage1024(): ?string | setImage1024(?string image1024): void |
| `image192` | `?string` | Optional | - | getImage192(): ?string | setImage192(?string image192): void |
| `image24` | `?string` | Optional | - | getImage24(): ?string | setImage24(?string image24): void |
| `image32` | `?string` | Optional | - | getImage32(): ?string | setImage32(?string image32): void |
| `image48` | `?string` | Optional | - | getImage48(): ?string | setImage48(?string image48): void |
| `image512` | `?string` | Optional | - | getImage512(): ?string | setImage512(?string image512): void |
| `image72` | `?string` | Optional | - | getImage72(): ?string | setImage72(?string image72): void |
| `imageOriginal` | `?string` | Optional | - | getImageOriginal(): ?string | setImageOriginal(?string imageOriginal): void |
| `isAppUser` | `?bool` | Optional | - | getIsAppUser(): ?bool | setIsAppUser(?bool isAppUser): void |
| `isCustomImage` | `?bool` | Optional | - | getIsCustomImage(): ?bool | setIsCustomImage(?bool isCustomImage): void |
| `isRestricted` | `?bool` | Optional | - | getIsRestricted(): ?bool | setIsRestricted(?bool isRestricted): void |
| `isUltraRestricted` | `?bool` | Optional | - | getIsUltraRestricted(): ?bool | setIsUltraRestricted(?bool isUltraRestricted): void |
| `lastAvatarImageHash` | `?string` | Optional | - | getLastAvatarImageHash(): ?string | setLastAvatarImageHash(?string lastAvatarImageHash): void |
| `lastName` | `?string` | Optional | - | getLastName(): ?string | setLastName(?string lastName): void |
| `membershipsCount` | `?int` | Optional | - | getMembershipsCount(): ?int | setMembershipsCount(?int membershipsCount): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `phone` | `string` | Required | - | getPhone(): string | setPhone(string phone): void |
| `pronouns` | `?string` | Optional | - | getPronouns(): ?string | setPronouns(?string pronouns): void |
| `realName` | `string` | Required | - | getRealName(): string | setRealName(string realName): void |
| `realNameNormalized` | `string` | Required | - | getRealNameNormalized(): string | setRealNameNormalized(string realNameNormalized): void |
| `skype` | `string` | Required | - | getSkype(): string | setSkype(string skype): void |
| `statusDefaultEmoji` | `?string` | Optional | - | getStatusDefaultEmoji(): ?string | setStatusDefaultEmoji(?string statusDefaultEmoji): void |
| `statusDefaultText` | `?string` | Optional | - | getStatusDefaultText(): ?string | setStatusDefaultText(?string statusDefaultText): void |
| `statusDefaultTextCanonical` | `?string` | Optional | - | getStatusDefaultTextCanonical(): ?string | setStatusDefaultTextCanonical(?string statusDefaultTextCanonical): void |
| `statusEmoji` | `string` | Required | - | getStatusEmoji(): string | setStatusEmoji(string statusEmoji): void |
| `statusExpiration` | `?int` | Optional | - | getStatusExpiration(): ?int | setStatusExpiration(?int statusExpiration): void |
| `statusText` | `string` | Required | - | getStatusText(): string | setStatusText(string statusText): void |
| `statusTextCanonical` | `?string` | Optional | - | getStatusTextCanonical(): ?string | setStatusTextCanonical(?string statusTextCanonical): void |
| `team` | `?string` | Optional | **Constraints**: *Pattern*: `^[TE][A-Z0-9]{8,}$` | getTeam(): ?string | setTeam(?string team): void |
| `title` | `string` | Required | - | getTitle(): string | setTitle(string title): void |
| `updated` | `?int` | Optional | - | getUpdated(): ?int | setUpdated(?int updated): void |
| `userId` | `?string` | Optional | - | getUserId(): ?string | setUserId(?string userId): void |
| `username` | `?string` | Optional | - | getUsername(): ?string | setUsername(?string username): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\UserProfileObjectBuilder;
use SlackWebApiLib\ApiHelper;

$userProfileObject = UserProfileObjectBuilder::init(
    'avatar_hash2',
    'display_name2',
    'display_name_normalized2',
    'phone8',
    'real_name8',
    'real_name_normalized4',
    'skype2',
    'status_emoji6',
    'status_text6',
    'title8'
)
    ->alwaysActive(false)
    ->apiAppId('api_app_id2')
    ->botId('bot_id4')
    ->email('email4')
    ->fields(
        [
            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
        ]
    )
    ->firstName('first_name2')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


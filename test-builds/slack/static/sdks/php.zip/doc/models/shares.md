
# Shares

*This model accepts additional fields of type array.*

## Structure

`Shares`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `private` | `?array` | Optional | - | getPrivate(): ?array | setPrivate(?array private): void |
| `public` | `?array` | Optional | - | getPublic(): ?array | setPublic(?array public): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\SharesBuilder;
use SlackWebApiLib\ApiHelper;

$shares = SharesBuilder::init()
    ->private(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->public(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


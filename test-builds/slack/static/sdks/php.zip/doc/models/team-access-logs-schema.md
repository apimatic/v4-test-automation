
# Team Access Logs Schema

Schema for successful response from team.accessLogs method

*This model accepts additional fields of type array.*

## Structure

`TeamAccessLogsSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `logins` | [`Login[]`](../../doc/models/login.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | getLogins(): array | setLogins(array logins): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - | getPaging(): PagingObject | setPaging(PagingObject paging): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\TeamAccessLogsSchemaBuilder;
use SlackWebApiLib\Models\Builders\LoginBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\PagingObjectBuilder;

$teamAccessLogsSchema = TeamAccessLogsSchemaBuilder::init(
    [
        LoginBuilder::init(
            244,
            108,
            124,
            'user_agent6',
            'user_id2',
            'username6'
        )
            ->country('country8')
            ->ip('ip8')
            ->isp('isp4')
            ->region('region0')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ],
    PagingObjectBuilder::init(
        26,
        6
    )
        ->count(56)
        ->pages(150)
        ->perPage(194)
        ->spill(246)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Scheduled Message

*This model accepts additional fields of type array.*

## Structure

`ScheduledMessage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channelId` | `string` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` | getChannelId(): string | setChannelId(string channelId): void |
| `dateCreated` | `int` | Required | - | getDateCreated(): int | setDateCreated(int dateCreated): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^[Q][A-Z0-9]{8,}$` | getId(): string | setId(string id): void |
| `postAt` | `int` | Required | - | getPostAt(): int | setPostAt(int postAt): void |
| `text` | `?string` | Optional | - | getText(): ?string | setText(?string text): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ScheduledMessageBuilder;
use SlackWebApiLib\ApiHelper;

$scheduledMessage = ScheduledMessageBuilder::init(
    'channel_id6',
    168,
    'id0',
    244
)
    ->text('text0')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


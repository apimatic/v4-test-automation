
# Team Integration Logs Schema

Schema for successful response from team.integrationLogs method

*This model accepts additional fields of type array.*

## Structure

`TeamIntegrationLogsSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `logs` | [`Log[]`](../../doc/models/log.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | getLogs(): array | setLogs(array logs): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - | getPaging(): PagingObject | setPaging(PagingObject paging): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\TeamIntegrationLogsSchemaBuilder;
use SlackWebApiLib\Models\Builders\LogBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\PagingObjectBuilder;

$teamIntegrationLogsSchema = TeamIntegrationLogsSchemaBuilder::init(
    [
        LogBuilder::init(
            'app_id8',
            'app_type2',
            'change_type8',
            'date4',
            'scope6',
            'user_id6',
            'user_name4'
        )
            ->adminAppId('admin_app_id6')
            ->channel('channel6')
            ->serviceId('service_id8')
            ->serviceType('service_type4')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ],
    PagingObjectBuilder::init(
        26,
        6
    )
        ->count(56)
        ->pages(150)
        ->perPage(194)
        ->spill(246)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


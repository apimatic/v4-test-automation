
# Files Info Schema

Schema for successful response from files.info method

*This model accepts additional fields of type array.*

## Structure

`FilesInfoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `comments` | `array[]` | Required | - | getComments(): array | setComments(array comments): void |
| `contentHtml` | `?string` | Optional | - | getContentHtml(): ?string | setContentHtml(?string contentHtml): void |
| `editor` | `?string` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getEditor(): ?string | setEditor(?string editor): void |
| `file` | [`FileObject`](../../doc/models/file-object.md) | Required | - | getFile(): FileObject | setFile(FileObject file): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `paging` | [`?PagingObject`](../../doc/models/paging-object.md) | Optional | - | getPaging(): ?PagingObject | setPaging(?PagingObject paging): void |
| `responseMetadata` | `?array` | Optional | - | getResponseMetadata(): ?array | setResponseMetadata(?array responseMetadata): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\FilesInfoSchemaBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\FileObjectBuilder;
use SlackWebApiLib\Models\Builders\PagingObjectBuilder;

$filesInfoSchema = FilesInfoSchemaBuilder::init(
    [
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
    ],
    FileObjectBuilder::init()
        ->channels(
            [
                'channels5',
                'channels4'
            ]
        )
        ->commentsCount(56)
        ->created(220)
        ->dateDelete(118)
        ->displayAsBot(false)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->contentHtml('content_html0')
    ->editor('editor4')
    ->paging(
        PagingObjectBuilder::init(
            26,
            6
        )
            ->count(56)
            ->pages(150)
            ->perPage(194)
            ->spill(246)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->responseMetadata(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


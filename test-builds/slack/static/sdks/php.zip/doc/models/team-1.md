
# Team 1

*This model accepts additional fields of type array.*

## Structure

`Team1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `domain` | `string` | Required | - | getDomain(): string | setDomain(string domain): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | getId(): string | setId(string id): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\Team1Builder;
use SlackWebApiLib\ApiHelper;

$team1 = Team1Builder::init(
    'domain8',
    'id2',
    'name2'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Subteam Usergroup Object

*This model accepts additional fields of type array.*

## Structure

`SubteamUsergroupObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `autoProvision` | `bool` | Required | - | getAutoProvision(): bool | setAutoProvision(bool autoProvision): void |
| `autoType` | `array` | Required | - | getAutoType(): array | setAutoType(array autoType): void |
| `channelCount` | `?int` | Optional | - | getChannelCount(): ?int | setChannelCount(?int channelCount): void |
| `createdBy` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getCreatedBy(): string | setCreatedBy(string createdBy): void |
| `dateCreate` | `int` | Required | - | getDateCreate(): int | setDateCreate(int dateCreate): void |
| `dateDelete` | `int` | Required | - | getDateDelete(): int | setDateDelete(int dateDelete): void |
| `dateUpdate` | `int` | Required | - | getDateUpdate(): int | setDateUpdate(int dateUpdate): void |
| `deletedBy` | `array` | Required | - | getDeletedBy(): array | setDeletedBy(array deletedBy): void |
| `description` | `string` | Required | - | getDescription(): string | setDescription(string description): void |
| `enterpriseSubteamId` | `string` | Required | - | getEnterpriseSubteamId(): string | setEnterpriseSubteamId(string enterpriseSubteamId): void |
| `handle` | `string` | Required | - | getHandle(): string | setHandle(string handle): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^S[A-Z0-9]{2,}$` | getId(): string | setId(string id): void |
| `isExternal` | `bool` | Required | - | getIsExternal(): bool | setIsExternal(bool isExternal): void |
| `isSubteam` | `bool` | Required | - | getIsSubteam(): bool | setIsSubteam(bool isSubteam): void |
| `isUsergroup` | `bool` | Required | - | getIsUsergroup(): bool | setIsUsergroup(bool isUsergroup): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `prefs` | [`Prefs`](../../doc/models/prefs.md) | Required | - | getPrefs(): Prefs | setPrefs(Prefs prefs): void |
| `teamId` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | getTeamId(): string | setTeamId(string teamId): void |
| `updatedBy` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUpdatedBy(): string | setUpdatedBy(string updatedBy): void |
| `userCount` | `?int` | Optional | - | getUserCount(): ?int | setUserCount(?int userCount): void |
| `users` | `?(string[])` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUsers(): ?array | setUsers(?array users): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\SubteamUsergroupObjectBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\PrefsBuilder;

$subteamUsergroupObject = SubteamUsergroupObjectBuilder::init(
    false,
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
    'created_by8',
    254,
    46,
    32,
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
    'description0',
    'enterprise_subteam_id8',
    'handle6',
    'id0',
    false,
    false,
    false,
    'name0',
    PrefsBuilder::init(
        [
            'channels5',
            'channels4'
        ],
        [
            'groups4',
            'groups5',
            'groups6'
        ]
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    'team_id4',
    'updated_by4'
)
    ->channelCount(154)
    ->userCount(160)
    ->users(
        [
            'users1',
            'users2',
            'users3'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


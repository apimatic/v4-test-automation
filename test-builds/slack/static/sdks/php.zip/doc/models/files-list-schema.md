
# Files List Schema

Schema for successful response from files.list method

*This model accepts additional fields of type array.*

## Structure

`FilesListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `files` | [`FileObject[]`](../../doc/models/file-object.md) | Required | **Constraints**: *Minimum Items*: `0`, *Unique Items Required* | getFiles(): array | setFiles(array files): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - | getPaging(): PagingObject | setPaging(PagingObject paging): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\FilesListSchemaBuilder;
use SlackWebApiLib\Models\Builders\FileObjectBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\PagingObjectBuilder;

$filesListSchema = FilesListSchemaBuilder::init(
    [
        FileObjectBuilder::init()
            ->channels(
                [
                    'channels9'
                ]
            )
            ->commentsCount(150)
            ->created(58)
            ->dateDelete(212)
            ->displayAsBot(false)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ],
    PagingObjectBuilder::init(
        26,
        6
    )
        ->count(56)
        ->pages(150)
        ->perPage(194)
        ->spill(246)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


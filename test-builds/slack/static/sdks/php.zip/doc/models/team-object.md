
# Team Object

*This model accepts additional fields of type array.*

## Structure

`TeamObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `archived` | `?bool` | Optional | - | getArchived(): ?bool | setArchived(?bool archived): void |
| `avatarBaseUrl` | `?string` | Optional | - | getAvatarBaseUrl(): ?string | setAvatarBaseUrl(?string avatarBaseUrl): void |
| `created` | `?int` | Optional | - | getCreated(): ?int | setCreated(?int created): void |
| `dateCreate` | `?int` | Optional | - | getDateCreate(): ?int | setDateCreate(?int dateCreate): void |
| `deleted` | `?bool` | Optional | - | getDeleted(): ?bool | setDeleted(?bool deleted): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `discoverable` | `?array` | Optional | - | getDiscoverable(): ?array | setDiscoverable(?array discoverable): void |
| `domain` | `string` | Required | - | getDomain(): string | setDomain(string domain): void |
| `emailDomain` | `string` | Required | - | getEmailDomain(): string | setEmailDomain(string emailDomain): void |
| `enterpriseId` | `?string` | Optional | **Constraints**: *Pattern*: `^[E][A-Z0-9]{8,}$` | getEnterpriseId(): ?string | setEnterpriseId(?string enterpriseId): void |
| `enterpriseName` | `?string` | Optional | - | getEnterpriseName(): ?string | setEnterpriseName(?string enterpriseName): void |
| `externalOrgMigrations` | [`?ExternalOrgMigrations`](../../doc/models/external-org-migrations.md) | Optional | - | getExternalOrgMigrations(): ?ExternalOrgMigrations | setExternalOrgMigrations(?ExternalOrgMigrations externalOrgMigrations): void |
| `hasComplianceExport` | `?bool` | Optional | - | getHasComplianceExport(): ?bool | setHasComplianceExport(?bool hasComplianceExport): void |
| `icon` | [`ObjsIcon`](../../doc/models/objs-icon.md) | Required | - | getIcon(): ObjsIcon | setIcon(ObjsIcon icon): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^[TE][A-Z0-9]{8,}$` | getId(): string | setId(string id): void |
| `isAssigned` | `?bool` | Optional | - | getIsAssigned(): ?bool | setIsAssigned(?bool isAssigned): void |
| `isEnterprise` | `?int` | Optional | - | getIsEnterprise(): ?int | setIsEnterprise(?int isEnterprise): void |
| `isOverStorageLimit` | `?bool` | Optional | - | getIsOverStorageLimit(): ?bool | setIsOverStorageLimit(?bool isOverStorageLimit): void |
| `limitTs` | `?int` | Optional | - | getLimitTs(): ?int | setLimitTs(?int limitTs): void |
| `locale` | `?string` | Optional | - | getLocale(): ?string | setLocale(?string locale): void |
| `messagesCount` | `?int` | Optional | - | getMessagesCount(): ?int | setMessagesCount(?int messagesCount): void |
| `msgEditWindowMins` | `?int` | Optional | - | getMsgEditWindowMins(): ?int | setMsgEditWindowMins(?int msgEditWindowMins): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `overIntegrationsLimit` | `?bool` | Optional | - | getOverIntegrationsLimit(): ?bool | setOverIntegrationsLimit(?bool overIntegrationsLimit): void |
| `overStorageLimit` | `?bool` | Optional | - | getOverStorageLimit(): ?bool | setOverStorageLimit(?bool overStorageLimit): void |
| `payProdCur` | `?string` | Optional | - | getPayProdCur(): ?string | setPayProdCur(?string payProdCur): void |
| `plan` | [`?string(Plan)`](../../doc/models/plan.md) | Optional | - | getPlan(): ?string | setPlan(?string plan): void |
| `primaryOwner` | [`?ObjsPrimaryOwner`](../../doc/models/objs-primary-owner.md) | Optional | - | getPrimaryOwner(): ?ObjsPrimaryOwner | setPrimaryOwner(?ObjsPrimaryOwner primaryOwner): void |
| `ssoProvider` | [`?SsoProvider`](../../doc/models/sso-provider.md) | Optional | - | getSsoProvider(): ?SsoProvider | setSsoProvider(?SsoProvider ssoProvider): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\TeamObjectBuilder;
use SlackWebApiLib\Models\Builders\ObjsIconBuilder;
use SlackWebApiLib\ApiHelper;

$teamObject = TeamObjectBuilder::init(
    'domain2',
    'email_domain6',
    ObjsIconBuilder::init()
        ->image102('image_1020')
        ->image132('image_1326')
        ->image230('image_2308')
        ->image34('image_340')
        ->image44('image_440')
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    'id6',
    'name6'
)
    ->archived(false)
    ->avatarBaseUrl('avatar_base_url6')
    ->created(166)
    ->dateCreate(16)
    ->deleted(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


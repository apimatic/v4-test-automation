
# Conversations Info Error Enum

## Enumeration

`ConversationsInfoErrorEnum`

## Fields

| Name |
|  --- |
| `MISSING_SCOPE` |
| `CHANNEL_NOT_FOUND` |
| `TEAM_ADDED_TO_ORG` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```php
use SlackWebApiLib\Models\ConversationsInfoErrorEnum;

$conversationsInfoErrorEnum = ConversationsInfoErrorEnum::MISSING_SCOPE;
```



# Block Kit Block

*This model accepts additional fields of type array.*

## Structure

`BlockKitBlock`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `string` | Required | - | getType(): string | setType(string type): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\BlockKitBlockBuilder;
use SlackWebApiLib\ApiHelper;

$blockKitBlock = BlockKitBlockBuilder::init(
    'type0'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# External Org Migrations

*This model accepts additional fields of type array.*

## Structure

`ExternalOrgMigrations`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `current` | [`Current[]`](../../doc/models/current.md) | Required | - | getCurrent(): array | setCurrent(array current): void |
| `dateUpdated` | `int` | Required | - | getDateUpdated(): int | setDateUpdated(int dateUpdated): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ExternalOrgMigrationsBuilder;
use SlackWebApiLib\Models\Builders\CurrentBuilder;
use SlackWebApiLib\ApiHelper;

$externalOrgMigrations = ExternalOrgMigrationsBuilder::init(
    [
        CurrentBuilder::init(
            84,
            'team_id0'
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ],
    16
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Current

*This model accepts additional fields of type array.*

## Structure

`Current`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dateStarted` | `int` | Required | - | getDateStarted(): int | setDateStarted(int dateStarted): void |
| `teamId` | `string` | Required | - | getTeamId(): string | setTeamId(string teamId): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\CurrentBuilder;
use SlackWebApiLib\ApiHelper;

$current = CurrentBuilder::init(
    84,
    'team_id0'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


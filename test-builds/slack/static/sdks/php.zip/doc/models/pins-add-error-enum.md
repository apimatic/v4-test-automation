
# Pins Add Error Enum

## Enumeration

`PinsAddErrorEnum`

## Fields

| Name |
|  --- |
| `BAD_TIMESTAMP` |
| `MESSAGE_NOT_FOUND` |
| `CHANNEL_NOT_FOUND` |
| `NO_ITEM_SPECIFIED` |
| `ALREADY_PINNED` |
| `PERMISSION_DENIED` |
| `FILE_NOT_SHARED` |
| `NOT_PINNABLE` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```php
use SlackWebApiLib\Models\PinsAddErrorEnum;

$pinsAddErrorEnum = PinsAddErrorEnum::ACCOUNT_INACTIVE;
```


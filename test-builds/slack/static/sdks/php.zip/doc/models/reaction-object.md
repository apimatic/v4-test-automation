
# Reaction Object

*This model accepts additional fields of type array.*

## Structure

`ReactionObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `count` | `int` | Required | - | getCount(): int | setCount(int count): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `users` | `string[]` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUsers(): array | setUsers(array users): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ReactionObjectBuilder;
use SlackWebApiLib\ApiHelper;

$reactionObject = ReactionObjectBuilder::init(
    228,
    'name8',
    [
        'users5',
        'users4'
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Conversations Leave Success Schema

Schema for successful response from conversations.leave method

*This model accepts additional fields of type array.*

## Structure

`ConversationsLeaveSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `notInChannel` | `?bool` | Optional | - | getNotInChannel(): ?bool | setNotInChannel(?bool notInChannel): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ConversationsLeaveSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$conversationsLeaveSuccessSchema = ConversationsLeaveSuccessSchemaBuilder::init()
    ->notInChannel(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


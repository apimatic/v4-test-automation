
# Objs Team Profile Field

*This model accepts additional fields of type array.*

## Structure

`ObjsTeamProfileField`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `fieldName` | `?string` | Optional | - | getFieldName(): ?string | setFieldName(?string fieldName): void |
| `hint` | `string` | Required | - | getHint(): string | setHint(string hint): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^X[a-zA-Z0-9]{9,}$` | getId(): string | setId(string id): void |
| `isHidden` | `?bool` | Optional | - | getIsHidden(): ?bool | setIsHidden(?bool isHidden): void |
| `label` | `string` | Required | - | getLabel(): string | setLabel(string label): void |
| `options` | `?array` | Optional | - | getOptions(): ?array | setOptions(?array options): void |
| `ordering` | `float` | Required | - | getOrdering(): float | setOrdering(float ordering): void |
| `possibleValues` | `?(string[])` | Optional | - | getPossibleValues(): ?array | setPossibleValues(?array possibleValues): void |
| `type` | [`string(Type)`](../../doc/models/type.md) | Required | - | getType(): string | setType(string type): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ObjsTeamProfileFieldBuilder;
use SlackWebApiLib\Models\Type;
use SlackWebApiLib\ApiHelper;

$objsTeamProfileField = ObjsTeamProfileFieldBuilder::init(
    'hint6',
    'id6',
    'label6',
    127.94,
    Type::OPTIONS_LIST
)
    ->fieldName('field_name0')
    ->isHidden(false)
    ->options(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->possibleValues(
        [
            'possible_values7',
            'possible_values8'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


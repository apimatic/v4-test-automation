
# Auth Revoke Schema

Schema for successful response from auth.revoke method

*This model accepts additional fields of type array.*

## Structure

`AuthRevokeSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `revoked` | `bool` | Required | - | getRevoked(): bool | setRevoked(bool revoked): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AuthRevokeSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$authRevokeSchema = AuthRevokeSchemaBuilder::init(
    false
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


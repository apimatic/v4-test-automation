
# Icons

*This model accepts additional fields of type array.*

## Structure

`Icons`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `image36` | `string` | Required | - | getImage36(): string | setImage36(string image36): void |
| `image48` | `string` | Required | - | getImage48(): string | setImage48(string image48): void |
| `image72` | `string` | Required | - | getImage72(): string | setImage72(string image72): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\IconsBuilder;
use SlackWebApiLib\ApiHelper;

$icons = IconsBuilder::init(
    'image_362',
    'image_488',
    'image_722'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


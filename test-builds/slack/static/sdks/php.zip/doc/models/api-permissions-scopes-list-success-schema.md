
# Api Permissions Scopes List Success Schema

Schema for successful response api.permissions.scopes.list method

*This model accepts additional fields of type array.*

## Structure

`ApiPermissionsScopesListSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `scopes` | [`Scopes`](../../doc/models/scopes.md) | Required | - | getScopes(): Scopes | setScopes(Scopes scopes): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ApiPermissionsScopesListSuccessSchemaBuilder;
use SlackWebApiLib\Models\Builders\ScopesBuilder;
use SlackWebApiLib\ApiHelper;

$apiPermissionsScopesListSuccessSchema = ApiPermissionsScopesListSuccessSchemaBuilder::init(
    ScopesBuilder::init()
        ->appHome(
            [
                'app_home0',
                'app_home1',
                'app_home2'
            ]
        )
        ->channel(
            [
                'channel2',
                'channel1'
            ]
        )
        ->group(
            [
                'group1'
            ]
        )
        ->im(
            [
                'im1',
                'im2',
                'im3'
            ]
        )
        ->mpim(
            [
                'mpim2'
            ]
        )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


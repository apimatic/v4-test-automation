
# Admin Conversations Search Error Enum

## Enumeration

`AdminConversationsSearchErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `NOT_AN_ADMIN` |
| `NOT_AN_ENTERPRISE` |
| `TEAM_NOT_FOUND` |
| `NOT_ALLOWED` |
| `INVALID_AUTH` |
| `INVALID_CURSOR` |
| `INVALID_SEARCH_CHANNEL_TYPE` |
| `INVALID_SORT` |
| `INVALID_SORT_DIR` |

## Example

```php
use SlackWebApiLib\Models\AdminConversationsSearchErrorEnum;

$adminConversationsSearchErrorEnum = AdminConversationsSearchErrorEnum::NOT_ALLOWED;
```



# Team Profile Get Error Schema Exception

Schema for error response from team.profile.get method

*This model accepts additional fields of type array.*

## Structure

`TeamProfileGetErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callstack` | `?string` | Optional | Note: PHP callstack is only visible in dev/qa | getCallstack(): ?string | setCallstack(?string callstack): void |
| `error` | [`string(TeamProfileGetErrorEnum)`](../../doc/models/team-profile-get-error-enum.md) | Required | - | getError(): string | setError(string error): void |
| `ok` | `string` | Required, Constant | **Value**: `'False'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |


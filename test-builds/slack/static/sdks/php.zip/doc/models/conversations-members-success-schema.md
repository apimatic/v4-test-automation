
# Conversations Members Success Schema

Schema for successful response conversations.members method

*This model accepts additional fields of type array.*

## Structure

`ConversationsMembersSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `members` | `string[]` | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required*, *Pattern*: `^[UW][A-Z0-9]{2,}$` | getMembers(): array | setMembers(array members): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `responseMetadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Required | - | getResponseMetadata(): ResponseMetadata | setResponseMetadata(ResponseMetadata responseMetadata): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ConversationsMembersSuccessSchemaBuilder;
use SlackWebApiLib\Models\Builders\ResponseMetadataBuilder;
use SlackWebApiLib\ApiHelper;

$conversationsMembersSuccessSchema = ConversationsMembersSuccessSchemaBuilder::init(
    [
        'members0',
        'members1'
    ],
    ResponseMetadataBuilder::init(
        'next_cursor2'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Sso Provider

*This model accepts additional fields of type array.*

## Structure

`SsoProvider`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `label` | `?string` | Optional | - | getLabel(): ?string | setLabel(?string label): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `type` | `?string` | Optional | - | getType(): ?string | setType(?string type): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\SsoProviderBuilder;
use SlackWebApiLib\ApiHelper;

$ssoProvider = SsoProviderBuilder::init()
    ->label('label8')
    ->name('name8')
    ->type('type2')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Users Set Photo Schema

Schema for successful response from users.setPhoto method

*This model accepts additional fields of type array.*

## Structure

`UsersSetPhotoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `profile` | [`Profile1`](../../doc/models/profile-1.md) | Required | - | getProfile(): Profile1 | setProfile(Profile1 profile): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\UsersSetPhotoSchemaBuilder;
use SlackWebApiLib\Models\Builders\Profile1Builder;
use SlackWebApiLib\ApiHelper;

$usersSetPhotoSchema = UsersSetPhotoSchemaBuilder::init(
    Profile1Builder::init(
        'avatar_hash0',
        'image_10246',
        'image_1926',
        'image_248',
        'image_326',
        'image_488',
        'image_5124',
        'image_724',
        'image_original6'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


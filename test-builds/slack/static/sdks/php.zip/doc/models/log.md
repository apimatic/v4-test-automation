
# Log

*This model accepts additional fields of type array.*

## Structure

`Log`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `adminAppId` | `?string` | Optional | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` | getAdminAppId(): ?string | setAdminAppId(?string adminAppId): void |
| `appId` | `string` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` | getAppId(): string | setAppId(string appId): void |
| `appType` | `string` | Required | - | getAppType(): string | setAppType(string appType): void |
| `changeType` | `string` | Required | - | getChangeType(): string | setChangeType(string changeType): void |
| `channel` | `?string` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | getChannel(): ?string | setChannel(?string channel): void |
| `date` | `string` | Required | - | getDate(): string | setDate(string date): void |
| `scope` | `string` | Required | - | getScope(): string | setScope(string scope): void |
| `serviceId` | `?string` | Optional | - | getServiceId(): ?string | setServiceId(?string serviceId): void |
| `serviceType` | `?string` | Optional | - | getServiceType(): ?string | setServiceType(?string serviceType): void |
| `userId` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUserId(): string | setUserId(string userId): void |
| `userName` | `string` | Required | - | getUserName(): string | setUserName(string userName): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\LogBuilder;
use SlackWebApiLib\ApiHelper;

$log = LogBuilder::init(
    'app_id8',
    'app_type2',
    'change_type8',
    'date6',
    'scope4',
    'user_id6',
    'user_name4'
)
    ->adminAppId('admin_app_id6')
    ->channel('channel6')
    ->serviceId('service_id2')
    ->serviceType('service_type4')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


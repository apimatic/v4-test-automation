
# Objs Primary Owner

*This model accepts additional fields of type array.*

## Structure

`ObjsPrimaryOwner`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `email` | `string` | Required | - | getEmail(): string | setEmail(string email): void |
| `id` | `string` | Required | - | getId(): string | setId(string id): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ObjsPrimaryOwnerBuilder;
use SlackWebApiLib\ApiHelper;

$objsPrimaryOwner = ObjsPrimaryOwnerBuilder::init(
    'email4',
    'id2'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


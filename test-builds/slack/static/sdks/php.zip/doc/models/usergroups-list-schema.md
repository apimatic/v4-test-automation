
# Usergroups List Schema

Schema for successful response from usergroups.list method

*This model accepts additional fields of type array.*

## Structure

`UsergroupsListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `usergroups` | [`SubteamUsergroupObject[]`](../../doc/models/subteam-usergroup-object.md) | Required | - | getUsergroups(): array | setUsergroups(array usergroups): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\UsergroupsListSchemaBuilder;
use SlackWebApiLib\Models\Builders\SubteamUsergroupObjectBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\PrefsBuilder;

$usergroupsListSchema = UsergroupsListSchemaBuilder::init(
    [
        SubteamUsergroupObjectBuilder::init(
            false,
            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
            'created_by8',
            66,
            114,
            100,
            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
            'description6',
            'enterprise_subteam_id2',
            'handle0',
            'id4',
            false,
            false,
            false,
            'name4',
            PrefsBuilder::init(
                [
                    'channels5',
                    'channels4'
                ],
                [
                    'groups4',
                    'groups5',
                    'groups6'
                ]
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            'team_id2',
            'updated_by8'
        )
            ->channelCount(222)
            ->userCount(28)
            ->users(
                [
                    'users9'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


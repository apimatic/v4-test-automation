
# Conversations Set Purpose Success Schema

Schema for successful response from conversations.setPurpose method

*This model accepts additional fields of type array.*

## Structure

`ConversationsSetPurposeSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channel` | `array` | Required | - | getChannel(): array | setChannel(array channel): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ConversationsSetPurposeSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$conversationsSetPurposeSuccessSchema = ConversationsSetPurposeSuccessSchemaBuilder::init(
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


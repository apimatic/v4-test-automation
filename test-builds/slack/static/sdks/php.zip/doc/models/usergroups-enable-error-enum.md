
# Usergroups Enable Error Enum

## Enumeration

`UsergroupsEnableErrorEnum`

## Fields

| Name |
|  --- |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `USER_IS_BOT` |
| `USER_IS_RESTRICTED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRE` |
| `FATAL_ERROR` |
| `MISSING_CHARSET` |
| `SUPERFLUOUS_CHARSET` |

## Example

```php
use SlackWebApiLib\Models\UsergroupsEnableErrorEnum;

$usergroupsEnableErrorEnum = UsergroupsEnableErrorEnum::UPGRADE_REQUIRE;
```


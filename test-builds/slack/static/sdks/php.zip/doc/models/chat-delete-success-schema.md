
# Chat Delete Success Schema

Schema for successful response of chat.delete method

*This model accepts additional fields of type array.*

## Structure

`ChatDeleteSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channel` | `string` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | getChannel(): string | setChannel(string channel): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `ts` | `string` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | getTs(): string | setTs(string ts): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ChatDeleteSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$chatDeleteSuccessSchema = ChatDeleteSuccessSchemaBuilder::init(
    'channel6',
    'ts0'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


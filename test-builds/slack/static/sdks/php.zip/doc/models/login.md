
# Login

*This model accepts additional fields of type array.*

## Structure

`Login`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `count` | `int` | Required | - | getCount(): int | setCount(int count): void |
| `country` | `?string` | Required | - | getCountry(): ?string | setCountry(?string country): void |
| `dateFirst` | `int` | Required | - | getDateFirst(): int | setDateFirst(int dateFirst): void |
| `dateLast` | `int` | Required | - | getDateLast(): int | setDateLast(int dateLast): void |
| `ip` | `?string` | Required | - | getIp(): ?string | setIp(?string ip): void |
| `isp` | `?string` | Required | - | getIsp(): ?string | setIsp(?string isp): void |
| `region` | `?string` | Required | - | getRegion(): ?string | setRegion(?string region): void |
| `userAgent` | `string` | Required | - | getUserAgent(): string | setUserAgent(string userAgent): void |
| `userId` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUserId(): string | setUserId(string userId): void |
| `username` | `string` | Required | - | getUsername(): string | setUsername(string username): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\LoginBuilder;
use SlackWebApiLib\ApiHelper;

$login = LoginBuilder::init(
    110,
    206,
    222,
    'user_agent2',
    'user_id8',
    'username0'
)
    ->country('country4')
    ->ip('ip4')
    ->isp('isp0')
    ->region('region6')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


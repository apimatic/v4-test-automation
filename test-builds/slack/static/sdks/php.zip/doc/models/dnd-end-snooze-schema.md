
# Dnd End Snooze Schema

Schema for successful response from dnd.endSnooze method

*This model accepts additional fields of type array.*

## Structure

`DndEndSnoozeSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dndEnabled` | `bool` | Required | - | getDndEnabled(): bool | setDndEnabled(bool dndEnabled): void |
| `nextDndEndTs` | `int` | Required | - | getNextDndEndTs(): int | setNextDndEndTs(int nextDndEndTs): void |
| `nextDndStartTs` | `int` | Required | - | getNextDndStartTs(): int | setNextDndStartTs(int nextDndStartTs): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `snoozeEnabled` | `bool` | Required | - | getSnoozeEnabled(): bool | setSnoozeEnabled(bool snoozeEnabled): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\DndEndSnoozeSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$dndEndSnoozeSchema = DndEndSnoozeSchemaBuilder::init(
    false,
    152,
    184,
    false
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


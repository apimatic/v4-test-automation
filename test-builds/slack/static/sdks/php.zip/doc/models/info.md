
# Info

*This model accepts additional fields of type array.*

## Structure

`Info`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appHome` | [`AppHome`](../../doc/models/app-home.md) | Required | - | getAppHome(): AppHome | setAppHome(AppHome appHome): void |
| `channel` | [`Channel`](../../doc/models/channel.md) | Required | - | getChannel(): Channel | setChannel(Channel channel): void |
| `group` | [`Group`](../../doc/models/group.md) | Required | - | getGroup(): Group | setGroup(Group group): void |
| `im` | [`Im`](../../doc/models/im.md) | Required | - | getIm(): Im | setIm(Im im): void |
| `mpim` | [`Mpim`](../../doc/models/mpim.md) | Required | - | getMpim(): Mpim | setMpim(Mpim mpim): void |
| `team` | [`Team`](../../doc/models/team.md) | Required | - | getTeam(): Team | setTeam(Team team): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\InfoBuilder;
use SlackWebApiLib\Models\Builders\AppHomeBuilder;
use SlackWebApiLib\Models\Builders\ResourcesInInfoFromAppsPermissionsInfoBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\ChannelBuilder;
use SlackWebApiLib\Models\Builders\GroupBuilder;
use SlackWebApiLib\Models\Builders\ImBuilder;
use SlackWebApiLib\Models\Builders\MpimBuilder;
use SlackWebApiLib\Models\Builders\TeamBuilder;

$info = InfoBuilder::init(
    AppHomeBuilder::init()
        ->resources(
            ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                [
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
                ->excludedIds(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                ->wildcard(false)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
        ->scopes(
            [
                'scopes4',
                'scopes3',
                'scopes2'
            ]
        )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    ChannelBuilder::init()
        ->resources(
            ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                [
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
                ->excludedIds(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                ->wildcard(false)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
        ->scopes(
            [
                'scopes2',
                'scopes1'
            ]
        )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    GroupBuilder::init()
        ->resources(
            ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                [
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
                ->excludedIds(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                ->wildcard(false)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
        ->scopes(
            [
                'scopes4'
            ]
        )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    ImBuilder::init()
        ->resources(
            ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                [
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
                ->excludedIds(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                ->wildcard(false)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
        ->scopes(
            [
                'scopes0',
                'scopes9',
                'scopes8'
            ]
        )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    MpimBuilder::init()
        ->resources(
            ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                [
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
                ->excludedIds(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                ->wildcard(false)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
        ->scopes(
            [
                'scopes6'
            ]
        )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    TeamBuilder::init(
        ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
            [
                ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
            ]
        )
            ->excludedIds(
                [
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
            ->wildcard(false)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build(),
        [
            'scopes6',
            'scopes5',
            'scopes4'
        ]
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


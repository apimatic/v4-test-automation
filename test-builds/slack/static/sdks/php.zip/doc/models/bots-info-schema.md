
# Bots Info Schema

Schema for successful response from bots.info method

*This model accepts additional fields of type array.*

## Structure

`BotsInfoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bot` | [`Bot`](../../doc/models/bot.md) | Required | - | getBot(): Bot | setBot(Bot bot): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\BotsInfoSchemaBuilder;
use SlackWebApiLib\Models\Builders\BotBuilder;
use SlackWebApiLib\Models\Builders\IconsBuilder;
use SlackWebApiLib\ApiHelper;

$botsInfoSchema = BotsInfoSchemaBuilder::init(
    BotBuilder::init(
        'app_id0',
        false,
        IconsBuilder::init(
            'image_362',
            'image_488',
            'image_722'
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build(),
        'id6',
        'name6',
        214
    )
        ->userId('user_id4')
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


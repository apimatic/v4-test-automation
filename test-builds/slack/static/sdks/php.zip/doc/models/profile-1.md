
# Profile 1

*This model accepts additional fields of type array.*

## Structure

`Profile1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `avatarHash` | `string` | Required | **Constraints**: *Pattern*: `^[0-9a-f]{12}$` | getAvatarHash(): string | setAvatarHash(string avatarHash): void |
| `image1024` | `string` | Required | - | getImage1024(): string | setImage1024(string image1024): void |
| `image192` | `string` | Required | - | getImage192(): string | setImage192(string image192): void |
| `image24` | `string` | Required | - | getImage24(): string | setImage24(string image24): void |
| `image32` | `string` | Required | - | getImage32(): string | setImage32(string image32): void |
| `image48` | `string` | Required | - | getImage48(): string | setImage48(string image48): void |
| `image512` | `string` | Required | - | getImage512(): string | setImage512(string image512): void |
| `image72` | `string` | Required | - | getImage72(): string | setImage72(string image72): void |
| `imageOriginal` | `string` | Required | - | getImageOriginal(): string | setImageOriginal(string imageOriginal): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\Profile1Builder;
use SlackWebApiLib\ApiHelper;

$profile1 = Profile1Builder::init(
    'avatar_hash2',
    'image_10248',
    'image_1928',
    'image_246',
    'image_328',
    'image_480',
    'image_5122',
    'image_726',
    'image_original8'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


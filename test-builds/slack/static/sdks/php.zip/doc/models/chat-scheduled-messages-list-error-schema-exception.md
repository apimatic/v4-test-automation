
# Chat Scheduled Messages List Error Schema Exception

Schema for error response from chat.scheduledMessages.list method

*This model accepts additional fields of type array.*

## Structure

`ChatScheduledMessagesListErrorSchemaException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callstack` | `?string` | Optional | Note: PHP callstack is only visible in dev/qa | getCallstack(): ?string | setCallstack(?string callstack): void |
| `error` | [`string(ChatScheduledMessagesListErrorEnum)`](../../doc/models/chat-scheduled-messages-list-error-enum.md) | Required | - | getError(): string | setError(string error): void |
| `ok` | `string` | Required, Constant | **Value**: `'False'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |


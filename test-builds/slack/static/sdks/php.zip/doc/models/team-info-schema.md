
# Team Info Schema

Schema for successful response from team.info method

*This model accepts additional fields of type array.*

## Structure

`TeamInfoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `team` | [`TeamObject`](../../doc/models/team-object.md) | Required | - | getTeam(): TeamObject | setTeam(TeamObject team): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\TeamInfoSchemaBuilder;
use SlackWebApiLib\Models\Builders\TeamObjectBuilder;
use SlackWebApiLib\Models\Builders\ObjsIconBuilder;
use SlackWebApiLib\ApiHelper;

$teamInfoSchema = TeamInfoSchemaBuilder::init(
    TeamObjectBuilder::init(
        'domain6',
        'email_domain0',
        ObjsIconBuilder::init()
            ->image102('image_1020')
            ->image132('image_1326')
            ->image230('image_2308')
            ->image34('image_340')
            ->image44('image_440')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build(),
        'id0',
        'name0'
    )
        ->archived(false)
        ->avatarBaseUrl('avatar_base_url0')
        ->created(212)
        ->dateCreate(62)
        ->deleted(false)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


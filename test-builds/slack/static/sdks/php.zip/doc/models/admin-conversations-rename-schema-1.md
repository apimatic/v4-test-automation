
# Admin Conversations Rename Schema 1

Schema for successful response of admin.conversations.rename

*This model accepts additional fields of type array.*

## Structure

`AdminConversationsRenameSchema1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AdminConversationsRenameSchema1Builder;
use SlackWebApiLib\ApiHelper;

$adminConversationsRenameSchema1 = AdminConversationsRenameSchema1Builder::init()
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


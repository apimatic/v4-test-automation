
# Conversations Join Success Schema

Schema for successful response from conversations.join method

*This model accepts additional fields of type array.*

## Structure

`ConversationsJoinSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channel` | `array` | Required | - | getChannel(): array | setChannel(array channel): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `responseMetadata` | [`?ResponseMetadata3`](../../doc/models/response-metadata-3.md) | Optional | - | getResponseMetadata(): ?ResponseMetadata3 | setResponseMetadata(?ResponseMetadata3 responseMetadata): void |
| `warning` | `?string` | Optional | - | getWarning(): ?string | setWarning(?string warning): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ConversationsJoinSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\ResponseMetadata3Builder;

$conversationsJoinSuccessSchema = ConversationsJoinSuccessSchemaBuilder::init(
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
)
    ->responseMetadata(
        ResponseMetadata3Builder::init()
            ->warnings(
                [
                    'warnings8',
                    'warnings9',
                    'warnings0'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->warning('warning4')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


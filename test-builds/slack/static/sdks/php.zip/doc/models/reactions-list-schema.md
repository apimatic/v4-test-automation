
# Reactions List Schema

Schema for successful response from reactions.list method

*This model accepts additional fields of type array.*

## Structure

`ReactionsListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | `array[]` | Required | - | getItems(): array | setItems(array items): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `paging` | [`?PagingObject`](../../doc/models/paging-object.md) | Optional | - | getPaging(): ?PagingObject | setPaging(?PagingObject paging): void |
| `responseMetadata` | `?array` | Optional | - | getResponseMetadata(): ?array | setResponseMetadata(?array responseMetadata): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ReactionsListSchemaBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\PagingObjectBuilder;

$reactionsListSchema = ReactionsListSchemaBuilder::init(
    [
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
    ]
)
    ->paging(
        PagingObjectBuilder::init(
            26,
            6
        )
            ->count(56)
            ->pages(150)
            ->perPage(194)
            ->spill(246)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->responseMetadata(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


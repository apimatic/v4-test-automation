
# Attachment

*This model accepts additional fields of type array.*

## Structure

`Attachment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `fallback` | `?string` | Optional | - | getFallback(): ?string | setFallback(?string fallback): void |
| `id` | `int` | Required | - | getId(): int | setId(int id): void |
| `imageBytes` | `?int` | Optional | - | getImageBytes(): ?int | setImageBytes(?int imageBytes): void |
| `imageHeight` | `?int` | Optional | - | getImageHeight(): ?int | setImageHeight(?int imageHeight): void |
| `imageUrl` | `?string` | Optional | - | getImageUrl(): ?string | setImageUrl(?string imageUrl): void |
| `imageWidth` | `?int` | Optional | - | getImageWidth(): ?int | setImageWidth(?int imageWidth): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AttachmentBuilder;
use SlackWebApiLib\ApiHelper;

$attachment = AttachmentBuilder::init(
    248
)
    ->fallback('fallback6')
    ->imageBytes(78)
    ->imageHeight(110)
    ->imageUrl('image_url4')
    ->imageWidth(236)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


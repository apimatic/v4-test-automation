
# Files Shared Public Url Schema

Schema for successful response from files.sharedPublicURL method

*This model accepts additional fields of type array.*

## Structure

`FilesSharedPublicUrlSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `file` | [`FileObject`](../../doc/models/file-object.md) | Required | - | getFile(): FileObject | setFile(FileObject file): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\FilesSharedPublicUrlSchemaBuilder;
use SlackWebApiLib\Models\Builders\FileObjectBuilder;
use SlackWebApiLib\ApiHelper;

$filesSharedPublicUrlSchema = FilesSharedPublicUrlSchemaBuilder::init(
    FileObjectBuilder::init()
        ->channels(
            [
                'channels5',
                'channels4'
            ]
        )
        ->commentsCount(56)
        ->created(220)
        ->dateDelete(118)
        ->displayAsBot(false)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


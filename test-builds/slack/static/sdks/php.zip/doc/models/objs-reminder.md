
# Objs Reminder

*This model accepts additional fields of type array.*

## Structure

`ObjsReminder`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `completeTs` | `?int` | Optional | - | getCompleteTs(): ?int | setCompleteTs(?int completeTs): void |
| `creator` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getCreator(): string | setCreator(string creator): void |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^Rm[A-Z0-9]{8,}$` | getId(): string | setId(string id): void |
| `recurring` | `bool` | Required | - | getRecurring(): bool | setRecurring(bool recurring): void |
| `text` | `string` | Required | - | getText(): string | setText(string text): void |
| `time` | `?int` | Optional | - | getTime(): ?int | setTime(?int time): void |
| `user` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUser(): string | setUser(string user): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ObjsReminderBuilder;
use SlackWebApiLib\ApiHelper;

$objsReminder = ObjsReminderBuilder::init(
    'creator8',
    'id0',
    false,
    'text0',
    'user0'
)
    ->completeTs(160)
    ->time(194)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Admin Conversations Get Conversation Prefs Schema

Schema for successful response of admin.conversations.getConversationPrefs

*This model accepts additional fields of type array.*

## Structure

`AdminConversationsGetConversationPrefsSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `prefs` | [`?Prefs1`](../../doc/models/prefs-1.md) | Optional | - | getPrefs(): ?Prefs1 | setPrefs(?Prefs1 prefs): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AdminConversationsGetConversationPrefsSchemaBuilder;
use SlackWebApiLib\Models\Builders\Prefs1Builder;
use SlackWebApiLib\Models\Builders\CanThreadBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\WhoCanPostBuilder;

$adminConversationsGetConversationPrefsSchema = AdminConversationsGetConversationPrefsSchemaBuilder::init()
    ->prefs(
        Prefs1Builder::init()
            ->canThread(
                CanThreadBuilder::init()
                    ->type(
                        [
                            'type1',
                            'type0'
                        ]
                    )
                    ->user(
                        [
                            'user6',
                            'user7'
                        ]
                    )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->whoCanPost(
                WhoCanPostBuilder::init()
                    ->type(
                        [
                            'type5',
                            'type4'
                        ]
                    )
                    ->user(
                        [
                            'user0',
                            'user1'
                        ]
                    )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


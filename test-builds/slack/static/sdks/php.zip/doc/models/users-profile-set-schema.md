
# Users Profile Set Schema

Schema for successful response from users.profile.set method

*This model accepts additional fields of type array.*

## Structure

`UsersProfileSetSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `emailPending` | `?string` | Optional | - | getEmailPending(): ?string | setEmailPending(?string emailPending): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `profile` | [`UserProfileObject`](../../doc/models/user-profile-object.md) | Required | - | getProfile(): UserProfileObject | setProfile(UserProfileObject profile): void |
| `username` | `string` | Required | - | getUsername(): string | setUsername(string username): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\UsersProfileSetSchemaBuilder;
use SlackWebApiLib\Models\Builders\UserProfileObjectBuilder;
use SlackWebApiLib\ApiHelper;

$usersProfileSetSchema = UsersProfileSetSchemaBuilder::init(
    UserProfileObjectBuilder::init(
        'avatar_hash0',
        'display_name0',
        'display_name_normalized0',
        'phone0',
        'real_name6',
        'real_name_normalized6',
        'skype0',
        'status_emoji4',
        'status_text8',
        'title6'
    )
        ->alwaysActive(false)
        ->apiAppId('api_app_id0')
        ->botId('bot_id6')
        ->email('email6')
        ->fields(
            [
                ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
            ]
        )
        ->firstName('first_name0')
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    'username8'
)
    ->emailPending('email_pending0')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


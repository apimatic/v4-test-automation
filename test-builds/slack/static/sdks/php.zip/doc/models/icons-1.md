
# Icons 1

*This model accepts additional fields of type array.*

## Structure

`Icons1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `emoji` | `?string` | Optional | - | getEmoji(): ?string | setEmoji(?string emoji): void |
| `image64` | `?string` | Optional | - | getImage64(): ?string | setImage64(?string image64): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\Icons1Builder;
use SlackWebApiLib\ApiHelper;

$icons1 = Icons1Builder::init()
    ->emoji('emoji4')
    ->image64('image_646')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


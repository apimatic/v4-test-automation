
# Users List Schema

Schema for successful response from users.list method

*This model accepts additional fields of type array.*

## Structure

`UsersListSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cacheTs` | `int` | Required | - | getCacheTs(): int | setCacheTs(int cacheTs): void |
| `members` | `array[]` | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* | getMembers(): array | setMembers(array members): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `responseMetadata` | `?array` | Optional | - | getResponseMetadata(): ?array | setResponseMetadata(?array responseMetadata): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\UsersListSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$usersListSchema = UsersListSchemaBuilder::init(
    60,
    [
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
    ]
)
    ->responseMetadata(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Team Profile Get Success Schema

Schema for successful response from team.profile.get method

*This model accepts additional fields of type array.*

## Structure

`TeamProfileGetSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `profile` | [`Profile`](../../doc/models/profile.md) | Required | - | getProfile(): Profile | setProfile(Profile profile): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\TeamProfileGetSuccessSchemaBuilder;
use SlackWebApiLib\Models\Builders\ProfileBuilder;
use SlackWebApiLib\Models\Builders\ObjsTeamProfileFieldBuilder;
use SlackWebApiLib\Models\Type;
use SlackWebApiLib\ApiHelper;

$teamProfileGetSuccessSchema = TeamProfileGetSuccessSchemaBuilder::init(
    ProfileBuilder::init(
        [
            ObjsTeamProfileFieldBuilder::init(
                'hint8',
                'id8',
                'label8',
                158.68,
                Type::OPTIONS_LIST
            )
                ->fieldName('field_name2')
                ->isHidden(false)
                ->options(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->possibleValues(
                    [
                        'possible_values9',
                        'possible_values0'
                    ]
                )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```



# Apps Permissions Info Schema

Schema for successful response from apps.permissions.info method

*This model accepts additional fields of type array.*

## Structure

`AppsPermissionsInfoSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `info` | [`Info`](../../doc/models/info.md) | Required | - | getInfo(): Info | setInfo(Info info): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\AppsPermissionsInfoSchemaBuilder;
use SlackWebApiLib\Models\Builders\InfoBuilder;
use SlackWebApiLib\Models\Builders\AppHomeBuilder;
use SlackWebApiLib\Models\Builders\ResourcesInInfoFromAppsPermissionsInfoBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\ChannelBuilder;
use SlackWebApiLib\Models\Builders\GroupBuilder;
use SlackWebApiLib\Models\Builders\ImBuilder;
use SlackWebApiLib\Models\Builders\MpimBuilder;
use SlackWebApiLib\Models\Builders\TeamBuilder;

$appsPermissionsInfoSchema = AppsPermissionsInfoSchemaBuilder::init(
    InfoBuilder::init(
        AppHomeBuilder::init()
            ->resources(
                ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                    ->excludedIds(
                        [
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                        ]
                    )
                    ->wildcard(false)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->scopes(
                [
                    'scopes4',
                    'scopes3',
                    'scopes2'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build(),
        ChannelBuilder::init()
            ->resources(
                ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                    ->excludedIds(
                        [
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                        ]
                    )
                    ->wildcard(false)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->scopes(
                [
                    'scopes2',
                    'scopes1'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build(),
        GroupBuilder::init()
            ->resources(
                ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                    ->excludedIds(
                        [
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                        ]
                    )
                    ->wildcard(false)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->scopes(
                [
                    'scopes4'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build(),
        ImBuilder::init()
            ->resources(
                ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                    ->excludedIds(
                        [
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                        ]
                    )
                    ->wildcard(false)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->scopes(
                [
                    'scopes0',
                    'scopes9',
                    'scopes8'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build(),
        MpimBuilder::init()
            ->resources(
                ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                    ->excludedIds(
                        [
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                        ]
                    )
                    ->wildcard(false)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->scopes(
                [
                    'scopes6'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build(),
        TeamBuilder::init(
            ResourcesInInfoFromAppsPermissionsInfoBuilder::init(
                [
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
                ->excludedIds(
                    [
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                    ]
                )
                ->wildcard(false)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            [
                'scopes6',
                'scopes5',
                'scopes4'
            ]
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


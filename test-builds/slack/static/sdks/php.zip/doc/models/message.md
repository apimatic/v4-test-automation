
# Message

*This model accepts additional fields of type array.*

## Structure

`Message`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `botId` | `string` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` | getBotId(): string | setBotId(string botId): void |
| `botProfile` | [`?BotProfileObject`](../../doc/models/bot-profile-object.md) | Optional | - | getBotProfile(): ?BotProfileObject | setBotProfile(?BotProfileObject botProfile): void |
| `team` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | getTeam(): string | setTeam(string team): void |
| `text` | `string` | Required | - | getText(): string | setText(string text): void |
| `type` | `string` | Required | - | getType(): string | setType(string type): void |
| `user` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` | getUser(): string | setUser(string user): void |
| `username` | `?string` | Optional | - | getUsername(): ?string | setUsername(?string username): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\MessageBuilder;
use SlackWebApiLib\Models\Builders\BotProfileObjectBuilder;
use SlackWebApiLib\Models\Builders\IconsBuilder;
use SlackWebApiLib\ApiHelper;

$message = MessageBuilder::init(
    'bot_id6',
    'team0',
    'text0',
    'type0',
    'user0'
)
    ->botProfile(
        BotProfileObjectBuilder::init(
            'app_id8',
            false,
            IconsBuilder::init(
                'image_362',
                'image_488',
                'image_722'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            'id8',
            'name8',
            'team_id8',
            44
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->username('username0')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


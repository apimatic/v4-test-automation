
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `TEXT` |
| `DATE` |
| `LINK` |
| `MAILTO` |
| `OPTIONS_LIST` |
| `USER` |

## Example

```php
use SlackWebApiLib\Models\Type;

$type = Type::LINK;
```


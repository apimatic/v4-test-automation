
# Chat Post Message Success Schema

Schema for successful response of chat.postMessage method

*This model accepts additional fields of type array.*

## Structure

`ChatPostMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channel` | `string` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` | getChannel(): string | setChannel(string channel): void |
| `message` | [`MessageObject`](../../doc/models/message-object.md) | Required | - | getMessage(): MessageObject | setMessage(MessageObject message): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `ts` | `string` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | getTs(): string | setTs(string ts): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ChatPostMessageSuccessSchemaBuilder;
use SlackWebApiLib\Models\Builders\MessageObjectBuilder;
use SlackWebApiLib\Models\Builders\AttachmentBuilder;
use SlackWebApiLib\ApiHelper;
use SlackWebApiLib\Models\Builders\BlockKitBlockBuilder;
use SlackWebApiLib\Models\Builders\BotProfileObjectBuilder;
use SlackWebApiLib\Models\Builders\IconsBuilder;

$chatPostMessageSuccessSchema = ChatPostMessageSuccessSchemaBuilder::init(
    'channel6',
    MessageObjectBuilder::init(
        'text0',
        'ts2',
        'type0'
    )
        ->attachments(
            [
                AttachmentBuilder::init(
                    36
                )
                    ->fallback('fallback4')
                    ->imageBytes(34)
                    ->imageHeight(154)
                    ->imageUrl('image_url6')
                    ->imageWidth(24)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build(),
                AttachmentBuilder::init(
                    36
                )
                    ->fallback('fallback4')
                    ->imageBytes(34)
                    ->imageHeight(154)
                    ->imageUrl('image_url6')
                    ->imageWidth(24)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            ]
        )
        ->blocks(
            [
                BlockKitBlockBuilder::init(
                    'type4'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build(),
                BlockKitBlockBuilder::init(
                    'type4'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            ]
        )
        ->botId(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->botProfile(
            BotProfileObjectBuilder::init(
                'app_id8',
                false,
                IconsBuilder::init(
                    'image_362',
                    'image_488',
                    'image_722'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build(),
                'id8',
                'name8',
                'team_id8',
                44
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
        ->clientMsgId('client_msg_id4')
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    'ts0'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


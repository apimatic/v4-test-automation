
# Migration Exchange Success Schema

Schema for successful response from migration.exchange method

*This model accepts additional fields of type array.*

## Structure

`MigrationExchangeSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `enterpriseId` | `string` | Required | - | getEnterpriseId(): string | setEnterpriseId(string enterpriseId): void |
| `invalidUserIds` | `?(string[])` | Optional | - | getInvalidUserIds(): ?array | setInvalidUserIds(?array invalidUserIds): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `teamId` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` | getTeamId(): string | setTeamId(string teamId): void |
| `userIdMap` | `?array` | Optional | - | getUserIdMap(): ?array | setUserIdMap(?array userIdMap): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\MigrationExchangeSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$migrationExchangeSuccessSchema = MigrationExchangeSuccessSchemaBuilder::init(
    'enterprise_id2',
    'team_id4'
)
    ->invalidUserIds(
        [
            'invalid_user_ids0'
        ]
    )
    ->userIdMap(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


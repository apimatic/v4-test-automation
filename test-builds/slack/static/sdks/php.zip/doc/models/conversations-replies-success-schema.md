
# Conversations Replies Success Schema

Schema for successful response from conversations.replies method

*This model accepts additional fields of type array.*

## Structure

`ConversationsRepliesSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `hasMore` | `?bool` | Optional | - | getHasMore(): ?bool | setHasMore(?bool hasMore): void |
| `messages` | `array[]` | Required | - | getMessages(): array | setMessages(array messages): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ConversationsRepliesSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$conversationsRepliesSuccessSchema = ConversationsRepliesSuccessSchemaBuilder::init(
    [
        ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
    ]
)
    ->hasMore(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


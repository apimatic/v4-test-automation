
# Apps Permissions Resources List Error Enum

## Enumeration

`AppsPermissionsResourcesListErrorEnum`

## Fields

| Name |
|  --- |
| `INVALID_CURSOR` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `USER_IS_BOT` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```php
use SlackWebApiLib\Models\AppsPermissionsResourcesListErrorEnum;

$appsPermissionsResourcesListErrorEnum = AppsPermissionsResourcesListErrorEnum::TEAM_ADDED_TO_ORG;
```


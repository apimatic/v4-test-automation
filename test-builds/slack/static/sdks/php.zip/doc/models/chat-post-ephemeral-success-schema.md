
# Chat Post Ephemeral Success Schema

Schema for successful response from chat.postEphemeral method

*This model accepts additional fields of type array.*

## Structure

`ChatPostEphemeralSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `messageTs` | `string` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` | getMessageTs(): string | setMessageTs(string messageTs): void |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\ChatPostEphemeralSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$chatPostEphemeralSuccessSchema = ChatPostEphemeralSuccessSchemaBuilder::init(
    'message_ts2'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


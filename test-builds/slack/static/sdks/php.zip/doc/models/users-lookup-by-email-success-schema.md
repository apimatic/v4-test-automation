
# Users Lookup by Email Success Schema

Schema for successful response from users.lookupByEmail method

*This model accepts additional fields of type array.*

## Structure

`UsersLookupByEmailSuccessSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `user` | `array` | Required | - | getUser(): array | setUser(array user): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\UsersLookupByEmailSuccessSchemaBuilder;
use SlackWebApiLib\ApiHelper;

$usersLookupByEmailSuccessSchema = UsersLookupByEmailSuccessSchemaBuilder::init(
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


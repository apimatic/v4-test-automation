
# Reminders Add Schema

Schema for successful response from reminders.add method

*This model accepts additional fields of type array.*

## Structure

`RemindersAddSchema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` | getOk(): string | setOk(string ok): void |
| `reminder` | [`ObjsReminder`](../../doc/models/objs-reminder.md) | Required | - | getReminder(): ObjsReminder | setReminder(ObjsReminder reminder): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use SlackWebApiLib\Models\Builders\RemindersAddSchemaBuilder;
use SlackWebApiLib\Models\Builders\ObjsReminderBuilder;
use SlackWebApiLib\ApiHelper;

$remindersAddSchema = RemindersAddSchemaBuilder::init(
    ObjsReminderBuilder::init(
        'creator8',
        'id0',
        false,
        'text0',
        'user0'
    )
        ->completeTs(136)
        ->time(38)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```


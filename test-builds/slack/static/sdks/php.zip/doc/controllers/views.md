# Views

```php
$viewsApi = $client->getViewsApi();
```

## Class Name

`ViewsApi`

## Methods

* [Views Open](../../doc/controllers/views.md#views-open)
* [Views Publish](../../doc/controllers/views.md#views-publish)
* [Views Push](../../doc/controllers/views.md#views-push)
* [Views Update](../../doc/controllers/views.md#views-update)


# Views Open

Open a view for a user.

API method documentation: [https://api.slack.com/methods/views.open](https://api.slack.com/methods/views.open)

```php
function viewsOpen(string $token, string $triggerId, string $view): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `none` |
| `triggerId` | `string` | Query, Required | Exchange a trigger to post to the user. |
| `view` | `string` | Query, Required | A [view payload](/reference/surfaces/views). This must be a JSON-encoded string. |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Typical success response includes the opened view payload.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$triggerId = 'trigger_id6';

$view = 'view2';

$viewsApi = $client->getViewsApi();
$apiResponse = $viewsApi->viewsOpen(
    $token,
    $triggerId,
    $view
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response, before getting to any possible validation errors. | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Views Publish

Publish a static view for a User.

API method documentation: [https://api.slack.com/methods/views.publish](https://api.slack.com/methods/views.publish)

```php
function viewsPublish(string $token, string $userId, string $view, ?string $hash = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `none` |
| `userId` | `string` | Query, Required | `id` of the user you want publish a view to. |
| `view` | `string` | Query, Required | A [view payload](/reference/surfaces/views). This must be a JSON-encoded string. |
| `hash` | `?string` | Query, Optional | A string that represents view state to protect against possible race conditions. |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Typical success response includes the published view payload.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$userId = 'user_id8';

$view = 'view2';

$viewsApi = $client->getViewsApi();
$apiResponse = $viewsApi->viewsPublish(
    $token,
    $userId,
    $view
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response, before getting to any possible validation errors. | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Views Push

Push a view onto the stack of a root view.

API method documentation: [https://api.slack.com/methods/views.push](https://api.slack.com/methods/views.push)

```php
function viewsPush(string $token, string $triggerId, string $view): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `none` |
| `triggerId` | `string` | Query, Required | Exchange a trigger to post to the user. |
| `view` | `string` | Query, Required | A [view payload](/reference/surfaces/views). This must be a JSON-encoded string. |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Typical success response includes the pushed view payload.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$triggerId = 'trigger_id6';

$view = 'view2';

$viewsApi = $client->getViewsApi();
$apiResponse = $viewsApi->viewsPush(
    $token,
    $triggerId,
    $view
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response. | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Views Update

Update an existing view.

API method documentation: [https://api.slack.com/methods/views.update](https://api.slack.com/methods/views.update)

```php
function viewsUpdate(
    string $token,
    ?string $viewId = null,
    ?string $externalId = null,
    ?string $view = null,
    ?string $hash = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `none` |
| `viewId` | `?string` | Query, Optional | A unique identifier of the view to be updated. Either `view_id` or `external_id` is required. |
| `externalId` | `?string` | Query, Optional | A unique identifier of the view set by the developer. Must be unique for all views on a team. Max length of 255 characters. Either `view_id` or `external_id` is required. |
| `view` | `?string` | Query, Optional | A [view object](/reference/surfaces/views). This must be a JSON-encoded string. |
| `hash` | `?string` | Query, Optional | A string that represents view state to protect against possible race conditions. |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Typical success response includes the updated view payload.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$viewsApi = $client->getViewsApi();
$apiResponse = $viewsApi->viewsUpdate($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response. | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


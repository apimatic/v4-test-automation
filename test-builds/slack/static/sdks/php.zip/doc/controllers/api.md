# Api

```php
$api = $client->getApi();
```

## Class Name

`Api`


# Api Test

Checks API calling code.

API method documentation: [https://api.slack.com/methods/api.test](https://api.slack.com/methods/api.test)

```php
function apiTest(?string $error = null, ?string $foo = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `?string` | Query, Optional | Error response to return |
| `foo` | `?string` | Query, Optional | example property to return |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Standard success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ApiTestSuccessSchema`](../../doc/models/api-test-success-schema.md).

## Example Usage

```php
$api = $client->getApi();
$apiResponse = $api->apiTest();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ApiTestSuccessSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Artificial error response | [`ApiTestErrorSchemaException`](../../doc/models/api-test-error-schema-exception.md) |


# oauth V2

```php
$oauthV2Api = $client->getOauthV2Api();
```

## Class Name

`OauthV2Api`


# oauth V2 Access

Exchanges a temporary OAuth verifier code for an access token.

API method documentation: [https://api.slack.com/methods/oauth.v2.access](https://api.slack.com/methods/oauth.v2.access)

```php
function oauthV2Access(
    string $code,
    ?string $clientId = null,
    ?string $clientSecret = null,
    ?string $redirectUri = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string` | Query, Required | The `code` param returned via the OAuth callback. |
| `clientId` | `?string` | Query, Optional | Issued when you created your application. |
| `clientSecret` | `?string` | Query, Optional | Issued when you created your application. |
| `redirectUri` | `?string` | Query, Optional | This must match the originally submitted URI (if one was sent). |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Successful token request with scopes for both a bot user and a user token

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$code = 'code8';

$oauthV2Api = $client->getOauthV2Api();
$apiResponse = $oauthV2Api->oauthV2Access($code);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


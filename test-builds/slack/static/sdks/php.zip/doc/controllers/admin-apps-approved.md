# Admin Apps Approved

```php
$adminAppsApprovedApi = $client->getAdminAppsApprovedApi();
```

## Class Name

`AdminAppsApprovedApi`


# Admin Apps Approved List

List approved apps for an org or workspace.

API method documentation: [https://api.slack.com/methods/admin.apps.approved.list](https://api.slack.com/methods/admin.apps.approved.list)

```php
function adminAppsApprovedList(
    string $token,
    ?int $limit = null,
    ?string $cursor = null,
    ?string $teamId = null,
    ?string $enterpriseId = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `admin.apps:read` |
| `limit` | `?int` | Query, Optional | The maximum number of items to return. Must be between 1 - 1000 both inclusive. |
| `cursor` | `?string` | Query, Optional | Set `cursor` to `next_cursor` returned by the previous call to list items in the next page |
| `teamId` | `?string` | Query, Optional | - |
| `enterpriseId` | `?string` | Query, Optional | - |

## Requires scope

### slackAuth

`admin.apps:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$adminAppsApprovedApi = $client->getAdminAppsApprovedApi();
$apiResponse = $adminAppsApprovedApi->adminAppsApprovedList($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


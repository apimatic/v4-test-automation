# oauth

```php
$oauthApi = $client->getOauthApi();
```

## Class Name

`OauthApi`

## Methods

* [oauth Access](../../doc/controllers/oauth.md#oauth-access)
* [oauth Token](../../doc/controllers/oauth.md#oauth-token)


# oauth Access

Exchanges a temporary OAuth verifier code for an access token.

API method documentation: [https://api.slack.com/methods/oauth.access](https://api.slack.com/methods/oauth.access)

```php
function oauthAccess(
    ?string $clientId = null,
    ?string $clientSecret = null,
    ?string $code = null,
    ?string $redirectUri = null,
    ?bool $singleChannel = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clientId` | `?string` | Query, Optional | Issued when you created your application. |
| `clientSecret` | `?string` | Query, Optional | Issued when you created your application. |
| `code` | `?string` | Query, Optional | The `code` param returned via the OAuth callback. |
| `redirectUri` | `?string` | Query, Optional | This must match the originally submitted URI (if one was sent). |
| `singleChannel` | `?bool` | Query, Optional | Request the user to add your app only to a single channel. Only valid with a [legacy workspace app](https://api.slack.com/legacy-workspace-apps). |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Successful user token negotiation for a single scope

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$oauthApi = $client->getOauthApi();
$apiResponse = $oauthApi->oauthAccess();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# oauth Token

Exchanges a temporary OAuth verifier code for a workspace token.

API method documentation: [https://api.slack.com/methods/oauth.token](https://api.slack.com/methods/oauth.token)

```php
function oauthToken(
    ?string $clientId = null,
    ?string $clientSecret = null,
    ?string $code = null,
    ?string $redirectUri = null,
    ?bool $singleChannel = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clientId` | `?string` | Query, Optional | Issued when you created your application. |
| `clientSecret` | `?string` | Query, Optional | Issued when you created your application. |
| `code` | `?string` | Query, Optional | The `code` param returned via the OAuth callback. |
| `redirectUri` | `?string` | Query, Optional | This must match the originally submitted URI (if one was sent). |
| `singleChannel` | `?bool` | Query, Optional | Request the user to add your app only to a single channel. |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Success example using a workspace app produces a very different kind of response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$oauthApi = $client->getOauthApi();
$apiResponse = $oauthApi->oauthToken();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


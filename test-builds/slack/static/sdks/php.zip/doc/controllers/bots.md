# Bots

```php
$botsApi = $client->getBotsApi();
```

## Class Name

`BotsApi`


# Bots Info

Gets information about a bot user.

API method documentation: [https://api.slack.com/methods/bots.info](https://api.slack.com/methods/bots.info)

```php
function botsInfo(string $token, ?string $bot = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `users:read` |
| `bot` | `?string` | Query, Optional | Bot user to get info on |

## Requires scope

### slackAuth

`users:read`

## Response Type

**200**: When successful, returns bot info by bot ID.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`BotsInfoSchema`](../../doc/models/bots-info-schema.md).

## Example Usage

```php
$token = 'token6';

$botsApi = $client->getBotsApi();
$apiResponse = $botsApi->botsInfo($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'BotsInfoSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | When no bot can be found, it returns an error. | [`BotsInfoErrorSchemaException`](../../doc/models/bots-info-error-schema-exception.md) |


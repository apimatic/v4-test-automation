# Reactions

```php
$reactionsApi = $client->getReactionsApi();
```

## Class Name

`ReactionsApi`

## Methods

* [Reactions Add](../../doc/controllers/reactions.md#reactions-add)
* [Reactions Get](../../doc/controllers/reactions.md#reactions-get)
* [Reactions List](../../doc/controllers/reactions.md#reactions-list)
* [Reactions Remove](../../doc/controllers/reactions.md#reactions-remove)


# Reactions Add

Adds a reaction to an item.

API method documentation: [https://api.slack.com/methods/reactions.add](https://api.slack.com/methods/reactions.add)

```php
function reactionsAdd(string $channel, string $name, string $timestamp, string $token): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `string` | Form, Required | Channel where the message to add reaction to was posted. |
| `name` | `string` | Form, Required | Reaction (emoji) name. |
| `timestamp` | `string` | Form, Required | Timestamp of the message to add reaction to. |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `reactions:write` |

## Requires scope

### slackAuth

`reactions:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ReactionsAddSchema`](../../doc/models/reactions-add-schema.md).

## Example Usage

```php
$channel = 'channel4';

$name = 'name0';

$timestamp = 'timestamp2';

$token = 'token6';

$reactionsApi = $client->getReactionsApi();
$apiResponse = $reactionsApi->reactionsAdd(
    $channel,
    $name,
    $timestamp,
    $token
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ReactionsAddSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`ReactionsAddErrorSchemaException`](../../doc/models/reactions-add-error-schema-exception.md) |


# Reactions Get

Gets reactions for an item.

API method documentation: [https://api.slack.com/methods/reactions.get](https://api.slack.com/methods/reactions.get)

```php
function reactionsGet(
    string $token,
    ?string $channel = null,
    ?string $file = null,
    ?string $fileComment = null,
    ?bool $full = null,
    ?string $timestamp = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `reactions:read` |
| `channel` | `?string` | Query, Optional | Channel where the message to get reactions for was posted. |
| `file` | `?string` | Query, Optional | File to get reactions for. |
| `fileComment` | `?string` | Query, Optional | File comment to get reactions for. |
| `full` | `?bool` | Query, Optional | If true always return the complete reaction list. |
| `timestamp` | `?string` | Query, Optional | Timestamp of the message to get reactions for. |

## Requires scope

### slackAuth

`reactions:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$token = 'token6';

$reactionsApi = $client->getReactionsApi();
$apiResponse = $reactionsApi->reactionsGet($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response

```
{
  "file": {
    "channels": [
      "C2U7V2YA2"
    ],
    "comments_count": 1,
    "created": 1507850315,
    "groups": [],
    "id": "F7H0D7ZA4",
    "ims": [],
    "name": "computer.gif",
    "reactions": [
      {
        "count": 1,
        "name": "stuck_out_tongue_winking_eye",
        "users": [
          "U2U85N1RV"
        ]
      }
    ],
    "timestamp": 1507850315,
    "title": "computer.gif",
    "user": "U2U85N1RV"
  },
  "ok": true,
  "type": "file"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`ReactionsGetErrorSchemaException`](../../doc/models/reactions-get-error-schema-exception.md) |


# Reactions List

Lists reactions made by a user.

API method documentation: [https://api.slack.com/methods/reactions.list](https://api.slack.com/methods/reactions.list)

```php
function reactionsList(
    string $token,
    ?string $user = null,
    ?bool $full = null,
    ?int $count = null,
    ?int $page = null,
    ?string $cursor = null,
    ?int $limit = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `reactions:read` |
| `user` | `?string` | Query, Optional | Show reactions made by this user. Defaults to the authed user. |
| `full` | `?bool` | Query, Optional | If true always return the complete reaction list. |
| `count` | `?int` | Query, Optional | - |
| `page` | `?int` | Query, Optional | - |
| `cursor` | `?string` | Query, Optional | Parameter for pagination. Set `cursor` equal to the `next_cursor` attribute returned by the previous request's `response_metadata`. This parameter is optional, but pagination is mandatory: the default value simply fetches the first "page" of the collection. |
| `limit` | `?int` | Query, Optional | The maximum number of items to return. Fewer than the requested number of items may be returned, even if the end of the list hasn't been reached. |

## Requires scope

### slackAuth

`reactions:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ReactionsListSchema`](../../doc/models/reactions-list-schema.md).

## Example Usage

```php
$token = 'token6';

$reactionsApi = $client->getReactionsApi();
$apiResponse = $reactionsApi->reactionsList($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ReactionsListSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`ReactionsListErrorSchemaException`](../../doc/models/reactions-list-error-schema-exception.md) |


# Reactions Remove

Removes a reaction from an item.

API method documentation: [https://api.slack.com/methods/reactions.remove](https://api.slack.com/methods/reactions.remove)

```php
function reactionsRemove(
    string $token,
    string $name,
    ?string $file = null,
    ?string $fileComment = null,
    ?string $channel = null,
    ?string $timestamp = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `reactions:write` |
| `name` | `string` | Form, Required | Reaction (emoji) name. |
| `file` | `?string` | Form, Optional | File to remove reaction from. |
| `fileComment` | `?string` | Form, Optional | File comment to remove reaction from. |
| `channel` | `?string` | Form, Optional | Channel where the message to remove reaction from was posted. |
| `timestamp` | `?string` | Form, Optional | Timestamp of the message to remove reaction from. |

## Requires scope

### slackAuth

`reactions:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ReactionsRemoveSchema`](../../doc/models/reactions-remove-schema.md).

## Example Usage

```php
$token = 'token6';

$name = 'name0';

$reactionsApi = $client->getReactionsApi();
$apiResponse = $reactionsApi->reactionsRemove(
    $token,
    $name
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ReactionsRemoveSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`ReactionsRemoveErrorSchemaException`](../../doc/models/reactions-remove-error-schema-exception.md) |


# Admin Invite Requests

```php
$adminInviteRequestsApi = $client->getAdminInviteRequestsApi();
```

## Class Name

`AdminInviteRequestsApi`

## Methods

* [Admin Invite Requests Approve](../../doc/controllers/admin-invite-requests.md#admin-invite-requests-approve)
* [Admin Invite Requests Deny](../../doc/controllers/admin-invite-requests.md#admin-invite-requests-deny)
* [Admin Invite Requests List](../../doc/controllers/admin-invite-requests.md#admin-invite-requests-list)


# Admin Invite Requests Approve

Approve a workspace invite request.

API method documentation: [https://api.slack.com/methods/admin.inviteRequests.approve](https://api.slack.com/methods/admin.inviteRequests.approve)

```php
function adminInviteRequestsApprove(string $token, string $inviteRequestId, ?string $teamId = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.invites:write` |
| `inviteRequestId` | `string` | Form, Required | ID of the request to invite. |
| `teamId` | `?string` | Form, Optional | ID for the workspace where the invite request was made. |

## Requires scope

### slackAuth

`admin.invites:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$inviteRequestId = 'invite_request_id4';

$adminInviteRequestsApi = $client->getAdminInviteRequestsApi();
$apiResponse = $adminInviteRequestsApi->adminInviteRequestsApprove(
    $token,
    $inviteRequestId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Invite Requests Deny

Deny a workspace invite request.

API method documentation: [https://api.slack.com/methods/admin.inviteRequests.deny](https://api.slack.com/methods/admin.inviteRequests.deny)

```php
function adminInviteRequestsDeny(string $token, string $inviteRequestId, ?string $teamId = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.invites:write` |
| `inviteRequestId` | `string` | Form, Required | ID of the request to invite. |
| `teamId` | `?string` | Form, Optional | ID for the workspace where the invite request was made. |

## Requires scope

### slackAuth

`admin.invites:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$inviteRequestId = 'invite_request_id4';

$adminInviteRequestsApi = $client->getAdminInviteRequestsApi();
$apiResponse = $adminInviteRequestsApi->adminInviteRequestsDeny(
    $token,
    $inviteRequestId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Invite Requests List

List all pending workspace invite requests.

API method documentation: [https://api.slack.com/methods/admin.inviteRequests.list](https://api.slack.com/methods/admin.inviteRequests.list)

```php
function adminInviteRequestsList(
    string $token,
    ?string $teamId = null,
    ?string $cursor = null,
    ?int $limit = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.invites:read` |
| `teamId` | `?string` | Query, Optional | ID for the workspace where the invite requests were made. |
| `cursor` | `?string` | Query, Optional | Value of the `next_cursor` field sent as part of the previous API response |
| `limit` | `?int` | Query, Optional | The number of results that will be returned by the API on each invocation. Must be between 1 - 1000, both inclusive |

## Requires scope

### slackAuth

`admin.invites:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$adminInviteRequestsApi = $client->getAdminInviteRequestsApi();
$apiResponse = $adminInviteRequestsApi->adminInviteRequestsList($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


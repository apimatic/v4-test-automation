# Pins

```php
$pinsApi = $client->getPinsApi();
```

## Class Name

`PinsApi`

## Methods

* [Pins Add](../../doc/controllers/pins.md#pins-add)
* [Pins List](../../doc/controllers/pins.md#pins-list)
* [Pins Remove](../../doc/controllers/pins.md#pins-remove)


# Pins Add

Pins an item to a channel.

API method documentation: [https://api.slack.com/methods/pins.add](https://api.slack.com/methods/pins.add)

```php
function pinsAdd(string $token, string $channel, ?string $timestamp = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `pins:write` |
| `channel` | `string` | Form, Required | Channel to pin the item in. |
| `timestamp` | `?string` | Form, Optional | Timestamp of the message to pin. |

## Requires scope

### slackAuth

`pins:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`PinsAddSchema`](../../doc/models/pins-add-schema.md).

## Example Usage

```php
$token = 'token6';

$channel = 'channel4';

$pinsApi = $client->getPinsApi();
$apiResponse = $pinsApi->pinsAdd(
    $token,
    $channel
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'PinsAddSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`PinsAddErrorSchemaException`](../../doc/models/pins-add-error-schema-exception.md) |


# Pins List

Lists items pinned to a channel.

API method documentation: [https://api.slack.com/methods/pins.list](https://api.slack.com/methods/pins.list)

```php
function pinsList(string $token, string $channel): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `pins:read` |
| `channel` | `string` | Query, Required | Channel to get pinned items for. |

## Requires scope

### slackAuth

`pins:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `mixed`.

## Example Usage

```php
$token = 'token6';

$channel = 'channel4';

$pinsApi = $client->getPinsApi();
$apiResponse = $pinsApi->pinsList(
    $token,
    $channel
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'mixed:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response

```
{
  "items": [
    {
      "channel": "C2U86NC6H",
      "created": 1508881078,
      "created_by": "U2U85N1RZ",
      "message": {
        "permalink": "https://hitchhikers.slack.com/archives/C2U86NC6H/p1508197641000151",
        "pinned_to": [
          "C2U86NC6H"
        ],
        "text": "What is the meaning of life?",
        "ts": "1508197641.000151",
        "type": "message",
        "user": "U2U85N1RZ"
      },
      "type": "message"
    },
    {
      "channel": "C2U86NC6H",
      "created": 1508880991,
      "created_by": "U2U85N1RZ",
      "message": {
        "permalink": "https://hitchhikers.slack.com/archives/C2U86NC6H/p1508284197000015",
        "pinned_to": [
          "C2U86NC6H"
        ],
        "text": "The meaning of life, the universe, and everything is 42.",
        "ts": "1503289197.000015",
        "type": "message",
        "user": "U2U85N1RZ"
      },
      "type": "message"
    }
  ],
  "ok": true
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`PinsListErrorSchemaException`](../../doc/models/pins-list-error-schema-exception.md) |


# Pins Remove

Un-pins an item from a channel.

API method documentation: [https://api.slack.com/methods/pins.remove](https://api.slack.com/methods/pins.remove)

```php
function pinsRemove(string $token, string $channel, ?string $timestamp = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `pins:write` |
| `channel` | `string` | Form, Required | Channel where the item is pinned to. |
| `timestamp` | `?string` | Form, Optional | Timestamp of the message to un-pin. |

## Requires scope

### slackAuth

`pins:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`PinsRemoveSchema`](../../doc/models/pins-remove-schema.md).

## Example Usage

```php
$token = 'token6';

$channel = 'channel4';

$pinsApi = $client->getPinsApi();
$apiResponse = $pinsApi->pinsRemove(
    $token,
    $channel
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'PinsRemoveSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`PinsRemoveErrorSchemaException`](../../doc/models/pins-remove-error-schema-exception.md) |


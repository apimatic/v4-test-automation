# Reminders

```php
$remindersApi = $client->getRemindersApi();
```

## Class Name

`RemindersApi`

## Methods

* [Reminders Add](../../doc/controllers/reminders.md#reminders-add)
* [Reminders Complete](../../doc/controllers/reminders.md#reminders-complete)
* [Reminders Delete](../../doc/controllers/reminders.md#reminders-delete)
* [Reminders Info](../../doc/controllers/reminders.md#reminders-info)
* [Reminders List](../../doc/controllers/reminders.md#reminders-list)


# Reminders Add

Creates a reminder.

API method documentation: [https://api.slack.com/methods/reminders.add](https://api.slack.com/methods/reminders.add)

```php
function remindersAdd(string $token, string $text, string $time, ?string $user = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `reminders:write` |
| `text` | `string` | Form, Required | The content of the reminder |
| `time` | `string` | Form, Required | When this reminder should happen: the Unix timestamp (up to five years from now), the number of seconds until the reminder (if within 24 hours), or a natural language description (Ex. "in 15 minutes," or "every Thursday") |
| `user` | `?string` | Form, Optional | The user who will receive the reminder. If no user is specified, the reminder will go to user who created it. |

## Requires scope

### slackAuth

`reminders:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`RemindersAddSchema`](../../doc/models/reminders-add-schema.md).

## Example Usage

```php
$token = 'token6';

$text = 'text0';

$time = 'time0';

$remindersApi = $client->getRemindersApi();
$apiResponse = $remindersApi->remindersAdd(
    $token,
    $text,
    $time
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'RemindersAddSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`RemindersAddErrorSchemaException`](../../doc/models/reminders-add-error-schema-exception.md) |


# Reminders Complete

Marks a reminder as complete.

API method documentation: [https://api.slack.com/methods/reminders.complete](https://api.slack.com/methods/reminders.complete)

```php
function remindersComplete(?string $token = null, ?string $reminder = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `?string` | Header, Optional | Authentication token. Requires scope: `reminders:write` |
| `reminder` | `?string` | Form, Optional | The ID of the reminder to be marked as complete |

## Requires scope

### slackAuth

`reminders:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`RemindersCompleteSchema`](../../doc/models/reminders-complete-schema.md).

## Example Usage

```php
$remindersApi = $client->getRemindersApi();
$apiResponse = $remindersApi->remindersComplete();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'RemindersCompleteSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`RemindersCompleteErrorSchemaException`](../../doc/models/reminders-complete-error-schema-exception.md) |


# Reminders Delete

Deletes a reminder.

API method documentation: [https://api.slack.com/methods/reminders.delete](https://api.slack.com/methods/reminders.delete)

```php
function remindersDelete(?string $token = null, ?string $reminder = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `?string` | Header, Optional | Authentication token. Requires scope: `reminders:write` |
| `reminder` | `?string` | Form, Optional | The ID of the reminder |

## Requires scope

### slackAuth

`reminders:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`RemindersDeleteSchema`](../../doc/models/reminders-delete-schema.md).

## Example Usage

```php
$remindersApi = $client->getRemindersApi();
$apiResponse = $remindersApi->remindersDelete();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'RemindersDeleteSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`RemindersDeleteErrorSchemaException`](../../doc/models/reminders-delete-error-schema-exception.md) |


# Reminders Info

Gets information about a reminder.

API method documentation: [https://api.slack.com/methods/reminders.info](https://api.slack.com/methods/reminders.info)

```php
function remindersInfo(?string $token = null, ?string $reminder = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `?string` | Query, Optional | Authentication token. Requires scope: `reminders:read` |
| `reminder` | `?string` | Query, Optional | The ID of the reminder |

## Requires scope

### slackAuth

`reminders:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`RemindersInfoSchema`](../../doc/models/reminders-info-schema.md).

## Example Usage

```php
$remindersApi = $client->getRemindersApi();
$apiResponse = $remindersApi->remindersInfo();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'RemindersInfoSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`RemindersInfoErrorSchemaException`](../../doc/models/reminders-info-error-schema-exception.md) |


# Reminders List

Lists all reminders created by or for a given user.

API method documentation: [https://api.slack.com/methods/reminders.list](https://api.slack.com/methods/reminders.list)

```php
function remindersList(?string $token = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `?string` | Query, Optional | Authentication token. Requires scope: `reminders:read` |

## Requires scope

### slackAuth

`reminders:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`RemindersListSchema`](../../doc/models/reminders-list-schema.md).

## Example Usage

```php
$remindersApi = $client->getRemindersApi();
$apiResponse = $remindersApi->remindersList();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'RemindersListSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`RemindersListErrorSchemaException`](../../doc/models/reminders-list-error-schema-exception.md) |


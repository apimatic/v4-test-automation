# Admin Conversations

```php
$adminConversationsApi = $client->getAdminConversationsApi();
```

## Class Name

`AdminConversationsApi`

## Methods

* [Admin Conversations Archive](../../doc/controllers/admin-conversations.md#admin-conversations-archive)
* [Admin Conversations Convert to Private](../../doc/controllers/admin-conversations.md#admin-conversations-convert-to-private)
* [Admin Conversations Create](../../doc/controllers/admin-conversations.md#admin-conversations-create)
* [Admin Conversations Delete](../../doc/controllers/admin-conversations.md#admin-conversations-delete)
* [Admin Conversations Disconnect Shared](../../doc/controllers/admin-conversations.md#admin-conversations-disconnect-shared)
* [Admin Conversations Get Conversation Prefs](../../doc/controllers/admin-conversations.md#admin-conversations-get-conversation-prefs)
* [Admin Conversations Get Teams](../../doc/controllers/admin-conversations.md#admin-conversations-get-teams)
* [Admin Conversations Invite](../../doc/controllers/admin-conversations.md#admin-conversations-invite)
* [Admin Conversations Rename](../../doc/controllers/admin-conversations.md#admin-conversations-rename)
* [Admin Conversations Search](../../doc/controllers/admin-conversations.md#admin-conversations-search)
* [Admin Conversations Set Conversation Prefs](../../doc/controllers/admin-conversations.md#admin-conversations-set-conversation-prefs)
* [Admin Conversations Set Teams](../../doc/controllers/admin-conversations.md#admin-conversations-set-teams)
* [Admin Conversations Unarchive](../../doc/controllers/admin-conversations.md#admin-conversations-unarchive)


# Admin Conversations Archive

Archive a public or private channel.

API method documentation: [https://api.slack.com/methods/admin.conversations.archive](https://api.slack.com/methods/admin.conversations.archive)

```php
function adminConversationsArchive(string $token, string $channelId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `channelId` | `string` | Form, Required | The channel to archive. |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsArchiveSchema`](../../doc/models/admin-conversations-archive-schema.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsArchive(
    $token,
    $channelId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsArchiveSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsArchiveErrorSchemaException`](../../doc/models/admin-conversations-archive-error-schema-exception.md) |


# Admin Conversations Convert to Private

Convert a public channel to a private channel.

API method documentation: [https://api.slack.com/methods/admin.conversations.convertToPrivate](https://api.slack.com/methods/admin.conversations.convertToPrivate)

```php
function adminConversationsConvertToPrivate(string $token, string $channelId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `channelId` | `string` | Form, Required | The channel to convert to private. |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsConvertToPrivateSchema`](../../doc/models/admin-conversations-convert-to-private-schema.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsConvertToPrivate(
    $token,
    $channelId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsConvertToPrivateSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsConvertToPrivateErrorSchemaException`](../../doc/models/admin-conversations-convert-to-private-error-schema-exception.md) |


# Admin Conversations Create

Create a public or private channel-based conversation.

API method documentation: [https://api.slack.com/methods/admin.conversations.create](https://api.slack.com/methods/admin.conversations.create)

```php
function adminConversationsCreate(
    string $token,
    string $name,
    bool $isPrivate,
    ?string $description = null,
    ?bool $orgWide = null,
    ?string $teamId = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `name` | `string` | Form, Required | Name of the public or private channel to create. |
| `isPrivate` | `bool` | Form, Required | When `true`, creates a private channel instead of a public channel |
| `description` | `?string` | Form, Optional | Description of the public or private channel to create. |
| `orgWide` | `?bool` | Form, Optional | When `true`, the channel will be available org-wide. Note: if the channel is not `org_wide=true`, you must specify a `team_id` for this channel |
| `teamId` | `?string` | Form, Optional | The workspace to create the channel in. Note: this argument is required unless you set `org_wide=true`. |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsCreateSchema`](../../doc/models/admin-conversations-create-schema.md).

## Example Usage

```php
$token = 'token6';

$name = 'name0';

$isPrivate = false;

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsCreate(
    $token,
    $name,
    $isPrivate
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsCreateSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsCreateErrorSchemaException`](../../doc/models/admin-conversations-create-error-schema-exception.md) |


# Admin Conversations Delete

Delete a public or private channel.

API method documentation: [https://api.slack.com/methods/admin.conversations.delete](https://api.slack.com/methods/admin.conversations.delete)

```php
function adminConversationsDelete(string $token, string $channelId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `channelId` | `string` | Form, Required | The channel to delete. |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsDeleteSchema`](../../doc/models/admin-conversations-delete-schema.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsDelete(
    $token,
    $channelId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsDeleteSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsDeleteErrorSchemaException`](../../doc/models/admin-conversations-delete-error-schema-exception.md) |


# Admin Conversations Disconnect Shared

Disconnect a connected channel from one or more workspaces.

API method documentation: [https://api.slack.com/methods/admin.conversations.disconnectShared](https://api.slack.com/methods/admin.conversations.disconnectShared)

```php
function adminConversationsDisconnectShared(
    string $token,
    string $channelId,
    ?string $leavingTeamIds = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `channelId` | `string` | Form, Required | The channel to be disconnected from some workspaces. |
| `leavingTeamIds` | `?string` | Form, Optional | The team to be removed from the channel. Currently only a single team id can be specified. |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsRenameSchema`](../../doc/models/admin-conversations-rename-schema.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsDisconnectShared(
    $token,
    $channelId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsRenameSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsDisconnectSharedErrorSchemaException`](../../doc/models/admin-conversations-disconnect-shared-error-schema-exception.md) |


# Admin Conversations Get Conversation Prefs

Get conversation preferences for a public or private channel.

API method documentation: [https://api.slack.com/methods/admin.conversations.getConversationPrefs](https://api.slack.com/methods/admin.conversations.getConversationPrefs)

```php
function adminConversationsGetConversationPrefs(string $token, string $channelId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:read` |
| `channelId` | `string` | Query, Required | The channel to get preferences for. |

## Requires scope

### slackAuth

`admin.conversations:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsGetConversationPrefsSchema`](../../doc/models/admin-conversations-get-conversation-prefs-schema.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsGetConversationPrefs(
    $token,
    $channelId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsGetConversationPrefsSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsUnarchiveErrorSchemaException`](../../doc/models/admin-conversations-unarchive-error-schema-exception.md) |


# Admin Conversations Get Teams

Get all the workspaces a given public or private channel is connected to within this Enterprise org.

API method documentation: [https://api.slack.com/methods/admin.conversations.getTeams](https://api.slack.com/methods/admin.conversations.getTeams)

```php
function adminConversationsGetTeams(
    string $token,
    string $channelId,
    ?string $cursor = null,
    ?int $limit = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:read` |
| `channelId` | `string` | Query, Required | The channel to determine connected workspaces within the organization for. |
| `cursor` | `?string` | Query, Optional | Set `cursor` to `next_cursor` returned by the previous call to list items in the next page |
| `limit` | `?int` | Query, Optional | The maximum number of items to return. Must be between 1 - 1000 both inclusive. |

## Requires scope

### slackAuth

`admin.conversations:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsGetTeamsSchema`](../../doc/models/admin-conversations-get-teams-schema.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsGetTeams(
    $token,
    $channelId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsGetTeamsSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsGetTeamsErrorSchemaException`](../../doc/models/admin-conversations-get-teams-error-schema-exception.md) |


# Admin Conversations Invite

Invite a user to a public or private channel.

API method documentation: [https://api.slack.com/methods/admin.conversations.invite](https://api.slack.com/methods/admin.conversations.invite)

```php
function adminConversationsInvite(string $token, string $userIds, string $channelId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `userIds` | `string` | Form, Required | The users to invite. |
| `channelId` | `string` | Form, Required | The channel that the users will be invited to. |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsInviteSchema`](../../doc/models/admin-conversations-invite-schema.md).

## Example Usage

```php
$token = 'token6';

$userIds = 'user_ids4';

$channelId = 'channel_id4';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsInvite(
    $token,
    $userIds,
    $channelId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsInviteSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsInviteErrorSchemaException`](../../doc/models/admin-conversations-invite-error-schema-exception.md) |


# Admin Conversations Rename

Rename a public or private channel.

API method documentation: [https://api.slack.com/methods/admin.conversations.rename](https://api.slack.com/methods/admin.conversations.rename)

```php
function adminConversationsRename(string $token, string $channelId, string $name): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `channelId` | `string` | Form, Required | The channel to rename. |
| `name` | `string` | Form, Required | - |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsRenameSchema1`](../../doc/models/admin-conversations-rename-schema-1.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$name = 'name0';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsRename(
    $token,
    $channelId,
    $name
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsRenameSchema1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsUnarchiveErrorSchema2Exception`](../../doc/models/admin-conversations-unarchive-error-schema-2-exception.md) |


# Admin Conversations Search

Search for public or private channels in an Enterprise organization.

API method documentation: [https://api.slack.com/methods/admin.conversations.search](https://api.slack.com/methods/admin.conversations.search)

```php
function adminConversationsSearch(
    string $token,
    ?string $teamIds = null,
    ?string $query = null,
    ?int $limit = null,
    ?string $cursor = null,
    ?string $searchChannelTypes = null,
    ?string $sort = null,
    ?string $sortDir = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:read` |
| `teamIds` | `?string` | Query, Optional | Comma separated string of team IDs, signifying the workspaces to search through. |
| `query` | `?string` | Query, Optional | Name of the the channel to query by. |
| `limit` | `?int` | Query, Optional | Maximum number of items to be returned. Must be between 1 - 20 both inclusive. Default is 10. |
| `cursor` | `?string` | Query, Optional | Set `cursor` to `next_cursor` returned by the previous call to list items in the next page. |
| `searchChannelTypes` | `?string` | Query, Optional | The type of channel to include or exclude in the search. For example `private` will search private channels, while `private_exclude` will exclude them. For a full list of types, check the [Types section](#types). |
| `sort` | `?string` | Query, Optional | Possible values are `relevant` (search ranking based on what we think is closest), `name` (alphabetical), `member_count` (number of users in the channel), and `created` (date channel was created). You can optionally pair this with the `sort_dir` arg to change how it is sorted |
| `sortDir` | `?string` | Query, Optional | Sort direction. Possible values are `asc` for ascending order like (1, 2, 3) or (a, b, c), and `desc` for descending order like (3, 2, 1) or (c, b, a) |

## Requires scope

### slackAuth

`admin.conversations:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsSearchSchema`](../../doc/models/admin-conversations-search-schema.md).

## Example Usage

```php
$token = 'token6';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsSearch($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsSearchSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsSearchErrorSchemaException`](../../doc/models/admin-conversations-search-error-schema-exception.md) |


# Admin Conversations Set Conversation Prefs

Set the posting permissions for a public or private channel.

API method documentation: [https://api.slack.com/methods/admin.conversations.setConversationPrefs](https://api.slack.com/methods/admin.conversations.setConversationPrefs)

```php
function adminConversationsSetConversationPrefs(string $token, string $channelId, string $prefs): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `channelId` | `string` | Form, Required | The channel to set the prefs for |
| `prefs` | `string` | Form, Required | The prefs for this channel in a stringified JSON format. |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsSetConversationPrefsSchema`](../../doc/models/admin-conversations-set-conversation-prefs-schema.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$prefs = 'prefs0';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsSetConversationPrefs(
    $token,
    $channelId,
    $prefs
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsSetConversationPrefsSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsSetConversationPrefsErrorSchemaException`](../../doc/models/admin-conversations-set-conversation-prefs-error-schema-exception.md) |


# Admin Conversations Set Teams

Set the workspaces in an Enterprise grid org that connect to a public or private channel.

API method documentation: [https://api.slack.com/methods/admin.conversations.setTeams](https://api.slack.com/methods/admin.conversations.setTeams)

```php
function adminConversationsSetTeams(
    string $token,
    string $channelId,
    ?string $teamId = null,
    ?string $targetTeamIds = null,
    ?bool $orgChannel = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `channelId` | `string` | Form, Required | The encoded `channel_id` to add or remove to workspaces. |
| `teamId` | `?string` | Form, Optional | The workspace to which the channel belongs. Omit this argument if the channel is a cross-workspace shared channel. |
| `targetTeamIds` | `?string` | Form, Optional | A comma-separated list of workspaces to which the channel should be shared. Not required if the channel is being shared org-wide. |
| `orgChannel` | `?bool` | Form, Optional | True if channel has to be converted to an org channel |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsSetTeams(
    $token,
    $channelId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Conversations Unarchive

Unarchive a public or private channel.

API method documentation: [https://api.slack.com/methods/admin.conversations.unarchive](https://api.slack.com/methods/admin.conversations.unarchive)

```php
function adminConversationsUnarchive(string $token, string $channelId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.conversations:write` |
| `channelId` | `string` | Form, Required | The channel to unarchive. |

## Requires scope

### slackAuth

`admin.conversations:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AdminConversationsUnarchiveSchema`](../../doc/models/admin-conversations-unarchive-schema.md).

## Example Usage

```php
$token = 'token6';

$channelId = 'channel_id4';

$adminConversationsApi = $client->getAdminConversationsApi();
$apiResponse = $adminConversationsApi->adminConversationsUnarchive(
    $token,
    $channelId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AdminConversationsUnarchiveSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AdminConversationsUnarchiveErrorSchema3Exception`](../../doc/models/admin-conversations-unarchive-error-schema-3-exception.md) |


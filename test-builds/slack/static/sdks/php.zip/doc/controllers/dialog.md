# Dialog

```php
$dialogApi = $client->getDialogApi();
```

## Class Name

`DialogApi`


# Dialog Open

Open a dialog with a user

API method documentation: [https://api.slack.com/methods/dialog.open](https://api.slack.com/methods/dialog.open)

```php
function dialogOpen(string $token, string $dialog, string $triggerId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `none` |
| `dialog` | `string` | Query, Required | The dialog definition. This must be a JSON-encoded string. |
| `triggerId` | `string` | Query, Required | Exchange a trigger to post to the user. |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Typical success response is quite minimal.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DialogOpenSchema`](../../doc/models/dialog-open-schema.md).

## Example Usage

```php
$token = 'token6';

$dialog = 'dialog4';

$triggerId = 'trigger_id6';

$dialogApi = $client->getDialogApi();
$apiResponse = $dialogApi->dialogOpen(
    $token,
    $dialog,
    $triggerId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DialogOpenSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response, before getting to any possible validation errors. | [`DialogOpenErrorSchemaException`](../../doc/models/dialog-open-error-schema-exception.md) |


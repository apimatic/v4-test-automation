# Auth

```php
$authApi = $client->getAuthApi();
```

## Class Name

`AuthApi`

## Methods

* [Auth Revoke](../../doc/controllers/auth.md#auth-revoke)
* [Auth Test](../../doc/controllers/auth.md#auth-test)


# Auth Revoke

Revokes a token.

API method documentation: [https://api.slack.com/methods/auth.revoke](https://api.slack.com/methods/auth.revoke)

```php
function authRevoke(string $token, ?bool $test = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `none` |
| `test` | `?bool` | Query, Optional | Setting this parameter to `1` triggers a _testing mode_ where the specified token will not actually be revoked. |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AuthRevokeSchema`](../../doc/models/auth-revoke-schema.md).

## Example Usage

```php
$token = 'token6';

$authApi = $client->getAuthApi();
$apiResponse = $authApi->authRevoke($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AuthRevokeSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AuthRevokeErrorSchemaException`](../../doc/models/auth-revoke-error-schema-exception.md) |


# Auth Test

Checks authentication & identity.

API method documentation: [https://api.slack.com/methods/auth.test](https://api.slack.com/methods/auth.test)

```php
function authTest(string $token): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `none` |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Standard success response when used with a user token

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AuthTestSuccessSchema`](../../doc/models/auth-test-success-schema.md).

## Example Usage

```php
$token = 'token6';

$authApi = $client->getAuthApi();
$apiResponse = $authApi->authTest($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AuthTestSuccessSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Standard failure response when used with an invalid token | [`AuthTestErrorSchemaException`](../../doc/models/auth-test-error-schema-exception.md) |


# Admin Invite Requests Denied

```php
$adminInviteRequestsDeniedApi = $client->getAdminInviteRequestsDeniedApi();
```

## Class Name

`AdminInviteRequestsDeniedApi`


# Admin Invite Requests Denied List

List all denied workspace invite requests.

API method documentation: [https://api.slack.com/methods/admin.inviteRequests.denied.list](https://api.slack.com/methods/admin.inviteRequests.denied.list)

```php
function adminInviteRequestsDeniedList(
    string $token,
    ?string $teamId = null,
    ?string $cursor = null,
    ?int $limit = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.invites:read` |
| `teamId` | `?string` | Query, Optional | ID for the workspace where the invite requests were made. |
| `cursor` | `?string` | Query, Optional | Value of the `next_cursor` field sent as part of the previous api response |
| `limit` | `?int` | Query, Optional | The number of results that will be returned by the API on each invocation. Must be between 1 - 1000 both inclusive |

## Requires scope

### slackAuth

`admin.invites:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$adminInviteRequestsDeniedApi = $client->getAdminInviteRequestsDeniedApi();
$apiResponse = $adminInviteRequestsDeniedApi->adminInviteRequestsDeniedList($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Chat Scheduled Messages

```php
$chatScheduledMessagesApi = $client->getChatScheduledMessagesApi();
```

## Class Name

`ChatScheduledMessagesApi`


# Chat Scheduled Messages List

Returns a list of scheduled messages.

API method documentation: [https://api.slack.com/methods/chat.scheduledMessages.list](https://api.slack.com/methods/chat.scheduledMessages.list)

```php
function chatScheduledMessagesList(
    ?string $token = null,
    ?string $channel = null,
    ?float $latest = null,
    ?float $oldest = null,
    ?int $limit = null,
    ?string $cursor = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `?string` | Header, Optional | Authentication token. Requires scope: `none` |
| `channel` | `?string` | Query, Optional | The channel of the scheduled messages |
| `latest` | `?float` | Query, Optional | A UNIX timestamp of the latest value in the time range |
| `oldest` | `?float` | Query, Optional | A UNIX timestamp of the oldest value in the time range |
| `limit` | `?int` | Query, Optional | Maximum number of original entries to return. |
| `cursor` | `?string` | Query, Optional | For pagination purposes, this is the `cursor` value returned from a previous call to `chat.scheduledmessages.list` indicating where you want to start this call from. |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ChatScheduledMessagesListSchema`](../../doc/models/chat-scheduled-messages-list-schema.md).

## Example Usage

```php
$chatScheduledMessagesApi = $client->getChatScheduledMessagesApi();
$apiResponse = $chatScheduledMessagesApi->chatScheduledMessagesList();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ChatScheduledMessagesListSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response if the channel passed is invalid | [`ChatScheduledMessagesListErrorSchemaException`](../../doc/models/chat-scheduled-messages-list-error-schema-exception.md) |


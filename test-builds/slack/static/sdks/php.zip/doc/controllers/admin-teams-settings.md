# Admin Teams Settings

```php
$adminTeamsSettingsApi = $client->getAdminTeamsSettingsApi();
```

## Class Name

`AdminTeamsSettingsApi`

## Methods

* [Admin Teams Settings Info](../../doc/controllers/admin-teams-settings.md#admin-teams-settings-info)
* [Admin Teams Settings Set Default Channels](../../doc/controllers/admin-teams-settings.md#admin-teams-settings-set-default-channels)
* [Admin Teams Settings Set Description](../../doc/controllers/admin-teams-settings.md#admin-teams-settings-set-description)
* [Admin Teams Settings Set Discoverability](../../doc/controllers/admin-teams-settings.md#admin-teams-settings-set-discoverability)
* [Admin Teams Settings Set Icon](../../doc/controllers/admin-teams-settings.md#admin-teams-settings-set-icon)
* [Admin Teams Settings Set Name](../../doc/controllers/admin-teams-settings.md#admin-teams-settings-set-name)


# Admin Teams Settings Info

Fetch information about settings in a workspace

API method documentation: [https://api.slack.com/methods/admin.teams.settings.info](https://api.slack.com/methods/admin.teams.settings.info)

```php
function adminTeamsSettingsInfo(string $token, string $teamId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.teams:read` |
| `teamId` | `string` | Query, Required | - |

## Requires scope

### slackAuth

`admin.teams:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$teamId = 'team_id6';

$adminTeamsSettingsApi = $client->getAdminTeamsSettingsApi();
$apiResponse = $adminTeamsSettingsApi->adminTeamsSettingsInfo(
    $token,
    $teamId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Teams Settings Set Default Channels

Set the default channels of a workspace.

API method documentation: [https://api.slack.com/methods/admin.teams.settings.setDefaultChannels](https://api.slack.com/methods/admin.teams.settings.setDefaultChannels)

```php
function adminTeamsSettingsSetDefaultChannels(string $token, string $teamId, string $channelIds): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Form, Required | Authentication token. Requires scope: `admin.teams:write` |
| `teamId` | `string` | Form, Required | ID for the workspace to set the default channel for. |
| `channelIds` | `string` | Form, Required | An array of channel IDs. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$teamId = 'team_id6';

$channelIds = 'channel_ids8';

$adminTeamsSettingsApi = $client->getAdminTeamsSettingsApi();
$apiResponse = $adminTeamsSettingsApi->adminTeamsSettingsSetDefaultChannels(
    $token,
    $teamId,
    $channelIds
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Teams Settings Set Description

Set the description of a given workspace.

API method documentation: [https://api.slack.com/methods/admin.teams.settings.setDescription](https://api.slack.com/methods/admin.teams.settings.setDescription)

```php
function adminTeamsSettingsSetDescription(string $token, string $teamId, string $description): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.teams:write` |
| `teamId` | `string` | Form, Required | ID for the workspace to set the description for. |
| `description` | `string` | Form, Required | The new description for the workspace. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$teamId = 'team_id6';

$description = 'description0';

$adminTeamsSettingsApi = $client->getAdminTeamsSettingsApi();
$apiResponse = $adminTeamsSettingsApi->adminTeamsSettingsSetDescription(
    $token,
    $teamId,
    $description
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Teams Settings Set Discoverability

An API method that allows admins to set the discoverability of a given workspace

API method documentation: [https://api.slack.com/methods/admin.teams.settings.setDiscoverability](https://api.slack.com/methods/admin.teams.settings.setDiscoverability)

```php
function adminTeamsSettingsSetDiscoverability(
    string $token,
    string $teamId,
    string $discoverability
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.teams:write` |
| `teamId` | `string` | Form, Required | The ID of the workspace to set discoverability on. |
| `discoverability` | `string` | Form, Required | This workspace's discovery setting. It must be set to one of `open`, `invite_only`, `closed`, or `unlisted`. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$teamId = 'team_id6';

$discoverability = 'discoverability0';

$adminTeamsSettingsApi = $client->getAdminTeamsSettingsApi();
$apiResponse = $adminTeamsSettingsApi->adminTeamsSettingsSetDiscoverability(
    $token,
    $teamId,
    $discoverability
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Teams Settings Set Icon

Sets the icon of a workspace.

API method documentation: [https://api.slack.com/methods/admin.teams.settings.setIcon](https://api.slack.com/methods/admin.teams.settings.setIcon)

```php
function adminTeamsSettingsSetIcon(string $token, string $imageUrl, string $teamId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Form, Required | Authentication token. Requires scope: `admin.teams:write` |
| `imageUrl` | `string` | Form, Required | Image URL for the icon |
| `teamId` | `string` | Form, Required | ID for the workspace to set the icon for. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$imageUrl = 'image_url6';

$teamId = 'team_id6';

$adminTeamsSettingsApi = $client->getAdminTeamsSettingsApi();
$apiResponse = $adminTeamsSettingsApi->adminTeamsSettingsSetIcon(
    $token,
    $imageUrl,
    $teamId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Teams Settings Set Name

Set the name of a given workspace.

API method documentation: [https://api.slack.com/methods/admin.teams.settings.setName](https://api.slack.com/methods/admin.teams.settings.setName)

```php
function adminTeamsSettingsSetName(string $token, string $teamId, string $name): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.teams:write` |
| `teamId` | `string` | Form, Required | ID for the workspace to set the name for. |
| `name` | `string` | Form, Required | The new name of the workspace. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$teamId = 'team_id6';

$name = 'name0';

$adminTeamsSettingsApi = $client->getAdminTeamsSettingsApi();
$apiResponse = $adminTeamsSettingsApi->adminTeamsSettingsSetName(
    $token,
    $teamId,
    $name
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Rtm

```php
$rtmApi = $client->getRtmApi();
```

## Class Name

`RtmApi`


# Rtm Connect

Starts a Real Time Messaging session.

API method documentation: [https://api.slack.com/methods/rtm.connect](https://api.slack.com/methods/rtm.connect)

```php
function rtmConnect(string $token, ?bool $batchPresenceAware = null, ?bool $presenceSub = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `rtm:stream` |
| `batchPresenceAware` | `?bool` | Query, Optional | Batch presence deliveries via subscription. Enabling changes the shape of `presence_change` events. |
| `presenceSub` | `?bool` | Query, Optional | Only deliver presence events when requested by subscription |

## Requires scope

### slackAuth

`rtm:stream`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`RtmConnectSchema`](../../doc/models/rtm-connect-schema.md).

## Example Usage

```php
$token = 'token6';

$rtmApi = $client->getRtmApi();
$apiResponse = $rtmApi->rtmConnect($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'RtmConnectSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`RtmConnectErrorSchemaException`](../../doc/models/rtm-connect-error-schema-exception.md) |


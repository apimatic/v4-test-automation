# Apps Event Authorizations

```php
$appsEventAuthorizationsApi = $client->getAppsEventAuthorizationsApi();
```

## Class Name

`AppsEventAuthorizationsApi`


# Apps Event Authorizations List

Get a list of authorizations for the given event context. Each authorization represents an app installation that the event is visible to.

API method documentation: [https://api.slack.com/methods/apps.event.authorizations.list](https://api.slack.com/methods/apps.event.authorizations.list)

```php
function appsEventAuthorizationsList(
    string $token,
    string $eventContext,
    ?string $cursor = null,
    ?int $limit = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `authorizations:read` |
| `eventContext` | `string` | Query, Required | - |
| `cursor` | `?string` | Query, Optional | - |
| `limit` | `?int` | Query, Optional | - |

## Requires scope

### slackAuth

`authorizations:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$eventContext = 'event_context0';

$appsEventAuthorizationsApi = $client->getAppsEventAuthorizationsApi();
$apiResponse = $appsEventAuthorizationsApi->appsEventAuthorizationsList(
    $token,
    $eventContext
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


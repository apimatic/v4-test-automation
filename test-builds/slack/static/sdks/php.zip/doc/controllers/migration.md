# Migration

```php
$migrationApi = $client->getMigrationApi();
```

## Class Name

`MigrationApi`


# Migration Exchange

For Enterprise Grid workspaces, map local user IDs to global user IDs

API method documentation: [https://api.slack.com/methods/migration.exchange](https://api.slack.com/methods/migration.exchange)

```php
function migrationExchange(
    string $token,
    string $users,
    ?string $teamId = null,
    ?bool $toOld = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `tokens.basic` |
| `users` | `string` | Query, Required | A comma-separated list of user ids, up to 400 per request |
| `teamId` | `?string` | Query, Optional | Specify team_id starts with `T` in case of Org Token |
| `toOld` | `?bool` | Query, Optional | Specify `true` to convert `W` global user IDs to workspace-specific `U` IDs. Defaults to `false`. |

## Requires scope

### slackAuth

`tokens.basic`

## Response Type

**200**: Typical success response when mappings exist for the specified user IDs

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`MigrationExchangeSuccessSchema`](../../doc/models/migration-exchange-success-schema.md).

## Example Usage

```php
$token = 'token6';

$users = 'users6';

$migrationApi = $client->getMigrationApi();
$apiResponse = $migrationApi->migrationExchange(
    $token,
    $users
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'MigrationExchangeSuccessSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response when there are no mappings to provide | [`MigrationExchangeErrorSchemaException`](../../doc/models/migration-exchange-error-schema-exception.md) |


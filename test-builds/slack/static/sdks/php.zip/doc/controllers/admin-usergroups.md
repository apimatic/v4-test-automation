# Admin Usergroups

```php
$adminUsergroupsApi = $client->getAdminUsergroupsApi();
```

## Class Name

`AdminUsergroupsApi`

## Methods

* [Admin Usergroups Add Channels](../../doc/controllers/admin-usergroups.md#admin-usergroups-add-channels)
* [Admin Usergroups Add Teams](../../doc/controllers/admin-usergroups.md#admin-usergroups-add-teams)
* [Admin Usergroups List Channels](../../doc/controllers/admin-usergroups.md#admin-usergroups-list-channels)
* [Admin Usergroups Remove Channels](../../doc/controllers/admin-usergroups.md#admin-usergroups-remove-channels)


# Admin Usergroups Add Channels

Add one or more default channels to an IDP group.

API method documentation: [https://api.slack.com/methods/admin.usergroups.addChannels](https://api.slack.com/methods/admin.usergroups.addChannels)

```php
function adminUsergroupsAddChannels(
    string $token,
    string $usergroupId,
    string $channelIds,
    ?string $teamId = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.usergroups:write` |
| `usergroupId` | `string` | Form, Required | ID of the IDP group to add default channels for. |
| `channelIds` | `string` | Form, Required | Comma separated string of channel IDs. |
| `teamId` | `?string` | Form, Optional | The workspace to add default channels in. |

## Requires scope

### slackAuth

`admin.usergroups:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$usergroupId = 'usergroup_id0';

$channelIds = 'channel_ids8';

$adminUsergroupsApi = $client->getAdminUsergroupsApi();
$apiResponse = $adminUsergroupsApi->adminUsergroupsAddChannels(
    $token,
    $usergroupId,
    $channelIds
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response if the token provided is not associated with an Org Admin or Owner | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Usergroups Add Teams

Associate one or more default workspaces with an organization-wide IDP group.

API method documentation: [https://api.slack.com/methods/admin.usergroups.addTeams](https://api.slack.com/methods/admin.usergroups.addTeams)

```php
function adminUsergroupsAddTeams(
    string $token,
    string $usergroupId,
    string $teamIds,
    ?bool $autoProvision = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.teams:write` |
| `usergroupId` | `string` | Form, Required | An encoded usergroup (IDP Group) ID. |
| `teamIds` | `string` | Form, Required | A comma separated list of encoded team (workspace) IDs. Each workspace *MUST* belong to the organization associated with the token. |
| `autoProvision` | `?bool` | Form, Optional | When `true`, this method automatically creates new workspace accounts for the IDP group members. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$usergroupId = 'usergroup_id0';

$teamIds = 'team_ids2';

$adminUsergroupsApi = $client->getAdminUsergroupsApi();
$apiResponse = $adminUsergroupsApi->adminUsergroupsAddTeams(
    $token,
    $usergroupId,
    $teamIds
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Usergroups List Channels

List the channels linked to an org-level IDP group (user group).

API method documentation: [https://api.slack.com/methods/admin.usergroups.listChannels](https://api.slack.com/methods/admin.usergroups.listChannels)

```php
function adminUsergroupsListChannels(
    string $token,
    string $usergroupId,
    ?string $teamId = null,
    ?bool $includeNumMembers = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.usergroups:read` |
| `usergroupId` | `string` | Query, Required | ID of the IDP group to list default channels for. |
| `teamId` | `?string` | Query, Optional | ID of the the workspace. |
| `includeNumMembers` | `?bool` | Query, Optional | Flag to include or exclude the count of members per channel. |

## Requires scope

### slackAuth

`admin.usergroups:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$usergroupId = 'usergroup_id0';

$adminUsergroupsApi = $client->getAdminUsergroupsApi();
$apiResponse = $adminUsergroupsApi->adminUsergroupsListChannels(
    $token,
    $usergroupId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response if the token provided is not associated with an Org Admin or Owner | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Usergroups Remove Channels

Remove one or more default channels from an org-level IDP group (user group).

API method documentation: [https://api.slack.com/methods/admin.usergroups.removeChannels](https://api.slack.com/methods/admin.usergroups.removeChannels)

```php
function adminUsergroupsRemoveChannels(string $token, string $usergroupId, string $channelIds): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.usergroups:write` |
| `usergroupId` | `string` | Form, Required | ID of the IDP Group |
| `channelIds` | `string` | Form, Required | Comma-separated string of channel IDs |

## Requires scope

### slackAuth

`admin.usergroups:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$usergroupId = 'usergroup_id0';

$channelIds = 'channel_ids8';

$adminUsergroupsApi = $client->getAdminUsergroupsApi();
$apiResponse = $adminUsergroupsApi->adminUsergroupsRemoveChannels(
    $token,
    $usergroupId,
    $channelIds
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response if the token provided is not associated with an Org Admin or Owner | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


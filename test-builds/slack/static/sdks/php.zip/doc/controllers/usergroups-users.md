# Usergroups Users

```php
$usergroupsUsersApi = $client->getUsergroupsUsersApi();
```

## Class Name

`UsergroupsUsersApi`

## Methods

* [Usergroups Users List](../../doc/controllers/usergroups-users.md#usergroups-users-list)
* [Usergroups Users Update](../../doc/controllers/usergroups-users.md#usergroups-users-update)


# Usergroups Users List

List all users in a User Group

API method documentation: [https://api.slack.com/methods/usergroups.users.list](https://api.slack.com/methods/usergroups.users.list)

```php
function usergroupsUsersList(string $token, string $usergroup, ?bool $includeDisabled = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `usergroups:read` |
| `usergroup` | `string` | Query, Required | The encoded ID of the User Group to update. |
| `includeDisabled` | `?bool` | Query, Optional | Allow results that involve disabled User Groups. |

## Requires scope

### slackAuth

`usergroups:read`

## Response Type

**200**: Standard success response when used with a user token

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`UsergroupsUsersListSchema`](../../doc/models/usergroups-users-list-schema.md).

## Example Usage

```php
$token = 'token6';

$usergroup = 'usergroup2';

$usergroupsUsersApi = $client->getUsergroupsUsersApi();
$apiResponse = $usergroupsUsersApi->usergroupsUsersList(
    $token,
    $usergroup
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'UsergroupsUsersListSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Standard failure response when used with an invalid token | [`UsergroupsUsersListErrorSchemaException`](../../doc/models/usergroups-users-list-error-schema-exception.md) |


# Usergroups Users Update

Update the list of users for a User Group

API method documentation: [https://api.slack.com/methods/usergroups.users.update](https://api.slack.com/methods/usergroups.users.update)

```php
function usergroupsUsersUpdate(
    string $token,
    string $usergroup,
    string $users,
    ?bool $includeCount = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `usergroups:write` |
| `usergroup` | `string` | Form, Required | The encoded ID of the User Group to update. |
| `users` | `string` | Form, Required | A comma separated string of encoded user IDs that represent the entire list of users for the User Group. |
| `includeCount` | `?bool` | Form, Optional | Include the number of users in the User Group. |

## Requires scope

### slackAuth

`usergroups:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`UsergroupsUsersUpdateSchema`](../../doc/models/usergroups-users-update-schema.md).

## Example Usage

```php
$token = 'token6';

$usergroup = 'usergroup2';

$users = 'users6';

$usergroupsUsersApi = $client->getUsergroupsUsersApi();
$apiResponse = $usergroupsUsersApi->usergroupsUsersUpdate(
    $token,
    $usergroup,
    $users
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'UsergroupsUsersUpdateSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`UsergroupsUsersUpdateErrorSchemaException`](../../doc/models/usergroups-users-update-error-schema-exception.md) |


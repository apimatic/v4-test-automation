# Search

```php
$searchApi = $client->getSearchApi();
```

## Class Name

`SearchApi`


# Search Messages

Searches for messages matching a query.

API method documentation: [https://api.slack.com/methods/search.messages](https://api.slack.com/methods/search.messages)

```php
function searchMessages(
    string $token,
    string $query,
    ?int $count = null,
    ?bool $highlight = null,
    ?int $page = null,
    ?string $sort = null,
    ?string $sortDir = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `search:read` |
| `query` | `string` | Query, Required | Search query. |
| `count` | `?int` | Query, Optional | Pass the number of results you want per "page". Maximum of `100`. |
| `highlight` | `?bool` | Query, Optional | Pass a value of `true` to enable query highlight markers (see below). |
| `page` | `?int` | Query, Optional | - |
| `sort` | `?string` | Query, Optional | Return matches sorted by either `score` or `timestamp`. |
| `sortDir` | `?string` | Query, Optional | Change sort direction to ascending (`asc`) or descending (`desc`). |

## Requires scope

### slackAuth

`search:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$query = 'query0';

$searchApi = $client->getSearchApi();
$apiResponse = $searchApi->searchMessages(
    $token,
    $query
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


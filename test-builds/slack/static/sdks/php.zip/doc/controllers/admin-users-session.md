# Admin Users Session

```php
$adminUsersSessionApi = $client->getAdminUsersSessionApi();
```

## Class Name

`AdminUsersSessionApi`

## Methods

* [Admin Users Session Invalidate](../../doc/controllers/admin-users-session.md#admin-users-session-invalidate)
* [Admin Users Session Reset](../../doc/controllers/admin-users-session.md#admin-users-session-reset)


# Admin Users Session Invalidate

Invalidate a single session for a user by session_id

API method documentation: [https://api.slack.com/methods/admin.users.session.invalidate](https://api.slack.com/methods/admin.users.session.invalidate)

```php
function adminUsersSessionInvalidate(string $token, string $teamId, int $sessionId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.users:write` |
| `teamId` | `string` | Form, Required | ID of the team that the session belongs to |
| `sessionId` | `int` | Form, Required | - |

## Requires scope

### slackAuth

`admin.users:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$teamId = 'team_id6';

$sessionId = 2;

$adminUsersSessionApi = $client->getAdminUsersSessionApi();
$apiResponse = $adminUsersSessionApi->adminUsersSessionInvalidate(
    $token,
    $teamId,
    $sessionId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Users Session Reset

Wipes all valid sessions on all devices for a given user

API method documentation: [https://api.slack.com/methods/admin.users.session.reset](https://api.slack.com/methods/admin.users.session.reset)

```php
function adminUsersSessionReset(
    string $token,
    string $userId,
    ?bool $mobileOnly = null,
    ?bool $webOnly = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `admin.users:write` |
| `userId` | `string` | Form, Required | The ID of the user to wipe sessions for |
| `mobileOnly` | `?bool` | Form, Optional | Only expire mobile sessions (default: false) |
| `webOnly` | `?bool` | Form, Optional | Only expire web sessions (default: false) |

## Requires scope

### slackAuth

`admin.users:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$userId = 'user_id8';

$adminUsersSessionApi = $client->getAdminUsersSessionApi();
$apiResponse = $adminUsersSessionApi->adminUsersSessionReset(
    $token,
    $userId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


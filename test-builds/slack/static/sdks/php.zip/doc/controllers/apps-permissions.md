# Apps Permissions

```php
$appsPermissionsApi = $client->getAppsPermissionsApi();
```

## Class Name

`AppsPermissionsApi`

## Methods

* [Apps Permissions Info](../../doc/controllers/apps-permissions.md#apps-permissions-info)
* [Apps Permissions Request](../../doc/controllers/apps-permissions.md#apps-permissions-request)


# Apps Permissions Info

Returns list of permissions this app has on a team.

API method documentation: [https://api.slack.com/methods/apps.permissions.info](https://api.slack.com/methods/apps.permissions.info)

```php
function appsPermissionsInfo(?string $token = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `?string` | Query, Optional | Authentication token. Requires scope: `none` |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Standard success response when used with a user token

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AppsPermissionsInfoSchema`](../../doc/models/apps-permissions-info-schema.md).

## Example Usage

```php
$appsPermissionsApi = $client->getAppsPermissionsApi();
$apiResponse = $appsPermissionsApi->appsPermissionsInfo();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AppsPermissionsInfoSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Standard failure response when used with an invalid token | [`AppsPermissionsInfoErrorSchemaException`](../../doc/models/apps-permissions-info-error-schema-exception.md) |


# Apps Permissions Request

Allows an app to request additional scopes

API method documentation: [https://api.slack.com/methods/apps.permissions.request](https://api.slack.com/methods/apps.permissions.request)

```php
function appsPermissionsRequest(string $token, string $scopes, string $triggerId): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `none` |
| `scopes` | `string` | Query, Required | A comma separated list of scopes to request for |
| `triggerId` | `string` | Query, Required | Token used to trigger the permissions API |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Standard success response when used with a user token

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`AppsPermissionsRequestSchema`](../../doc/models/apps-permissions-request-schema.md).

## Example Usage

```php
$token = 'token6';

$scopes = 'scopes4';

$triggerId = 'trigger_id6';

$appsPermissionsApi = $client->getAppsPermissionsApi();
$apiResponse = $appsPermissionsApi->appsPermissionsRequest(
    $token,
    $scopes,
    $triggerId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'AppsPermissionsRequestSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Standard failure response when trigger_id is invalid | [`AppsPermissionsRequestErrorSchemaException`](../../doc/models/apps-permissions-request-error-schema-exception.md) |


# Apps Permissions Scopes

```php
$appsPermissionsScopesApi = $client->getAppsPermissionsScopesApi();
```

## Class Name

`AppsPermissionsScopesApi`


# Apps Permissions Scopes List

Returns list of scopes this app has on a team.

API method documentation: [https://api.slack.com/methods/apps.permissions.scopes.list](https://api.slack.com/methods/apps.permissions.scopes.list)

```php
function appsPermissionsScopesList(string $token): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `none` |

## Requires scope

### slackAuth

`none`

## Response Type

**200**: Typical successful paginated response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ApiPermissionsScopesListSuccessSchema`](../../doc/models/api-permissions-scopes-list-success-schema.md).

## Example Usage

```php
$token = 'token6';

$appsPermissionsScopesApi = $client->getAppsPermissionsScopesApi();
$apiResponse = $appsPermissionsScopesApi->appsPermissionsScopesList($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ApiPermissionsScopesListSuccessSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`AppsPermissionsScopesListErrorSchemaException`](../../doc/models/apps-permissions-scopes-list-error-schema-exception.md) |


# Admin Emoji

```php
$adminEmojiApi = $client->getAdminEmojiApi();
```

## Class Name

`AdminEmojiApi`

## Methods

* [Admin Emoji Add](../../doc/controllers/admin-emoji.md#admin-emoji-add)
* [Admin Emoji Add Alias](../../doc/controllers/admin-emoji.md#admin-emoji-add-alias)
* [Admin Emoji List](../../doc/controllers/admin-emoji.md#admin-emoji-list)
* [Admin Emoji Remove](../../doc/controllers/admin-emoji.md#admin-emoji-remove)
* [Admin Emoji Rename](../../doc/controllers/admin-emoji.md#admin-emoji-rename)


# Admin Emoji Add

Add an emoji.

API method documentation: [https://api.slack.com/methods/admin.emoji.add](https://api.slack.com/methods/admin.emoji.add)

```php
function adminEmojiAdd(string $token, string $name, string $url): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Form, Required | Authentication token. Requires scope: `admin.teams:write` |
| `name` | `string` | Form, Required | The name of the emoji to be removed. Colons (`:myemoji:`) around the value are not required, although they may be included. |
| `url` | `string` | Form, Required | The URL of a file to use as an image for the emoji. Square images under 128KB and with transparent backgrounds work best. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$name = 'name0';

$url = 'url4';

$adminEmojiApi = $client->getAdminEmojiApi();
$apiResponse = $adminEmojiApi->adminEmojiAdd(
    $token,
    $name,
    $url
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Emoji Add Alias

Add an emoji alias.

API method documentation: [https://api.slack.com/methods/admin.emoji.addAlias](https://api.slack.com/methods/admin.emoji.addAlias)

```php
function adminEmojiAddAlias(string $token, string $name, string $aliasFor): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Form, Required | Authentication token. Requires scope: `admin.teams:write` |
| `name` | `string` | Form, Required | The name of the emoji to be aliased. Colons (`:myemoji:`) around the value are not required, although they may be included. |
| `aliasFor` | `string` | Form, Required | The alias of the emoji. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$name = 'name0';

$aliasFor = 'alias_for4';

$adminEmojiApi = $client->getAdminEmojiApi();
$apiResponse = $adminEmojiApi->adminEmojiAddAlias(
    $token,
    $name,
    $aliasFor
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Emoji List

List emoji for an Enterprise Grid organization.

API method documentation: [https://api.slack.com/methods/admin.emoji.list](https://api.slack.com/methods/admin.emoji.list)

```php
function adminEmojiList(string $token, ?string $cursor = null, ?int $limit = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `admin.teams:read` |
| `cursor` | `?string` | Query, Optional | Set `cursor` to `next_cursor` returned by the previous call to list items in the next page |
| `limit` | `?int` | Query, Optional | The maximum number of items to return. Must be between 1 - 1000 both inclusive. |

## Requires scope

### slackAuth

`admin.teams:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$adminEmojiApi = $client->getAdminEmojiApi();
$apiResponse = $adminEmojiApi->adminEmojiList($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Emoji Remove

Remove an emoji across an Enterprise Grid organization

API method documentation: [https://api.slack.com/methods/admin.emoji.remove](https://api.slack.com/methods/admin.emoji.remove)

```php
function adminEmojiRemove(string $token, string $name): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Form, Required | Authentication token. Requires scope: `admin.teams:write` |
| `name` | `string` | Form, Required | The name of the emoji to be removed. Colons (`:myemoji:`) around the value are not required, although they may be included. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$name = 'name0';

$adminEmojiApi = $client->getAdminEmojiApi();
$apiResponse = $adminEmojiApi->adminEmojiRemove(
    $token,
    $name
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


# Admin Emoji Rename

Rename an emoji.

API method documentation: [https://api.slack.com/methods/admin.emoji.rename](https://api.slack.com/methods/admin.emoji.rename)

```php
function adminEmojiRename(string $token, string $name, string $newName): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Form, Required | Authentication token. Requires scope: `admin.teams:write` |
| `name` | `string` | Form, Required | The name of the emoji to be renamed. Colons (`:myemoji:`) around the value are not required, although they may be included. |
| `newName` | `string` | Form, Required | The new name of the emoji. |

## Requires scope

### slackAuth

`admin.teams:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`DefaultSuccessTemplate`](../../doc/models/default-success-template.md).

## Example Usage

```php
$token = 'token6';

$name = 'name0';

$newName = 'new_name8';

$adminEmojiApi = $client->getAdminEmojiApi();
$apiResponse = $adminEmojiApi->adminEmojiRename(
    $token,
    $name,
    $newName
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'DefaultSuccessTemplate:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`DefaultErrorTemplateException`](../../doc/models/default-error-template-exception.md) |


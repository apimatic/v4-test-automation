# Stars

```php
$starsApi = $client->getStarsApi();
```

## Class Name

`StarsApi`

## Methods

* [Stars Add](../../doc/controllers/stars.md#stars-add)
* [Stars List](../../doc/controllers/stars.md#stars-list)
* [Stars Remove](../../doc/controllers/stars.md#stars-remove)


# Stars Add

Adds a star to an item.

API method documentation: [https://api.slack.com/methods/stars.add](https://api.slack.com/methods/stars.add)

```php
function starsAdd(
    string $token,
    ?string $channel = null,
    ?string $file = null,
    ?string $fileComment = null,
    ?string $timestamp = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `stars:write` |
| `channel` | `?string` | Form, Optional | Channel to add star to, or channel where the message to add star to was posted (used with `timestamp`). |
| `file` | `?string` | Form, Optional | File to add star to. |
| `fileComment` | `?string` | Form, Optional | File comment to add star to. |
| `timestamp` | `?string` | Form, Optional | Timestamp of the message to add star to. |

## Requires scope

### slackAuth

`stars:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`StarsAddSchema`](../../doc/models/stars-add-schema.md).

## Example Usage

```php
$token = 'token6';

$starsApi = $client->getStarsApi();
$apiResponse = $starsApi->starsAdd($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'StarsAddSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`StarsAddErrorSchemaException`](../../doc/models/stars-add-error-schema-exception.md) |


# Stars List

Lists stars for a user.

API method documentation: [https://api.slack.com/methods/stars.list](https://api.slack.com/methods/stars.list)

```php
function starsList(
    ?string $token = null,
    ?string $count = null,
    ?string $page = null,
    ?string $cursor = null,
    ?int $limit = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `?string` | Query, Optional | Authentication token. Requires scope: `stars:read` |
| `count` | `?string` | Query, Optional | - |
| `page` | `?string` | Query, Optional | - |
| `cursor` | `?string` | Query, Optional | Parameter for pagination. Set `cursor` equal to the `next_cursor` attribute returned by the previous request's `response_metadata`. This parameter is optional, but pagination is mandatory: the default value simply fetches the first "page" of the collection. |
| `limit` | `?int` | Query, Optional | The maximum number of items to return. Fewer than the requested number of items may be returned, even if the end of the list hasn't been reached. |

## Requires scope

### slackAuth

`stars:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`StarsListSchema`](../../doc/models/stars-list-schema.md).

## Example Usage

```php
$starsApi = $client->getStarsApi();
$apiResponse = $starsApi->starsList();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'StarsListSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`StarsListErrorSchemaException`](../../doc/models/stars-list-error-schema-exception.md) |


# Stars Remove

Removes a star from an item.

API method documentation: [https://api.slack.com/methods/stars.remove](https://api.slack.com/methods/stars.remove)

```php
function starsRemove(
    string $token,
    ?string $channel = null,
    ?string $file = null,
    ?string $fileComment = null,
    ?string $timestamp = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `stars:write` |
| `channel` | `?string` | Form, Optional | Channel to remove star from, or channel where the message to remove star from was posted (used with `timestamp`). |
| `file` | `?string` | Form, Optional | File to remove star from. |
| `fileComment` | `?string` | Form, Optional | File comment to remove star from. |
| `timestamp` | `?string` | Form, Optional | Timestamp of the message to remove star from. |

## Requires scope

### slackAuth

`stars:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`StarsRemoveSchema`](../../doc/models/stars-remove-schema.md).

## Example Usage

```php
$token = 'token6';

$starsApi = $client->getStarsApi();
$apiResponse = $starsApi->starsRemove($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'StarsRemoveSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`StarsRemoveErrorSchemaException`](../../doc/models/stars-remove-error-schema-exception.md) |


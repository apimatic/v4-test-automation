# Usergroups

```php
$usergroupsApi = $client->getUsergroupsApi();
```

## Class Name

`UsergroupsApi`

## Methods

* [Usergroups Create](../../doc/controllers/usergroups.md#usergroups-create)
* [Usergroups Disable](../../doc/controllers/usergroups.md#usergroups-disable)
* [Usergroups Enable](../../doc/controllers/usergroups.md#usergroups-enable)
* [Usergroups List](../../doc/controllers/usergroups.md#usergroups-list)
* [Usergroups Update](../../doc/controllers/usergroups.md#usergroups-update)


# Usergroups Create

Create a User Group

API method documentation: [https://api.slack.com/methods/usergroups.create](https://api.slack.com/methods/usergroups.create)

```php
function usergroupsCreate(
    string $token,
    string $name,
    ?string $channels = null,
    ?string $description = null,
    ?string $handle = null,
    ?bool $includeCount = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `usergroups:write` |
| `name` | `string` | Form, Required | A name for the User Group. Must be unique among User Groups. |
| `channels` | `?string` | Form, Optional | A comma separated string of encoded channel IDs for which the User Group uses as a default. |
| `description` | `?string` | Form, Optional | A short description of the User Group. |
| `handle` | `?string` | Form, Optional | A mention handle. Must be unique among channels, users and User Groups. |
| `includeCount` | `?bool` | Form, Optional | Include the number of users in each User Group. |

## Requires scope

### slackAuth

`usergroups:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`UsergroupsCreateSchema`](../../doc/models/usergroups-create-schema.md).

## Example Usage

```php
$token = 'token6';

$name = 'name0';

$usergroupsApi = $client->getUsergroupsApi();
$apiResponse = $usergroupsApi->usergroupsCreate(
    $token,
    $name
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'UsergroupsCreateSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`UsergroupsCreateErrorSchemaException`](../../doc/models/usergroups-create-error-schema-exception.md) |


# Usergroups Disable

Disable an existing User Group

API method documentation: [https://api.slack.com/methods/usergroups.disable](https://api.slack.com/methods/usergroups.disable)

```php
function usergroupsDisable(string $token, string $usergroup, ?bool $includeCount = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `usergroups:write` |
| `usergroup` | `string` | Form, Required | The encoded ID of the User Group to disable. |
| `includeCount` | `?bool` | Form, Optional | Include the number of users in the User Group. |

## Requires scope

### slackAuth

`usergroups:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`UsergroupsDisableSchema`](../../doc/models/usergroups-disable-schema.md).

## Example Usage

```php
$token = 'token6';

$usergroup = 'usergroup2';

$usergroupsApi = $client->getUsergroupsApi();
$apiResponse = $usergroupsApi->usergroupsDisable(
    $token,
    $usergroup
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'UsergroupsDisableSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`UsergroupsDisableErrorSchemaException`](../../doc/models/usergroups-disable-error-schema-exception.md) |


# Usergroups Enable

Enable a User Group

API method documentation: [https://api.slack.com/methods/usergroups.enable](https://api.slack.com/methods/usergroups.enable)

```php
function usergroupsEnable(string $token, string $usergroup, ?bool $includeCount = null): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `usergroups:write` |
| `usergroup` | `string` | Form, Required | The encoded ID of the User Group to enable. |
| `includeCount` | `?bool` | Form, Optional | Include the number of users in the User Group. |

## Requires scope

### slackAuth

`usergroups:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`UsergroupsEnableSchema`](../../doc/models/usergroups-enable-schema.md).

## Example Usage

```php
$token = 'token6';

$usergroup = 'usergroup2';

$usergroupsApi = $client->getUsergroupsApi();
$apiResponse = $usergroupsApi->usergroupsEnable(
    $token,
    $usergroup
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'UsergroupsEnableSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`UsergroupsEnableErrorSchemaException`](../../doc/models/usergroups-enable-error-schema-exception.md) |


# Usergroups List

List all User Groups for a team

API method documentation: [https://api.slack.com/methods/usergroups.list](https://api.slack.com/methods/usergroups.list)

```php
function usergroupsList(
    string $token,
    ?bool $includeUsers = null,
    ?bool $includeCount = null,
    ?bool $includeDisabled = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | Authentication token. Requires scope: `usergroups:read` |
| `includeUsers` | `?bool` | Query, Optional | Include the list of users for each User Group. |
| `includeCount` | `?bool` | Query, Optional | Include the number of users in each User Group. |
| `includeDisabled` | `?bool` | Query, Optional | Include disabled User Groups. |

## Requires scope

### slackAuth

`usergroups:read`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`UsergroupsListSchema`](../../doc/models/usergroups-list-schema.md).

## Example Usage

```php
$token = 'token6';

$usergroupsApi = $client->getUsergroupsApi();
$apiResponse = $usergroupsApi->usergroupsList($token);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'UsergroupsListSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`UsergroupsListErrorSchemaException`](../../doc/models/usergroups-list-error-schema-exception.md) |


# Usergroups Update

Update an existing User Group

API method documentation: [https://api.slack.com/methods/usergroups.update](https://api.slack.com/methods/usergroups.update)

```php
function usergroupsUpdate(
    string $token,
    string $usergroup,
    ?string $handle = null,
    ?string $description = null,
    ?string $channels = null,
    ?bool $includeCount = null,
    ?string $name = null
): ApiResponse
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Header, Required | Authentication token. Requires scope: `usergroups:write` |
| `usergroup` | `string` | Form, Required | The encoded ID of the User Group to update. |
| `handle` | `?string` | Form, Optional | A mention handle. Must be unique among channels, users and User Groups. |
| `description` | `?string` | Form, Optional | A short description of the User Group. |
| `channels` | `?string` | Form, Optional | A comma separated string of encoded channel IDs for which the User Group uses as a default. |
| `includeCount` | `?bool` | Form, Optional | Include the number of users in the User Group. |
| `name` | `?string` | Form, Optional | A name for the User Group. Must be unique among User Groups. |

## Requires scope

### slackAuth

`usergroups:write`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`UsergroupsUpdateSchema`](../../doc/models/usergroups-update-schema.md).

## Example Usage

```php
$token = 'token6';

$usergroup = 'usergroup2';

$usergroupsApi = $client->getUsergroupsApi();
$apiResponse = $usergroupsApi->usergroupsUpdate(
    $token,
    $usergroup
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'UsergroupsUpdateSchema:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`UsergroupsUpdateErrorSchemaException`](../../doc/models/usergroups-update-error-schema-exception.md) |



# Getting Started with Slack Web API

## Introduction

One way to interact with the Slack platform is its HTTP RPC-based Web API, a collection of methods requiring OAuth 2.0-based user, bot, or workspace tokens blessed with related OAuth scopes.

Learn more about the Slack Web API: [https://api.slack.com/web](https://api.slack.com/web)

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install slack-apimatic-sdk==1.0.0
```

You can also view the package at:
https://pypi.python.org/pypi/slack-apimatic-sdk/1.0.0

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 30** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT", "GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| logging_configuration | [`LoggingConfiguration`](doc/logging-configuration.md) | The SDK logging configuration for API calls |
| authorization_code_auth_credentials | [`AuthorizationCodeAuthCredentials`](doc/auth/oauth-2-authorization-code-grant.md) | The credential object for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

### Code-Based Client Initialization

```python
import logging

from slackwebapi.configuration import Environment
from slackwebapi.http.auth.oauth_2 import AuthorizationCodeAuthCredentials
from slackwebapi.logging.configuration.api_logging_configuration import LoggingConfiguration
from slackwebapi.logging.configuration.api_logging_configuration import RequestLoggingConfiguration
from slackwebapi.logging.configuration.api_logging_configuration import ResponseLoggingConfiguration
from slackwebapi.models.oauth_scope import OauthScope
from slackwebapi.slackwebapi_client import SlackwebapiClient

client = SlackwebapiClient(
    authorization_code_auth_credentials=AuthorizationCodeAuthCredentials(
        oauth_client_id='OAuthClientId',
        oauth_client_secret='OAuthClientSecret',
        oauth_redirect_uri='OAuthRedirectUri',
        oauth_scopes=[
            OauthScope.ADMIN,
            OauthScope.ADMIN_APPSREAD
        ]
    ),
    environment=Environment.PRODUCTION,
    logging_configuration=LoggingConfiguration(
        log_level=logging.INFO,
        request_logging_config=RequestLoggingConfiguration(
            log_body=True
        ),
        response_logging_config=ResponseLoggingConfiguration(
            log_headers=True
        )
    )
)
```

### Environment-Based Client Initialization

```python
from slackwebapi.slackwebapi_client import SlackwebapiClient

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = SlackwebapiClient.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](doc/environment-based-client-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| PRODUCTION | **Default** |

## Authorization

This API uses the following authentication schemes.

* [`slackAuth (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)

## List of APIs

* [Admin Apps](doc/controllers/admin-apps.md)
* [Admin Apps Approved](doc/controllers/admin-apps-approved.md)
* [Admin Apps Requests](doc/controllers/admin-apps-requests.md)
* [Admin Apps Restricted](doc/controllers/admin-apps-restricted.md)
* [Admin Conversations](doc/controllers/admin-conversations.md)
* [Admin Conversations Ekm](doc/controllers/admin-conversations-ekm.md)
* [Admin Conversations Restrict Access](doc/controllers/admin-conversations-restrict-access.md)
* [Admin Emoji](doc/controllers/admin-emoji.md)
* [Admin Invite Requests](doc/controllers/admin-invite-requests.md)
* [Admin Invite Requests Approved](doc/controllers/admin-invite-requests-approved.md)
* [Admin Invite Requests Denied](doc/controllers/admin-invite-requests-denied.md)
* [Admin Teams Admins](doc/controllers/admin-teams-admins.md)
* [Admin Teams](doc/controllers/admin-teams.md)
* [Admin Teams Owners](doc/controllers/admin-teams-owners.md)
* [Admin Teams Settings](doc/controllers/admin-teams-settings.md)
* [Admin Usergroups](doc/controllers/admin-usergroups.md)
* [Admin Users](doc/controllers/admin-users.md)
* [Admin Users Session](doc/controllers/admin-users-session.md)
* [Api](doc/controllers/api.md)
* [Apps Event Authorizations](doc/controllers/apps-event-authorizations.md)
* [Apps Permissions](doc/controllers/apps-permissions.md)
* [Apps Permissions Resources](doc/controllers/apps-permissions-resources.md)
* [Apps Permissions Scopes](doc/controllers/apps-permissions-scopes.md)
* [Apps Permissions Users](doc/controllers/apps-permissions-users.md)
* [Apps](doc/controllers/apps.md)
* [Auth](doc/controllers/auth.md)
* [Bots](doc/controllers/bots.md)
* [Calls](doc/controllers/calls.md)
* [Calls Participants](doc/controllers/calls-participants.md)
* [Chat](doc/controllers/chat.md)
* [Chat Scheduled Messages](doc/controllers/chat-scheduled-messages.md)
* [Conversations](doc/controllers/conversations.md)
* [Dialog](doc/controllers/dialog.md)
* [Dnd](doc/controllers/dnd.md)
* [Emoji](doc/controllers/emoji.md)
* [Files Comments](doc/controllers/files-comments.md)
* [Files](doc/controllers/files.md)
* [Files Remote](doc/controllers/files-remote.md)
* [Migration](doc/controllers/migration.md)
* [oauth](doc/controllers/oauth.md)
* [oauth V2](doc/controllers/oauth-v2.md)
* [Pins](doc/controllers/pins.md)
* [Reactions](doc/controllers/reactions.md)
* [Reminders](doc/controllers/reminders.md)
* [Rtm](doc/controllers/rtm.md)
* [Search](doc/controllers/search.md)
* [Stars](doc/controllers/stars.md)
* [Team](doc/controllers/team.md)
* [Team Profile](doc/controllers/team-profile.md)
* [Usergroups](doc/controllers/usergroups.md)
* [Usergroups Users](doc/controllers/usergroups-users.md)
* [Users](doc/controllers/users.md)
* [Users Profile](doc/controllers/users-profile.md)
* [Views](doc/controllers/views.md)
* [Workflows](doc/controllers/workflows.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](doc/proxy-settings.md)
* [Environment-Based Client Initialization](doc/environment-based-client-initialization.md)
* [AbstractLogger](doc/abstract-logger.md)
* [LoggingConfiguration](doc/logging-configuration.md)
* [RequestLoggingConfiguration](doc/request-logging-configuration.md)
* [ResponseLoggingConfiguration](doc/response-logging-configuration.md)

### HTTP

* [HttpResponse](doc/http-response.md)
* [HttpRequest](doc/http-request.md)

### Utilities

* [ApiResponse](doc/api-response.md)
* [ApiHelper](doc/api-helper.md)
* [HttpDateTime](doc/http-date-time.md)
* [RFC3339DateTime](doc/rfc3339-date-time.md)
* [UnixDateTime](doc/unix-date-time.md)


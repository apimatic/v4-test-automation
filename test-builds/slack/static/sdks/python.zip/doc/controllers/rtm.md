# Rtm

```python
rtm_api = client.rtm
```

## Class Name

`RtmApi`


# Rtm Connect

Starts a Real Time Messaging session.

API method documentation: [https://api.slack.com/methods/rtm.connect](https://api.slack.com/methods/rtm.connect)

```python
def rtm_connect(self,
               token,
               batch_presence_aware=None,
               presence_sub=None)
```

## Authentication

This endpoint requires [slackAuth](../../doc/auth/oauth-2-authorization-code-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `str` | Query, Required | Authentication token. Requires scope: `rtm:stream` |
| `batch_presence_aware` | `bool` | Query, Optional | Batch presence deliveries via subscription. Enabling changes the shape of `presence_change` events. |
| `presence_sub` | `bool` | Query, Optional | Only deliver presence events when requested by subscription |

## Requires scope

### slackAuth

`rtm:stream`

## Response Type

**200**: Typical success response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`RtmConnectSchema`](../../doc/models/rtm-connect-schema.md).

## Example Usage

```python
token = 'token6'

result = rtm_api.rtm_connect(token)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Typical error response | [`RtmConnectErrorSchemaException`](../../doc/models/rtm-connect-error-schema-exception.md) |


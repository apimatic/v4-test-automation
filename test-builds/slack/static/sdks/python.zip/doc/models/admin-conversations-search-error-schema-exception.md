
# Admin Conversations Search Error Schema Exception

Schema for error response from admin.conversations.search

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsSearchErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsSearchErrorEnum`](../../doc/models/admin-conversations-search-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except AdminConversationsSearchErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


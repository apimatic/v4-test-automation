
# Rtm Connect Schema

Schema for successful response from rtm.connect method

*This model accepts additional fields of type Any.*

## Structure

`RtmConnectSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `mself` | [`Self`](../../doc/models/self.md) | Required | - |
| `team` | [`Team1`](../../doc/models/team-1.md) | Required | - |
| `url` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.mself import Self
from slackwebapi.models.rtm_connect_schema import RtmConnectSchema
from slackwebapi.models.team_1 import Team1

rtm_connect_schema = RtmConnectSchema(
    mself=Self(
        id='id8',
        name='name8',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    team=Team1(
        domain='domain6',
        id='id0',
        name='name0',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    url='url8',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


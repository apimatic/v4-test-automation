
# Conversations Kick Success Schema

Schema for successful response conversations.kick method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsKickSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_kick_success_schema import ConversationsKickSuccessSchema

conversations_kick_success_schema = ConversationsKickSuccessSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


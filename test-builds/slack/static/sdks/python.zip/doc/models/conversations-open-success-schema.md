
# Conversations Open Success Schema

Schema for successful response from conversations.open method when opening channels, ims, mpims

*This model accepts additional fields of type Any.*

## Structure

`ConversationsOpenSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `already_open` | `bool` | Optional | - |
| `channel` | `Any` | Required | - |
| `no_op` | `bool` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_open_success_schema import ConversationsOpenSuccessSchema

conversations_open_success_schema = ConversationsOpenSuccessSchema(
    channel=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    already_open=False,
    no_op=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Migration Exchange Error Schema Exception

Schema for error response from migration.exchange method

*This model accepts additional fields of type Any.*

## Structure

`MigrationExchangeErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`MigrationExchangeErrorEnum`](../../doc/models/migration-exchange-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except MigrationExchangeErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


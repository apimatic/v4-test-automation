
# Dnd End Snooze Error Schema Exception

Schema for error response from dnd.endSnooze method

*This model accepts additional fields of type Any.*

## Structure

`DndEndSnoozeErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndEndSnoozeErrorEnum`](../../doc/models/dnd-end-snooze-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except DndEndSnoozeErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Usergroups Create Error Schema Exception

Schema for error response from usergroups.create method

*This model accepts additional fields of type Any.*

## Structure

`UsergroupsCreateErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsCreateErrorEnum`](../../doc/models/usergroups-create-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsergroupsCreateErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


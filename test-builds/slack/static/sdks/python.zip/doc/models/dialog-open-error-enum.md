
# Dialog Open Error Enum

## Enumeration

`DialogOpenErrorEnum`

## Fields

| Name |
|  --- |
| `VALIDATION_ERRORS` |
| `MISSING_TRIGGER` |
| `MISSING_DIALOG` |
| `TRIGGER_EXCHANGED` |
| `TRIGGER_EXPIRED` |
| `INVALID_TRIGGER` |
| `APP_MISSING_ACTION_URL` |
| `CANNOT_CREATE_DIALOG` |
| `FAILED_SENDING_DIALOG` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```python
from slackwebapi.models.dialog_open_error_enum import DialogOpenErrorEnum

dialog_open_error_enum = DialogOpenErrorEnum.TOKEN_REVOKED
```



# Admin Conversations Archive Schema

Schema for successful response of admin.conversations.archive

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsArchiveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_archive_schema import AdminConversationsArchiveSchema

admin_conversations_archive_schema = AdminConversationsArchiveSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


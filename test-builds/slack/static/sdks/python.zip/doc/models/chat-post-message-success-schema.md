
# Chat Post Message Success Schema

Schema for successful response of chat.postMessage method

*This model accepts additional fields of type Any.*

## Structure

`ChatPostMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `str` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `message` | [`MessageObject`](../../doc/models/message-object.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `ts` | `str` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.attachment import Attachment
from slackwebapi.models.block_kit_block import BlockKitBlock
from slackwebapi.models.bot_profile_object import BotProfileObject
from slackwebapi.models.chat_post_message_success_schema import ChatPostMessageSuccessSchema
from slackwebapi.models.icons import Icons
from slackwebapi.models.message_object import MessageObject

chat_post_message_success_schema = ChatPostMessageSuccessSchema(
    channel='channel0',
    message=MessageObject(
        text='text0',
        ts='ts2',
        mtype='type0',
        attachments=[
            Attachment(
                id=36,
                fallback='fallback4',
                image_bytes=34,
                image_height=154,
                image_url='image_url6',
                image_width=24,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Attachment(
                id=36,
                fallback='fallback4',
                image_bytes=34,
                image_height=154,
                image_url='image_url6',
                image_width=24,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        blocks=[
            BlockKitBlock(
                mtype='type4',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            BlockKitBlock(
                mtype='type4',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        bot_id=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
        bot_profile=BotProfileObject(
            app_id='app_id8',
            deleted=False,
            icons=Icons(
                image_36='image_362',
                image_48='image_488',
                image_72='image_722',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            id='id8',
            name='name8',
            team_id='team_id8',
            updated=44,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        client_msg_id='client_msg_id4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    ts='ts6',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


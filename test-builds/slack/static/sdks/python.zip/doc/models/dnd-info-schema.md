
# Dnd Info Schema

Schema for successful response from dnd.info method

*This model accepts additional fields of type Any.*

## Structure

`DndInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dnd_enabled` | `bool` | Required | - |
| `next_dnd_end_ts` | `int` | Required | - |
| `next_dnd_start_ts` | `int` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `snooze_enabled` | `bool` | Optional | - |
| `snooze_endtime` | `int` | Optional | - |
| `snooze_remaining` | `int` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.dnd_info_schema import DndInfoSchema

dnd_info_schema = DndInfoSchema(
    dnd_enabled=False,
    next_dnd_end_ts=18,
    next_dnd_start_ts=62,
    snooze_enabled=False,
    snooze_endtime=216,
    snooze_remaining=216,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


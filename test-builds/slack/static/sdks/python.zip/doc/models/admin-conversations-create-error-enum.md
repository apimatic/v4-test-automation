
# Admin Conversations Create Error Enum

## Enumeration

`AdminConversationsCreateErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `NAME_TAKEN` |
| `RESTRICTED_ACTION` |
| `TEAM_NOT_FOUND` |
| `INVALID_TEAM` |
| `INVALID_NAME` |
| `COULD_NOT_CREATE_CHANNEL` |
| `TEAM_ID_OR_ORG_REQUIRED` |

## Example

```python
from slackwebapi.models.admin_conversations_create_error_enum import AdminConversationsCreateErrorEnum

admin_conversations_create_error_enum = AdminConversationsCreateErrorEnum.RESTRICTED_ACTION
```



# Apps Permissions Request Error Schema Exception

Schema for error response from apps.permissions.request method

*This model accepts additional fields of type Any.*

## Structure

`AppsPermissionsRequestErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsRequestErrorEnum`](../../doc/models/apps-permissions-request-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except AppsPermissionsRequestErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


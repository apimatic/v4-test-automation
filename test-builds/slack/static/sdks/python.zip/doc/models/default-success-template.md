
# Default Success Template

This method either only returns a brief _OK_ response or a verbose schema is not available for this method.

*This model accepts additional fields of type Any.*

## Structure

`DefaultSuccessTemplate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.default_success_template import DefaultSuccessTemplate

default_success_template = DefaultSuccessTemplate(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


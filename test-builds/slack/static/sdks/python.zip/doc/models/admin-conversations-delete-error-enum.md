
# Admin Conversations Delete Error Enum

## Enumeration

`AdminConversationsDeleteErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `NOT_AN_ADMIN` |
| `CHANNEL_NOT_FOUND` |
| `CHANNEL_TYPE_NOT_SUPPORTED` |
| `DEFAULT_ORG_WIDE_CHANNEL` |
| `RESTRICTED_ACTION` |
| `COULD_NOT_DELETE_CHANNEL` |
| `MISSING_SCOPE` |

## Example

```python
from slackwebapi.models.admin_conversations_delete_error_enum import AdminConversationsDeleteErrorEnum

admin_conversations_delete_error_enum = AdminConversationsDeleteErrorEnum.DEFAULT_ORG_WIDE_CHANNEL
```



# Chat Unfurl Success Schema

Schema for successful response from chat.unfurl method

*This model accepts additional fields of type Any.*

## Structure

`ChatUnfurlSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.chat_unfurl_success_schema import ChatUnfurlSuccessSchema

chat_unfurl_success_schema = ChatUnfurlSuccessSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Attachment

*This model accepts additional fields of type Any.*

## Structure

`Attachment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fallback` | `str` | Optional | - |
| `id` | `int` | Required | - |
| `image_bytes` | `int` | Optional | - |
| `image_height` | `int` | Optional | - |
| `image_url` | `str` | Optional | - |
| `image_width` | `int` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.attachment import Attachment

attachment = Attachment(
    id=248,
    fallback='fallback6',
    image_bytes=78,
    image_height=110,
    image_url='image_url4',
    image_width=236,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


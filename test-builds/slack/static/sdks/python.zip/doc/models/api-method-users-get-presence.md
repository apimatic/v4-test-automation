
# Api Method Users Get Presence

Generated from users.getPresence with shasum e7251aec575d8863f9e0eb38663ae9dc26655f65

*This model accepts additional fields of type Any.*

## Structure

`ApiMethodUsersGetPresence`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `auto_away` | `bool` | Optional | - |
| `connection_count` | `int` | Optional | - |
| `last_activity` | `int` | Optional | - |
| `manual_away` | `bool` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `online` | `bool` | Optional | - |
| `presence` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.api_method_users_get_presence import ApiMethodUsersGetPresence

api_method_users_get_presence = ApiMethodUsersGetPresence(
    presence='presence8',
    auto_away=False,
    connection_count=32,
    last_activity=156,
    manual_away=False,
    online=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


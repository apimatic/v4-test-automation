
# Conversations Kick Error Schema Exception

Schema for error response conversations.kick method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsKickErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsKickErrorEnum`](../../doc/models/conversations-kick-error-enum.md) | Required | - |
| `needed` | `str` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `provided` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ConversationsKickErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Conversations Members Error Enum

## Enumeration

`ConversationsMembersErrorEnum`

## Fields

| Name |
|  --- |
| `CHANNEL_NOT_FOUND` |
| `INVALID_LIMIT` |
| `INVALID_CURSOR` |
| `FETCH_MEMBERS_FAILED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```python
from slackwebapi.models.conversations_members_error_enum import ConversationsMembersErrorEnum

conversations_members_error_enum = ConversationsMembersErrorEnum.MISSING_POST_TYPE
```


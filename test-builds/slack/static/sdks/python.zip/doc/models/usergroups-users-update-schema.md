
# Usergroups Users Update Schema

Schema for successful response from usergroups.users.update method

*This model accepts additional fields of type Any.*

## Structure

`UsergroupsUsersUpdateSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `usergroup` | [`SubteamUsergroupObject`](../../doc/models/subteam-usergroup-object.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.prefs import Prefs
from slackwebapi.models.subteam_usergroup_object import SubteamUsergroupObject
from slackwebapi.models.usergroups_users_update_schema import UsergroupsUsersUpdateSchema

usergroups_users_update_schema = UsergroupsUsersUpdateSchema(
    usergroup=SubteamUsergroupObject(
        auto_provision=False,
        auto_type=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
        created_by='created_by0',
        date_create=164,
        date_delete=212,
        date_update=198,
        deleted_by=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
        description='description2',
        enterprise_subteam_id='enterprise_subteam_id0',
        handle='handle8',
        id='id2',
        is_external=False,
        is_subteam=False,
        is_usergroup=False,
        name='name2',
        prefs=Prefs(
            channels=[
                'channels5',
                'channels4'
            ],
            groups=[
                'groups4',
                'groups5',
                'groups6'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        team_id='team_id6',
        updated_by='updated_by6',
        channel_count=64,
        user_count=70,
        users=[
            'users3',
            'users4',
            'users5'
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


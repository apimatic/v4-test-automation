
# Conversations Rename Error Schema Exception

Schema for error response from conversations.rename method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsRenameErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsRenameErrorEnum`](../../doc/models/conversations-rename-error-enum.md) | Required | - |
| `needed` | `str` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `provided` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ConversationsRenameErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


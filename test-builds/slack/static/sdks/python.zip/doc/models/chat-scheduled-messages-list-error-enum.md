
# Chat Scheduled Messages List Error Enum

## Enumeration

`ChatScheduledMessagesListErrorEnum`

## Fields

| Name |
|  --- |
| `INVALID_CHANNEL` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `EKM_ACCESS_DENIED` |
| `MISSING_SCOPE` |
| `INVALID_ARGUMENTS` |
| `INVALID_ARG_NAME` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```python
from slackwebapi.models.chat_scheduled_messages_list_error_enum import ChatScheduledMessagesListErrorEnum

chat_scheduled_messages_list_error_enum = ChatScheduledMessagesListErrorEnum.NOT_AUTHED
```



# Current

*This model accepts additional fields of type Any.*

## Structure

`Current`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date_started` | `int` | Required | - |
| `team_id` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.current import Current

current = Current(
    date_started=84,
    team_id='team_id0',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


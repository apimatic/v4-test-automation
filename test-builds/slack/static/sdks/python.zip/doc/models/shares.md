
# Shares

*This model accepts additional fields of type Any.*

## Structure

`Shares`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `private` | `Any` | Optional | - |
| `public` | `Any` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.shares import Shares

shares = Shares(
    private=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    public=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Apps Permissions Resources List Success Schema

Schema for successful response apps.permissions.resources.list method

*This model accepts additional fields of type Any.*

## Structure

`AppsPermissionsResourcesListSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `resources` | [`List[Resource]`](../../doc/models/resource.md) | Required | - |
| `response_metadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.apps_permissions_resources_list_success_schema import AppsPermissionsResourcesListSuccessSchema
from slackwebapi.models.resource import Resource
from slackwebapi.models.response_metadata import ResponseMetadata

apps_permissions_resources_list_success_schema = AppsPermissionsResourcesListSuccessSchema(
    resources=[
        Resource(
            id='id0',
            mtype='type0',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    response_metadata=ResponseMetadata(
        next_cursor='next_cursor2',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Sso Provider

*This model accepts additional fields of type Any.*

## Structure

`SsoProvider`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | `str` | Optional | - |
| `name` | `str` | Optional | - |
| `mtype` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.sso_provider import SsoProvider

sso_provider = SsoProvider(
    label='label6',
    name='name6',
    mtype='type4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


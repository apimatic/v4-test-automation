
# Subteam Usergroup Object

*This model accepts additional fields of type Any.*

## Structure

`SubteamUsergroupObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `auto_provision` | `bool` | Required | - |
| `auto_type` | `Any` | Required | - |
| `channel_count` | `int` | Optional | - |
| `created_by` | `str` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `date_create` | `int` | Required | - |
| `date_delete` | `int` | Required | - |
| `date_update` | `int` | Required | - |
| `deleted_by` | `Any` | Required | - |
| `description` | `str` | Required | - |
| `enterprise_subteam_id` | `str` | Required | - |
| `handle` | `str` | Required | - |
| `id` | `str` | Required | **Constraints**: *Pattern*: `^S[A-Z0-9]{2,}$` |
| `is_external` | `bool` | Required | - |
| `is_subteam` | `bool` | Required | - |
| `is_usergroup` | `bool` | Required | - |
| `name` | `str` | Required | - |
| `prefs` | [`Prefs`](../../doc/models/prefs.md) | Required | - |
| `team_id` | `str` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `updated_by` | `str` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `user_count` | `int` | Optional | - |
| `users` | `List[str]` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.prefs import Prefs
from slackwebapi.models.subteam_usergroup_object import SubteamUsergroupObject

subteam_usergroup_object = SubteamUsergroupObject(
    auto_provision=False,
    auto_type=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    created_by='created_by6',
    date_create=96,
    date_delete=144,
    date_update=130,
    deleted_by=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    description='description8',
    enterprise_subteam_id='enterprise_subteam_id6',
    handle='handle4',
    id='id8',
    is_external=False,
    is_subteam=False,
    is_usergroup=False,
    name='name8',
    prefs=Prefs(
        channels=[
            'channels5',
            'channels4'
        ],
        groups=[
            'groups4',
            'groups5',
            'groups6'
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    team_id='team_id2',
    updated_by='updated_by2',
    channel_count=252,
    user_count=2,
    users=[
        'users9',
        'users0',
        'users1'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


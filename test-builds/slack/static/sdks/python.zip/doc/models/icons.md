
# Icons

*This model accepts additional fields of type Any.*

## Structure

`Icons`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image_36` | `str` | Required | - |
| `image_48` | `str` | Required | - |
| `image_72` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.icons import Icons

icons = Icons(
    image_36='image_362',
    image_48='image_488',
    image_72='image_722',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Admin Conversations Invite Schema

Schema for successful response of admin.conversations.invite

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsInviteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_invite_schema import AdminConversationsInviteSchema

admin_conversations_invite_schema = AdminConversationsInviteSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Chat Delete Error Schema Exception

Schema for error response from chat.delete method

*This model accepts additional fields of type Any.*

## Structure

`ChatDeleteErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatDeleteErrorEnum`](../../doc/models/chat-delete-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ChatDeleteErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


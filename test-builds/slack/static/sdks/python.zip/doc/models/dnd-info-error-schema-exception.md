
# Dnd Info Error Schema Exception

Schema for error response from dnd.info method

*This model accepts additional fields of type Any.*

## Structure

`DndInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndInfoErrorEnum`](../../doc/models/dnd-info-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except DndInfoErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Purpose

*This model accepts additional fields of type Any.*

## Structure

`Purpose`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `creator` | `str` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{8,}$\|^$` |
| `last_set` | `int` | Required | - |
| `value` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.purpose import Purpose

purpose = Purpose(
    creator='creator4',
    last_set=30,
    value='value8',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


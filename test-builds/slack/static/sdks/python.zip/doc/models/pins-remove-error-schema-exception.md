
# Pins Remove Error Schema Exception

Schema for error response from pins.remove method

*This model accepts additional fields of type Any.*

## Structure

`PinsRemoveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`PinsRemoveErrorEnum`](../../doc/models/pins-remove-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except PinsRemoveErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


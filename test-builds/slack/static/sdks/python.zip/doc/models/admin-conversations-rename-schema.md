
# Admin Conversations Rename Schema

Schema for successful response of admin.conversations.disconnectShared

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsRenameSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_rename_schema import AdminConversationsRenameSchema

admin_conversations_rename_schema = AdminConversationsRenameSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


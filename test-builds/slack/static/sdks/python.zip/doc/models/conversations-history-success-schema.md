
# Conversations History Success Schema

Schema for successful response from conversations.history method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsHistorySuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel_actions_count` | `int` | Required | - |
| `channel_actions_ts` | `Any` | Required | - |
| `has_more` | `bool` | Required | - |
| `messages` | [`List[MessageObject]`](../../doc/models/message-object.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `pin_count` | `int` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.attachment import Attachment
from slackwebapi.models.block_kit_block import BlockKitBlock
from slackwebapi.models.bot_profile_object import BotProfileObject
from slackwebapi.models.conversations_history_success_schema import ConversationsHistorySuccessSchema
from slackwebapi.models.icons import Icons
from slackwebapi.models.message_object import MessageObject

conversations_history_success_schema = ConversationsHistorySuccessSchema(
    channel_actions_count=96,
    channel_actions_ts=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    has_more=False,
    messages=[
        MessageObject(
            text='text8',
            ts='ts0',
            mtype='type8',
            attachments=[
                Attachment(
                    id=36,
                    fallback='fallback4',
                    image_bytes=34,
                    image_height=154,
                    image_url='image_url6',
                    image_width=24,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                Attachment(
                    id=36,
                    fallback='fallback4',
                    image_bytes=34,
                    image_height=154,
                    image_url='image_url6',
                    image_width=24,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            blocks=[
                BlockKitBlock(
                    mtype='type4',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                BlockKitBlock(
                    mtype='type4',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            bot_id=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
            bot_profile=BotProfileObject(
                app_id='app_id8',
                deleted=False,
                icons=Icons(
                    image_36='image_362',
                    image_48='image_488',
                    image_72='image_722',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                id='id8',
                name='name8',
                team_id='team_id8',
                updated=44,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            client_msg_id='client_msg_id4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    pin_count=162,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# File Comment Object

*This model accepts additional fields of type Any.*

## Structure

`FileCommentObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `comment` | `str` | Required | - |
| `created` | `int` | Required | - |
| `id` | `str` | Required | **Constraints**: *Pattern*: `^Fc[A-Z0-9]{8,}$` |
| `is_intro` | `bool` | Required | - |
| `is_starred` | `bool` | Optional | - |
| `num_stars` | `int` | Optional | - |
| `pinned_info` | `Any` | Optional | - |
| `pinned_to` | `List[str]` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `reactions` | [`List[ReactionObject]`](../../doc/models/reaction-object.md) | Optional | - |
| `timestamp` | `int` | Required | - |
| `user` | `str` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.file_comment_object import FileCommentObject
from slackwebapi.models.reaction_object import ReactionObject

file_comment_object = FileCommentObject(
    comment='comment8',
    created=190,
    id='id4',
    is_intro=False,
    timestamp=168,
    user='user4',
    is_starred=False,
    num_stars=158,
    pinned_info=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    pinned_to=[
        'pinned_to8',
        'pinned_to9',
        'pinned_to0'
    ],
    reactions=[
        ReactionObject(
            count=208,
            name='name8',
            users=[
                'users5',
                'users6',
                'users7'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


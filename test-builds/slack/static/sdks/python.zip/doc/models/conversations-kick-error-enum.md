
# Conversations Kick Error Enum

## Enumeration

`ConversationsKickErrorEnum`

## Fields

| Name |
|  --- |
| `METHOD_NOT_SUPPORTED_FOR_CHANNEL_TYPE` |
| `MISSING_SCOPE` |
| `CHANNEL_NOT_FOUND` |
| `USER_NOT_FOUND` |
| `CANT_KICK_SELF` |
| `NOT_IN_CHANNEL` |
| `CANT_KICK_FROM_GENERAL` |
| `RESTRICTED_ACTION` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `USER_IS_BOT` |
| `USER_IS_RESTRICTED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```python
from slackwebapi.models.conversations_kick_error_enum import ConversationsKickErrorEnum

conversations_kick_error_enum = ConversationsKickErrorEnum.MISSING_POST_TYPE
```



# Conversations Create Success Schema

Schema for successful response conversations.create method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsCreateSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `Any` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_create_success_schema import ConversationsCreateSuccessSchema

conversations_create_success_schema = ConversationsCreateSuccessSchema(
    channel=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Pins Add Schema

Schema for successful response from pins.add method

*This model accepts additional fields of type Any.*

## Structure

`PinsAddSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.pins_add_schema import PinsAddSchema

pins_add_schema = PinsAddSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


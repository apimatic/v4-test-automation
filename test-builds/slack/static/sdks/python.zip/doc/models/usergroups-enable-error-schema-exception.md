
# Usergroups Enable Error Schema Exception

Schema for error response from usergroups.enable method

*This model accepts additional fields of type Any.*

## Structure

`UsergroupsEnableErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsEnableErrorEnum`](../../doc/models/usergroups-enable-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsergroupsEnableErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


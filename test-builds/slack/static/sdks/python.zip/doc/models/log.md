
# Log

*This model accepts additional fields of type Any.*

## Structure

`Log`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `admin_app_id` | `str` | Optional | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` |
| `app_id` | `str` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` |
| `app_type` | `str` | Required | - |
| `change_type` | `str` | Required | - |
| `channel` | `str` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `date` | `str` | Required | - |
| `scope` | `str` | Required | - |
| `service_id` | `str` | Optional | - |
| `service_type` | `str` | Optional | - |
| `user_id` | `str` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `user_name` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.log import Log

log = Log(
    app_id='app_id8',
    app_type='app_type2',
    change_type='change_type8',
    date='date6',
    scope='scope4',
    user_id='user_id6',
    user_name='user_name4',
    admin_app_id='admin_app_id6',
    channel='channel6',
    service_id='service_id2',
    service_type='service_type4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Reminders Info Error Schema Exception

Schema for error response from reminders.info method

*This model accepts additional fields of type Any.*

## Structure

`RemindersInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RemindersDeleteErrorEnum`](../../doc/models/reminders-delete-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except RemindersInfoErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


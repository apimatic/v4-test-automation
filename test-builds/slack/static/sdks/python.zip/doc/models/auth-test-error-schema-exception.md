
# Auth Test Error Schema Exception

Schema for error response auth.test method

*This model accepts additional fields of type Any.*

## Structure

`AuthTestErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AuthTestErrorEnum`](../../doc/models/auth-test-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except AuthTestErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


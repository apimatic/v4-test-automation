
# Team Profile Get Error Schema Exception

Schema for error response from team.profile.get method

*This model accepts additional fields of type Any.*

## Structure

`TeamProfileGetErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`TeamProfileGetErrorEnum`](../../doc/models/team-profile-get-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except TeamProfileGetErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


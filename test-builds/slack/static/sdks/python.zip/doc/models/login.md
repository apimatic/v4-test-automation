
# Login

*This model accepts additional fields of type Any.*

## Structure

`Login`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `int` | Required | - |
| `country` | `str` | Required | - |
| `date_first` | `int` | Required | - |
| `date_last` | `int` | Required | - |
| `ip` | `str` | Required | - |
| `isp` | `str` | Required | - |
| `region` | `str` | Required | - |
| `user_agent` | `str` | Required | - |
| `user_id` | `str` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `username` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.login import Login

login = Login(
    count=110,
    country='country4',
    date_first=206,
    date_last=222,
    ip='ip4',
    isp='isp0',
    region='region6',
    user_agent='user_agent2',
    user_id='user_id8',
    username='username0',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Admin Conversations Convert to Private Schema

Schema for successful response of admin.conversations.convertToPrivate

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsConvertToPrivateSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_convert_to_private_schema import AdminConversationsConvertToPrivateSchema

admin_conversations_convert_to_private_schema = AdminConversationsConvertToPrivateSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


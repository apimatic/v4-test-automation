
# Migration Exchange Success Schema

Schema for successful response from migration.exchange method

*This model accepts additional fields of type Any.*

## Structure

`MigrationExchangeSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enterprise_id` | `str` | Required | - |
| `invalid_user_ids` | `List[str]` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `team_id` | `str` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `user_id_map` | `Any` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.migration_exchange_success_schema import MigrationExchangeSuccessSchema

migration_exchange_success_schema = MigrationExchangeSuccessSchema(
    enterprise_id='enterprise_id6',
    team_id='team_id0',
    invalid_user_ids=[
        'invalid_user_ids4'
    ],
    user_id_map=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


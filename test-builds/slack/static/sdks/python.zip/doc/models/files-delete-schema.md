
# Files Delete Schema

Schema for successful response files.delete method

*This model accepts additional fields of type Any.*

## Structure

`FilesDeleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.files_delete_schema import FilesDeleteSchema

files_delete_schema = FilesDeleteSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


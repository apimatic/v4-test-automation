
# Files List Schema

Schema for successful response from files.list method

*This model accepts additional fields of type Any.*

## Structure

`FilesListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `files` | [`List[FileObject]`](../../doc/models/file-object.md) | Required | **Constraints**: *Minimum Items*: `0`, *Unique Items Required* |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.file_object import FileObject
from slackwebapi.models.files_list_schema import FilesListSchema
from slackwebapi.models.paging_object import PagingObject

files_list_schema = FilesListSchema(
    files=[
        FileObject(
            channels=[
                'channels9'
            ],
            comments_count=150,
            created=58,
            date_delete=212,
            display_as_bot=False,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    paging=PagingObject(
        page=26,
        total=6,
        count=56,
        pages=150,
        per_page=194,
        spill=246,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


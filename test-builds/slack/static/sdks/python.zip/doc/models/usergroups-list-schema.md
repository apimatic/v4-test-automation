
# Usergroups List Schema

Schema for successful response from usergroups.list method

*This model accepts additional fields of type Any.*

## Structure

`UsergroupsListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `usergroups` | [`List[SubteamUsergroupObject]`](../../doc/models/subteam-usergroup-object.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.prefs import Prefs
from slackwebapi.models.subteam_usergroup_object import SubteamUsergroupObject
from slackwebapi.models.usergroups_list_schema import UsergroupsListSchema

usergroups_list_schema = UsergroupsListSchema(
    usergroups=[
        SubteamUsergroupObject(
            auto_provision=False,
            auto_type=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
            created_by='created_by8',
            date_create=66,
            date_delete=114,
            date_update=100,
            deleted_by=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
            description='description6',
            enterprise_subteam_id='enterprise_subteam_id2',
            handle='handle0',
            id='id4',
            is_external=False,
            is_subteam=False,
            is_usergroup=False,
            name='name4',
            prefs=Prefs(
                channels=[
                    'channels5',
                    'channels4'
                ],
                groups=[
                    'groups4',
                    'groups5',
                    'groups6'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            team_id='team_id2',
            updated_by='updated_by8',
            channel_count=222,
            user_count=28,
            users=[
                'users9'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


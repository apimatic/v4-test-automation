
# Chat Update Success Schema

Schema for successful response of chat.update method

*This model accepts additional fields of type Any.*

## Structure

`ChatUpdateSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `str` | Required | - |
| `message` | [`MessageObject1`](../../doc/models/message-object-1.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `text` | `str` | Required | - |
| `ts` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.chat_update_success_schema import ChatUpdateSuccessSchema
from slackwebapi.models.message_object_1 import MessageObject1

chat_update_success_schema = ChatUpdateSuccessSchema(
    channel='channel2',
    message=MessageObject1(
        text='text0',
        attachments=[
            jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
            jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        ],
        blocks=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    text='text8',
    ts='ts4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


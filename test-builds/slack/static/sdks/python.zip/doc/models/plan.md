
# Plan

## Enumeration

`Plan`

## Fields

| Name |
|  --- |
| `STD` |
| `PLUS` |
| `COMPLIANCE` |
| `ENTERPRISE` |

## Example

```python
from slackwebapi.models.plan import Plan

plan = Plan.COMPLIANCE
```


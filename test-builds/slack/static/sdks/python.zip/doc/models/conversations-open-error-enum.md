
# Conversations Open Error Enum

## Enumeration

`ConversationsOpenErrorEnum`

## Fields

| Name |
|  --- |
| `METHOD_NOT_SUPPORTED_FOR_CHANNEL_TYPE` |
| `USER_NOT_FOUND` |
| `USER_NOT_VISIBLE` |
| `USER_DISABLED` |
| `USERS_LIST_NOT_SUPPLIED` |
| `NOT_ENOUGH_USERS` |
| `TOO_MANY_USERS` |
| `INVALID_USER_COMBINATION` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `CHANNEL_NOT_FOUND` |

## Example

```python
from slackwebapi.models.conversations_open_error_enum import ConversationsOpenErrorEnum

conversations_open_error_enum = ConversationsOpenErrorEnum.NOT_ENOUGH_USERS
```


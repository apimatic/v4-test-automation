
# Users Set Active Error Enum

## Enumeration

`UsersSetActiveErrorEnum`

## Fields

| Name |
|  --- |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `EKM_ACCESS_DENIED` |
| `MISSING_SCOPE` |
| `INVALID_ARGUMENTS` |
| `INVALID_ARG_NAME` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `REQUEST_TIMEOUT` |
| `FATAL_ERROR` |
| `INTERNAL_ERROR` |

## Example

```python
from slackwebapi.models.users_set_active_error_enum import UsersSetActiveErrorEnum

users_set_active_error_enum = UsersSetActiveErrorEnum.ACCOUNT_INACTIVE
```


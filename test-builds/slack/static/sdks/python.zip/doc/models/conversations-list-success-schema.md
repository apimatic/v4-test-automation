
# Conversations List Success Schema

Schema for successful response from conversations.list method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsListSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channels` | `List[Any]` | Required | **Constraints**: *Unique Items Required* |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `response_metadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_list_success_schema import ConversationsListSuccessSchema
from slackwebapi.models.response_metadata import ResponseMetadata

conversations_list_success_schema = ConversationsListSuccessSchema(
    channels=[
        jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
        jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    ],
    response_metadata=ResponseMetadata(
        next_cursor='next_cursor2',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


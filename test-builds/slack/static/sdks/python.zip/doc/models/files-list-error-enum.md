
# Files List Error Enum

## Enumeration

`FilesListErrorEnum`

## Fields

| Name |
|  --- |
| `USER_NOT_FOUND` |
| `UNKNOWN_TYPE` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `USER_IS_BOT` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```python
from slackwebapi.models.files_list_error_enum import FilesListErrorEnum

files_list_error_enum = FilesListErrorEnum.INVALID_JSON
```


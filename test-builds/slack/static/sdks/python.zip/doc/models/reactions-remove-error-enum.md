
# Reactions Remove Error Enum

## Enumeration

`ReactionsRemoveErrorEnum`

## Fields

| Name |
|  --- |
| `BAD_TIMESTAMP` |
| `FILE_NOT_FOUND` |
| `FILE_COMMENT_NOT_FOUND` |
| `MESSAGE_NOT_FOUND` |
| `NO_ITEM_SPECIFIED` |
| `INVALID_NAME` |
| `NO_REACTION` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```python
from slackwebapi.models.reactions_remove_error_enum import ReactionsRemoveErrorEnum

reactions_remove_error_enum = ReactionsRemoveErrorEnum.JSON_NOT_OBJECT
```


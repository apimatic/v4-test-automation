
# Conversations Mark Success Schema

Schema for successful response conversations.mark method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsMarkSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_mark_success_schema import ConversationsMarkSuccessSchema

conversations_mark_success_schema = ConversationsMarkSuccessSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Can Thread

*This model accepts additional fields of type Any.*

## Structure

`CanThread`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `List[str]` | Optional | - |
| `user` | `List[str]` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.can_thread import CanThread

can_thread = CanThread(
    mtype=[
        'type1',
        'type0'
    ],
    user=[
        'user6',
        'user7'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


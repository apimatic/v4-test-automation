
# Users Conversations Error Schema Exception

Schema for error response from users.conversations method

*This model accepts additional fields of type Any.*

## Structure

`UsersConversationsErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersConversationsErrorEnum`](../../doc/models/users-conversations-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersConversationsErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


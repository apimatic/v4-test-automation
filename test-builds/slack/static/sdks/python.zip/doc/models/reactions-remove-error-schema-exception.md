
# Reactions Remove Error Schema Exception

Schema for error response from reactions.remove method

*This model accepts additional fields of type Any.*

## Structure

`ReactionsRemoveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ReactionsRemoveErrorEnum`](../../doc/models/reactions-remove-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ReactionsRemoveErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


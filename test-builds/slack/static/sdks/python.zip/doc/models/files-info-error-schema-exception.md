
# Files Info Error Schema Exception

Schema for error response from files.info method

*This model accepts additional fields of type Any.*

## Structure

`FilesInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesInfoErrorEnum`](../../doc/models/files-info-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except FilesInfoErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


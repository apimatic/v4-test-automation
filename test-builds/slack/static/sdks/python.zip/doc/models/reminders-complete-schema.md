
# Reminders Complete Schema

Schema for successful response from reminders.complete method

*This model accepts additional fields of type Any.*

## Structure

`RemindersCompleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.reminders_complete_schema import RemindersCompleteSchema

reminders_complete_schema = RemindersCompleteSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


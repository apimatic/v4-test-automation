
# Users List Error Schema Exception

Schema for error response from users.list method

*This model accepts additional fields of type Any.*

## Structure

`UsersListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersListErrorEnum`](../../doc/models/users-list-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersListErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Chat Schedule Message Error Schema Exception

Schema for error response chat.scheduleMessage method

*This model accepts additional fields of type Any.*

## Structure

`ChatScheduleMessageErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatScheduleMessageErrorEnum`](../../doc/models/chat-schedule-message-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ChatScheduleMessageErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


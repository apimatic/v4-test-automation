
# Objs Primary Owner

*This model accepts additional fields of type Any.*

## Structure

`ObjsPrimaryOwner`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `str` | Required | - |
| `id` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.objs_primary_owner import ObjsPrimaryOwner

objs_primary_owner = ObjsPrimaryOwner(
    email='email0',
    id='id6',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


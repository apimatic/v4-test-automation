
# Admin Conversations Unarchive Schema

Schema for successful response of admin.conversations.unarchive

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsUnarchiveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_unarchive_schema import AdminConversationsUnarchiveSchema

admin_conversations_unarchive_schema = AdminConversationsUnarchiveSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


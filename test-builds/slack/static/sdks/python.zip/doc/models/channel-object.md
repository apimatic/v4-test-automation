
# Channel Object

*This model accepts additional fields of type Any.*

## Structure

`ChannelObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accepted_user` | `str` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `created` | `int` | Required | - |
| `creator` | `str` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `id` | `str` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` |
| `is_archived` | `bool` | Optional | - |
| `is_channel` | `bool` | Required | - |
| `is_frozen` | `bool` | Optional | - |
| `is_general` | `bool` | Optional | - |
| `is_member` | `bool` | Optional | - |
| `is_moved` | `int` | Optional | - |
| `is_mpim` | `bool` | Required | - |
| `is_non_threadable` | `bool` | Optional | - |
| `is_org_shared` | `bool` | Required | - |
| `is_pending_ext_shared` | `bool` | Optional | - |
| `is_private` | `bool` | Required | - |
| `is_read_only` | `bool` | Optional | - |
| `is_shared` | `bool` | Required | - |
| `is_thread_only` | `bool` | Optional | - |
| `last_read` | `str` | Optional | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` |
| `latest` | `Any` | Optional | - |
| `members` | `List[str]` | Required | **Constraints**: *Minimum Items*: `0`, *Unique Items Required*, *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `name` | `str` | Required | - |
| `name_normalized` | `str` | Required | - |
| `num_members` | `int` | Optional | - |
| `pending_shared` | `List[str]` | Optional | **Constraints**: *Minimum Items*: `0`, *Unique Items Required*, *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `previous_names` | `List[str]` | Optional | **Constraints**: *Minimum Items*: `0`, *Unique Items Required* |
| `priority` | `float` | Optional | - |
| `purpose` | [`Purpose`](../../doc/models/purpose.md) | Required | - |
| `topic` | [`Topic`](../../doc/models/topic.md) | Required | - |
| `unlinked` | `int` | Optional | - |
| `unread_count` | `int` | Optional | - |
| `unread_count_display` | `int` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.channel_object import ChannelObject
from slackwebapi.models.purpose import Purpose
from slackwebapi.models.topic import Topic

channel_object = ChannelObject(
    created=202,
    creator='creator6',
    id='id8',
    is_channel=False,
    is_mpim=False,
    is_org_shared=False,
    is_private=False,
    is_shared=False,
    members=[
        'members4',
        'members3',
        'members2'
    ],
    name='name8',
    name_normalized='name_normalized6',
    purpose=Purpose(
        creator='creator4',
        last_set=30,
        value='value8',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    topic=Topic(
        creator='creator6',
        last_set=242,
        value='value0',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    accepted_user='accepted_user6',
    is_archived=False,
    is_frozen=False,
    is_general=False,
    is_member=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


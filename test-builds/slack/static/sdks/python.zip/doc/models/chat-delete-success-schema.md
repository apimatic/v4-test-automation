
# Chat Delete Success Schema

Schema for successful response of chat.delete method

*This model accepts additional fields of type Any.*

## Structure

`ChatDeleteSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `str` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `ts` | `str` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.chat_delete_success_schema import ChatDeleteSuccessSchema

chat_delete_success_schema = ChatDeleteSuccessSchema(
    channel='channel2',
    ts='ts4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


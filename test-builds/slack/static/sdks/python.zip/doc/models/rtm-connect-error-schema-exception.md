
# Rtm Connect Error Schema Exception

Schema for error response from rtm.connect method

*This model accepts additional fields of type Any.*

## Structure

`RtmConnectErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RtmConnectErrorEnum`](../../doc/models/rtm-connect-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except RtmConnectErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


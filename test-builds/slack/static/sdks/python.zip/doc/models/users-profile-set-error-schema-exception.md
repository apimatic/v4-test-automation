
# Users Profile Set Error Schema Exception

Schema for error response from users.profile.set method

*This model accepts additional fields of type Any.*

## Structure

`UsersProfileSetErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersProfileSetErrorEnum`](../../doc/models/users-profile-set-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersProfileSetErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


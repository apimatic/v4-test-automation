
# Apps Permissions Request Schema

Schema for successful response from apps.permissions.request method

*This model accepts additional fields of type Any.*

## Structure

`AppsPermissionsRequestSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.apps_permissions_request_schema import AppsPermissionsRequestSchema

apps_permissions_request_schema = AppsPermissionsRequestSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


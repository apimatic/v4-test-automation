
# Pins List Error Schema Exception

Schema for error response from pins.list method

*This model accepts additional fields of type Any.*

## Structure

`PinsListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`PinsListErrorEnum`](../../doc/models/pins-list-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except PinsListErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


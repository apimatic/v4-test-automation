
# Conversations Join Success Schema

Schema for successful response from conversations.join method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsJoinSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `Any` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `response_metadata` | [`ResponseMetadata3`](../../doc/models/response-metadata-3.md) | Optional | - |
| `warning` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_join_success_schema import ConversationsJoinSuccessSchema
from slackwebapi.models.response_metadata_3 import ResponseMetadata3

conversations_join_success_schema = ConversationsJoinSuccessSchema(
    channel=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    response_metadata=ResponseMetadata3(
        warnings=[
            'warnings8',
            'warnings9',
            'warnings0'
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    warning='warning2',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


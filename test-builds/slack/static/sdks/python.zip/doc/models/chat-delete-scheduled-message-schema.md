
# Chat Delete Scheduled Message Schema

Schema for successful response from chat.deleteScheduledMessage method

*This model accepts additional fields of type Any.*

## Structure

`ChatDeleteScheduledMessageSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.chat_delete_scheduled_message_schema import ChatDeleteScheduledMessageSchema

chat_delete_scheduled_message_schema = ChatDeleteScheduledMessageSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Apps Permissions Scopes List Error Schema Exception

Schema for error response from apps.permissions.scopes.list method

*This model accepts additional fields of type Any.*

## Structure

`AppsPermissionsScopesListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsInfoErrorEnum`](../../doc/models/apps-permissions-info-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except AppsPermissionsScopesListErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Users Profile Set Schema

Schema for successful response from users.profile.set method

*This model accepts additional fields of type Any.*

## Structure

`UsersProfileSetSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email_pending` | `str` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `profile` | [`UserProfileObject`](../../doc/models/user-profile-object.md) | Required | - |
| `username` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.user_profile_object import UserProfileObject
from slackwebapi.models.users_profile_set_schema import UsersProfileSetSchema

users_profile_set_schema = UsersProfileSetSchema(
    profile=UserProfileObject(
        avatar_hash='avatar_hash0',
        display_name='display_name0',
        display_name_normalized='display_name_normalized0',
        fields=[
            jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        ],
        phone='phone0',
        real_name='real_name6',
        real_name_normalized='real_name_normalized6',
        skype='skype0',
        status_emoji='status_emoji4',
        status_text='status_text8',
        title='title6',
        always_active=False,
        api_app_id='api_app_id0',
        bot_id='bot_id6',
        email='email6',
        first_name='first_name0',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    username='username0',
    email_pending='email_pending8',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Conversations Archive Success Schema

Schema for successful response conversations.archive method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsArchiveSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_archive_success_schema import ConversationsArchiveSuccessSchema

conversations_archive_success_schema = ConversationsArchiveSuccessSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


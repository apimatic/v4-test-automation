
# Users Delete Photo Error Schema Exception

Schema for error response from users.deletePhoto method

*This model accepts additional fields of type Any.*

## Structure

`UsersDeletePhotoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsInfoErrorEnum`](../../doc/models/apps-permissions-info-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersDeletePhotoErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Team Object

*This model accepts additional fields of type Any.*

## Structure

`TeamObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `archived` | `bool` | Optional | - |
| `avatar_base_url` | `str` | Optional | - |
| `created` | `int` | Optional | - |
| `date_create` | `int` | Optional | - |
| `deleted` | `bool` | Optional | - |
| `description` | `str` | Optional | - |
| `discoverable` | `Any` | Optional | - |
| `domain` | `str` | Required | - |
| `email_domain` | `str` | Required | - |
| `enterprise_id` | `str` | Optional | **Constraints**: *Pattern*: `^[E][A-Z0-9]{8,}$` |
| `enterprise_name` | `str` | Optional | - |
| `external_org_migrations` | [`ExternalOrgMigrations`](../../doc/models/external-org-migrations.md) | Optional | - |
| `has_compliance_export` | `bool` | Optional | - |
| `icon` | [`ObjsIcon`](../../doc/models/objs-icon.md) | Required | - |
| `id` | `str` | Required | **Constraints**: *Pattern*: `^[TE][A-Z0-9]{8,}$` |
| `is_assigned` | `bool` | Optional | - |
| `is_enterprise` | `int` | Optional | - |
| `is_over_storage_limit` | `bool` | Optional | - |
| `limit_ts` | `int` | Optional | - |
| `locale` | `str` | Optional | - |
| `messages_count` | `int` | Optional | - |
| `msg_edit_window_mins` | `int` | Optional | - |
| `name` | `str` | Required | - |
| `over_integrations_limit` | `bool` | Optional | - |
| `over_storage_limit` | `bool` | Optional | - |
| `pay_prod_cur` | `str` | Optional | - |
| `plan` | [`Plan`](../../doc/models/plan.md) | Optional | - |
| `primary_owner` | [`ObjsPrimaryOwner`](../../doc/models/objs-primary-owner.md) | Optional | - |
| `sso_provider` | [`SsoProvider`](../../doc/models/sso-provider.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.objs_icon import ObjsIcon
from slackwebapi.models.team_object import TeamObject

team_object = TeamObject(
    domain='domain2',
    email_domain='email_domain6',
    icon=ObjsIcon(
        image_102='image_1020',
        image_132='image_1326',
        image_230='image_2308',
        image_34='image_340',
        image_44='image_440',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    id='id6',
    name='name6',
    archived=False,
    avatar_base_url='avatar_base_url6',
    created=72,
    date_create=178,
    deleted=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


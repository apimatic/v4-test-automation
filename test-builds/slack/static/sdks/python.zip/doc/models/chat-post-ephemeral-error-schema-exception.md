
# Chat Post Ephemeral Error Schema Exception

Schema for error response from chat.postEphemeral method

*This model accepts additional fields of type Any.*

## Structure

`ChatPostEphemeralErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatPostEphemeralErrorEnum`](../../doc/models/chat-post-ephemeral-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ChatPostEphemeralErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `TEXT` |
| `DATE` |
| `LINK` |
| `MAILTO` |
| `OPTIONS_LIST` |
| `USER` |

## Example

```python
from slackwebapi.models.mtype import Type

mtype = Type.TEXT
```



# Paging Object

*This model accepts additional fields of type Any.*

## Structure

`PagingObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `int` | Optional | - |
| `page` | `int` | Required | - |
| `pages` | `int` | Optional | - |
| `per_page` | `int` | Optional | - |
| `spill` | `int` | Optional | - |
| `total` | `int` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.paging_object import PagingObject

paging_object = PagingObject(
    page=0,
    total=236,
    count=30,
    pages=124,
    per_page=168,
    spill=220,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


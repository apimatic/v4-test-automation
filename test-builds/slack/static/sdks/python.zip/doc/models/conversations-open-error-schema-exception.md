
# Conversations Open Error Schema Exception

Schema for error response from conversations.open method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsOpenErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsOpenErrorEnum`](../../doc/models/conversations-open-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ConversationsOpenErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Dnd End Dnd Schema

Schema for successful response from dnd.endDnd method

*This model accepts additional fields of type Any.*

## Structure

`DndEndDndSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.dnd_end_dnd_schema import DndEndDndSchema

dnd_end_dnd_schema = DndEndDndSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


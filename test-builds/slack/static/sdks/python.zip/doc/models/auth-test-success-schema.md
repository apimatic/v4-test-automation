
# Auth Test Success Schema

Schema for successful response auth.test method

*This model accepts additional fields of type Any.*

## Structure

`AuthTestSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bot_id` | `str` | Optional | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` |
| `is_enterprise_install` | `bool` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `team` | `str` | Required | - |
| `team_id` | `str` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `url` | `str` | Required | - |
| `user` | `str` | Required | - |
| `user_id` | `str` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.auth_test_success_schema import AuthTestSuccessSchema

auth_test_success_schema = AuthTestSuccessSchema(
    team='team4',
    team_id='team_id0',
    url='url0',
    user='user6',
    user_id='user_id4',
    bot_id='bot_id0',
    is_enterprise_install=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


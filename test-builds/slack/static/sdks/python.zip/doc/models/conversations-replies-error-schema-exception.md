
# Conversations Replies Error Schema Exception

Schema for error response from conversations.replies method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsRepliesErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsRepliesErrorEnum`](../../doc/models/conversations-replies-error-enum.md) | Required | - |
| `needed` | `str` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `provided` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ConversationsRepliesErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


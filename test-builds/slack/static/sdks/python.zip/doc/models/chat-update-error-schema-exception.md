
# Chat Update Error Schema Exception

Schema for error response chat.update method

*This model accepts additional fields of type Any.*

## Structure

`ChatUpdateErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatUpdateErrorEnum`](../../doc/models/chat-update-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ChatUpdateErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Stars Add Schema

Schema for successful response from stars.add method

*This model accepts additional fields of type Any.*

## Structure

`StarsAddSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.stars_add_schema import StarsAddSchema

stars_add_schema = StarsAddSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Conversations Rename Success Schema

Schema for successful response from conversations.rename method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsRenameSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `Any` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_rename_success_schema import ConversationsRenameSuccessSchema

conversations_rename_success_schema = ConversationsRenameSuccessSchema(
    channel=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


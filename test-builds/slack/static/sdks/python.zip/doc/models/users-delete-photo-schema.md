
# Users Delete Photo Schema

Schema for successful response from users.deletePhoto method

*This model accepts additional fields of type Any.*

## Structure

`UsersDeletePhotoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.users_delete_photo_schema import UsersDeletePhotoSchema

users_delete_photo_schema = UsersDeletePhotoSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


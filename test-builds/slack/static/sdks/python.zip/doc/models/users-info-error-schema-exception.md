
# Users Info Error Schema Exception

Schema for error response from users.info method

*This model accepts additional fields of type Any.*

## Structure

`UsersInfoErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | - |
| `error` | [`UsersInfoErrorEnum`](../../doc/models/users-info-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersInfoErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


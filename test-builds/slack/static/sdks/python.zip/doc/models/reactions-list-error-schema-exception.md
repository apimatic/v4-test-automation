
# Reactions List Error Schema Exception

Schema for error response from reactions.list method

*This model accepts additional fields of type Any.*

## Structure

`ReactionsListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ReactionsListErrorEnum`](../../doc/models/reactions-list-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ReactionsListErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Files Comments Delete Schema

Schema for successful response files.comments.delete method

*This model accepts additional fields of type Any.*

## Structure

`FilesCommentsDeleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.files_comments_delete_schema import FilesCommentsDeleteSchema

files_comments_delete_schema = FilesCommentsDeleteSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


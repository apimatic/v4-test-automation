
# Users Set Active Schema

Schema for successful response from users.setActive method

*This model accepts additional fields of type Any.*

## Structure

`UsersSetActiveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.users_set_active_schema import UsersSetActiveSchema

users_set_active_schema = UsersSetActiveSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


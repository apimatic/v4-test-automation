
# Auth Revoke Schema

Schema for successful response from auth.revoke method

*This model accepts additional fields of type Any.*

## Structure

`AuthRevokeSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `revoked` | `bool` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.auth_revoke_schema import AuthRevokeSchema

auth_revoke_schema = AuthRevokeSchema(
    revoked=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


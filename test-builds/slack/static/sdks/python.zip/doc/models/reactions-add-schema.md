
# Reactions Add Schema

Schema for successful response from reactions.add method

*This model accepts additional fields of type Any.*

## Structure

`ReactionsAddSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.reactions_add_schema import ReactionsAddSchema

reactions_add_schema = ReactionsAddSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Reactions List Schema

Schema for successful response from reactions.list method

*This model accepts additional fields of type Any.*

## Structure

`ReactionsListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `items` | `List[Any]` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Optional | - |
| `response_metadata` | `Any` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.paging_object import PagingObject
from slackwebapi.models.reactions_list_schema import ReactionsListSchema

reactions_list_schema = ReactionsListSchema(
    items=[
        jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
        jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    ],
    paging=PagingObject(
        page=26,
        total=6,
        count=56,
        pages=150,
        per_page=194,
        spill=246,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    response_metadata=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


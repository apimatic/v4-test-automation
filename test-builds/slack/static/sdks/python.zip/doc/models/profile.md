
# Profile

*This model accepts additional fields of type Any.*

## Structure

`Profile`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fields` | [`List[ObjsTeamProfileField]`](../../doc/models/objs-team-profile-field.md) | Required | **Constraints**: *Unique Items Required* |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.mtype import Type
from slackwebapi.models.objs_team_profile_field import ObjsTeamProfileField
from slackwebapi.models.profile import Profile

profile = Profile(
    fields=[
        ObjsTeamProfileField(
            hint='hint8',
            id='id8',
            label='label8',
            ordering=158.68,
            mtype=Type.OPTIONS_LIST,
            field_name='field_name2',
            is_hidden=False,
            options=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
            possible_values=[
                'possible_values9',
                'possible_values0'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


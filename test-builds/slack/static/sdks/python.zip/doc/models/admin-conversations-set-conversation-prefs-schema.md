
# Admin Conversations Set Conversation Prefs Schema

Schema for successful response of admin.conversations.setConversationPrefs

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsSetConversationPrefsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_set_conversation_prefs_schema import AdminConversationsSetConversationPrefsSchema

admin_conversations_set_conversation_prefs_schema = AdminConversationsSetConversationPrefsSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


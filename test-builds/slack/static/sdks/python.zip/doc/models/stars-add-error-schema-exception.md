
# Stars Add Error Schema Exception

Schema for error response from stars.add method

*This model accepts additional fields of type Any.*

## Structure

`StarsAddErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`StarsAddErrorEnum`](../../doc/models/stars-add-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except StarsAddErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


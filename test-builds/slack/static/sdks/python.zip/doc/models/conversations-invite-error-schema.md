
# Conversations Invite Error Schema

Schema for successful response from conversations.invite method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsInviteErrorSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `Any` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_invite_error_schema import ConversationsInviteErrorSchema

conversations_invite_error_schema = ConversationsInviteErrorSchema(
    channel=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


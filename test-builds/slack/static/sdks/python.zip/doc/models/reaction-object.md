
# Reaction Object

*This model accepts additional fields of type Any.*

## Structure

`ReactionObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `int` | Required | - |
| `name` | `str` | Required | - |
| `users` | `List[str]` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.reaction_object import ReactionObject

reaction_object = ReactionObject(
    count=146,
    name='name4',
    users=[
        'users9',
        'users0',
        'users1'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


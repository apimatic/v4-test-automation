
# Users Lookup by Email Error Schema Exception

Schema for error response from users.lookupByEmail method

*This model accepts additional fields of type Any.*

## Structure

`UsersLookupByEmailErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersLookupByEmailErrorEnum`](../../doc/models/users-lookup-by-email-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersLookupByEmailErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


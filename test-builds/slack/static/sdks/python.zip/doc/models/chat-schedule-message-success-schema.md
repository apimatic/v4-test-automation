
# Chat Schedule Message Success Schema

Schema for successful response of chat.scheduleMessage method

*This model accepts additional fields of type Any.*

## Structure

`ChatScheduleMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `str` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `message` | [`Message`](../../doc/models/message.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `post_at` | `int` | Required | - |
| `scheduled_message_id` | `str` | Required | **Constraints**: *Pattern*: `^[Q][A-Z0-9]{8,}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.bot_profile_object import BotProfileObject
from slackwebapi.models.chat_schedule_message_success_schema import ChatScheduleMessageSuccessSchema
from slackwebapi.models.icons import Icons
from slackwebapi.models.message import Message

chat_schedule_message_success_schema = ChatScheduleMessageSuccessSchema(
    channel='channel8',
    message=Message(
        bot_id='bot_id6',
        team='team0',
        text='text0',
        mtype='type0',
        user='user0',
        bot_profile=BotProfileObject(
            app_id='app_id8',
            deleted=False,
            icons=Icons(
                image_36='image_362',
                image_48='image_488',
                image_72='image_722',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            id='id8',
            name='name8',
            team_id='team_id8',
            updated=44,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        username='username0',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    post_at=30,
    scheduled_message_id='scheduled_message_id2',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


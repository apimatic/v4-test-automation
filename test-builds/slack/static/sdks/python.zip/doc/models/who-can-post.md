
# Who Can Post

*This model accepts additional fields of type Any.*

## Structure

`WhoCanPost`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `List[str]` | Optional | - |
| `user` | `List[str]` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.who_can_post import WhoCanPost

who_can_post = WhoCanPost(
    mtype=[
        'type5',
        'type4'
    ],
    user=[
        'user0',
        'user1'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


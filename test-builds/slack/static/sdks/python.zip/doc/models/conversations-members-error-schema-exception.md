
# Conversations Members Error Schema Exception

Schema for error response conversations.members method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsMembersErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsMembersErrorEnum`](../../doc/models/conversations-members-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ConversationsMembersErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Team Profile Get Success Schema

Schema for successful response from team.profile.get method

*This model accepts additional fields of type Any.*

## Structure

`TeamProfileGetSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `profile` | [`Profile`](../../doc/models/profile.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.mtype import Type
from slackwebapi.models.objs_team_profile_field import ObjsTeamProfileField
from slackwebapi.models.profile import Profile
from slackwebapi.models.team_profile_get_success_schema import TeamProfileGetSuccessSchema

team_profile_get_success_schema = TeamProfileGetSuccessSchema(
    profile=Profile(
        fields=[
            ObjsTeamProfileField(
                hint='hint8',
                id='id8',
                label='label8',
                ordering=158.68,
                mtype=Type.OPTIONS_LIST,
                field_name='field_name2',
                is_hidden=False,
                options=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                possible_values=[
                    'possible_values9',
                    'possible_values0'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


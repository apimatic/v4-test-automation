
# Api Test Error Schema Exception

Schema for error response api.test method

*This model accepts additional fields of type Any.*

## Structure

`ApiTestErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `str` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ApiTestErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Prefs 1

*This model accepts additional fields of type Any.*

## Structure

`Prefs1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `can_thread` | [`CanThread`](../../doc/models/can-thread.md) | Optional | - |
| `who_can_post` | [`WhoCanPost`](../../doc/models/who-can-post.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.can_thread import CanThread
from slackwebapi.models.prefs_1 import Prefs1
from slackwebapi.models.who_can_post import WhoCanPost

prefs_1 = Prefs1(
    can_thread=CanThread(
        mtype=[
            'type1',
            'type0'
        ],
        user=[
            'user6',
            'user7'
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    who_can_post=WhoCanPost(
        mtype=[
            'type5',
            'type4'
        ],
        user=[
            'user0',
            'user1'
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


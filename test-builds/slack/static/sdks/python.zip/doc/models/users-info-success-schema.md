
# Users Info Success Schema

Schema for successful response from users.info method

*This model accepts additional fields of type Any.*

## Structure

`UsersInfoSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `user` | `Any` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.users_info_success_schema import UsersInfoSuccessSchema

users_info_success_schema = UsersInfoSuccessSchema(
    user=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


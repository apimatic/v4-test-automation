
# Users Counts Error Schema Exception

Schema for error response users.getPresence method

*This model accepts additional fields of type Any.*

## Structure

`UsersCountsErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `str` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersCountsErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


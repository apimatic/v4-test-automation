
# Apps Permissions Info Schema

Schema for successful response from apps.permissions.info method

*This model accepts additional fields of type Any.*

## Structure

`AppsPermissionsInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `info` | [`Info`](../../doc/models/info.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.app_home import AppHome
from slackwebapi.models.apps_permissions_info_schema import AppsPermissionsInfoSchema
from slackwebapi.models.channel import Channel
from slackwebapi.models.group import Group
from slackwebapi.models.im import Im
from slackwebapi.models.info import Info
from slackwebapi.models.mpim import Mpim
from slackwebapi.models.resources_in_info_from_apps_permissions_info import ResourcesInInfoFromAppsPermissionsInfo
from slackwebapi.models.team import Team

apps_permissions_info_schema = AppsPermissionsInfoSchema(
    info=Info(
        app_home=AppHome(
            resources=ResourcesInInfoFromAppsPermissionsInfo(
                ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                excluded_ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                wildcard=False,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            scopes=[
                'scopes4',
                'scopes3',
                'scopes2'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        channel=Channel(
            resources=ResourcesInInfoFromAppsPermissionsInfo(
                ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                excluded_ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                wildcard=False,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            scopes=[
                'scopes2',
                'scopes1'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        group=Group(
            resources=ResourcesInInfoFromAppsPermissionsInfo(
                ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                excluded_ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                wildcard=False,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            scopes=[
                'scopes4'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        im=Im(
            resources=ResourcesInInfoFromAppsPermissionsInfo(
                ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                excluded_ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                wildcard=False,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            scopes=[
                'scopes0',
                'scopes9',
                'scopes8'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        mpim=Mpim(
            resources=ResourcesInInfoFromAppsPermissionsInfo(
                ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                excluded_ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                wildcard=False,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            scopes=[
                'scopes6'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        team=Team(
            resources=ResourcesInInfoFromAppsPermissionsInfo(
                ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                excluded_ids=[
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                ],
                wildcard=False,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            scopes=[
                'scopes6',
                'scopes5',
                'scopes4'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


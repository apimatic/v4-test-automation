
# Conversations List Error Schema Exception

Schema for error response from conversations.list method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsListErrorEnum`](../../doc/models/conversations-list-error-enum.md) | Required | - |
| `needed` | `str` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `provided` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ConversationsListErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


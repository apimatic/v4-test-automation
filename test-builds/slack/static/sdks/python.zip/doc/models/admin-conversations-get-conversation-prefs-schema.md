
# Admin Conversations Get Conversation Prefs Schema

Schema for successful response of admin.conversations.getConversationPrefs

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsGetConversationPrefsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `prefs` | [`Prefs1`](../../doc/models/prefs-1.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_get_conversation_prefs_schema import AdminConversationsGetConversationPrefsSchema
from slackwebapi.models.can_thread import CanThread
from slackwebapi.models.prefs_1 import Prefs1
from slackwebapi.models.who_can_post import WhoCanPost

admin_conversations_get_conversation_prefs_schema = AdminConversationsGetConversationPrefsSchema(
    prefs=Prefs1(
        can_thread=CanThread(
            mtype=[
                'type1',
                'type0'
            ],
            user=[
                'user6',
                'user7'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        who_can_post=WhoCanPost(
            mtype=[
                'type5',
                'type4'
            ],
            user=[
                'user0',
                'user1'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


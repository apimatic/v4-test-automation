
# External Org Migrations

*This model accepts additional fields of type Any.*

## Structure

`ExternalOrgMigrations`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `current` | [`List[Current]`](../../doc/models/current.md) | Required | - |
| `date_updated` | `int` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.current import Current
from slackwebapi.models.external_org_migrations import ExternalOrgMigrations

external_org_migrations = ExternalOrgMigrations(
    current=[
        Current(
            date_started=84,
            team_id='team_id0',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    date_updated=206,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


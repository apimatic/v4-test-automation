
# Dnd End Snooze Schema

Schema for successful response from dnd.endSnooze method

*This model accepts additional fields of type Any.*

## Structure

`DndEndSnoozeSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dnd_enabled` | `bool` | Required | - |
| `next_dnd_end_ts` | `int` | Required | - |
| `next_dnd_start_ts` | `int` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `snooze_enabled` | `bool` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.dnd_end_snooze_schema import DndEndSnoozeSchema

dnd_end_snooze_schema = DndEndSnoozeSchema(
    dnd_enabled=False,
    next_dnd_end_ts=192,
    next_dnd_start_ts=144,
    snooze_enabled=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


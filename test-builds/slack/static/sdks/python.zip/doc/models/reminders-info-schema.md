
# Reminders Info Schema

Schema for successful response from reminders.info method

*This model accepts additional fields of type Any.*

## Structure

`RemindersInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `reminder` | [`ObjsReminder`](../../doc/models/objs-reminder.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.objs_reminder import ObjsReminder
from slackwebapi.models.reminders_info_schema import RemindersInfoSchema

reminders_info_schema = RemindersInfoSchema(
    reminder=ObjsReminder(
        creator='creator8',
        id='id0',
        recurring=False,
        text='text0',
        user='user0',
        complete_ts=136,
        time=38,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


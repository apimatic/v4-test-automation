
# Users Set Presence Schema

Schema for successful response from users.setPresence method

*This model accepts additional fields of type Any.*

## Structure

`UsersSetPresenceSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.users_set_presence_schema import UsersSetPresenceSchema

users_set_presence_schema = UsersSetPresenceSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


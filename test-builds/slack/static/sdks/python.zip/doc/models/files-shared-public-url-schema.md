
# Files Shared Public Url Schema

Schema for successful response from files.sharedPublicURL method

*This model accepts additional fields of type Any.*

## Structure

`FilesSharedPublicUrlSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `file` | [`FileObject`](../../doc/models/file-object.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.file_object import FileObject
from slackwebapi.models.files_shared_public_url_schema import FilesSharedPublicUrlSchema

files_shared_public_url_schema = FilesSharedPublicUrlSchema(
    file=FileObject(
        channels=[
            'channels5',
            'channels4'
        ],
        comments_count=56,
        created=220,
        date_delete=118,
        display_as_bot=False,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


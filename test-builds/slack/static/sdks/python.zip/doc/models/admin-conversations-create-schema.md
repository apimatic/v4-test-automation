
# Admin Conversations Create Schema

Schema for successful response of admin.conversations.create

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsCreateSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel_id` | `str` | Optional | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_create_schema import AdminConversationsCreateSchema

admin_conversations_create_schema = AdminConversationsCreateSchema(
    channel_id='channel_id4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Team Access Logs Schema

Schema for successful response from team.accessLogs method

*This model accepts additional fields of type Any.*

## Structure

`TeamAccessLogsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `logins` | [`List[Login]`](../../doc/models/login.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.login import Login
from slackwebapi.models.paging_object import PagingObject
from slackwebapi.models.team_access_logs_schema import TeamAccessLogsSchema

team_access_logs_schema = TeamAccessLogsSchema(
    logins=[
        Login(
            count=244,
            country='country8',
            date_first=108,
            date_last=124,
            ip='ip8',
            isp='isp4',
            region='region0',
            user_agent='user_agent6',
            user_id='user_id2',
            username='username6',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    paging=PagingObject(
        page=26,
        total=6,
        count=56,
        pages=150,
        per_page=194,
        spill=246,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Chat Unfurl Error Schema Exception

Schema for error response from chat.unfurl method

*This model accepts additional fields of type Any.*

## Structure

`ChatUnfurlErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatUnfurlErrorEnum`](../../doc/models/chat-unfurl-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ChatUnfurlErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Dnd Set Snooze Schema

Schema for successful response from dnd.setSnooze method

*This model accepts additional fields of type Any.*

## Structure

`DndSetSnoozeSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `snooze_enabled` | `bool` | Required | - |
| `snooze_endtime` | `int` | Required | - |
| `snooze_remaining` | `int` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.dnd_set_snooze_schema import DndSetSnoozeSchema

dnd_set_snooze_schema = DndSetSnoozeSchema(
    snooze_enabled=False,
    snooze_endtime=194,
    snooze_remaining=194,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


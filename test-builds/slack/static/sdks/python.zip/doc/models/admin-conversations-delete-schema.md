
# Admin Conversations Delete Schema

Schema for successful response of admin.conversations.delete

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsDeleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_delete_schema import AdminConversationsDeleteSchema

admin_conversations_delete_schema = AdminConversationsDeleteSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


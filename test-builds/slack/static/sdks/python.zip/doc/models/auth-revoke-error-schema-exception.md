
# Auth Revoke Error Schema Exception

Schema for error response from auth.revoke method

*This model accepts additional fields of type Any.*

## Structure

`AuthRevokeErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AuthRevokeErrorEnum`](../../doc/models/auth-revoke-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except AuthRevokeErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


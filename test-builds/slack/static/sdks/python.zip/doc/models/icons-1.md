
# Icons 1

*This model accepts additional fields of type Any.*

## Structure

`Icons1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `emoji` | `str` | Optional | - |
| `image_64` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.icons_1 import Icons1

icons_1 = Icons1(
    emoji='emoji2',
    image_64='image_648',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


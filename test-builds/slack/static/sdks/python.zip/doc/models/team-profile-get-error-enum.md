
# Team Profile Get Error Enum

## Enumeration

`TeamProfileGetErrorEnum`

## Fields

| Name |
|  --- |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `NO_PERMISSION` |
| `USER_IS_BOT` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYP` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOU` |
| `UPGRADE_REQUIRED` |

## Example

```python
from slackwebapi.models.team_profile_get_error_enum import TeamProfileGetErrorEnum

team_profile_get_error_enum = TeamProfileGetErrorEnum.USER_IS_BOT
```


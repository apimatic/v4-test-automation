
# Chat Scheduled Messages List Error Schema Exception

Schema for error response from chat.scheduledMessages.list method

*This model accepts additional fields of type Any.*

## Structure

`ChatScheduledMessagesListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatScheduledMessagesListErrorEnum`](../../doc/models/chat-scheduled-messages-list-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ChatScheduledMessagesListErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


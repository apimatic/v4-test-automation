
# Team Access Logs Error Schema Exception

Schema for error response from team.accessLogs method

*This model accepts additional fields of type Any.*

## Structure

`TeamAccessLogsErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`TeamAccessLogsErrorEnum`](../../doc/models/team-access-logs-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except TeamAccessLogsErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


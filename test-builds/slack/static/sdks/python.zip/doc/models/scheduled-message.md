
# Scheduled Message

*This model accepts additional fields of type Any.*

## Structure

`ScheduledMessage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel_id` | `str` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` |
| `date_created` | `int` | Required | - |
| `id` | `str` | Required | **Constraints**: *Pattern*: `^[Q][A-Z0-9]{8,}$` |
| `post_at` | `int` | Required | - |
| `text` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.scheduled_message import ScheduledMessage

scheduled_message = ScheduledMessage(
    channel_id='channel_id4',
    date_created=96,
    id='id8',
    post_at=60,
    text='text2',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


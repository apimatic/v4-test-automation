
# Prefs

*This model accepts additional fields of type Any.*

## Structure

`Prefs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channels` | `List[str]` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` |
| `groups` | `List[str]` | Required | **Constraints**: *Pattern*: `^[G][A-Z0-9]{8,}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.prefs import Prefs

prefs = Prefs(
    channels=[
        'channels5',
        'channels4'
    ],
    groups=[
        'groups4',
        'groups5',
        'groups6'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Objs Team Profile Field

*This model accepts additional fields of type Any.*

## Structure

`ObjsTeamProfileField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field_name` | `str` | Optional | - |
| `hint` | `str` | Required | - |
| `id` | `str` | Required | **Constraints**: *Pattern*: `^X[a-zA-Z0-9]{9,}$` |
| `is_hidden` | `bool` | Optional | - |
| `label` | `str` | Required | - |
| `options` | `Any` | Optional | - |
| `ordering` | `float` | Required | - |
| `possible_values` | `List[str]` | Optional | - |
| `mtype` | [`Type`](../../doc/models/type.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.mtype import Type
from slackwebapi.models.objs_team_profile_field import ObjsTeamProfileField

objs_team_profile_field = ObjsTeamProfileField(
    hint='hint0',
    id='id0',
    label='label0',
    ordering=211.1,
    mtype=Type.OPTIONS_LIST,
    field_name='field_name4',
    is_hidden=False,
    options=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    possible_values=[
        'possible_values1',
        'possible_values2'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


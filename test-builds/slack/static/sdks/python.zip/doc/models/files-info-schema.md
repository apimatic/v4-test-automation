
# Files Info Schema

Schema for successful response from files.info method

*This model accepts additional fields of type Any.*

## Structure

`FilesInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `comments` | `List[Any]` | Required | - |
| `content_html` | `str` | Optional | - |
| `editor` | `str` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `file` | [`FileObject`](../../doc/models/file-object.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Optional | - |
| `response_metadata` | `Any` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.file_object import FileObject
from slackwebapi.models.files_info_schema import FilesInfoSchema
from slackwebapi.models.paging_object import PagingObject

files_info_schema = FilesInfoSchema(
    comments=[
        jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    ],
    file=FileObject(
        channels=[
            'channels5',
            'channels4'
        ],
        comments_count=56,
        created=220,
        date_delete=118,
        display_as_bot=False,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    content_html='content_html6',
    editor='editor2',
    paging=PagingObject(
        page=26,
        total=6,
        count=56,
        pages=150,
        per_page=194,
        spill=246,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    response_metadata=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


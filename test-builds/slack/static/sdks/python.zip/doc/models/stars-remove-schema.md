
# Stars Remove Schema

Schema for successful response from stars.remove method

*This model accepts additional fields of type Any.*

## Structure

`StarsRemoveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.stars_remove_schema import StarsRemoveSchema

stars_remove_schema = StarsRemoveSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Files Shared Public Url Error Enum

## Enumeration

`FilesSharedPublicUrlErrorEnum`

## Fields

| Name |
|  --- |
| `FILE_NOT_FOUND` |
| `NOT_ALLOWED` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `ORG_LOGIN_REQUIRED` |
| `USER_IS_BOT` |
| `USER_IS_RESTRICTED` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```python
from slackwebapi.models.files_shared_public_url_error_enum import FilesSharedPublicUrlErrorEnum

files_shared_public_url_error_enum = FilesSharedPublicUrlErrorEnum.INVALID_POST_TYPE
```


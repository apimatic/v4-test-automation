
# Reactions Remove Schema

Schema for successful response from reactions.remove method

*This model accepts additional fields of type Any.*

## Structure

`ReactionsRemoveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.reactions_remove_schema import ReactionsRemoveSchema

reactions_remove_schema = ReactionsRemoveSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


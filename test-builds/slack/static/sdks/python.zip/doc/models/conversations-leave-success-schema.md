
# Conversations Leave Success Schema

Schema for successful response from conversations.leave method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsLeaveSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `not_in_channel` | `bool` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_leave_success_schema import ConversationsLeaveSuccessSchema

conversations_leave_success_schema = ConversationsLeaveSuccessSchema(
    not_in_channel=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


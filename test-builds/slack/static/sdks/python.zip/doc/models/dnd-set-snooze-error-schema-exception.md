
# Dnd Set Snooze Error Schema Exception

Schema for error response from dnd.setSnooze method

*This model accepts additional fields of type Any.*

## Structure

`DndSetSnoozeErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndSetSnoozeErrorEnum`](../../doc/models/dnd-set-snooze-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except DndSetSnoozeErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```



# Conversations Set Topic Success Schema

Schema for successful response from conversations.setTopic method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsSetTopicSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `Any` | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_set_topic_success_schema import ConversationsSetTopicSuccessSchema

conversations_set_topic_success_schema = ConversationsSetTopicSuccessSchema(
    channel=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


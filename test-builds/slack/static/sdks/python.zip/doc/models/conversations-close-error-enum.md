
# Conversations Close Error Enum

## Enumeration

`ConversationsCloseErrorEnum`

## Fields

| Name |
|  --- |
| `METHOD_NOT_SUPPORTED_FOR_CHANNEL_TYPE` |
| `CHANNEL_NOT_FOUND` |
| `USER_DOES_NOT_OWN_CHANNEL` |
| `MISSING_SCOPE` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |

## Example

```python
from slackwebapi.models.conversations_close_error_enum import ConversationsCloseErrorEnum

conversations_close_error_enum = ConversationsCloseErrorEnum.INVALID_ARRAY_ARG
```


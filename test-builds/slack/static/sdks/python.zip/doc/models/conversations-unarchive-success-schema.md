
# Conversations Unarchive Success Schema

Schema for successful response from conversations.unarchive method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsUnarchiveSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_unarchive_success_schema import ConversationsUnarchiveSuccessSchema

conversations_unarchive_success_schema = ConversationsUnarchiveSuccessSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


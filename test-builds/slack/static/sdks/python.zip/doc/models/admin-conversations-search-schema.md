
# Admin Conversations Search Schema

Schema for successful response of admin.conversations.search

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsSearchSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channels` | [`List[ChannelObject]`](../../doc/models/channel-object.md) | Required | - |
| `next_cursor` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_search_schema import AdminConversationsSearchSchema
from slackwebapi.models.channel_object import ChannelObject
from slackwebapi.models.purpose import Purpose
from slackwebapi.models.topic import Topic

admin_conversations_search_schema = AdminConversationsSearchSchema(
    channels=[
        ChannelObject(
            created=90,
            creator='creator8',
            id='id0',
            is_channel=False,
            is_mpim=False,
            is_org_shared=False,
            is_private=False,
            is_shared=False,
            members=[
                'members8'
            ],
            name='name0',
            name_normalized='name_normalized8',
            purpose=Purpose(
                creator='creator4',
                last_set=30,
                value='value8',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            topic=Topic(
                creator='creator6',
                last_set=242,
                value='value0',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            accepted_user='accepted_user8',
            is_archived=False,
            is_frozen=False,
            is_general=False,
            is_member=False,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    next_cursor='next_cursor6',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


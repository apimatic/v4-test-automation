
# Reminders List Schema

Schema for successful response from reminders.list method

*This model accepts additional fields of type Any.*

## Structure

`RemindersListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `reminders` | [`List[ObjsReminder]`](../../doc/models/objs-reminder.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.objs_reminder import ObjsReminder
from slackwebapi.models.reminders_list_schema import RemindersListSchema

reminders_list_schema = RemindersListSchema(
    reminders=[
        ObjsReminder(
            creator='creator0',
            id='id2',
            recurring=False,
            text='text2',
            user='user2',
            complete_ts=28,
            time=186,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


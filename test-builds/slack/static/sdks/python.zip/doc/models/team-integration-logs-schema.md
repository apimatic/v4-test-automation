
# Team Integration Logs Schema

Schema for successful response from team.integrationLogs method

*This model accepts additional fields of type Any.*

## Structure

`TeamIntegrationLogsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `logs` | [`List[Log]`](../../doc/models/log.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.log import Log
from slackwebapi.models.paging_object import PagingObject
from slackwebapi.models.team_integration_logs_schema import TeamIntegrationLogsSchema

team_integration_logs_schema = TeamIntegrationLogsSchema(
    logs=[
        Log(
            app_id='app_id8',
            app_type='app_type2',
            change_type='change_type8',
            date='date4',
            scope='scope6',
            user_id='user_id6',
            user_name='user_name4',
            admin_app_id='admin_app_id6',
            channel='channel6',
            service_id='service_id8',
            service_type='service_type4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    paging=PagingObject(
        page=26,
        total=6,
        count=56,
        pages=150,
        per_page=194,
        spill=246,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


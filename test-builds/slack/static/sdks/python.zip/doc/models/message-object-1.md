
# Message Object 1

*This model accepts additional fields of type Any.*

## Structure

`MessageObject1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `attachments` | `List[Any]` | Optional | - |
| `blocks` | `Any` | Optional | - |
| `text` | `str` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.message_object_1 import MessageObject1

message_object_1 = MessageObject1(
    text='text2',
    attachments=[
        jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    ],
    blocks=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Users Identity Error Schema Exception

Schema for error response from users.identity method

*This model accepts additional fields of type Any.*

## Structure

`UsersIdentityErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsInfoErrorEnum`](../../doc/models/apps-permissions-info-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersIdentityErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


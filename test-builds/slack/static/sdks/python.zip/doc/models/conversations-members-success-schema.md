
# Conversations Members Success Schema

Schema for successful response conversations.members method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsMembersSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `members` | `List[str]` | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required*, *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `response_metadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_members_success_schema import ConversationsMembersSuccessSchema
from slackwebapi.models.response_metadata import ResponseMetadata

conversations_members_success_schema = ConversationsMembersSuccessSchema(
    members=[
        'members8',
        'members7',
        'members6'
    ],
    response_metadata=ResponseMetadata(
        next_cursor='next_cursor2',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


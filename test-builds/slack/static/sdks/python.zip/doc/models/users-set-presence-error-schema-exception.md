
# Users Set Presence Error Schema Exception

Schema for error response from users.setPresence method

*This model accepts additional fields of type Any.*

## Structure

`UsersSetPresenceErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersSetPresenceErrorEnum`](../../doc/models/users-set-presence-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersSetPresenceErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


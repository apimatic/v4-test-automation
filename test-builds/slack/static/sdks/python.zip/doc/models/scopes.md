
# Scopes

*This model accepts additional fields of type Any.*

## Structure

`Scopes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_home` | `List[str]` | Optional | - |
| `channel` | `List[str]` | Optional | - |
| `group` | `List[str]` | Optional | - |
| `im` | `List[str]` | Optional | - |
| `mpim` | `List[str]` | Optional | - |
| `team` | `List[str]` | Optional | - |
| `user` | `List[str]` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.scopes import Scopes

scopes = Scopes(
    app_home=[
        'app_home0',
        'app_home1',
        'app_home2'
    ],
    channel=[
        'channel2',
        'channel1'
    ],
    group=[
        'group1'
    ],
    im=[
        'im1',
        'im2',
        'im3'
    ],
    mpim=[
        'mpim2'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Users Conversations Success Schema

Schema for successful response from users.conversations method. Returned conversation objects do not include `num_members` or `is_member`

*This model accepts additional fields of type Any.*

## Structure

`UsersConversationsSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channels` | `List[Any]` | Required | **Constraints**: *Unique Items Required* |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `response_metadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.response_metadata import ResponseMetadata
from slackwebapi.models.users_conversations_success_schema import UsersConversationsSuccessSchema

users_conversations_success_schema = UsersConversationsSuccessSchema(
    channels=[
        jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    ],
    response_metadata=ResponseMetadata(
        next_cursor='next_cursor2',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


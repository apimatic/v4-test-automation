
# Reminders Complete Error Schema Exception

Schema for error response from reminders.complete method

*This model accepts additional fields of type Any.*

## Structure

`RemindersCompleteErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RemindersCompleteErrorEnum`](../../doc/models/reminders-complete-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except RemindersCompleteErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


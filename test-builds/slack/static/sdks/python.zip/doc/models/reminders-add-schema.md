
# Reminders Add Schema

Schema for successful response from reminders.add method

*This model accepts additional fields of type Any.*

## Structure

`RemindersAddSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `reminder` | [`ObjsReminder`](../../doc/models/objs-reminder.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.objs_reminder import ObjsReminder
from slackwebapi.models.reminders_add_schema import RemindersAddSchema

reminders_add_schema = RemindersAddSchema(
    reminder=ObjsReminder(
        creator='creator8',
        id='id0',
        recurring=False,
        text='text0',
        user='user0',
        complete_ts=136,
        time=38,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Apps Permissions Resources List Error Schema Exception

Schema for error response from apps.permissions.resources.list method

*This model accepts additional fields of type Any.*

## Structure

`AppsPermissionsResourcesListErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsResourcesListErrorEnum`](../../doc/models/apps-permissions-resources-list-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except AppsPermissionsResourcesListErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


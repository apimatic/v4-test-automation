
# Files Shared Public Url Error Schema Exception

Schema for error response from files.sharedPublicURL method

*This model accepts additional fields of type Any.*

## Structure

`FilesSharedPublicUrlErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesSharedPublicUrlErrorEnum`](../../doc/models/files-shared-public-url-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except FilesSharedPublicUrlErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


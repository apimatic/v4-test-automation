
# Usergroups Users Update Error Schema Exception

Schema for error response from usergroups.users.update method

*This model accepts additional fields of type Any.*

## Structure

`UsergroupsUsersUpdateErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsUpdateErrorEnum`](../../doc/models/usergroups-update-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsergroupsUsersUpdateErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


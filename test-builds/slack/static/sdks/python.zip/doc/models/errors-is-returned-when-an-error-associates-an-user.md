
# Errors Is Returned when an Error Associates an User

*This model accepts additional fields of type Any.*

## Structure

`ErrorsIsReturnedWhenAnErrorAssociatesAnUser`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`ConversationsInviteErrorEnum`](../../doc/models/conversations-invite-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `user` | `str` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_invite_error_enum import ConversationsInviteErrorEnum
from slackwebapi.models.errors_is_returned_when_an_error_associates_an_user import ErrorsIsReturnedWhenAnErrorAssociatesAnUser

errors_is_returned_when_an_error_associates_an_user = ErrorsIsReturnedWhenAnErrorAssociatesAnUser(
    error=ConversationsInviteErrorEnum.USER_IS_BOT,
    user='user8',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Team Info Schema

Schema for successful response from team.info method

*This model accepts additional fields of type Any.*

## Structure

`TeamInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `team` | [`TeamObject`](../../doc/models/team-object.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.objs_icon import ObjsIcon
from slackwebapi.models.team_info_schema import TeamInfoSchema
from slackwebapi.models.team_object import TeamObject

team_info_schema = TeamInfoSchema(
    team=TeamObject(
        domain='domain6',
        email_domain='email_domain0',
        icon=ObjsIcon(
            image_102='image_1020',
            image_132='image_1326',
            image_230='image_2308',
            image_34='image_340',
            image_44='image_440',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        id='id0',
        name='name0',
        archived=False,
        avatar_base_url='avatar_base_url0',
        created=212,
        date_create=62,
        deleted=False,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


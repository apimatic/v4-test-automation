
# Conversations Close Success Schema

Schema for successful response conversations.close method

*This model accepts additional fields of type Any.*

## Structure

`ConversationsCloseSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `already_closed` | `bool` | Optional | - |
| `no_op` | `bool` | Optional | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.conversations_close_success_schema import ConversationsCloseSuccessSchema

conversations_close_success_schema = ConversationsCloseSuccessSchema(
    already_closed=False,
    no_op=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


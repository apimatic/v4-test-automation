
# Dialog Open Schema

Schema for successful response from dialog.open method

*This model accepts additional fields of type Any.*

## Structure

`DialogOpenSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.dialog_open_schema import DialogOpenSchema

dialog_open_schema = DialogOpenSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


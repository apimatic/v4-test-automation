
# Users Set Active Error Schema Exception

Schema for error response from users.setActive method

*This model accepts additional fields of type Any.*

## Structure

`UsersSetActiveErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersSetActiveErrorEnum`](../../doc/models/users-set-active-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except UsersSetActiveErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


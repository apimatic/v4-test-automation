
# Dialog Open Error Schema Exception

Schema for error response from dialog.open method

*This model accepts additional fields of type Any.*

## Structure

`DialogOpenErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DialogOpenErrorEnum`](../../doc/models/dialog-open-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except DialogOpenErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


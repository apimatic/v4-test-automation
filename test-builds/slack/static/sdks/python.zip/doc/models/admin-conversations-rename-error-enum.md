
# Admin Conversations Rename Error Enum

## Enumeration

`AdminConversationsRenameErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `CHANNEL_NOT_FOUND` |
| `CHANNEL_TYPE_NOT_SUPPORTED` |
| `RESTRICTED_ACTION` |
| `COULD_NOT_RENAME_CHANNEL` |
| `DEFAULT_ORG_WIDE_CHANNEL` |
| `NAME_TAKEN` |

## Example

```python
from slackwebapi.models.admin_conversations_rename_error_enum import AdminConversationsRenameErrorEnum

admin_conversations_rename_error_enum = AdminConversationsRenameErrorEnum.FEATURE_NOT_ENABLED
```



# Response Metadata 3

*This model accepts additional fields of type Any.*

## Structure

`ResponseMetadata3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `warnings` | `List[str]` | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.response_metadata_3 import ResponseMetadata3

response_metadata_3 = ResponseMetadata3(
    warnings=[
        'warnings8',
        'warnings9'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


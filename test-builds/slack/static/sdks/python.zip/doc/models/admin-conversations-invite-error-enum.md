
# Admin Conversations Invite Error Enum

## Enumeration

`AdminConversationsInviteErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `CHANNEL_NOT_FOUND` |
| `CHANNEL_TYPE_NOT_SUPPORTED` |
| `DEFAULT_ORG_WIDE_CHANNEL` |
| `RESTRICTED_ACTION` |
| `USER_MUST_BE_ADMIN` |
| `FAILED_FOR_SOME_USERS` |

## Example

```python
from slackwebapi.models.admin_conversations_invite_error_enum import AdminConversationsInviteErrorEnum

admin_conversations_invite_error_enum = AdminConversationsInviteErrorEnum.RESTRICTED_ACTION
```


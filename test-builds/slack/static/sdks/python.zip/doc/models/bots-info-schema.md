
# Bots Info Schema

Schema for successful response from bots.info method

*This model accepts additional fields of type Any.*

## Structure

`BotsInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bot` | [`Bot`](../../doc/models/bot.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.bot import Bot
from slackwebapi.models.bots_info_schema import BotsInfoSchema
from slackwebapi.models.icons import Icons

bots_info_schema = BotsInfoSchema(
    bot=Bot(
        app_id='app_id0',
        deleted=False,
        icons=Icons(
            image_36='image_362',
            image_48='image_488',
            image_72='image_722',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        id='id6',
        name='name6',
        updated=214,
        user_id='user_id4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```



# Admin Conversations Rename Schema 1

Schema for successful response of admin.conversations.rename

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsRenameSchema1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_rename_schema_1 import AdminConversationsRenameSchema1

admin_conversations_rename_schema_1 = AdminConversationsRenameSchema1(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


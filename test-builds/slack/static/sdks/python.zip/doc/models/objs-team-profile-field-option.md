
# Objs Team Profile Field Option

*This model accepts additional fields of type Any.*

## Structure

`ObjsTeamProfileFieldOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_custom` | `bool` | Optional | - |
| `is_multiple_entry` | `bool` | Optional | - |
| `is_protected` | `bool` | Optional | - |
| `is_scim` | `bool` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.objs_team_profile_field_option import ObjsTeamProfileFieldOption

objs_team_profile_field_option = ObjsTeamProfileFieldOption(
    is_custom=False,
    is_multiple_entry=False,
    is_protected=False,
    is_scim=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


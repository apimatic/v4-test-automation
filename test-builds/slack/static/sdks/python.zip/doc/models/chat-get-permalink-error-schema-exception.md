
# Chat Get Permalink Error Schema Exception

Schema for error response from chat.getPermalink method

*This model accepts additional fields of type Any.*

## Structure

`ChatGetPermalinkErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatGetPermalinkErrorEnum`](../../doc/models/chat-get-permalink-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except ChatGetPermalinkErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


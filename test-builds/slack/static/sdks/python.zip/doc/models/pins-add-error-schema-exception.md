
# Pins Add Error Schema Exception

Schema for error response from pins.add method

*This model accepts additional fields of type Any.*

## Structure

`PinsAddErrorSchemaException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `str` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`PinsAddErrorEnum`](../../doc/models/pins-add-error-enum.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"False"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except PinsAddErrorSchemaException as e:
    print(e)
except ApiException as e:
    print(e)
```


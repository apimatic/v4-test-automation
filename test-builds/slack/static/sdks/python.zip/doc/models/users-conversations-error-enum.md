
# Users Conversations Error Enum

## Enumeration

`UsersConversationsErrorEnum`

## Fields

| Name |
|  --- |
| `METHOD_NOT_SUPPORTED_FOR_CHANNEL_TYPE` |
| `MISSING_SCOPE` |
| `INVALID_TYPES` |
| `INVALID_CURSOR` |
| `INVALID_LIMIT` |
| `NOT_AUTHED` |
| `INVALID_AUTH` |
| `ACCOUNT_INACTIVE` |
| `TOKEN_REVOKED` |
| `NO_PERMISSION` |
| `INVALID_ARG_NAME` |
| `INVALID_ARRAY_ARG` |
| `INVALID_CHARSET` |
| `INVALID_FORM_DATA` |
| `INVALID_POST_TYPE` |
| `MISSING_POST_TYPE` |
| `TEAM_ADDED_TO_ORG` |
| `INVALID_JSON` |
| `JSON_NOT_OBJECT` |
| `REQUEST_TIMEOUT` |
| `UPGRADE_REQUIRED` |
| `FATAL_ERROR` |

## Example

```python
from slackwebapi.models.users_conversations_error_enum import UsersConversationsErrorEnum

users_conversations_error_enum = UsersConversationsErrorEnum.TEAM_ADDED_TO_ORG
```


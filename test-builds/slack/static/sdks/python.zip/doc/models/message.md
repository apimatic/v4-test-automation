
# Message

*This model accepts additional fields of type Any.*

## Structure

`Message`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bot_id` | `str` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` |
| `bot_profile` | [`BotProfileObject`](../../doc/models/bot-profile-object.md) | Optional | - |
| `team` | `str` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `text` | `str` | Required | - |
| `mtype` | `str` | Required | - |
| `user` | `str` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `username` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.bot_profile_object import BotProfileObject
from slackwebapi.models.icons import Icons
from slackwebapi.models.message import Message

message = Message(
    bot_id='bot_id6',
    team='team0',
    text='text0',
    mtype='type0',
    user='user0',
    bot_profile=BotProfileObject(
        app_id='app_id8',
        deleted=False,
        icons=Icons(
            image_36='image_362',
            image_48='image_488',
            image_72='image_722',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        id='id8',
        name='name8',
        team_id='team_id8',
        updated=44,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    username='username0',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


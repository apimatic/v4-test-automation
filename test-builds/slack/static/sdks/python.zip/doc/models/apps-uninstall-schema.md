
# Apps Uninstall Schema

Schema for successful response from apps.uninstall method

*This model accepts additional fields of type Any.*

## Structure

`AppsUninstallSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.apps_uninstall_schema import AppsUninstallSchema

apps_uninstall_schema = AppsUninstallSchema(
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


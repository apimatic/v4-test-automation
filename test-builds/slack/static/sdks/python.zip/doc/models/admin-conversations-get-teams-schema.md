
# Admin Conversations Get Teams Schema

Schema for successful response of admin.conversations.getTeams

*This model accepts additional fields of type Any.*

## Structure

`AdminConversationsGetTeamsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `response_metadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Optional | - |
| `team_ids` | `List[str]` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.admin_conversations_get_teams_schema import AdminConversationsGetTeamsSchema
from slackwebapi.models.response_metadata import ResponseMetadata

admin_conversations_get_teams_schema = AdminConversationsGetTeamsSchema(
    team_ids=[
        'team_ids5',
        'team_ids6',
        'team_ids7'
    ],
    response_metadata=ResponseMetadata(
        next_cursor='next_cursor2',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


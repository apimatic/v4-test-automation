
# Admin Conversations Get Conversation Prefs Error Enum

## Enumeration

`AdminConversationsGetConversationPrefsErrorEnum`

## Fields

| Name |
|  --- |
| `FEATURE_NOT_ENABLED` |
| `NOT_AN_ADMIN` |
| `NOT_AN_ENTERPRISE` |
| `RESTRICTED_ACTION` |
| `MISSING_SCOPE` |
| `CHANNEL_NOT_FOUND` |
| `CHANNEL_TYPE_NOT_SUPPORTED` |
| `COULD_NOT_GET_CONVERSATION_PREFS` |

## Example

```python
from slackwebapi.models.admin_conversations_get_conversation_prefs_error_enum import AdminConversationsGetConversationPrefsErrorEnum

admin_conversations_get_conversation_prefs_error_enum = AdminConversationsGetConversationPrefsErrorEnum.NOT_AN_ENTERPRISE
```


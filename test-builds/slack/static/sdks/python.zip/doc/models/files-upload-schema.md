
# Files Upload Schema

Schema for successful response files.upload method

*This model accepts additional fields of type Any.*

## Structure

`FilesUploadSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `file` | [`FileObject`](../../doc/models/file-object.md) | Required | - |
| `ok` | `str` | Required, Constant | **Value**: `"True"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from slackwebapi.models.file_object import FileObject
from slackwebapi.models.files_upload_schema import FilesUploadSchema

files_upload_schema = FilesUploadSchema(
    file=FileObject(
        channels=[
            'channels5',
            'channels4'
        ],
        comments_count=56,
        created=220,
        date_delete=118,
        display_as_bot=False,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```


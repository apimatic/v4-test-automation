
# Getting Started with Slack Web API

## Introduction

One way to interact with the Slack platform is its HTTP RPC-based Web API, a collection of methods requiring OAuth 2.0-based user, bot, or workspace tokens blessed with related OAuth scopes.

Learn more about the Slack Web API: [https://api.slack.com/web](https://api.slack.com/web)

## Install the Package

Run the following command from your project directory to install the package from npm:

```bash
npm install slack-apimatic-sdk@1.0.0
```

For additional package details, see the [Npm page for the slack-apimatic-sdk@1.0.0 npm](https://www.npmjs.com/package/slack-apimatic-sdk/v/1.0.0).

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.Production`** |
| timeout | `number` | Timeout for API calls.<br>*Default*: `30000` |
| httpClientOptions | [`Partial<HttpClientOptions>`](doc/http-client-options.md) | Stable configurable http client options. |
| unstableHttpClientOptions | `any` | Unstable configurable http client options. |
| logging | [`PartialLoggingOptions`](doc/partial-logging-options.md) | Logging Configuration to enable logging |
| authorizationCodeAuthCredentials | [`AuthorizationCodeAuthCredentials`](doc/auth/oauth-2-authorization-code-grant.md) | The credential object for authorizationCodeAuth |

The API client can be initialized as follows:

### Code-Based Client Initialization

```ts
import {
  Client,
  Environment,
  LogLevel,
  OauthScope,
} from 'slack-apimatic-sdk';

const client = new Client({
  authorizationCodeAuthCredentials: {
    oauthClientId: 'OAuthClientId',
    oauthClientSecret: 'OAuthClientSecret',
    oauthRedirectUri: 'OAuthRedirectUri',
    oauthScopes: [
      OauthScope.Admin,
      OauthScope.AdminAppsread
    ]
  },
  timeout: 30000,
  environment: Environment.Production,
  logging: {
    logLevel: LogLevel.Info,
    logRequest: {
      logBody: true
    },
    logResponse: {
      logHeaders: true
    }
  },
});
```

### Configuration-Based Client Initialization

```ts
import * as path from 'path';
import * as fs from 'fs';
import { Client } from 'slack-apimatic-sdk';

// Provide absolute path for the configuration file
const absolutePath = path.resolve('./config.json');

// Read the configuration file content
const fileContent = fs.readFileSync(absolutePath, 'utf-8');

// Initialize client from JSON configuration content
const client = Client.fromJsonConfig(fileContent);
```

See the [Configuration-Based Client Initialization](doc/configuration-based-client-initialization.md) section for details.

### Environment-Based Client Initialization

```ts
import * as dotenv from 'dotenv';
import * as path from 'path';
import * as fs from 'fs';
import { Client } from 'slack-apimatic-sdk';

// Optional - Provide absolute path for the .env file
const absolutePath = path.resolve('./.env');

if (fs.existsSync(absolutePath)) {
  // Load environment variables from .env file
  dotenv.config({ path: absolutePath, override: true });
}

// Initialize client using environment variables
const client = Client.fromEnvironment(process.env);
```

See the [Environment-Based Client Initialization](doc/environment-based-client-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| Production | **Default** |

## Authorization

This API uses the following authentication schemes.

* [`slackAuth (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)

## List of APIs

* [Admin Apps](doc/controllers/admin-apps.md)
* [Admin Apps Approved](doc/controllers/admin-apps-approved.md)
* [Admin Apps Requests](doc/controllers/admin-apps-requests.md)
* [Admin Apps Restricted](doc/controllers/admin-apps-restricted.md)
* [Admin Conversations](doc/controllers/admin-conversations.md)
* [Admin Conversations Ekm](doc/controllers/admin-conversations-ekm.md)
* [Admin Conversations Restrict Access](doc/controllers/admin-conversations-restrict-access.md)
* [Admin Emoji](doc/controllers/admin-emoji.md)
* [Admin Invite Requests](doc/controllers/admin-invite-requests.md)
* [Admin Invite Requests Approved](doc/controllers/admin-invite-requests-approved.md)
* [Admin Invite Requests Denied](doc/controllers/admin-invite-requests-denied.md)
* [Admin Teams Admins](doc/controllers/admin-teams-admins.md)
* [Admin Teams](doc/controllers/admin-teams.md)
* [Admin Teams Owners](doc/controllers/admin-teams-owners.md)
* [Admin Teams Settings](doc/controllers/admin-teams-settings.md)
* [Admin Usergroups](doc/controllers/admin-usergroups.md)
* [Admin Users](doc/controllers/admin-users.md)
* [Admin Users Session](doc/controllers/admin-users-session.md)
* [Api](doc/controllers/api.md)
* [Apps Event Authorizations](doc/controllers/apps-event-authorizations.md)
* [Apps Permissions](doc/controllers/apps-permissions.md)
* [Apps Permissions Resources](doc/controllers/apps-permissions-resources.md)
* [Apps Permissions Scopes](doc/controllers/apps-permissions-scopes.md)
* [Apps Permissions Users](doc/controllers/apps-permissions-users.md)
* [Apps](doc/controllers/apps.md)
* [Auth](doc/controllers/auth.md)
* [Bots](doc/controllers/bots.md)
* [Calls](doc/controllers/calls.md)
* [Calls Participants](doc/controllers/calls-participants.md)
* [Chat](doc/controllers/chat.md)
* [Chat Scheduled Messages](doc/controllers/chat-scheduled-messages.md)
* [Conversations](doc/controllers/conversations.md)
* [Dialog](doc/controllers/dialog.md)
* [Dnd](doc/controllers/dnd.md)
* [Emoji](doc/controllers/emoji.md)
* [Files Comments](doc/controllers/files-comments.md)
* [Files](doc/controllers/files.md)
* [Files Remote](doc/controllers/files-remote.md)
* [Migration](doc/controllers/migration.md)
* [oauth](doc/controllers/oauth.md)
* [oauth V2](doc/controllers/oauth-v2.md)
* [Pins](doc/controllers/pins.md)
* [Reactions](doc/controllers/reactions.md)
* [Reminders](doc/controllers/reminders.md)
* [Rtm](doc/controllers/rtm.md)
* [Search](doc/controllers/search.md)
* [Stars](doc/controllers/stars.md)
* [Team](doc/controllers/team.md)
* [Team Profile](doc/controllers/team-profile.md)
* [Usergroups](doc/controllers/usergroups.md)
* [Usergroups Users](doc/controllers/usergroups-users.md)
* [Users](doc/controllers/users.md)
* [Users Profile](doc/controllers/users-profile.md)
* [Views](doc/controllers/views.md)
* [Workflows](doc/controllers/workflows.md)

## SDK Infrastructure

### Configuration

* [HttpClientOptions](doc/http-client-options.md)
* [RetryConfiguration](doc/retry-configuration.md)
* [ProxySettings](doc/proxy-settings.md)
* [Configuration-Based Client Initialization](doc/configuration-based-client-initialization.md)
* [Environment-Based Client Initialization](doc/environment-based-client-initialization.md)
* [PartialLoggingOptions](doc/partial-logging-options.md)
* [PartialRequestLoggingOptions](doc/partial-request-logging-options.md)
* [PartialResponseLoggingOptions](doc/partial-response-logging-options.md)
* [LoggerInterface](doc/logger-interface.md)

### HTTP

* [HttpRequest](doc/http-request.md)

### Utilities

* [ApiResponse](doc/api-response.md)
* [ApiError](doc/api-error.md)



# Users Profile Get Error Schema Error

Schema for error response from users.profile.get method

*This model accepts additional fields of type unknown.*

## Structure

`UsersProfileGetErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersProfileGetErrorEnum`](../../doc/models/users-profile-get-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsersProfileGetErrorSchemaError) {
    console.log(error.result);
  }
}
```


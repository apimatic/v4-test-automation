
# Auth Test Error Enum

## Enumeration

`AuthTestErrorEnum`

## Fields

| Name |
|  --- |
| `NotAuthed` |
| `InvalidAuth` |
| `TokenRevoked` |
| `AccountInactive` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { AuthTestErrorEnum } from 'slack-apimatic-sdk';

const authTestErrorEnum = AuthTestErrorEnum.InvalidPostType;
```


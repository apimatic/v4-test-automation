
# Prefs

*This model accepts additional fields of type unknown.*

## Structure

`Prefs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channels` | `string[]` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` |
| `groups` | `string[]` | Required | **Constraints**: *Pattern*: `^[G][A-Z0-9]{8,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Prefs } from 'slack-apimatic-sdk';

const prefs: Prefs = {
  channels: [
    'channels5',
    'channels4'
  ],
  groups: [
    'groups4',
    'groups5',
    'groups6'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Users Profile Get Schema

Schema for successful response from users.profile.get method

*This model accepts additional fields of type unknown.*

## Structure

`UsersProfileGetSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `profile` | [`UserProfileObject`](../../doc/models/user-profile-object.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UsersProfileGetSchema } from 'slack-apimatic-sdk';

const usersProfileGetSchema: UsersProfileGetSchema = {
  ok: 'True',
  profile: {
    avatarHash: 'avatar_hash0',
    displayName: 'display_name0',
    displayNameNormalized: 'display_name_normalized0',
    fields: [
      { 'key1': 'val1', 'key2': 'val2' }
    ],
    phone: 'phone0',
    realName: 'real_name6',
    realNameNormalized: 'real_name_normalized6',
    skype: 'skype0',
    statusEmoji: 'status_emoji4',
    statusText: 'status_text8',
    title: 'title6',
    alwaysActive: false,
    apiAppId: 'api_app_id0',
    botId: 'bot_id6',
    email: 'email6',
    firstName: 'first_name0',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Admin Conversations Rename Error Enum

## Enumeration

`AdminConversationsRenameErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `ChannelNotFound` |
| `ChannelTypeNotSupported` |
| `RestrictedAction` |
| `CouldNotRenameChannel` |
| `DefaultOrgWideChannel` |
| `NameTaken` |

## Example

```ts
import { AdminConversationsRenameErrorEnum } from 'slack-apimatic-sdk';

const adminConversationsRenameErrorEnum = AdminConversationsRenameErrorEnum.RestrictedAction;
```


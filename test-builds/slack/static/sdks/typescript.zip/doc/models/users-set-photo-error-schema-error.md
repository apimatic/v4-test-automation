
# Users Set Photo Error Schema Error

Schema for error response from users.setPhoto method

*This model accepts additional fields of type unknown.*

## Structure

`UsersSetPhotoErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `debugStep` | `string \| undefined` | Optional | possibly DEV/QA only |
| `dims` | `string \| undefined` | Optional | possibly DEV/QA only |
| `error` | [`UsersSetPhotoErrorEnum`](../../doc/models/users-set-photo-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `timeIdent` | `number \| undefined` | Optional | possibly DEV/QA only |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsersSetPhotoErrorSchemaError) {
    console.log(error.result);
  }
}
```


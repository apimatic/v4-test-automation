
# Admin Conversations Rename Schema 1

Schema for successful response of admin.conversations.rename

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsRenameSchema1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AdminConversationsRenameSchema1 } from 'slack-apimatic-sdk';

const adminConversationsRenameSchema1: AdminConversationsRenameSchema1 = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


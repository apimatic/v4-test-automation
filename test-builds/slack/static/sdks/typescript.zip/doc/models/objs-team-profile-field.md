
# Objs Team Profile Field

*This model accepts additional fields of type unknown.*

## Structure

`ObjsTeamProfileField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fieldName` | `string \| null \| undefined` | Optional | - |
| `hint` | `string` | Required | - |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^X[a-zA-Z0-9]{9,}$` |
| `isHidden` | `boolean \| undefined` | Optional | - |
| `label` | `string` | Required | - |
| `options` | `unknown \| undefined` | Optional | - |
| `ordering` | `number` | Required | - |
| `possibleValues` | `string[] \| null \| undefined` | Optional | - |
| `type` | [`Type`](../../doc/models/type.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ObjsTeamProfileField, Type } from 'slack-apimatic-sdk';

const objsTeamProfileField: ObjsTeamProfileField = {
  hint: 'hint6',
  id: 'id6',
  label: 'label6',
  ordering: 127.94,
  type: Type.OptionsList,
  fieldName: 'field_name0',
  isHidden: false,
  options: { 'key1': 'val1', 'key2': 'val2' },
  possibleValues: [
    'possible_values7',
    'possible_values8'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


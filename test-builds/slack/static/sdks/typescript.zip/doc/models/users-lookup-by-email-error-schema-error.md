
# Users Lookup by Email Error Schema Error

Schema for error response from users.lookupByEmail method

*This model accepts additional fields of type unknown.*

## Structure

`UsersLookupByEmailErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersLookupByEmailErrorEnum`](../../doc/models/users-lookup-by-email-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsersLookupByEmailErrorSchemaError) {
    console.log(error.result);
  }
}
```


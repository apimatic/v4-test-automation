
# Login

*This model accepts additional fields of type unknown.*

## Structure

`Login`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `number` | Required | - |
| `country` | `string \| null` | Required | - |
| `dateFirst` | `number` | Required | - |
| `dateLast` | `number` | Required | - |
| `ip` | `string \| null` | Required | - |
| `isp` | `string \| null` | Required | - |
| `region` | `string \| null` | Required | - |
| `userAgent` | `string` | Required | - |
| `userId` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `username` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Login } from 'slack-apimatic-sdk';

const login: Login = {
  count: 110,
  country: 'country4',
  dateFirst: 206,
  dateLast: 222,
  ip: 'ip4',
  isp: 'isp0',
  region: 'region6',
  userAgent: 'user_agent2',
  userId: 'user_id8',
  username: 'username0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Sso Provider

*This model accepts additional fields of type unknown.*

## Structure

`SsoProvider`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | `string \| undefined` | Optional | - |
| `name` | `string \| undefined` | Optional | - |
| `type` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { SsoProvider } from 'slack-apimatic-sdk';

const ssoProvider: SsoProvider = {
  label: 'label8',
  name: 'name8',
  type: 'type2',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


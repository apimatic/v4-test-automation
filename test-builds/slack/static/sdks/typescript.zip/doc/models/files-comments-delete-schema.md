
# Files Comments Delete Schema

Schema for successful response files.comments.delete method

*This model accepts additional fields of type unknown.*

## Structure

`FilesCommentsDeleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { FilesCommentsDeleteSchema } from 'slack-apimatic-sdk';

const filesCommentsDeleteSchema: FilesCommentsDeleteSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Conversations Invite Error Schema 1 Error

Schema for error response from conversations.invite method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsInviteErrorSchema1Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsInviteErrorEnum \| undefined`](../../doc/models/conversations-invite-error-enum.md) | Optional | - |
| `errors` | [`ErrorsIsReturnedWhenAnErrorAssociatesAnUser[] \| undefined`](../../doc/models/errors-is-returned-when-an-error-associates-an-user.md) | Optional | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `needed` | `string \| undefined` | Optional | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `provided` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ConversationsInviteErrorSchema1Error) {
    console.log(error.result);
  }
}
```


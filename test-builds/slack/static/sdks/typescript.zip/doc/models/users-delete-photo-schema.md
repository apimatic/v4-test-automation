
# Users Delete Photo Schema

Schema for successful response from users.deletePhoto method

*This model accepts additional fields of type unknown.*

## Structure

`UsersDeletePhotoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UsersDeletePhotoSchema } from 'slack-apimatic-sdk';

const usersDeletePhotoSchema: UsersDeletePhotoSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


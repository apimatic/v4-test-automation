
# Objs User Profile Short

*This model accepts additional fields of type unknown.*

## Structure

`ObjsUserProfileShort`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `avatarHash` | `string` | Required | - |
| `displayName` | `string` | Required | - |
| `displayNameNormalized` | `string \| undefined` | Optional | - |
| `firstName` | `string \| null` | Required | - |
| `image72` | `string` | Required | - |
| `isRestricted` | `boolean` | Required | - |
| `isUltraRestricted` | `boolean` | Required | - |
| `name` | `string` | Required | - |
| `realName` | `string` | Required | - |
| `realNameNormalized` | `string \| undefined` | Optional | - |
| `team` | `string` | Required | **Constraints**: *Pattern*: `^[TE][A-Z0-9]{8,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ObjsUserProfileShort } from 'slack-apimatic-sdk';

const objsUserProfileShort: ObjsUserProfileShort = {
  avatarHash: 'avatar_hash2',
  displayName: 'display_name2',
  firstName: 'first_name2',
  image72: 'image_726',
  isRestricted: false,
  isUltraRestricted: false,
  name: 'name2',
  realName: 'real_name8',
  team: 'team8',
  displayNameNormalized: 'display_name_normalized2',
  realNameNormalized: 'real_name_normalized4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


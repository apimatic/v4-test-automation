
# Conversations Mark Success Schema

Schema for successful response conversations.mark method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsMarkSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsMarkSuccessSchema } from 'slack-apimatic-sdk';

const conversationsMarkSuccessSchema: ConversationsMarkSuccessSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Auth Test Success Schema

Schema for successful response auth.test method

*This model accepts additional fields of type unknown.*

## Structure

`AuthTestSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `botId` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` |
| `isEnterpriseInstall` | `boolean \| undefined` | Optional | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `team` | `string` | Required | - |
| `teamId` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `url` | `string` | Required | - |
| `user` | `string` | Required | - |
| `userId` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AuthTestSuccessSchema } from 'slack-apimatic-sdk';

const authTestSuccessSchema: AuthTestSuccessSchema = {
  ok: 'True',
  team: 'team6',
  teamId: 'team_id8',
  url: 'url8',
  user: 'user4',
  userId: 'user_id2',
  botId: 'bot_id2',
  isEnterpriseInstall: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


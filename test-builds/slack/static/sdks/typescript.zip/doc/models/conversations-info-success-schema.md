
# Conversations Info Success Schema

Schema for successful response conversations.info

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsInfoSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `unknown` | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsInfoSuccessSchema } from 'slack-apimatic-sdk';

const conversationsInfoSuccessSchema: ConversationsInfoSuccessSchema = {
  channel: { 'key1': 'val1', 'key2': 'val2' },
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Log

*This model accepts additional fields of type unknown.*

## Structure

`Log`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `adminAppId` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` |
| `appId` | `string` | Required | **Constraints**: *Pattern*: `^A[A-Z0-9]{1,}$` |
| `appType` | `string` | Required | - |
| `changeType` | `string` | Required | - |
| `channel` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `date` | `string` | Required | - |
| `scope` | `string` | Required | - |
| `serviceId` | `string \| undefined` | Optional | - |
| `serviceType` | `string \| undefined` | Optional | - |
| `userId` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `userName` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Log } from 'slack-apimatic-sdk';

const log: Log = {
  appId: 'app_id8',
  appType: 'app_type2',
  changeType: 'change_type8',
  date: 'date6',
  scope: 'scope4',
  userId: 'user_id6',
  userName: 'user_name4',
  adminAppId: 'admin_app_id6',
  channel: 'channel6',
  serviceId: 'service_id2',
  serviceType: 'service_type4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


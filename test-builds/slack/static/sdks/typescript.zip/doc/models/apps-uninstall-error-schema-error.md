
# Apps Uninstall Error Schema Error

Schema for error response from apps.uninstall method

*This model accepts additional fields of type unknown.*

## Structure

`AppsUninstallErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsUninstallErrorEnum`](../../doc/models/apps-uninstall-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AppsUninstallErrorSchemaError) {
    console.log(error.result);
  }
}
```


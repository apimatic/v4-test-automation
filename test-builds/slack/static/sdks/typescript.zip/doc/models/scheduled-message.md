
# Scheduled Message

*This model accepts additional fields of type unknown.*

## Structure

`ScheduledMessage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channelId` | `string` | Required | **Constraints**: *Pattern*: `^[C][A-Z0-9]{2,}$` |
| `dateCreated` | `number` | Required | - |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^[Q][A-Z0-9]{8,}$` |
| `postAt` | `number` | Required | - |
| `text` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ScheduledMessage } from 'slack-apimatic-sdk';

const scheduledMessage: ScheduledMessage = {
  channelId: 'channel_id6',
  dateCreated: 168,
  id: 'id0',
  postAt: 244,
  text: 'text0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Files Info Error Schema Error

Schema for error response from files.info method

*This model accepts additional fields of type unknown.*

## Structure

`FilesInfoErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesInfoErrorEnum`](../../doc/models/files-info-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof FilesInfoErrorSchemaError) {
    console.log(error.result);
  }
}
```


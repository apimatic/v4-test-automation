
# Api Test Error Schema Error

Schema for error response api.test method

*This model accepts additional fields of type unknown.*

## Structure

`ApiTestErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `string` | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ApiTestErrorSchemaError) {
    console.log(error.result);
  }
}
```


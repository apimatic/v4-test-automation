
# Usergroups Update Error Enum

## Enumeration

`UsergroupsUpdateErrorEnum`

## Fields

| Name |
|  --- |
| `PermissionDenied` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `UserIsRestricted` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequire` |
| `FatalError` |
| `MissingCharset` |
| `SuperfluousCharset` |

## Example

```ts
import { UsergroupsUpdateErrorEnum } from 'slack-apimatic-sdk';

const usergroupsUpdateErrorEnum = UsergroupsUpdateErrorEnum.RequestTimeout;
```


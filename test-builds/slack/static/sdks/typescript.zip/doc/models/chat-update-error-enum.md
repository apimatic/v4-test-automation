
# Chat Update Error Enum

## Enumeration

`ChatUpdateErrorEnum`

## Fields

| Name |
|  --- |
| `MessageNotFound` |
| `CantUpdateMessage` |
| `ChannelNotFound` |
| `EditWindowClosed` |
| `MsgTooLong` |
| `TooManyAttachments` |
| `RateLimited` |
| `NoText` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `RequestTimeout` |
| `InvalidJson` |
| `JsonNotObject` |
| `UpgradeRequired` |
| `FatalError` |
| `IsInactive` |

## Example

```ts
import { ChatUpdateErrorEnum } from 'slack-apimatic-sdk';

const chatUpdateErrorEnum = ChatUpdateErrorEnum.InvalidArrayArg;
```


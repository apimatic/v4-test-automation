
# Chat Schedule Message Success Schema

Schema for successful response of chat.scheduleMessage method

*This model accepts additional fields of type unknown.*

## Structure

`ChatScheduleMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `string` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `message` | [`Message`](../../doc/models/message.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `postAt` | `number` | Required | - |
| `scheduledMessageId` | `string` | Required | **Constraints**: *Pattern*: `^[Q][A-Z0-9]{8,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ChatScheduleMessageSuccessSchema } from 'slack-apimatic-sdk';

const chatScheduleMessageSuccessSchema: ChatScheduleMessageSuccessSchema = {
  channel: 'channel0',
  message: {
    botId: 'bot_id6',
    team: 'team0',
    text: 'text0',
    type: 'type0',
    user: 'user0',
    botProfile: {
      appId: 'app_id8',
      deleted: false,
      icons: {
        image36: 'image_362',
        image48: 'image_488',
        image72: 'image_722',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      id: 'id8',
      name: 'name8',
      teamId: 'team_id8',
      updated: 44,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    username: 'username0',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  ok: 'True',
  postAt: 76,
  scheduledMessageId: 'scheduled_message_id6',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


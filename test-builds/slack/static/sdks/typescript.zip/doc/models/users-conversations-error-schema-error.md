
# Users Conversations Error Schema Error

Schema for error response from users.conversations method

*This model accepts additional fields of type unknown.*

## Structure

`UsersConversationsErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersConversationsErrorEnum`](../../doc/models/users-conversations-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsersConversationsErrorSchemaError) {
    console.log(error.result);
  }
}
```


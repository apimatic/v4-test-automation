
# Conversations Replies Error Schema Error

Schema for error response from conversations.replies method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsRepliesErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsRepliesErrorEnum`](../../doc/models/conversations-replies-error-enum.md) | Required | - |
| `needed` | `string \| undefined` | Optional | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `provided` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ConversationsRepliesErrorSchemaError) {
    console.log(error.result);
  }
}
```


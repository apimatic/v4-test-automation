
# Reminders Delete Error Enum

## Enumeration

`RemindersDeleteErrorEnum`

## Fields

| Name |
|  --- |
| `NotFound` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { RemindersDeleteErrorEnum } from 'slack-apimatic-sdk';

const remindersDeleteErrorEnum = RemindersDeleteErrorEnum.NotFound;
```



# Reactions Add Error Enum

## Enumeration

`ReactionsAddErrorEnum`

## Fields

| Name |
|  --- |
| `BadTimestamp` |
| `MessageNotFound` |
| `NoItemSpecified` |
| `InvalidName` |
| `AlreadyReacted` |
| `TooManyEmoji` |
| `TooManyReactions` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { ReactionsAddErrorEnum } from 'slack-apimatic-sdk';

const reactionsAddErrorEnum = ReactionsAddErrorEnum.MissingPostType;
```


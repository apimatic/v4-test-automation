
# Chat Scheduled Messages List Schema

Schema for successful response from chat.scheduledMessages.list method

*This model accepts additional fields of type unknown.*

## Structure

`ChatScheduledMessagesListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `responseMetadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Required | - |
| `scheduledMessages` | [`ScheduledMessage[]`](../../doc/models/scheduled-message.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ChatScheduledMessagesListSchema } from 'slack-apimatic-sdk';

const chatScheduledMessagesListSchema: ChatScheduledMessagesListSchema = {
  ok: 'True',
  responseMetadata: {
    nextCursor: 'next_cursor2',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  scheduledMessages: [
    {
      channelId: 'channel_id8',
      dateCreated: 100,
      id: 'id2',
      postAt: 0,
      text: 'text2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Admin Conversations Convert to Private Error Schema Error

Schema for error response from admin.conversations.convertToPrivate

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsConvertToPrivateErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsConvertToPrivateErrorEnum`](../../doc/models/admin-conversations-convert-to-private-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AdminConversationsConvertToPrivateErrorSchemaError) {
    console.log(error.result);
  }
}
```


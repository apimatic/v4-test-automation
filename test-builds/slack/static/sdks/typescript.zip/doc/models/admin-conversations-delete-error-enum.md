
# Admin Conversations Delete Error Enum

## Enumeration

`AdminConversationsDeleteErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `NotAnAdmin` |
| `ChannelNotFound` |
| `ChannelTypeNotSupported` |
| `DefaultOrgWideChannel` |
| `RestrictedAction` |
| `CouldNotDeleteChannel` |
| `MissingScope` |

## Example

```ts
import { AdminConversationsDeleteErrorEnum } from 'slack-apimatic-sdk';

const adminConversationsDeleteErrorEnum = AdminConversationsDeleteErrorEnum.ChannelNotFound;
```


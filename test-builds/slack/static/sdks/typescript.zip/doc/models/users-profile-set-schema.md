
# Users Profile Set Schema

Schema for successful response from users.profile.set method

*This model accepts additional fields of type unknown.*

## Structure

`UsersProfileSetSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `emailPending` | `string \| undefined` | Optional | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `profile` | [`UserProfileObject`](../../doc/models/user-profile-object.md) | Required | - |
| `username` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UsersProfileSetSchema } from 'slack-apimatic-sdk';

const usersProfileSetSchema: UsersProfileSetSchema = {
  ok: 'True',
  profile: {
    avatarHash: 'avatar_hash0',
    displayName: 'display_name0',
    displayNameNormalized: 'display_name_normalized0',
    fields: [
      { 'key1': 'val1', 'key2': 'val2' }
    ],
    phone: 'phone0',
    realName: 'real_name6',
    realNameNormalized: 'real_name_normalized6',
    skype: 'skype0',
    statusEmoji: 'status_emoji4',
    statusText: 'status_text8',
    title: 'title6',
    alwaysActive: false,
    apiAppId: 'api_app_id0',
    botId: 'bot_id6',
    email: 'email6',
    firstName: 'first_name0',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  username: 'username8',
  emailPending: 'email_pending0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


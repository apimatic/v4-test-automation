
# Dnd Set Snooze Error Schema Error

Schema for error response from dnd.setSnooze method

*This model accepts additional fields of type unknown.*

## Structure

`DndSetSnoozeErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndSetSnoozeErrorEnum`](../../doc/models/dnd-set-snooze-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof DndSetSnoozeErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Chat Get Permalink Error Enum

## Enumeration

`ChatGetPermalinkErrorEnum`

## Fields

| Name |
|  --- |
| `ChannelNotFound` |
| `MessageNotFound` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { ChatGetPermalinkErrorEnum } from 'slack-apimatic-sdk';

const chatGetPermalinkErrorEnum = ChatGetPermalinkErrorEnum.InvalidPostType;
```



# Usergroups Update Error Schema Error

Schema for error response from usergroups.update method

*This model accepts additional fields of type unknown.*

## Structure

`UsergroupsUpdateErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsUpdateErrorEnum`](../../doc/models/usergroups-update-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsergroupsUpdateErrorSchemaError) {
    console.log(error.result);
  }
}
```


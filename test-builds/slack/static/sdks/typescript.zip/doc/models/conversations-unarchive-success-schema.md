
# Conversations Unarchive Success Schema

Schema for successful response from conversations.unarchive method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsUnarchiveSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsUnarchiveSuccessSchema } from 'slack-apimatic-sdk';

const conversationsUnarchiveSuccessSchema: ConversationsUnarchiveSuccessSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


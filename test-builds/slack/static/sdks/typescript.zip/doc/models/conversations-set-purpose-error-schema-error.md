
# Conversations Set Purpose Error Schema Error

Schema for error response from conversations.setPurpose method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsSetPurposeErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsSetPurposeErrorEnum`](../../doc/models/conversations-set-purpose-error-enum.md) | Required | - |
| `needed` | `string \| undefined` | Optional | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `provided` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ConversationsSetPurposeErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Usergroups Create Error Schema Error

Schema for error response from usergroups.create method

*This model accepts additional fields of type unknown.*

## Structure

`UsergroupsCreateErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsCreateErrorEnum`](../../doc/models/usergroups-create-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsergroupsCreateErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Team Profile Get Success Schema

Schema for successful response from team.profile.get method

*This model accepts additional fields of type unknown.*

## Structure

`TeamProfileGetSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `profile` | [`Profile`](../../doc/models/profile.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { TeamProfileGetSuccessSchema, Type } from 'slack-apimatic-sdk';

const teamProfileGetSuccessSchema: TeamProfileGetSuccessSchema = {
  ok: 'True',
  profile: {
    fields: [
      {
        hint: 'hint8',
        id: 'id8',
        label: 'label8',
        ordering: 158.68,
        type: Type.OptionsList,
        fieldName: 'field_name2',
        isHidden: false,
        options: { 'key1': 'val1', 'key2': 'val2' },
        possibleValues: [
          'possible_values9',
          'possible_values0'
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Apps Uninstall Error Enum

## Enumeration

`AppsUninstallErrorEnum`

## Fields

| Name |
|  --- |
| `InvalidClientId` |
| `BadClientSecret` |
| `ClientIdTokenMismatch` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { AppsUninstallErrorEnum } from 'slack-apimatic-sdk';

const appsUninstallErrorEnum = AppsUninstallErrorEnum.OrgLoginRequired;
```



# Admin Conversations Get Teams Error Schema Error

Schema for error response from admin.conversations.getTeams

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsGetTeamsErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsGetTeamsErrorEnum`](../../doc/models/admin-conversations-get-teams-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AdminConversationsGetTeamsErrorSchemaError) {
    console.log(error.result);
  }
}
```


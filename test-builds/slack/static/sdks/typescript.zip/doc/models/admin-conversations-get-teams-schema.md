
# Admin Conversations Get Teams Schema

Schema for successful response of admin.conversations.getTeams

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsGetTeamsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `responseMetadata` | [`ResponseMetadata \| undefined`](../../doc/models/response-metadata.md) | Optional | - |
| `teamIds` | `string[]` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AdminConversationsGetTeamsSchema } from 'slack-apimatic-sdk';

const adminConversationsGetTeamsSchema: AdminConversationsGetTeamsSchema = {
  ok: 'True',
  teamIds: [
    'team_ids1',
    'team_ids2',
    'team_ids3'
  ],
  responseMetadata: {
    nextCursor: 'next_cursor2',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


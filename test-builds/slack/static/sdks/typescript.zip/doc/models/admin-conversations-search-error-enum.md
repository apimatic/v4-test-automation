
# Admin Conversations Search Error Enum

## Enumeration

`AdminConversationsSearchErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `NotAnAdmin` |
| `NotAnEnterprise` |
| `TeamNotFound` |
| `NotAllowed` |
| `InvalidAuth` |
| `InvalidCursor` |
| `InvalidSearchChannelType` |
| `InvalidSort` |
| `InvalidSortDir` |

## Example

```ts
import { AdminConversationsSearchErrorEnum } from 'slack-apimatic-sdk';

const adminConversationsSearchErrorEnum = AdminConversationsSearchErrorEnum.NotAllowed;
```



# Users Set Presence Schema

Schema for successful response from users.setPresence method

*This model accepts additional fields of type unknown.*

## Structure

`UsersSetPresenceSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UsersSetPresenceSchema } from 'slack-apimatic-sdk';

const usersSetPresenceSchema: UsersSetPresenceSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Bots Info Schema

Schema for successful response from bots.info method

*This model accepts additional fields of type unknown.*

## Structure

`BotsInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bot` | [`Bot`](../../doc/models/bot.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { BotsInfoSchema } from 'slack-apimatic-sdk';

const botsInfoSchema: BotsInfoSchema = {
  bot: {
    appId: 'app_id0',
    deleted: false,
    icons: {
      image36: 'image_362',
      image48: 'image_488',
      image72: 'image_722',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    id: 'id6',
    name: 'name6',
    updated: 214,
    userId: 'user_id4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Reminders Add Error Schema Error

Schema for error response from reminders.add method

*This model accepts additional fields of type unknown.*

## Structure

`RemindersAddErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RemindersAddErrorEnum`](../../doc/models/reminders-add-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof RemindersAddErrorSchemaError) {
    console.log(error.result);
  }
}
```


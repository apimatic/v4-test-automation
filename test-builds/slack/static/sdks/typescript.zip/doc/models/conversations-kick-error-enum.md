
# Conversations Kick Error Enum

## Enumeration

`ConversationsKickErrorEnum`

## Fields

| Name |
|  --- |
| `MethodNotSupportedForChannelType` |
| `MissingScope` |
| `ChannelNotFound` |
| `UserNotFound` |
| `CantKickSelf` |
| `NotInChannel` |
| `CantKickFromGeneral` |
| `RestrictedAction` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `UserIsBot` |
| `UserIsRestricted` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { ConversationsKickErrorEnum } from 'slack-apimatic-sdk';

const conversationsKickErrorEnum = ConversationsKickErrorEnum.UserIsBot;
```


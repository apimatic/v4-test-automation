
# Files Upload Error Schema Error

Schema for error response files.upload method

*This model accepts additional fields of type unknown.*

## Structure

`FilesUploadErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesUploadErrorEnum`](../../doc/models/files-upload-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof FilesUploadErrorSchemaError) {
    console.log(error.result);
  }
}
```


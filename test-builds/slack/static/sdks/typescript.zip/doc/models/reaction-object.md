
# Reaction Object

*This model accepts additional fields of type unknown.*

## Structure

`ReactionObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `number` | Required | - |
| `name` | `string` | Required | - |
| `users` | `string[]` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ReactionObject } from 'slack-apimatic-sdk';

const reactionObject: ReactionObject = {
  count: 228,
  name: 'name8',
  users: [
    'users5',
    'users4'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


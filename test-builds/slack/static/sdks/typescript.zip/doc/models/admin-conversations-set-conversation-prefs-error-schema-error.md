
# Admin Conversations Set Conversation Prefs Error Schema Error

Schema for error response from admin.conversations.setConversationPrefs

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsSetConversationPrefsErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsSetConversationPrefsErrorEnum`](../../doc/models/admin-conversations-set-conversation-prefs-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AdminConversationsSetConversationPrefsErrorSchemaError) {
    console.log(error.result);
  }
}
```


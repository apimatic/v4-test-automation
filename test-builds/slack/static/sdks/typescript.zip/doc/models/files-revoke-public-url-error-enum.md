
# Files Revoke Public Url Error Enum

## Enumeration

`FilesRevokePublicUrlErrorEnum`

## Fields

| Name |
|  --- |
| `FileNotFound` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `UserIsRestricted` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { FilesRevokePublicUrlErrorEnum } from 'slack-apimatic-sdk';

const filesRevokePublicUrlErrorEnum = FilesRevokePublicUrlErrorEnum.MissingPostType;
```



# Files Info Error Enum

## Enumeration

`FilesInfoErrorEnum`

## Fields

| Name |
|  --- |
| `FileNotFound` |
| `FileDeleted` |
| `TimezoneCountFailed` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { FilesInfoErrorEnum } from 'slack-apimatic-sdk';

const filesInfoErrorEnum = FilesInfoErrorEnum.MissingPostType;
```


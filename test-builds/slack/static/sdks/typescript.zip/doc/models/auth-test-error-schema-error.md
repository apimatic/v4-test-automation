
# Auth Test Error Schema Error

Schema for error response auth.test method

*This model accepts additional fields of type unknown.*

## Structure

`AuthTestErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AuthTestErrorEnum`](../../doc/models/auth-test-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AuthTestErrorSchemaError) {
    console.log(error.result);
  }
}
```


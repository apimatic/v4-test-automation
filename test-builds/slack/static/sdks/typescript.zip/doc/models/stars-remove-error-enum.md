
# Stars Remove Error Enum

## Enumeration

`StarsRemoveErrorEnum`

## Fields

| Name |
|  --- |
| `BadTimestamp` |
| `MessageNotFound` |
| `FileNotFound` |
| `FileCommentNotFound` |
| `ChannelNotFound` |
| `NoItemSpecified` |
| `NotStarred` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { StarsRemoveErrorEnum } from 'slack-apimatic-sdk';

const starsRemoveErrorEnum = StarsRemoveErrorEnum.OrgLoginRequired;
```


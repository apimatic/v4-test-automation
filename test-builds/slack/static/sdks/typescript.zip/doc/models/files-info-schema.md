
# Files Info Schema

Schema for successful response from files.info method

*This model accepts additional fields of type unknown.*

## Structure

`FilesInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `comments` | `unknown[]` | Required | - |
| `contentHtml` | `string \| null \| undefined` | Optional | - |
| `editor` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `file` | [`FileObject`](../../doc/models/file-object.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `paging` | [`PagingObject \| undefined`](../../doc/models/paging-object.md) | Optional | - |
| `responseMetadata` | `unknown \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { FilesInfoSchema } from 'slack-apimatic-sdk';

const filesInfoSchema: FilesInfoSchema = {
  comments: [
    { 'key1': 'val1', 'key2': 'val2' },
    { 'key1': 'val1', 'key2': 'val2' },
    { 'key1': 'val1', 'key2': 'val2' }
  ],
  file: {
    channels: [
      'channels5',
      'channels4'
    ],
    commentsCount: 56,
    created: 220,
    dateDelete: 118,
    displayAsBot: false,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  ok: 'True',
  contentHtml: 'content_html0',
  editor: 'editor4',
  paging: {
    page: 26,
    total: 6,
    count: 56,
    pages: 150,
    perPage: 194,
    spill: 246,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  responseMetadata: { 'key1': 'val1', 'key2': 'val2' },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


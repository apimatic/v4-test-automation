
# Users Set Active Schema

Schema for successful response from users.setActive method

*This model accepts additional fields of type unknown.*

## Structure

`UsersSetActiveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UsersSetActiveSchema } from 'slack-apimatic-sdk';

const usersSetActiveSchema: UsersSetActiveSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


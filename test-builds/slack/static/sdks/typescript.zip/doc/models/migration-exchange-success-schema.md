
# Migration Exchange Success Schema

Schema for successful response from migration.exchange method

*This model accepts additional fields of type unknown.*

## Structure

`MigrationExchangeSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enterpriseId` | `string` | Required | - |
| `invalidUserIds` | `string[] \| undefined` | Optional | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `teamId` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `userIdMap` | `unknown \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { MigrationExchangeSuccessSchema } from 'slack-apimatic-sdk';

const migrationExchangeSuccessSchema: MigrationExchangeSuccessSchema = {
  enterpriseId: 'enterprise_id2',
  ok: 'True',
  teamId: 'team_id4',
  invalidUserIds: [
    'invalid_user_ids0'
  ],
  userIdMap: { 'key1': 'val1', 'key2': 'val2' },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Conversations Set Purpose Success Schema

Schema for successful response from conversations.setPurpose method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsSetPurposeSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `unknown` | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsSetPurposeSuccessSchema } from 'slack-apimatic-sdk';

const conversationsSetPurposeSuccessSchema: ConversationsSetPurposeSuccessSchema = {
  channel: { 'key1': 'val1', 'key2': 'val2' },
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Usergroups List Schema

Schema for successful response from usergroups.list method

*This model accepts additional fields of type unknown.*

## Structure

`UsergroupsListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `usergroups` | [`SubteamUsergroupObject[]`](../../doc/models/subteam-usergroup-object.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UsergroupsListSchema } from 'slack-apimatic-sdk';

const usergroupsListSchema: UsergroupsListSchema = {
  ok: 'True',
  usergroups: [
    {
      autoProvision: false,
      autoType: { 'key1': 'val1', 'key2': 'val2' },
      createdBy: 'created_by8',
      dateCreate: 66,
      dateDelete: 114,
      dateUpdate: 100,
      deletedBy: { 'key1': 'val1', 'key2': 'val2' },
      description: 'description6',
      enterpriseSubteamId: 'enterprise_subteam_id2',
      handle: 'handle0',
      id: 'id4',
      isExternal: false,
      isSubteam: false,
      isUsergroup: false,
      name: 'name4',
      prefs: {
        channels: [
          'channels5',
          'channels4'
        ],
        groups: [
          'groups4',
          'groups5',
          'groups6'
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      teamId: 'team_id2',
      updatedBy: 'updated_by8',
      channelCount: 222,
      userCount: 28,
      users: [
        'users9'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


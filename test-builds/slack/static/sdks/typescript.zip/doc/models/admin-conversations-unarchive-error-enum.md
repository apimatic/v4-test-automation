
# Admin Conversations Unarchive Error Enum

## Enumeration

`AdminConversationsUnarchiveErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `ChannelNotFound` |
| `ChannelNotArchived` |
| `ChannelTypeNotSupported` |
| `RestrictedAction` |
| `CouldNotUnarchiveChannel` |
| `DefaultOrgWideChannel` |
| `MissingScope` |

## Example

```ts
import { AdminConversationsUnarchiveErrorEnum } from 'slack-apimatic-sdk';

const adminConversationsUnarchiveErrorEnum = AdminConversationsUnarchiveErrorEnum.RestrictedAction;
```


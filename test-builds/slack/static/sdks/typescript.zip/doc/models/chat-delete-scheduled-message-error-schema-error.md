
# Chat Delete Scheduled Message Error Schema Error

Schema for error response from chat.deleteScheduledMessage method

*This model accepts additional fields of type unknown.*

## Structure

`ChatDeleteScheduledMessageErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatDeleteScheduledMessageErrorEnum`](../../doc/models/chat-delete-scheduled-message-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ChatDeleteScheduledMessageErrorSchemaError) {
    console.log(error.result);
  }
}
```


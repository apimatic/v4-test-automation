
# Team Profile Get Error Enum

## Enumeration

`TeamProfileGetErrorEnum`

## Fields

| Name |
|  --- |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostTyp` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeou` |
| `UpgradeRequired` |

## Example

```ts
import { TeamProfileGetErrorEnum } from 'slack-apimatic-sdk';

const teamProfileGetErrorEnum = TeamProfileGetErrorEnum.InvalidFormData;
```


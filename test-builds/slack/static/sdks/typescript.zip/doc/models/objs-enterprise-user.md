
# Objs Enterprise User

*This model accepts additional fields of type unknown.*

## Structure

`ObjsEnterpriseUser`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enterpriseId` | `string` | Required | **Constraints**: *Pattern*: `^[E][A-Z0-9]{8,}$` |
| `enterpriseName` | `string` | Required | - |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^[WU][A-Z0-9]{8,}$` |
| `isAdmin` | `boolean` | Required | - |
| `isOwner` | `boolean` | Required | - |
| `teams` | `string[]` | Required | **Constraints**: *Unique Items Required*, *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ObjsEnterpriseUser } from 'slack-apimatic-sdk';

const objsEnterpriseUser: ObjsEnterpriseUser = {
  enterpriseId: 'enterprise_id2',
  enterpriseName: 'enterprise_name8',
  id: 'id2',
  isAdmin: false,
  isOwner: false,
  teams: [
    'teams3',
    'teams2'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


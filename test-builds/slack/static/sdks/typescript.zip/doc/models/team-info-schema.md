
# Team Info Schema

Schema for successful response from team.info method

*This model accepts additional fields of type unknown.*

## Structure

`TeamInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `team` | [`TeamObject`](../../doc/models/team-object.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { TeamInfoSchema } from 'slack-apimatic-sdk';

const teamInfoSchema: TeamInfoSchema = {
  ok: 'True',
  team: {
    domain: 'domain6',
    emailDomain: 'email_domain0',
    icon: {
      image102: 'image_1020',
      image132: 'image_1326',
      image230: 'image_2308',
      image34: 'image_340',
      image44: 'image_440',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    id: 'id0',
    name: 'name0',
    archived: false,
    avatarBaseUrl: 'avatar_base_url0',
    created: 212,
    dateCreate: 62,
    deleted: false,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


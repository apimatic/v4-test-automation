
# Apps Permissions Scopes List Error Schema Error

Schema for error response from apps.permissions.scopes.list method

*This model accepts additional fields of type unknown.*

## Structure

`AppsPermissionsScopesListErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsInfoErrorEnum`](../../doc/models/apps-permissions-info-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AppsPermissionsScopesListErrorSchemaError) {
    console.log(error.result);
  }
}
```


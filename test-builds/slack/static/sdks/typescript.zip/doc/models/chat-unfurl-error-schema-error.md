
# Chat Unfurl Error Schema Error

Schema for error response from chat.unfurl method

*This model accepts additional fields of type unknown.*

## Structure

`ChatUnfurlErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatUnfurlErrorEnum`](../../doc/models/chat-unfurl-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ChatUnfurlErrorSchemaError) {
    console.log(error.result);
  }
}
```


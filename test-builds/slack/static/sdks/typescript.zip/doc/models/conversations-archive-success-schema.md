
# Conversations Archive Success Schema

Schema for successful response conversations.archive method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsArchiveSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsArchiveSuccessSchema } from 'slack-apimatic-sdk';

const conversationsArchiveSuccessSchema: ConversationsArchiveSuccessSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


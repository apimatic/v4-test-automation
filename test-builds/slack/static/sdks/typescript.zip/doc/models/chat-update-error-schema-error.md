
# Chat Update Error Schema Error

Schema for error response chat.update method

*This model accepts additional fields of type unknown.*

## Structure

`ChatUpdateErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatUpdateErrorEnum`](../../doc/models/chat-update-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ChatUpdateErrorSchemaError) {
    console.log(error.result);
  }
}
```


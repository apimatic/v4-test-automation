
# Conversations Mark Error Enum

## Enumeration

`ConversationsMarkErrorEnum`

## Fields

| Name |
|  --- |
| `MethodNotSupportedForChannelType` |
| `MissingScope` |
| `ChannelNotFound` |
| `InvalidTimestamp` |
| `NotInChannel` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `NotAllowedTokenType` |

## Example

```ts
import { ConversationsMarkErrorEnum } from 'slack-apimatic-sdk';

const conversationsMarkErrorEnum = ConversationsMarkErrorEnum.InvalidPostType;
```



# Conversations Rename Error Enum

## Enumeration

`ConversationsRenameErrorEnum`

## Fields

| Name |
|  --- |
| `UserIsRestricted` |
| `MethodNotSupportedForChannelType` |
| `MissingScope` |
| `ChannelNotFound` |
| `NotInChannel` |
| `NotAuthorized` |
| `InvalidName` |
| `NameTaken` |
| `InvalidNameRequired` |
| `InvalidNamePunctuation` |
| `InvalidNameMaxlength` |
| `InvalidNameSpecials` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { ConversationsRenameErrorEnum } from 'slack-apimatic-sdk';

const conversationsRenameErrorEnum = ConversationsRenameErrorEnum.InvalidNameMaxlength;
```


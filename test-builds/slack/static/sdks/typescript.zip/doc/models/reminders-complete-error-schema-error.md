
# Reminders Complete Error Schema Error

Schema for error response from reminders.complete method

*This model accepts additional fields of type unknown.*

## Structure

`RemindersCompleteErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RemindersCompleteErrorEnum`](../../doc/models/reminders-complete-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof RemindersCompleteErrorSchemaError) {
    console.log(error.result);
  }
}
```


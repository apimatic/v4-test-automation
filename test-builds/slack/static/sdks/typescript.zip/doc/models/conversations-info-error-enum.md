
# Conversations Info Error Enum

## Enumeration

`ConversationsInfoErrorEnum`

## Fields

| Name |
|  --- |
| `MissingScope` |
| `ChannelNotFound` |
| `TeamAddedToOrg` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { ConversationsInfoErrorEnum } from 'slack-apimatic-sdk';

const conversationsInfoErrorEnum = ConversationsInfoErrorEnum.MissingScope;
```



# Dnd Info Error Schema Error

Schema for error response from dnd.info method

*This model accepts additional fields of type unknown.*

## Structure

`DndInfoErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndInfoErrorEnum`](../../doc/models/dnd-info-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof DndInfoErrorSchemaError) {
    console.log(error.result);
  }
}
```


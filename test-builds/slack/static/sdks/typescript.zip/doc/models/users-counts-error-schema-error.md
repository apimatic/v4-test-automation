
# Users Counts Error Schema Error

Schema for error response users.getPresence method

*This model accepts additional fields of type unknown.*

## Structure

`UsersCountsErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `string` | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsersCountsErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Stars Add Error Enum

## Enumeration

`StarsAddErrorEnum`

## Fields

| Name |
|  --- |
| `BadTimestamp` |
| `MessageNotFound` |
| `FileNotFound` |
| `FileCommentNotFound` |
| `ChannelNotFound` |
| `NoItemSpecified` |
| `AlreadyStarred` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { StarsAddErrorEnum } from 'slack-apimatic-sdk';

const starsAddErrorEnum = StarsAddErrorEnum.FatalError;
```


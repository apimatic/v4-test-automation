
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Text` |
| `Date` |
| `Link` |
| `Mailto` |
| `OptionsList` |
| `User` |

## Example

```ts
import { Type } from 'slack-apimatic-sdk';

const type = Type.Link;
```



# Admin Conversations Set Conversation Prefs Error Enum

## Enumeration

`AdminConversationsSetConversationPrefsErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `NotAnAdmin` |
| `ChannelNotFound` |
| `ChannelTypeNotSupported` |
| `RestrictedAction` |
| `MissingScope` |
| `CouldNotSetChannelPref` |
| `DefaultOrgWideChannel` |

## Example

```ts
import {
  AdminConversationsSetConversationPrefsErrorEnum,
} from 'slack-apimatic-sdk';

const adminConversationsSetConversationPrefsErrorEnum = AdminConversationsSetConversationPrefsErrorEnum.FeatureNotEnabled;
```



# Admin Conversations Unarchive Error Schema 2 Error

Schema for error response from admin.conversations.rename

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsUnarchiveErrorSchema2Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsRenameErrorEnum`](../../doc/models/admin-conversations-rename-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AdminConversationsUnarchiveErrorSchema2Error) {
    console.log(error.result);
  }
}
```


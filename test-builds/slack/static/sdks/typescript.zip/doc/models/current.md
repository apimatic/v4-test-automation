
# Current

*This model accepts additional fields of type unknown.*

## Structure

`Current`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dateStarted` | `number` | Required | - |
| `teamId` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Current } from 'slack-apimatic-sdk';

const current: Current = {
  dateStarted: 84,
  teamId: 'team_id0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


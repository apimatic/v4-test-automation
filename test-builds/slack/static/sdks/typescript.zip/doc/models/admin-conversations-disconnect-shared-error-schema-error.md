
# Admin Conversations Disconnect Shared Error Schema Error

Schema for error response from admin.conversations.disconnectShared

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsDisconnectSharedErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsDisconnectSharedErrorEnum`](../../doc/models/admin-conversations-disconnect-shared-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AdminConversationsDisconnectSharedErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Apps Permissions Request Error Enum

## Enumeration

`AppsPermissionsRequestErrorEnum`

## Fields

| Name |
|  --- |
| `InvalidTrigger` |
| `TriggerExchanged` |
| `InvalidScope` |
| `InvalidUser` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { AppsPermissionsRequestErrorEnum } from 'slack-apimatic-sdk';

const appsPermissionsRequestErrorEnum = AppsPermissionsRequestErrorEnum.TriggerExchanged;
```


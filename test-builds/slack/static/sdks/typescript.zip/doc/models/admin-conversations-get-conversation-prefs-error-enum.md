
# Admin Conversations Get Conversation Prefs Error Enum

## Enumeration

`AdminConversationsGetConversationPrefsErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `NotAnAdmin` |
| `NotAnEnterprise` |
| `RestrictedAction` |
| `MissingScope` |
| `ChannelNotFound` |
| `ChannelTypeNotSupported` |
| `CouldNotGetConversationPrefs` |

## Example

```ts
import {
  AdminConversationsGetConversationPrefsErrorEnum,
} from 'slack-apimatic-sdk';

const adminConversationsGetConversationPrefsErrorEnum = AdminConversationsGetConversationPrefsErrorEnum.NotAnEnterprise;
```


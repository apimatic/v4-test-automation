
# Pins List Error Schema Error

Schema for error response from pins.list method

*This model accepts additional fields of type unknown.*

## Structure

`PinsListErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`PinsListErrorEnum`](../../doc/models/pins-list-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof PinsListErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Errors Is Returned when an Error Associates an User

*This model accepts additional fields of type unknown.*

## Structure

`ErrorsIsReturnedWhenAnErrorAssociatesAnUser`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`ConversationsInviteErrorEnum`](../../doc/models/conversations-invite-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `user` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  ConversationsInviteErrorEnum,
  ErrorsIsReturnedWhenAnErrorAssociatesAnUser,
} from 'slack-apimatic-sdk';

const errorsIsReturnedWhenAnErrorAssociatesAnUser: ErrorsIsReturnedWhenAnErrorAssociatesAnUser = {
  error: ConversationsInviteErrorEnum.UserNotFound,
  ok: 'False',
  user: 'user2',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


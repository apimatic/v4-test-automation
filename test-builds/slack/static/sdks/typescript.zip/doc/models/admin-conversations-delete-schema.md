
# Admin Conversations Delete Schema

Schema for successful response of admin.conversations.delete

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsDeleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AdminConversationsDeleteSchema } from 'slack-apimatic-sdk';

const adminConversationsDeleteSchema: AdminConversationsDeleteSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Admin Conversations Delete Error Schema Error

Schema for error response from admin.conversations.delete

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsDeleteErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsDeleteErrorEnum`](../../doc/models/admin-conversations-delete-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AdminConversationsDeleteErrorSchemaError) {
    console.log(error.result);
  }
}
```


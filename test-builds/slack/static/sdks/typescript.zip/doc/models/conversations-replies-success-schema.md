
# Conversations Replies Success Schema

Schema for successful response from conversations.replies method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsRepliesSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hasMore` | `boolean \| undefined` | Optional | - |
| `messages` | `unknown[]` | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsRepliesSuccessSchema } from 'slack-apimatic-sdk';

const conversationsRepliesSuccessSchema: ConversationsRepliesSuccessSchema = {
  messages: [
    { 'key1': 'val1', 'key2': 'val2' }
  ],
  ok: 'True',
  hasMore: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


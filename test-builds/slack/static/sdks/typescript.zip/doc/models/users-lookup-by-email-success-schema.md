
# Users Lookup by Email Success Schema

Schema for successful response from users.lookupByEmail method

*This model accepts additional fields of type unknown.*

## Structure

`UsersLookupByEmailSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `user` | `unknown` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UsersLookupByEmailSuccessSchema } from 'slack-apimatic-sdk';

const usersLookupByEmailSuccessSchema: UsersLookupByEmailSuccessSchema = {
  ok: 'True',
  user: { 'key1': 'val1', 'key2': 'val2' },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Users Set Photo Schema

Schema for successful response from users.setPhoto method

*This model accepts additional fields of type unknown.*

## Structure

`UsersSetPhotoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `profile` | [`Profile1`](../../doc/models/profile-1.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UsersSetPhotoSchema } from 'slack-apimatic-sdk';

const usersSetPhotoSchema: UsersSetPhotoSchema = {
  ok: 'True',
  profile: {
    avatarHash: 'avatar_hash0',
    image1024: 'image_10246',
    image192: 'image_1926',
    image24: 'image_248',
    image32: 'image_326',
    image48: 'image_488',
    image512: 'image_5124',
    image72: 'image_724',
    imageOriginal: 'image_original6',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Reactions Remove Error Schema Error

Schema for error response from reactions.remove method

*This model accepts additional fields of type unknown.*

## Structure

`ReactionsRemoveErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ReactionsRemoveErrorEnum`](../../doc/models/reactions-remove-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ReactionsRemoveErrorSchemaError) {
    console.log(error.result);
  }
}
```


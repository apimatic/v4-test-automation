
# Response Metadata

*This model accepts additional fields of type unknown.*

## Structure

`ResponseMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nextCursor` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ResponseMetadata } from 'slack-apimatic-sdk';

const responseMetadata: ResponseMetadata = {
  nextCursor: 'next_cursor8',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


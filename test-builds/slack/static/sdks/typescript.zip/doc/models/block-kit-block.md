
# Block Kit Block

*This model accepts additional fields of type unknown.*

## Structure

`BlockKitBlock`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { BlockKitBlock } from 'slack-apimatic-sdk';

const blockKitBlock: BlockKitBlock = {
  type: 'type0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


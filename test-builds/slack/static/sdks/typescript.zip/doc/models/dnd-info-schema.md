
# Dnd Info Schema

Schema for successful response from dnd.info method

*This model accepts additional fields of type unknown.*

## Structure

`DndInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dndEnabled` | `boolean` | Required | - |
| `nextDndEndTs` | `number` | Required | - |
| `nextDndStartTs` | `number` | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `snoozeEnabled` | `boolean \| undefined` | Optional | - |
| `snoozeEndtime` | `number \| undefined` | Optional | - |
| `snoozeRemaining` | `number \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DndInfoSchema } from 'slack-apimatic-sdk';

const dndInfoSchema: DndInfoSchema = {
  dndEnabled: false,
  nextDndEndTs: 132,
  nextDndStartTs: 204,
  ok: 'True',
  snoozeEnabled: false,
  snoozeEndtime: 102,
  snoozeRemaining: 102,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


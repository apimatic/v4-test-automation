
# Rtm Connect Error Schema Error

Schema for error response from rtm.connect method

*This model accepts additional fields of type unknown.*

## Structure

`RtmConnectErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`RtmConnectErrorEnum`](../../doc/models/rtm-connect-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof RtmConnectErrorSchemaError) {
    console.log(error.result);
  }
}
```


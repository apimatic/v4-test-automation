
# Team Access Logs Schema

Schema for successful response from team.accessLogs method

*This model accepts additional fields of type unknown.*

## Structure

`TeamAccessLogsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `logins` | [`Login[]`](../../doc/models/login.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { TeamAccessLogsSchema } from 'slack-apimatic-sdk';

const teamAccessLogsSchema: TeamAccessLogsSchema = {
  logins: [
    {
      count: 244,
      country: 'country8',
      dateFirst: 108,
      dateLast: 124,
      ip: 'ip8',
      isp: 'isp4',
      region: 'region0',
      userAgent: 'user_agent6',
      userId: 'user_id2',
      username: 'username6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  ok: 'True',
  paging: {
    page: 26,
    total: 6,
    count: 56,
    pages: 150,
    perPage: 194,
    spill: 246,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


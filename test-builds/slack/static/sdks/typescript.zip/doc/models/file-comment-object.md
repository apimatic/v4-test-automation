
# File Comment Object

*This model accepts additional fields of type unknown.*

## Structure

`FileCommentObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `comment` | `string` | Required | - |
| `created` | `number` | Required | - |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^Fc[A-Z0-9]{8,}$` |
| `isIntro` | `boolean` | Required | - |
| `isStarred` | `boolean \| undefined` | Optional | - |
| `numStars` | `number \| undefined` | Optional | - |
| `pinnedInfo` | `unknown \| undefined` | Optional | - |
| `pinnedTo` | `string[] \| undefined` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `reactions` | [`ReactionObject[] \| undefined`](../../doc/models/reaction-object.md) | Optional | - |
| `timestamp` | `number` | Required | - |
| `user` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { FileCommentObject } from 'slack-apimatic-sdk';

const fileCommentObject: FileCommentObject = {
  comment: 'comment4',
  created: 72,
  id: 'id2',
  isIntro: false,
  timestamp: 50,
  user: 'user2',
  isStarred: false,
  numStars: 40,
  pinnedInfo: { 'key1': 'val1', 'key2': 'val2' },
  pinnedTo: [
    'pinned_to0',
    'pinned_to1',
    'pinned_to2'
  ],
  reactions: [
    {
      count: 208,
      name: 'name8',
      users: [
        'users5',
        'users6',
        'users7'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


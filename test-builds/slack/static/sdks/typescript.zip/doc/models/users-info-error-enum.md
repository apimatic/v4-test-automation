
# Users Info Error Enum

## Enumeration

`UsersInfoErrorEnum`

## Fields

| Name |
|  --- |
| `UserNotFound` |
| `UserNotVisible` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { UsersInfoErrorEnum } from 'slack-apimatic-sdk';

const usersInfoErrorEnum = UsersInfoErrorEnum.InvalidJson;
```


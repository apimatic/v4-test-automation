
# Conversations Leave Success Schema

Schema for successful response from conversations.leave method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsLeaveSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notInChannel` | `boolean \| undefined` | Optional | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsLeaveSuccessSchema } from 'slack-apimatic-sdk';

const conversationsLeaveSuccessSchema: ConversationsLeaveSuccessSchema = {
  ok: 'True',
  notInChannel: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Chat Me Message Error Schema Error

Schema for error response from chat.meMessage method

*This model accepts additional fields of type unknown.*

## Structure

`ChatMeMessageErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatMeMessageErrorEnum`](../../doc/models/chat-me-message-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ChatMeMessageErrorSchemaError) {
    console.log(error.result);
  }
}
```


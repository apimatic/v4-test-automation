
# Reactions List Schema

Schema for successful response from reactions.list method

*This model accepts additional fields of type unknown.*

## Structure

`ReactionsListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `items` | `unknown[]` | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `paging` | [`PagingObject \| undefined`](../../doc/models/paging-object.md) | Optional | - |
| `responseMetadata` | `unknown \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ReactionsListSchema } from 'slack-apimatic-sdk';

const reactionsListSchema: ReactionsListSchema = {
  items: [
    { 'key1': 'val1', 'key2': 'val2' }
  ],
  ok: 'True',
  paging: {
    page: 26,
    total: 6,
    count: 56,
    pages: 150,
    perPage: 194,
    spill: 246,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  responseMetadata: { 'key1': 'val1', 'key2': 'val2' },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Chat Unfurl Success Schema

Schema for successful response from chat.unfurl method

*This model accepts additional fields of type unknown.*

## Structure

`ChatUnfurlSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ChatUnfurlSuccessSchema } from 'slack-apimatic-sdk';

const chatUnfurlSuccessSchema: ChatUnfurlSuccessSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


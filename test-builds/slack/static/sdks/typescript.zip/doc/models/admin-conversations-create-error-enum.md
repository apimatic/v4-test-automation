
# Admin Conversations Create Error Enum

## Enumeration

`AdminConversationsCreateErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `NameTaken` |
| `RestrictedAction` |
| `TeamNotFound` |
| `InvalidTeam` |
| `InvalidName` |
| `CouldNotCreateChannel` |
| `TeamIdOrOrgRequired` |

## Example

```ts
import { AdminConversationsCreateErrorEnum } from 'slack-apimatic-sdk';

const adminConversationsCreateErrorEnum = AdminConversationsCreateErrorEnum.FeatureNotEnabled;
```



# Bots Info Error Enum

## Enumeration

`BotsInfoErrorEnum`

## Fields

| Name |
|  --- |
| `BotNotFound` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { BotsInfoErrorEnum } from 'slack-apimatic-sdk';

const botsInfoErrorEnum = BotsInfoErrorEnum.InvalidPostType;
```


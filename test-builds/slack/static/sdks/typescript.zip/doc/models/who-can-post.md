
# Who Can Post

*This model accepts additional fields of type unknown.*

## Structure

`WhoCanPost`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `string[] \| undefined` | Optional | - |
| `user` | `string[] \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { WhoCanPost } from 'slack-apimatic-sdk';

const whoCanPost: WhoCanPost = {
  type: [
    'type7'
  ],
  user: [
    'user2',
    'user3',
    'user4'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


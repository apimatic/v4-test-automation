
# Users Set Active Error Enum

## Enumeration

`UsersSetActiveErrorEnum`

## Fields

| Name |
|  --- |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `EkmAccessDenied` |
| `MissingScope` |
| `InvalidArguments` |
| `InvalidArgName` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `RequestTimeout` |
| `FatalError` |
| `InternalError` |

## Example

```ts
import { UsersSetActiveErrorEnum } from 'slack-apimatic-sdk';

const usersSetActiveErrorEnum = UsersSetActiveErrorEnum.EkmAccessDenied;
```


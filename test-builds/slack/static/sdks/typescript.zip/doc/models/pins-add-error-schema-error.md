
# Pins Add Error Schema Error

Schema for error response from pins.add method

*This model accepts additional fields of type unknown.*

## Structure

`PinsAddErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`PinsAddErrorEnum`](../../doc/models/pins-add-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof PinsAddErrorSchemaError) {
    console.log(error.result);
  }
}
```


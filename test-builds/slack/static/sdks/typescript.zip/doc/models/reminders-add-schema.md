
# Reminders Add Schema

Schema for successful response from reminders.add method

*This model accepts additional fields of type unknown.*

## Structure

`RemindersAddSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `reminder` | [`ObjsReminder`](../../doc/models/objs-reminder.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { RemindersAddSchema } from 'slack-apimatic-sdk';

const remindersAddSchema: RemindersAddSchema = {
  ok: 'True',
  reminder: {
    creator: 'creator8',
    id: 'id0',
    recurring: false,
    text: 'text0',
    user: 'user0',
    completeTs: 136,
    time: 38,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


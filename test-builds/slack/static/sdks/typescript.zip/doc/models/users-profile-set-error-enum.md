
# Users Profile Set Error Enum

## Enumeration

`UsersProfileSetErrorEnum`

## Fields

| Name |
|  --- |
| `ReservedName` |
| `InvalidProfile` |
| `ProfileSetFailed` |
| `NotAdmin` |
| `NotAppAdmin` |
| `CannotUpdateAdminUser` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { UsersProfileSetErrorEnum } from 'slack-apimatic-sdk';

const usersProfileSetErrorEnum = UsersProfileSetErrorEnum.TokenRevoked;
```



# Usergroups Enable Error Enum

## Enumeration

`UsergroupsEnableErrorEnum`

## Fields

| Name |
|  --- |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `UserIsRestricted` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequire` |
| `FatalError` |
| `MissingCharset` |
| `SuperfluousCharset` |

## Example

```ts
import { UsergroupsEnableErrorEnum } from 'slack-apimatic-sdk';

const usergroupsEnableErrorEnum = UsergroupsEnableErrorEnum.UpgradeRequire;
```


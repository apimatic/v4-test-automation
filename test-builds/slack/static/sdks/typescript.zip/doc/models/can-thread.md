
# Can Thread

*This model accepts additional fields of type unknown.*

## Structure

`CanThread`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `string[] \| undefined` | Optional | - |
| `user` | `string[] \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { CanThread } from 'slack-apimatic-sdk';

const canThread: CanThread = {
  type: [
    'type3'
  ],
  user: [
    'user8',
    'user9',
    'user0'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


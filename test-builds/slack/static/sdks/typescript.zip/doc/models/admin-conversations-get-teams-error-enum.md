
# Admin Conversations Get Teams Error Enum

## Enumeration

`AdminConversationsGetTeamsErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `ChannelNotFound` |
| `ChannelTypeNotSupported` |
| `UnsupportedTeamType` |
| `RestrictedAction` |
| `CouldNotGetTeams` |
| `InvalidCursor` |
| `InvalidLimit` |

## Example

```ts
import { AdminConversationsGetTeamsErrorEnum } from 'slack-apimatic-sdk';

const adminConversationsGetTeamsErrorEnum = AdminConversationsGetTeamsErrorEnum.ChannelTypeNotSupported;
```


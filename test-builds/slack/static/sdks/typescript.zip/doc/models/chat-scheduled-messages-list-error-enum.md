
# Chat Scheduled Messages List Error Enum

## Enumeration

`ChatScheduledMessagesListErrorEnum`

## Fields

| Name |
|  --- |
| `InvalidChannel` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `EkmAccessDenied` |
| `MissingScope` |
| `InvalidArguments` |
| `InvalidArgName` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { ChatScheduledMessagesListErrorEnum } from 'slack-apimatic-sdk';

const chatScheduledMessagesListErrorEnum = ChatScheduledMessagesListErrorEnum.InvalidFormData;
```


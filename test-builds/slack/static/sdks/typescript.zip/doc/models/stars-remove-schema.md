
# Stars Remove Schema

Schema for successful response from stars.remove method

*This model accepts additional fields of type unknown.*

## Structure

`StarsRemoveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { StarsRemoveSchema } from 'slack-apimatic-sdk';

const starsRemoveSchema: StarsRemoveSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


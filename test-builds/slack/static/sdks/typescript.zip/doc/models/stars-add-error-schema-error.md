
# Stars Add Error Schema Error

Schema for error response from stars.add method

*This model accepts additional fields of type unknown.*

## Structure

`StarsAddErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`StarsAddErrorEnum`](../../doc/models/stars-add-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof StarsAddErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Admin Conversations Archive Schema

Schema for successful response of admin.conversations.archive

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsArchiveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AdminConversationsArchiveSchema } from 'slack-apimatic-sdk';

const adminConversationsArchiveSchema: AdminConversationsArchiveSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


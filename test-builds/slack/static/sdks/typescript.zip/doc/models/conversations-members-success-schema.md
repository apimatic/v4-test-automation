
# Conversations Members Success Schema

Schema for successful response conversations.members method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsMembersSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `members` | `string[]` | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required*, *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `responseMetadata` | [`ResponseMetadata`](../../doc/models/response-metadata.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsMembersSuccessSchema } from 'slack-apimatic-sdk';

const conversationsMembersSuccessSchema: ConversationsMembersSuccessSchema = {
  members: [
    'members0',
    'members1'
  ],
  ok: 'True',
  responseMetadata: {
    nextCursor: 'next_cursor2',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


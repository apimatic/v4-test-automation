
# Icons

*This model accepts additional fields of type unknown.*

## Structure

`Icons`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image36` | `string` | Required | - |
| `image48` | `string` | Required | - |
| `image72` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Icons } from 'slack-apimatic-sdk';

const icons: Icons = {
  image36: 'image_362',
  image48: 'image_488',
  image72: 'image_722',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


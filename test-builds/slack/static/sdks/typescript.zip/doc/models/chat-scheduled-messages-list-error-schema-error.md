
# Chat Scheduled Messages List Error Schema Error

Schema for error response from chat.scheduledMessages.list method

*This model accepts additional fields of type unknown.*

## Structure

`ChatScheduledMessagesListErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatScheduledMessagesListErrorEnum`](../../doc/models/chat-scheduled-messages-list-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ChatScheduledMessagesListErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Paging Object

*This model accepts additional fields of type unknown.*

## Structure

`PagingObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `number \| undefined` | Optional | - |
| `page` | `number` | Required | - |
| `pages` | `number \| undefined` | Optional | - |
| `perPage` | `number \| undefined` | Optional | - |
| `spill` | `number \| undefined` | Optional | - |
| `total` | `number` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { PagingObject } from 'slack-apimatic-sdk';

const pagingObject: PagingObject = {
  page: 62,
  total: 42,
  count: 92,
  pages: 186,
  perPage: 230,
  spill: 230,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


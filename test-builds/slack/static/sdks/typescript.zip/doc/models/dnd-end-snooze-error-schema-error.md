
# Dnd End Snooze Error Schema Error

Schema for error response from dnd.endSnooze method

*This model accepts additional fields of type unknown.*

## Structure

`DndEndSnoozeErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndEndSnoozeErrorEnum`](../../doc/models/dnd-end-snooze-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof DndEndSnoozeErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Topic

*This model accepts additional fields of type unknown.*

## Structure

`Topic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `creator` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{8,}$\|^$` |
| `lastSet` | `number` | Required | - |
| `value` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Topic } from 'slack-apimatic-sdk';

const topic: Topic = {
  creator: 'creator6',
  lastSet: 242,
  value: 'value0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Dialog Open Schema

Schema for successful response from dialog.open method

*This model accepts additional fields of type unknown.*

## Structure

`DialogOpenSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DialogOpenSchema } from 'slack-apimatic-sdk';

const dialogOpenSchema: DialogOpenSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


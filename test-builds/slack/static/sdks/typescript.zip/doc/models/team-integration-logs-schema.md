
# Team Integration Logs Schema

Schema for successful response from team.integrationLogs method

*This model accepts additional fields of type unknown.*

## Structure

`TeamIntegrationLogsSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `logs` | [`Log[]`](../../doc/models/log.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { TeamIntegrationLogsSchema } from 'slack-apimatic-sdk';

const teamIntegrationLogsSchema: TeamIntegrationLogsSchema = {
  logs: [
    {
      appId: 'app_id8',
      appType: 'app_type2',
      changeType: 'change_type8',
      date: 'date4',
      scope: 'scope6',
      userId: 'user_id6',
      userName: 'user_name4',
      adminAppId: 'admin_app_id6',
      channel: 'channel6',
      serviceId: 'service_id8',
      serviceType: 'service_type4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  ok: 'True',
  paging: {
    page: 26,
    total: 6,
    count: 56,
    pages: 150,
    perPage: 194,
    spill: 246,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


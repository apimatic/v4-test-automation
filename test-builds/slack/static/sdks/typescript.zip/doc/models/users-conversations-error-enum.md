
# Users Conversations Error Enum

## Enumeration

`UsersConversationsErrorEnum`

## Fields

| Name |
|  --- |
| `MethodNotSupportedForChannelType` |
| `MissingScope` |
| `InvalidTypes` |
| `InvalidCursor` |
| `InvalidLimit` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { UsersConversationsErrorEnum } from 'slack-apimatic-sdk';

const usersConversationsErrorEnum = UsersConversationsErrorEnum.InvalidCharset;
```


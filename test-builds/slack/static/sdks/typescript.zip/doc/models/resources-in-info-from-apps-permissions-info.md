
# Resources in Info from Apps Permissions Info

*This model accepts additional fields of type unknown.*

## Structure

`ResourcesInInfoFromAppsPermissionsInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `excludedIds` | `unknown[] \| undefined` | Optional | - |
| `ids` | `unknown[]` | Required | - |
| `wildcard` | `boolean \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ResourcesInInfoFromAppsPermissionsInfo } from 'slack-apimatic-sdk';

const resourcesInInfoFromAppsPermissionsInfo: ResourcesInInfoFromAppsPermissionsInfo = {
  ids: [
    { 'key1': 'val1', 'key2': 'val2' }
  ],
  excludedIds: [
    { 'key1': 'val1', 'key2': 'val2' }
  ],
  wildcard: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


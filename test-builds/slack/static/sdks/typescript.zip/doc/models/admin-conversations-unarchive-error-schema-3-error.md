
# Admin Conversations Unarchive Error Schema 3 Error

Schema for error response from admin.conversations.unarchive

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsUnarchiveErrorSchema3Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsUnarchiveErrorEnum`](../../doc/models/admin-conversations-unarchive-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AdminConversationsUnarchiveErrorSchema3Error) {
    console.log(error.result);
  }
}
```


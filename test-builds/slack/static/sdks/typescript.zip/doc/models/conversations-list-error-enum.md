
# Conversations List Error Enum

## Enumeration

`ConversationsListErrorEnum`

## Fields

| Name |
|  --- |
| `MissingScope` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { ConversationsListErrorEnum } from 'slack-apimatic-sdk';

const conversationsListErrorEnum = ConversationsListErrorEnum.InvalidPostType;
```


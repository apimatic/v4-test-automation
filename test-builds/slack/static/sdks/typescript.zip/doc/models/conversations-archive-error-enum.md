
# Conversations Archive Error Enum

## Enumeration

`ConversationsArchiveErrorEnum`

## Fields

| Name |
|  --- |
| `MethodNotSupportedForChannelType` |
| `MissingScope` |
| `NotSupported` |
| `ChannelNotFound` |
| `AlreadyArchived` |
| `CantArchiveGeneral` |
| `RestrictedAction` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `UserIsBot` |
| `UserIsRestricted` |
| `UserIsUltraRestricted` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `TeamAddedToOrg` |
| `MissingCharset` |
| `SuperfluousCharset` |

## Example

```ts
import { ConversationsArchiveErrorEnum } from 'slack-apimatic-sdk';

const conversationsArchiveErrorEnum = ConversationsArchiveErrorEnum.JsonNotObject;
```


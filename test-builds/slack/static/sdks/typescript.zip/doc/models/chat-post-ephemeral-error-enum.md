
# Chat Post Ephemeral Error Enum

## Enumeration

`ChatPostEphemeralErrorEnum`

## Fields

| Name |
|  --- |
| `ChannelNotFound` |
| `IsArchived` |
| `MsgTooLong` |
| `NoText` |
| `RestrictedAction` |
| `TooManyAttachments` |
| `UserNotInChannel` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { ChatPostEphemeralErrorEnum } from 'slack-apimatic-sdk';

const chatPostEphemeralErrorEnum = ChatPostEphemeralErrorEnum.AccountInactive;
```


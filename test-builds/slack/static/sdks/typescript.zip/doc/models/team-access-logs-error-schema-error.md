
# Team Access Logs Error Schema Error

Schema for error response from team.accessLogs method

*This model accepts additional fields of type unknown.*

## Structure

`TeamAccessLogsErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`TeamAccessLogsErrorEnum`](../../doc/models/team-access-logs-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof TeamAccessLogsErrorSchemaError) {
    console.log(error.result);
  }
}
```


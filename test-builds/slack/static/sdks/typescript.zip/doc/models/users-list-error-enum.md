
# Users List Error Enum

## Enumeration

`UsersListErrorEnum`

## Fields

| Name |
|  --- |
| `LimitRequired` |
| `InvalidCursor` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { UsersListErrorEnum } from 'slack-apimatic-sdk';

const usersListErrorEnum = UsersListErrorEnum.TeamAddedToOrg;
```



# Conversations History Success Schema

Schema for successful response from conversations.history method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsHistorySuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channelActionsCount` | `number` | Required | - |
| `channelActionsTs` | `unknown` | Required | - |
| `hasMore` | `boolean` | Required | - |
| `messages` | [`MessageObject[]`](../../doc/models/message-object.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `pinCount` | `number` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsHistorySuccessSchema } from 'slack-apimatic-sdk';

const conversationsHistorySuccessSchema: ConversationsHistorySuccessSchema = {
  channelActionsCount: 18,
  channelActionsTs: { 'key1': 'val1', 'key2': 'val2' },
  hasMore: false,
  messages: [
    {
      text: 'text8',
      ts: 'ts0',
      type: 'type8',
      attachments: [
        {
          id: 36,
          fallback: 'fallback4',
          imageBytes: 34,
          imageHeight: 154,
          imageUrl: 'image_url6',
          imageWidth: 24,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          id: 36,
          fallback: 'fallback4',
          imageBytes: 34,
          imageHeight: 154,
          imageUrl: 'image_url6',
          imageWidth: 24,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      blocks: [
        {
          type: 'type4',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          type: 'type4',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      botId: { 'key1': 'val1', 'key2': 'val2' },
      botProfile: {
        appId: 'app_id8',
        deleted: false,
        icons: {
          image36: 'image_362',
          image48: 'image_488',
          image72: 'image_722',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        id: 'id8',
        name: 'name8',
        teamId: 'team_id8',
        updated: 44,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      clientMsgId: 'client_msg_id4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  ok: 'True',
  pinCount: 84,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Usergroups Enable Error Schema Error

Schema for error response from usergroups.enable method

*This model accepts additional fields of type unknown.*

## Structure

`UsergroupsEnableErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsergroupsEnableErrorEnum`](../../doc/models/usergroups-enable-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsergroupsEnableErrorSchemaError) {
    console.log(error.result);
  }
}
```


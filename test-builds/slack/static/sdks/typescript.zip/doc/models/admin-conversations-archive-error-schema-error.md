
# Admin Conversations Archive Error Schema Error

Schema for error response from admin.conversations.archive

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsArchiveErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsArchiveErrorEnum`](../../doc/models/admin-conversations-archive-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AdminConversationsArchiveErrorSchemaError) {
    console.log(error.result);
  }
}
```


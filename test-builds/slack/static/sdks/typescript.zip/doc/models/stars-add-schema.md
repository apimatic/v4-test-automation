
# Stars Add Schema

Schema for successful response from stars.add method

*This model accepts additional fields of type unknown.*

## Structure

`StarsAddSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { StarsAddSchema } from 'slack-apimatic-sdk';

const starsAddSchema: StarsAddSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


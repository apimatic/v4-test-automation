
# Files List Schema

Schema for successful response from files.list method

*This model accepts additional fields of type unknown.*

## Structure

`FilesListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `files` | [`FileObject[]`](../../doc/models/file-object.md) | Required | **Constraints**: *Minimum Items*: `0`, *Unique Items Required* |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `paging` | [`PagingObject`](../../doc/models/paging-object.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { FilesListSchema } from 'slack-apimatic-sdk';

const filesListSchema: FilesListSchema = {
  files: [
    {
      channels: [
        'channels9'
      ],
      commentsCount: 150,
      created: 58,
      dateDelete: 212,
      displayAsBot: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  ok: 'True',
  paging: {
    page: 26,
    total: 6,
    count: 56,
    pages: 150,
    perPage: 194,
    spill: 246,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Profile 1

*This model accepts additional fields of type unknown.*

## Structure

`Profile1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `avatarHash` | `string` | Required | **Constraints**: *Pattern*: `^[0-9a-f]{12}$` |
| `image1024` | `string` | Required | - |
| `image192` | `string` | Required | - |
| `image24` | `string` | Required | - |
| `image32` | `string` | Required | - |
| `image48` | `string` | Required | - |
| `image512` | `string` | Required | - |
| `image72` | `string` | Required | - |
| `imageOriginal` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Profile1 } from 'slack-apimatic-sdk';

const profile1: Profile1 = {
  avatarHash: 'avatar_hash2',
  image1024: 'image_10248',
  image192: 'image_1928',
  image24: 'image_246',
  image32: 'image_328',
  image48: 'image_480',
  image512: 'image_5122',
  image72: 'image_726',
  imageOriginal: 'image_original8',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Chat Post Ephemeral Error Schema Error

Schema for error response from chat.postEphemeral method

*This model accepts additional fields of type unknown.*

## Structure

`ChatPostEphemeralErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatPostEphemeralErrorEnum`](../../doc/models/chat-post-ephemeral-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ChatPostEphemeralErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Users Set Presence Error Schema Error

Schema for error response from users.setPresence method

*This model accepts additional fields of type unknown.*

## Structure

`UsersSetPresenceErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersSetPresenceErrorEnum`](../../doc/models/users-set-presence-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsersSetPresenceErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Conversations Close Error Enum

## Enumeration

`ConversationsCloseErrorEnum`

## Fields

| Name |
|  --- |
| `MethodNotSupportedForChannelType` |
| `ChannelNotFound` |
| `UserDoesNotOwnChannel` |
| `MissingScope` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { ConversationsCloseErrorEnum } from 'slack-apimatic-sdk';

const conversationsCloseErrorEnum = ConversationsCloseErrorEnum.NotAuthed;
```



# Dnd End Dnd Error Schema Error

Schema for error response from dnd.endDnd method

*This model accepts additional fields of type unknown.*

## Structure

`DndEndDndErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`DndEndDndErrorEnum`](../../doc/models/dnd-end-dnd-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof DndEndDndErrorSchemaError) {
    console.log(error.result);
  }
}
```


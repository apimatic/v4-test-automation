
# Icons 1

*This model accepts additional fields of type unknown.*

## Structure

`Icons1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `emoji` | `string \| undefined` | Optional | - |
| `image64` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Icons1 } from 'slack-apimatic-sdk';

const icons1: Icons1 = {
  emoji: 'emoji4',
  image64: 'image_646',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


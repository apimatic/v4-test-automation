
# Plan

## Enumeration

`Plan`

## Fields

| Name |
|  --- |
| `Std` |
| `Plus` |
| `Compliance` |
| `Enterprise` |

## Example

```ts
import { Plan } from 'slack-apimatic-sdk';

const plan = Plan.Compliance;
```



# Users List Error Schema Error

Schema for error response from users.list method

*This model accepts additional fields of type unknown.*

## Structure

`UsersListErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`UsersListErrorEnum`](../../doc/models/users-list-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsersListErrorSchemaError) {
    console.log(error.result);
  }
}
```


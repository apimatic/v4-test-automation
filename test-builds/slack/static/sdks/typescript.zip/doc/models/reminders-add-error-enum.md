
# Reminders Add Error Enum

## Enumeration

`RemindersAddErrorEnum`

## Fields

| Name |
|  --- |
| `CannotParse` |
| `UserNotFound` |
| `CannotAddBot` |
| `CannotAddSlackbot` |
| `CannotAddOthers` |
| `CannotAddOthersRecurring` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { RemindersAddErrorEnum } from 'slack-apimatic-sdk';

const remindersAddErrorEnum = RemindersAddErrorEnum.InvalidCharset;
```


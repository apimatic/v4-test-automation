
# Conversations Kick Success Schema

Schema for successful response conversations.kick method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsKickSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsKickSuccessSchema } from 'slack-apimatic-sdk';

const conversationsKickSuccessSchema: ConversationsKickSuccessSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


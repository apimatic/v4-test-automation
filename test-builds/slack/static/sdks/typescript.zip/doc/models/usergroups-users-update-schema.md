
# Usergroups Users Update Schema

Schema for successful response from usergroups.users.update method

*This model accepts additional fields of type unknown.*

## Structure

`UsergroupsUsersUpdateSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `usergroup` | [`SubteamUsergroupObject`](../../doc/models/subteam-usergroup-object.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UsergroupsUsersUpdateSchema } from 'slack-apimatic-sdk';

const usergroupsUsersUpdateSchema: UsergroupsUsersUpdateSchema = {
  ok: 'True',
  usergroup: {
    autoProvision: false,
    autoType: { 'key1': 'val1', 'key2': 'val2' },
    createdBy: 'created_by0',
    dateCreate: 164,
    dateDelete: 212,
    dateUpdate: 198,
    deletedBy: { 'key1': 'val1', 'key2': 'val2' },
    description: 'description2',
    enterpriseSubteamId: 'enterprise_subteam_id0',
    handle: 'handle8',
    id: 'id2',
    isExternal: false,
    isSubteam: false,
    isUsergroup: false,
    name: 'name2',
    prefs: {
      channels: [
        'channels5',
        'channels4'
      ],
      groups: [
        'groups4',
        'groups5',
        'groups6'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    teamId: 'team_id6',
    updatedBy: 'updated_by6',
    channelCount: 64,
    userCount: 70,
    users: [
      'users3',
      'users4',
      'users5'
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


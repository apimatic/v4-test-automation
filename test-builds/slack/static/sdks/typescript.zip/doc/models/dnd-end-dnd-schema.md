
# Dnd End Dnd Schema

Schema for successful response from dnd.endDnd method

*This model accepts additional fields of type unknown.*

## Structure

`DndEndDndSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DndEndDndSchema } from 'slack-apimatic-sdk';

const dndEndDndSchema: DndEndDndSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


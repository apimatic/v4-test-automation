
# Conversations Rename Success Schema

Schema for successful response from conversations.rename method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsRenameSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `unknown` | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsRenameSuccessSchema } from 'slack-apimatic-sdk';

const conversationsRenameSuccessSchema: ConversationsRenameSuccessSchema = {
  channel: { 'key1': 'val1', 'key2': 'val2' },
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


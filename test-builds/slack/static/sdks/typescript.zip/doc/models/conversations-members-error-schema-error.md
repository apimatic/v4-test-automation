
# Conversations Members Error Schema Error

Schema for error response conversations.members method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsMembersErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsMembersErrorEnum`](../../doc/models/conversations-members-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ConversationsMembersErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Apps Permissions Info Schema

Schema for successful response from apps.permissions.info method

*This model accepts additional fields of type unknown.*

## Structure

`AppsPermissionsInfoSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `info` | [`Info`](../../doc/models/info.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AppsPermissionsInfoSchema } from 'slack-apimatic-sdk';

const appsPermissionsInfoSchema: AppsPermissionsInfoSchema = {
  info: {
    appHome: {
      resources: {
        ids: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        excludedIds: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        wildcard: false,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      scopes: [
        'scopes4',
        'scopes3',
        'scopes2'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    channel: {
      resources: {
        ids: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        excludedIds: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        wildcard: false,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      scopes: [
        'scopes2',
        'scopes1'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    group: {
      resources: {
        ids: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        excludedIds: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        wildcard: false,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      scopes: [
        'scopes4'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    im: {
      resources: {
        ids: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        excludedIds: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        wildcard: false,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      scopes: [
        'scopes0',
        'scopes9',
        'scopes8'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    mpim: {
      resources: {
        ids: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        excludedIds: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        wildcard: false,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      scopes: [
        'scopes6'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    team: {
      resources: {
        ids: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        excludedIds: [
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' },
          { 'key1': 'val1', 'key2': 'val2' }
        ],
        wildcard: false,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      scopes: [
        'scopes6',
        'scopes5',
        'scopes4'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


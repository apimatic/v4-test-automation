
# Files List Error Schema Error

Schema for error response from files.list method

*This model accepts additional fields of type unknown.*

## Structure

`FilesListErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesListErrorEnum`](../../doc/models/files-list-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof FilesListErrorSchemaError) {
    console.log(error.result);
  }
}
```


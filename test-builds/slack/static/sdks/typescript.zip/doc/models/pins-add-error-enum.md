
# Pins Add Error Enum

## Enumeration

`PinsAddErrorEnum`

## Fields

| Name |
|  --- |
| `BadTimestamp` |
| `MessageNotFound` |
| `ChannelNotFound` |
| `NoItemSpecified` |
| `AlreadyPinned` |
| `PermissionDenied` |
| `FileNotShared` |
| `NotPinnable` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { PinsAddErrorEnum } from 'slack-apimatic-sdk';

const pinsAddErrorEnum = PinsAddErrorEnum.AccountInactive;
```


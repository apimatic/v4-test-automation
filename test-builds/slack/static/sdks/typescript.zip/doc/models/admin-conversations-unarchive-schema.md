
# Admin Conversations Unarchive Schema

Schema for successful response of admin.conversations.unarchive

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsUnarchiveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AdminConversationsUnarchiveSchema } from 'slack-apimatic-sdk';

const adminConversationsUnarchiveSchema: AdminConversationsUnarchiveSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Objs Primary Owner

*This model accepts additional fields of type unknown.*

## Structure

`ObjsPrimaryOwner`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `string` | Required | - |
| `id` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ObjsPrimaryOwner } from 'slack-apimatic-sdk';

const objsPrimaryOwner: ObjsPrimaryOwner = {
  email: 'email4',
  id: 'id2',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


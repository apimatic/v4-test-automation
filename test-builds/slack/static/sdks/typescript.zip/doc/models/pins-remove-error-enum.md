
# Pins Remove Error Enum

## Enumeration

`PinsRemoveErrorEnum`

## Fields

| Name |
|  --- |
| `BadTimestamp` |
| `FileNotFound` |
| `FileCommentNotFound` |
| `MessageNotFound` |
| `NoItemSpecified` |
| `NotPinned` |
| `PermissionDenied` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostTyp` |
| `MissingPostTyp` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeou` |
| `UpgradeRequired` |

## Example

```ts
import { PinsRemoveErrorEnum } from 'slack-apimatic-sdk';

const pinsRemoveErrorEnum = PinsRemoveErrorEnum.InvalidAuth;
```


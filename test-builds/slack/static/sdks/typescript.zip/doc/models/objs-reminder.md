
# Objs Reminder

*This model accepts additional fields of type unknown.*

## Structure

`ObjsReminder`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `completeTs` | `number \| undefined` | Optional | - |
| `creator` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^Rm[A-Z0-9]{8,}$` |
| `recurring` | `boolean` | Required | - |
| `text` | `string` | Required | - |
| `time` | `number \| undefined` | Optional | - |
| `user` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ObjsReminder } from 'slack-apimatic-sdk';

const objsReminder: ObjsReminder = {
  creator: 'creator8',
  id: 'id0',
  recurring: false,
  text: 'text0',
  user: 'user0',
  completeTs: 160,
  time: 194,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Users Set Photo Error Enum

## Enumeration

`UsersSetPhotoErrorEnum`

## Fields

| Name |
|  --- |
| `BadImage` |
| `TooLarge` |
| `TooManyFrames` |
| `NotFound` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { UsersSetPhotoErrorEnum } from 'slack-apimatic-sdk';

const usersSetPhotoErrorEnum = UsersSetPhotoErrorEnum.AccountInactive;
```


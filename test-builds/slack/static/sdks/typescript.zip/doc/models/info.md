
# Info

*This model accepts additional fields of type unknown.*

## Structure

`Info`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appHome` | [`AppHome`](../../doc/models/app-home.md) | Required | - |
| `channel` | [`Channel`](../../doc/models/channel.md) | Required | - |
| `group` | [`Group`](../../doc/models/group.md) | Required | - |
| `im` | [`Im`](../../doc/models/im.md) | Required | - |
| `mpim` | [`Mpim`](../../doc/models/mpim.md) | Required | - |
| `team` | [`Team`](../../doc/models/team.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Info } from 'slack-apimatic-sdk';

const info: Info = {
  appHome: {
    resources: {
      ids: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      excludedIds: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      wildcard: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    scopes: [
      'scopes4',
      'scopes3',
      'scopes2'
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  channel: {
    resources: {
      ids: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      excludedIds: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      wildcard: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    scopes: [
      'scopes2',
      'scopes1'
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  group: {
    resources: {
      ids: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      excludedIds: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      wildcard: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    scopes: [
      'scopes4'
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  im: {
    resources: {
      ids: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      excludedIds: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      wildcard: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    scopes: [
      'scopes0',
      'scopes9',
      'scopes8'
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  mpim: {
    resources: {
      ids: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      excludedIds: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      wildcard: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    scopes: [
      'scopes6'
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  team: {
    resources: {
      ids: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      excludedIds: [
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' },
        { 'key1': 'val1', 'key2': 'val2' }
      ],
      wildcard: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    scopes: [
      'scopes6',
      'scopes5',
      'scopes4'
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


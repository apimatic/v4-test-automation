
# Dnd Set Snooze Error Enum

## Enumeration

`DndSetSnoozeErrorEnum`

## Fields

| Name |
|  --- |
| `MissingDuration` |
| `SnoozeFailed` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `TooLong` |
| `FatalError` |

## Example

```ts
import { DndSetSnoozeErrorEnum } from 'slack-apimatic-sdk';

const dndSetSnoozeErrorEnum = DndSetSnoozeErrorEnum.MissingPostType;
```


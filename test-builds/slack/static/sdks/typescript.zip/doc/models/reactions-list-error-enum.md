
# Reactions List Error Enum

## Enumeration

`ReactionsListErrorEnum`

## Fields

| Name |
|  --- |
| `UserNotFound` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactiv` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { ReactionsListErrorEnum } from 'slack-apimatic-sdk';

const reactionsListErrorEnum = ReactionsListErrorEnum.InvalidJson;
```


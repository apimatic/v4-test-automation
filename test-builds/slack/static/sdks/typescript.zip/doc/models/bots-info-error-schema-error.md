
# Bots Info Error Schema Error

Schema for error response from bots.info method

*This model accepts additional fields of type unknown.*

## Structure

`BotsInfoErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`BotsInfoErrorEnum`](../../doc/models/bots-info-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof BotsInfoErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Profile

*This model accepts additional fields of type unknown.*

## Structure

`Profile`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fields` | [`ObjsTeamProfileField[]`](../../doc/models/objs-team-profile-field.md) | Required | **Constraints**: *Unique Items Required* |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Profile, Type } from 'slack-apimatic-sdk';

const profile: Profile = {
  fields: [
    {
      hint: 'hint8',
      id: 'id8',
      label: 'label8',
      ordering: 158.68,
      type: Type.OptionsList,
      fieldName: 'field_name2',
      isHidden: false,
      options: { 'key1': 'val1', 'key2': 'val2' },
      possibleValues: [
        'possible_values9',
        'possible_values0'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


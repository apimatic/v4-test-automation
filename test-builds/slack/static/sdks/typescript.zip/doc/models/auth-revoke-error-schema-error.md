
# Auth Revoke Error Schema Error

Schema for error response from auth.revoke method

*This model accepts additional fields of type unknown.*

## Structure

`AuthRevokeErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AuthRevokeErrorEnum`](../../doc/models/auth-revoke-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AuthRevokeErrorSchemaError) {
    console.log(error.result);
  }
}
```


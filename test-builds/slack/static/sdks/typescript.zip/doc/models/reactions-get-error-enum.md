
# Reactions Get Error Enum

## Enumeration

`ReactionsGetErrorEnum`

## Fields

| Name |
|  --- |
| `BadTimestamp` |
| `FileNotFound` |
| `FileCommentNotFound` |
| `MessageNotFound` |
| `NoItemSpecified` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { ReactionsGetErrorEnum } from 'slack-apimatic-sdk';

const reactionsGetErrorEnum = ReactionsGetErrorEnum.InvalidCharset;
```


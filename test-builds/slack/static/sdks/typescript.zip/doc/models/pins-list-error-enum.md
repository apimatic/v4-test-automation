
# Pins List Error Enum

## Enumeration

`PinsListErrorEnum`

## Fields

| Name |
|  --- |
| `ChannelNotFound` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { PinsListErrorEnum } from 'slack-apimatic-sdk';

const pinsListErrorEnum = PinsListErrorEnum.InvalidFormData;
```


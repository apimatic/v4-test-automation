
# Purpose

*This model accepts additional fields of type unknown.*

## Structure

`Purpose`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `creator` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{8,}$\|^$` |
| `lastSet` | `number` | Required | - |
| `value` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Purpose } from 'slack-apimatic-sdk';

const purpose: Purpose = {
  creator: 'creator4',
  lastSet: 30,
  value: 'value8',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


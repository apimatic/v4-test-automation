
# Chat Post Message Success Schema

Schema for successful response of chat.postMessage method

*This model accepts additional fields of type unknown.*

## Structure

`ChatPostMessageSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `string` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `message` | [`MessageObject`](../../doc/models/message-object.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `ts` | `string` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ChatPostMessageSuccessSchema } from 'slack-apimatic-sdk';

const chatPostMessageSuccessSchema: ChatPostMessageSuccessSchema = {
  channel: 'channel6',
  message: {
    text: 'text0',
    ts: 'ts2',
    type: 'type0',
    attachments: [
      {
        id: 36,
        fallback: 'fallback4',
        imageBytes: 34,
        imageHeight: 154,
        imageUrl: 'image_url6',
        imageWidth: 24,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      {
        id: 36,
        fallback: 'fallback4',
        imageBytes: 34,
        imageHeight: 154,
        imageUrl: 'image_url6',
        imageWidth: 24,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    blocks: [
      {
        type: 'type4',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      {
        type: 'type4',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    botId: { 'key1': 'val1', 'key2': 'val2' },
    botProfile: {
      appId: 'app_id8',
      deleted: false,
      icons: {
        image36: 'image_362',
        image48: 'image_488',
        image72: 'image_722',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      id: 'id8',
      name: 'name8',
      teamId: 'team_id8',
      updated: 44,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    clientMsgId: 'client_msg_id4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  ok: 'True',
  ts: 'ts0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Attachment

*This model accepts additional fields of type unknown.*

## Structure

`Attachment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fallback` | `string \| undefined` | Optional | - |
| `id` | `number` | Required | - |
| `imageBytes` | `number \| undefined` | Optional | - |
| `imageHeight` | `number \| undefined` | Optional | - |
| `imageUrl` | `string \| undefined` | Optional | - |
| `imageWidth` | `number \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Attachment } from 'slack-apimatic-sdk';

const attachment: Attachment = {
  id: 248,
  fallback: 'fallback6',
  imageBytes: 78,
  imageHeight: 110,
  imageUrl: 'image_url4',
  imageWidth: 236,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


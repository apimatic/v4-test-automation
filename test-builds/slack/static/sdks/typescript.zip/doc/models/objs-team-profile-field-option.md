
# Objs Team Profile Field Option

*This model accepts additional fields of type unknown.*

## Structure

`ObjsTeamProfileFieldOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isCustom` | `boolean \| null \| undefined` | Optional | - |
| `isMultipleEntry` | `boolean \| null \| undefined` | Optional | - |
| `isProtected` | `boolean \| null \| undefined` | Optional | - |
| `isScim` | `boolean \| null \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ObjsTeamProfileFieldOption } from 'slack-apimatic-sdk';

const objsTeamProfileFieldOption: ObjsTeamProfileFieldOption = {
  isCustom: false,
  isMultipleEntry: false,
  isProtected: false,
  isScim: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


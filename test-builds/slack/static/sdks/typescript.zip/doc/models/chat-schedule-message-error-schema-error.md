
# Chat Schedule Message Error Schema Error

Schema for error response chat.scheduleMessage method

*This model accepts additional fields of type unknown.*

## Structure

`ChatScheduleMessageErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatScheduleMessageErrorEnum`](../../doc/models/chat-schedule-message-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ChatScheduleMessageErrorSchemaError) {
    console.log(error.result);
  }
}
```


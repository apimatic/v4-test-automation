
# Admin Conversations Search Schema

Schema for successful response of admin.conversations.search

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsSearchSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channels` | [`ChannelObject[]`](../../doc/models/channel-object.md) | Required | - |
| `nextCursor` | `string` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AdminConversationsSearchSchema } from 'slack-apimatic-sdk';

const adminConversationsSearchSchema: AdminConversationsSearchSchema = {
  channels: [
    {
      created: 90,
      creator: 'creator8',
      id: 'id0',
      isChannel: false,
      isMpim: false,
      isOrgShared: false,
      isPrivate: false,
      isShared: false,
      members: [
        'members8'
      ],
      name: 'name0',
      nameNormalized: 'name_normalized8',
      purpose: {
        creator: 'creator4',
        lastSet: 30,
        value: 'value8',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      topic: {
        creator: 'creator6',
        lastSet: 242,
        value: 'value0',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      acceptedUser: 'accepted_user8',
      isArchived: false,
      isFrozen: false,
      isGeneral: false,
      isMember: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  nextCursor: 'next_cursor4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


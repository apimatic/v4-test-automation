
# Conversations History Error Enum

## Enumeration

`ConversationsHistoryErrorEnum`

## Fields

| Name |
|  --- |
| `MissingScope` |
| `ChannelNotFound` |
| `InvalidTsLatest` |
| `InvalidTsOldest` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { ConversationsHistoryErrorEnum } from 'slack-apimatic-sdk';

const conversationsHistoryErrorEnum = ConversationsHistoryErrorEnum.ChannelNotFound;
```


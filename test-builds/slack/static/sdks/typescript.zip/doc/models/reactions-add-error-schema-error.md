
# Reactions Add Error Schema Error

Schema for error response from reactions.add method

*This model accepts additional fields of type unknown.*

## Structure

`ReactionsAddErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ReactionsAddErrorEnum`](../../doc/models/reactions-add-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ReactionsAddErrorSchemaError) {
    console.log(error.result);
  }
}
```


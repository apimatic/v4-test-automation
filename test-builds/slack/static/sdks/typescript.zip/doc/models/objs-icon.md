
# Objs Icon

*This model accepts additional fields of type unknown.*

## Structure

`ObjsIcon`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image102` | `string \| undefined` | Optional | - |
| `image132` | `string \| undefined` | Optional | - |
| `image230` | `string \| undefined` | Optional | - |
| `image34` | `string \| undefined` | Optional | - |
| `image44` | `string \| undefined` | Optional | - |
| `image68` | `string \| undefined` | Optional | - |
| `image88` | `string \| undefined` | Optional | - |
| `imageDefault` | `boolean \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ObjsIcon } from 'slack-apimatic-sdk';

const objsIcon: ObjsIcon = {
  image102: 'image_1024',
  image132: 'image_1322',
  image230: 'image_2308',
  image34: 'image_346',
  image44: 'image_446',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


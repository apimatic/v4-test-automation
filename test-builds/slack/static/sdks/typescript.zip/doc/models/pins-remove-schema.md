
# Pins Remove Schema

Schema for successful response from pins.remove method

*This model accepts additional fields of type unknown.*

## Structure

`PinsRemoveSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { PinsRemoveSchema } from 'slack-apimatic-sdk';

const pinsRemoveSchema: PinsRemoveSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


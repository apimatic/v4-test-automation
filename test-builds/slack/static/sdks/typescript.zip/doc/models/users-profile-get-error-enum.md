
# Users Profile Get Error Enum

## Enumeration

`UsersProfileGetErrorEnum`

## Fields

| Name |
|  --- |
| `UserNotFound` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { UsersProfileGetErrorEnum } from 'slack-apimatic-sdk';

const usersProfileGetErrorEnum = UsersProfileGetErrorEnum.InvalidAuth;
```


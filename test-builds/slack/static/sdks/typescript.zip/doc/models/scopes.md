
# Scopes

*This model accepts additional fields of type unknown.*

## Structure

`Scopes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appHome` | `string[] \| undefined` | Optional | - |
| `channel` | `string[] \| undefined` | Optional | - |
| `group` | `string[] \| undefined` | Optional | - |
| `im` | `string[] \| undefined` | Optional | - |
| `mpim` | `string[] \| undefined` | Optional | - |
| `team` | `string[] \| undefined` | Optional | - |
| `user` | `string[] \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Scopes } from 'slack-apimatic-sdk';

const scopes: Scopes = {
  appHome: [
    'app_home0',
    'app_home1',
    'app_home2'
  ],
  channel: [
    'channel2',
    'channel1'
  ],
  group: [
    'group1'
  ],
  im: [
    'im1',
    'im2',
    'im3'
  ],
  mpim: [
    'mpim2'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Chat Delete Success Schema

Schema for successful response of chat.delete method

*This model accepts additional fields of type unknown.*

## Structure

`ChatDeleteSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `string` | Required | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `ts` | `string` | Required | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ChatDeleteSuccessSchema } from 'slack-apimatic-sdk';

const chatDeleteSuccessSchema: ChatDeleteSuccessSchema = {
  channel: 'channel6',
  ok: 'True',
  ts: 'ts0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


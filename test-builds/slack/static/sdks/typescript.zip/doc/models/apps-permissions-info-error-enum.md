
# Apps Permissions Info Error Enum

## Enumeration

`AppsPermissionsInfoErrorEnum`

## Fields

| Name |
|  --- |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { AppsPermissionsInfoErrorEnum } from 'slack-apimatic-sdk';

const appsPermissionsInfoErrorEnum = AppsPermissionsInfoErrorEnum.UpgradeRequired;
```



# Reminders Delete Schema

Schema for successful response from reminders.delete method

*This model accepts additional fields of type unknown.*

## Structure

`RemindersDeleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { RemindersDeleteSchema } from 'slack-apimatic-sdk';

const remindersDeleteSchema: RemindersDeleteSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


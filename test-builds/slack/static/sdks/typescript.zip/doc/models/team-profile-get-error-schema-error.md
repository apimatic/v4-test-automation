
# Team Profile Get Error Schema Error

Schema for error response from team.profile.get method

*This model accepts additional fields of type unknown.*

## Structure

`TeamProfileGetErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`TeamProfileGetErrorEnum`](../../doc/models/team-profile-get-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof TeamProfileGetErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Chat Delete Error Enum

## Enumeration

`ChatDeleteErrorEnum`

## Fields

| Name |
|  --- |
| `MessageNotFound` |
| `ChannelNotFound` |
| `CantDeleteMessage` |
| `ComplianceExportsPreventDeletion` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { ChatDeleteErrorEnum } from 'slack-apimatic-sdk';

const chatDeleteErrorEnum = ChatDeleteErrorEnum.ChannelNotFound;
```


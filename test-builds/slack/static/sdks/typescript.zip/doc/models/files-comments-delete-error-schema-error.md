
# Files Comments Delete Error Schema Error

Schema for error response files.comments.delete method

*This model accepts additional fields of type unknown.*

## Structure

`FilesCommentsDeleteErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesCommentsDeleteErrorEnum`](../../doc/models/files-comments-delete-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof FilesCommentsDeleteErrorSchemaError) {
    console.log(error.result);
  }
}
```


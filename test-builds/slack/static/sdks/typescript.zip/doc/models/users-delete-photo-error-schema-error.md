
# Users Delete Photo Error Schema Error

Schema for error response from users.deletePhoto method

*This model accepts additional fields of type unknown.*

## Structure

`UsersDeletePhotoErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsInfoErrorEnum`](../../doc/models/apps-permissions-info-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsersDeletePhotoErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Chat Get Permalink Error Schema Error

Schema for error response from chat.getPermalink method

*This model accepts additional fields of type unknown.*

## Structure

`ChatGetPermalinkErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ChatGetPermalinkErrorEnum`](../../doc/models/chat-get-permalink-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ChatGetPermalinkErrorSchemaError) {
    console.log(error.result);
  }
}
```


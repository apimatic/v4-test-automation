
# Rtm Connect Error Enum

## Enumeration

`RtmConnectErrorEnum`

## Fields

| Name |
|  --- |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { RtmConnectErrorEnum } from 'slack-apimatic-sdk';

const rtmConnectErrorEnum = RtmConnectErrorEnum.NoPermission;
```


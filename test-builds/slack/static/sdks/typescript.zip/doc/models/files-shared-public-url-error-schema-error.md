
# Files Shared Public Url Error Schema Error

Schema for error response from files.sharedPublicURL method

*This model accepts additional fields of type unknown.*

## Structure

`FilesSharedPublicUrlErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesSharedPublicUrlErrorEnum`](../../doc/models/files-shared-public-url-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof FilesSharedPublicUrlErrorSchemaError) {
    console.log(error.result);
  }
}
```


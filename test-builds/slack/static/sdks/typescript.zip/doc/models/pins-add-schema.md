
# Pins Add Schema

Schema for successful response from pins.add method

*This model accepts additional fields of type unknown.*

## Structure

`PinsAddSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { PinsAddSchema } from 'slack-apimatic-sdk';

const pinsAddSchema: PinsAddSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


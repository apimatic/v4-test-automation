
# Chat Unfurl Error Enum

## Enumeration

`ChatUnfurlErrorEnum`

## Fields

| Name |
|  --- |
| `CannotUnfurlUrl` |
| `CannotFindService` |
| `MissingUnfurls` |
| `CannotPrompt` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { ChatUnfurlErrorEnum } from 'slack-apimatic-sdk';

const chatUnfurlErrorEnum = ChatUnfurlErrorEnum.UserIsBot;
```


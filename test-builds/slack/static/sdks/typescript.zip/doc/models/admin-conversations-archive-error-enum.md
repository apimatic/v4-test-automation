
# Admin Conversations Archive Error Enum

## Enumeration

`AdminConversationsArchiveErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `ChannelNotFound` |
| `ChannelTypeNotSupported` |
| `DefaultOrgWideChannel` |
| `AlreadyArchived` |
| `CantArchiveGeneral` |
| `RestrictedAction` |
| `CouldNotArchiveChannel` |

## Example

```ts
import { AdminConversationsArchiveErrorEnum } from 'slack-apimatic-sdk';

const adminConversationsArchiveErrorEnum = AdminConversationsArchiveErrorEnum.AlreadyArchived;
```


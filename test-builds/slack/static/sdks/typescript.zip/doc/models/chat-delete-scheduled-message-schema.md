
# Chat Delete Scheduled Message Schema

Schema for successful response from chat.deleteScheduledMessage method

*This model accepts additional fields of type unknown.*

## Structure

`ChatDeleteScheduledMessageSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ChatDeleteScheduledMessageSchema } from 'slack-apimatic-sdk';

const chatDeleteScheduledMessageSchema: ChatDeleteScheduledMessageSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


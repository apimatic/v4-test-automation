
# Reminders List Schema

Schema for successful response from reminders.list method

*This model accepts additional fields of type unknown.*

## Structure

`RemindersListSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `reminders` | [`ObjsReminder[]`](../../doc/models/objs-reminder.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { RemindersListSchema } from 'slack-apimatic-sdk';

const remindersListSchema: RemindersListSchema = {
  ok: 'True',
  reminders: [
    {
      creator: 'creator0',
      id: 'id2',
      recurring: false,
      text: 'text2',
      user: 'user2',
      completeTs: 28,
      time: 186,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


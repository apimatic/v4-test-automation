
# Conversations Open Error Enum

## Enumeration

`ConversationsOpenErrorEnum`

## Fields

| Name |
|  --- |
| `MethodNotSupportedForChannelType` |
| `UserNotFound` |
| `UserNotVisible` |
| `UserDisabled` |
| `UsersListNotSupplied` |
| `NotEnoughUsers` |
| `TooManyUsers` |
| `InvalidUserCombination` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `ChannelNotFound` |

## Example

```ts
import { ConversationsOpenErrorEnum } from 'slack-apimatic-sdk';

const conversationsOpenErrorEnum = ConversationsOpenErrorEnum.RequestTimeout;
```


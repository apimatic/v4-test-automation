
# Apps Permissions Resources List Error Schema Error

Schema for error response from apps.permissions.resources.list method

*This model accepts additional fields of type unknown.*

## Structure

`AppsPermissionsResourcesListErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`AppsPermissionsResourcesListErrorEnum`](../../doc/models/apps-permissions-resources-list-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AppsPermissionsResourcesListErrorSchemaError) {
    console.log(error.result);
  }
}
```


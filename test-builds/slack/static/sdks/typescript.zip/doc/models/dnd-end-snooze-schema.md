
# Dnd End Snooze Schema

Schema for successful response from dnd.endSnooze method

*This model accepts additional fields of type unknown.*

## Structure

`DndEndSnoozeSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dndEnabled` | `boolean` | Required | - |
| `nextDndEndTs` | `number` | Required | - |
| `nextDndStartTs` | `number` | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `snoozeEnabled` | `boolean` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DndEndSnoozeSchema } from 'slack-apimatic-sdk';

const dndEndSnoozeSchema: DndEndSnoozeSchema = {
  dndEnabled: false,
  nextDndEndTs: 152,
  nextDndStartTs: 184,
  ok: 'True',
  snoozeEnabled: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


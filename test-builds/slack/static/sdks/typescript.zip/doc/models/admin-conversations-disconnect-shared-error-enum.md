
# Admin Conversations Disconnect Shared Error Enum

## Enumeration

`AdminConversationsDisconnectSharedErrorEnum`

## Fields

| Name |
|  --- |
| `FeatureNotEnabled` |
| `NotAnAdmin` |
| `NotAnEnterprise` |
| `ChannelNotFound` |
| `NotSupported` |
| `TeamNotFound` |
| `RestrictedAction` |
| `MissingScope` |
| `LeavingTeamNotInChannel` |
| `NoTeamsToDisconnect` |
| `LeavingTeamRequired` |
| `CannotKickTeam` |
| `CannotKickHomeTeam` |

## Example

```ts
import {
  AdminConversationsDisconnectSharedErrorEnum,
} from 'slack-apimatic-sdk';

const adminConversationsDisconnectSharedErrorEnum = AdminConversationsDisconnectSharedErrorEnum.FeatureNotEnabled;
```


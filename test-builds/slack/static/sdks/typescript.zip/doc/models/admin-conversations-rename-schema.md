
# Admin Conversations Rename Schema

Schema for successful response of admin.conversations.disconnectShared

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsRenameSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AdminConversationsRenameSchema } from 'slack-apimatic-sdk';

const adminConversationsRenameSchema: AdminConversationsRenameSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


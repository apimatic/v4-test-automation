
# Conversations Open Success Schema

Schema for successful response from conversations.open method when opening channels, ims, mpims

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsOpenSuccessSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alreadyOpen` | `boolean \| undefined` | Optional | - |
| `channel` | `unknown` | Required | - |
| `noOp` | `boolean \| undefined` | Optional | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConversationsOpenSuccessSchema } from 'slack-apimatic-sdk';

const conversationsOpenSuccessSchema: ConversationsOpenSuccessSchema = {
  channel: { 'key1': 'val1', 'key2': 'val2' },
  ok: 'True',
  alreadyOpen: false,
  noOp: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


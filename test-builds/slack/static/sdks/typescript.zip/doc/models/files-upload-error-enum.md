
# Files Upload Error Enum

## Enumeration

`FilesUploadErrorEnum`

## Fields

| Name |
|  --- |
| `PostingToGeneralChannelDenied` |
| `InvalidChannel` |
| `FileUploadsDisabled` |
| `FileUploadsExceptImagesDisabled` |
| `StorageLimitReached` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |

## Example

```ts
import { FilesUploadErrorEnum } from 'slack-apimatic-sdk';

const filesUploadErrorEnum = FilesUploadErrorEnum.NoPermission;
```


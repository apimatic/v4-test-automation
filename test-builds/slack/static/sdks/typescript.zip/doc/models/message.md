
# Message

*This model accepts additional fields of type unknown.*

## Structure

`Message`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `botId` | `string` | Required | **Constraints**: *Pattern*: `^B[A-Z0-9]{8,}$` |
| `botProfile` | [`BotProfileObject \| undefined`](../../doc/models/bot-profile-object.md) | Optional | - |
| `team` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `text` | `string` | Required | - |
| `type` | `string` | Required | - |
| `user` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `username` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Message } from 'slack-apimatic-sdk';

const message: Message = {
  botId: 'bot_id6',
  team: 'team0',
  text: 'text0',
  type: 'type0',
  user: 'user0',
  botProfile: {
    appId: 'app_id8',
    deleted: false,
    icons: {
      image36: 'image_362',
      image48: 'image_488',
      image72: 'image_722',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    id: 'id8',
    name: 'name8',
    teamId: 'team_id8',
    updated: 44,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  username: 'username0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Auth Revoke Error Enum

## Enumeration

`AuthRevokeErrorEnum`

## Fields

| Name |
|  --- |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { AuthRevokeErrorEnum } from 'slack-apimatic-sdk';

const authRevokeErrorEnum = AuthRevokeErrorEnum.TeamAddedToOrg;
```


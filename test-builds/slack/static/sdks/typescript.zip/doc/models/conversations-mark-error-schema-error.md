
# Conversations Mark Error Schema Error

Schema for error response from conversations.mark method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsMarkErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsMarkErrorEnum`](../../doc/models/conversations-mark-error-enum.md) | Required | - |
| `needed` | `string \| undefined` | Optional | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `provided` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ConversationsMarkErrorSchemaError) {
    console.log(error.result);
  }
}
```


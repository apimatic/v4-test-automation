
# Files Upload Schema

Schema for successful response files.upload method

*This model accepts additional fields of type unknown.*

## Structure

`FilesUploadSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `file` | [`FileObject`](../../doc/models/file-object.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { FilesUploadSchema } from 'slack-apimatic-sdk';

const filesUploadSchema: FilesUploadSchema = {
  file: {
    channels: [
      'channels5',
      'channels4'
    ],
    commentsCount: 56,
    created: 220,
    dateDelete: 118,
    displayAsBot: false,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


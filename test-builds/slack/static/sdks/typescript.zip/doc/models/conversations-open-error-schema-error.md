
# Conversations Open Error Schema Error

Schema for error response from conversations.open method

*This model accepts additional fields of type unknown.*

## Structure

`ConversationsOpenErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`ConversationsOpenErrorEnum`](../../doc/models/conversations-open-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ConversationsOpenErrorSchemaError) {
    console.log(error.result);
  }
}
```


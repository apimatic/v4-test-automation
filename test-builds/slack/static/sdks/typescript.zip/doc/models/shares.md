
# Shares

*This model accepts additional fields of type unknown.*

## Structure

`Shares`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mPrivate` | `unknown \| undefined` | Optional | - |
| `mPublic` | `unknown \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Shares } from 'slack-apimatic-sdk';

const shares: Shares = {
  mPrivate: { 'key1': 'val1', 'key2': 'val2' },
  mPublic: { 'key1': 'val1', 'key2': 'val2' },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


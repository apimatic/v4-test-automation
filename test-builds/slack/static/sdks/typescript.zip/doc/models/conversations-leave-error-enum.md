
# Conversations Leave Error Enum

## Enumeration

`ConversationsLeaveErrorEnum`

## Fields

| Name |
|  --- |
| `MethodNotSupportedForChannelType` |
| `LastMember` |
| `MissingScope` |
| `ChannelNotFound` |
| `IsArchived` |
| `CantLeaveGeneral` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `UserIsBot` |
| `UserIsRestricted` |
| `UserIsUltraRestricted` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `TeamAddedToOrg` |
| `MissingCharset` |
| `SuperfluousCharset` |

## Example

```ts
import { ConversationsLeaveErrorEnum } from 'slack-apimatic-sdk';

const conversationsLeaveErrorEnum = ConversationsLeaveErrorEnum.InvalidArrayArg;
```


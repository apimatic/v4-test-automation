
# Admin Conversations Create Error Schema Error

Schema for error response from admin.conversations.create

*This model accepts additional fields of type unknown.*

## Structure

`AdminConversationsCreateErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`AdminConversationsCreateErrorEnum`](../../doc/models/admin-conversations-create-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof AdminConversationsCreateErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Usergroups Create Error Enum

## Enumeration

`UsergroupsCreateErrorEnum`

## Fields

| Name |
|  --- |
| `PermissionDenied` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `UserIsRestricted` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { UsergroupsCreateErrorEnum } from 'slack-apimatic-sdk';

const usergroupsCreateErrorEnum = UsergroupsCreateErrorEnum.JsonNotObject;
```



# Stars Remove Error Schema Error

Schema for error response from stars.remove method

*This model accepts additional fields of type unknown.*

## Structure

`StarsRemoveErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`StarsRemoveErrorEnum`](../../doc/models/stars-remove-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof StarsRemoveErrorSchemaError) {
    console.log(error.result);
  }
}
```


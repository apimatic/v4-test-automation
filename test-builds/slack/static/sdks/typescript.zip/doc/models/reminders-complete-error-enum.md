
# Reminders Complete Error Enum

## Enumeration

`RemindersCompleteErrorEnum`

## Fields

| Name |
|  --- |
| `NotFound` |
| `CannotCompleteRecurring` |
| `CannotCompleteOthers` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `TokenRevoked` |
| `NoPermission` |
| `OrgLoginRequired` |
| `UserIsBot` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { RemindersCompleteErrorEnum } from 'slack-apimatic-sdk';

const remindersCompleteErrorEnum = RemindersCompleteErrorEnum.InvalidArgName;
```



# Subteam Usergroup Object

*This model accepts additional fields of type unknown.*

## Structure

`SubteamUsergroupObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `autoProvision` | `boolean` | Required | - |
| `autoType` | `unknown` | Required | - |
| `channelCount` | `number \| undefined` | Optional | - |
| `createdBy` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `dateCreate` | `number` | Required | - |
| `dateDelete` | `number` | Required | - |
| `dateUpdate` | `number` | Required | - |
| `deletedBy` | `unknown` | Required | - |
| `description` | `string` | Required | - |
| `enterpriseSubteamId` | `string` | Required | - |
| `handle` | `string` | Required | - |
| `id` | `string` | Required | **Constraints**: *Pattern*: `^S[A-Z0-9]{2,}$` |
| `isExternal` | `boolean` | Required | - |
| `isSubteam` | `boolean` | Required | - |
| `isUsergroup` | `boolean` | Required | - |
| `name` | `string` | Required | - |
| `prefs` | [`Prefs`](../../doc/models/prefs.md) | Required | - |
| `teamId` | `string` | Required | **Constraints**: *Pattern*: `^[T][A-Z0-9]{2,}$` |
| `updatedBy` | `string` | Required | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `userCount` | `number \| undefined` | Optional | - |
| `users` | `string[] \| undefined` | Optional | **Constraints**: *Pattern*: `^[UW][A-Z0-9]{2,}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { SubteamUsergroupObject } from 'slack-apimatic-sdk';

const subteamUsergroupObject: SubteamUsergroupObject = {
  autoProvision: false,
  autoType: { 'key1': 'val1', 'key2': 'val2' },
  createdBy: 'created_by8',
  dateCreate: 254,
  dateDelete: 46,
  dateUpdate: 32,
  deletedBy: { 'key1': 'val1', 'key2': 'val2' },
  description: 'description0',
  enterpriseSubteamId: 'enterprise_subteam_id8',
  handle: 'handle6',
  id: 'id0',
  isExternal: false,
  isSubteam: false,
  isUsergroup: false,
  name: 'name0',
  prefs: {
    channels: [
      'channels5',
      'channels4'
    ],
    groups: [
      'groups4',
      'groups5',
      'groups6'
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  teamId: 'team_id4',
  updatedBy: 'updated_by4',
  channelCount: 154,
  userCount: 160,
  users: [
    'users1',
    'users2',
    'users3'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


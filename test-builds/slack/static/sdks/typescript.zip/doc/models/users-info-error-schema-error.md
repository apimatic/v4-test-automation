
# Users Info Error Schema Error

Schema for error response from users.info method

*This model accepts additional fields of type unknown.*

## Structure

`UsersInfoErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | - |
| `error` | [`UsersInfoErrorEnum`](../../doc/models/users-info-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof UsersInfoErrorSchemaError) {
    console.log(error.result);
  }
}
```


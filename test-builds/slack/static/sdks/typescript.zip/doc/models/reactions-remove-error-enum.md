
# Reactions Remove Error Enum

## Enumeration

`ReactionsRemoveErrorEnum`

## Fields

| Name |
|  --- |
| `BadTimestamp` |
| `FileNotFound` |
| `FileCommentNotFound` |
| `MessageNotFound` |
| `NoItemSpecified` |
| `InvalidName` |
| `NoReaction` |
| `NotAuthed` |
| `InvalidAuth` |
| `AccountInactive` |
| `NoPermission` |
| `InvalidArgName` |
| `InvalidArrayArg` |
| `InvalidCharset` |
| `InvalidFormData` |
| `InvalidPostType` |
| `MissingPostType` |
| `TeamAddedToOrg` |
| `InvalidJson` |
| `JsonNotObject` |
| `RequestTimeout` |
| `UpgradeRequired` |
| `FatalError` |

## Example

```ts
import { ReactionsRemoveErrorEnum } from 'slack-apimatic-sdk';

const reactionsRemoveErrorEnum = ReactionsRemoveErrorEnum.FileNotFound;
```


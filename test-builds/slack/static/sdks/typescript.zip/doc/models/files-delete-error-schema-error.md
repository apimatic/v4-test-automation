
# Files Delete Error Schema Error

Schema for error response files.delete method

*This model accepts additional fields of type unknown.*

## Structure

`FilesDeleteErrorSchemaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callstack` | `string \| undefined` | Optional | Note: PHP callstack is only visible in dev/qa |
| `error` | [`FilesDeleteErrorEnum`](../../doc/models/files-delete-error-enum.md) | Required | - |
| `ok` | `string` | Required, Constant | **Value**: `'False'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof FilesDeleteErrorSchemaError) {
    console.log(error.result);
  }
}
```



# Files Delete Schema

Schema for successful response files.delete method

*This model accepts additional fields of type unknown.*

## Structure

`FilesDeleteSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { FilesDeleteSchema } from 'slack-apimatic-sdk';

const filesDeleteSchema: FilesDeleteSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# External Org Migrations

*This model accepts additional fields of type unknown.*

## Structure

`ExternalOrgMigrations`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `current` | [`Current[]`](../../doc/models/current.md) | Required | - |
| `dateUpdated` | `number` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ExternalOrgMigrations } from 'slack-apimatic-sdk';

const externalOrgMigrations: ExternalOrgMigrations = {
  current: [
    {
      dateStarted: 84,
      teamId: 'team_id0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  dateUpdated: 16,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```



# Apps Uninstall Schema

Schema for successful response from apps.uninstall method

*This model accepts additional fields of type unknown.*

## Structure

`AppsUninstallSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AppsUninstallSchema } from 'slack-apimatic-sdk';

const appsUninstallSchema: AppsUninstallSchema = {
  ok: 'True',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


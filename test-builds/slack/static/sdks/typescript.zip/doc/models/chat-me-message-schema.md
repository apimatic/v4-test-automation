
# Chat Me Message Schema

Schema for successful response from chat.meMessage method

*This model accepts additional fields of type unknown.*

## Structure

`ChatMeMessageSchema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `^[CGD][A-Z0-9]{8,}$` |
| `ok` | `string` | Required, Constant | **Value**: `'True'` |
| `ts` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `^\d{10}\.\d{6}$` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ChatMeMessageSchema } from 'slack-apimatic-sdk';

const chatMeMessageSchema: ChatMeMessageSchema = {
  ok: 'True',
  channel: 'channel6',
  ts: 'ts0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```


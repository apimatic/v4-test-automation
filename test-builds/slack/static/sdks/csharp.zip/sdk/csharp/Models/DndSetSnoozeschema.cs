using System.Text.Json.Serialization;
using SlackWebApi.Core.Models;

namespace SlackWebApi.Models;

/// <summary>
/// Schema for successful response from dnd.setSnooze method
/// </summary>
public record DndSetSnoozeschema
{
    [JsonPropertyName("ok")]
    public string Ok { get; } = "True";

    [JsonPropertyName("snooze_enabled")]
    public required bool SnoozeEnabled { get; init; }

    [JsonPropertyName("snooze_endtime")]
    public required int SnoozeEndtime { get; init; }

    [JsonPropertyName("snooze_remaining")]
    public required int SnoozeRemaining { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}

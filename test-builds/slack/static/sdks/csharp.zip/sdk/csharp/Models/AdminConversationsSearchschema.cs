using System.Collections.Generic;
using System.Text.Json.Serialization;
using SlackWebApi.Core.Models;

namespace SlackWebApi.Models;

/// <summary>
/// Schema for successful response of admin.conversations.search
/// </summary>
public record AdminConversationsSearchschema
{
    [JsonPropertyName("channels")]
    public required IReadOnlyList<ChannelObject> Channels { get; init; }

    [JsonPropertyName("next_cursor")]
    public required string NextCursor { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
